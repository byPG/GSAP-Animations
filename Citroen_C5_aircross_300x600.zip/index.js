(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.heroFR = function() {
	this.initialize(img.heroFR);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1200,800);


(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1200,800);


(lib.img2 = function() {
	this.initialize(img.img2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1200,800);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bXcMAAAgu3MAu3AAAMAAAAu3g");
	this.shape.setTransform(150,150);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,300,300), null);


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D356B").s().p("AgVArIAAhTIAMAAIADAIIAHgGIAJgDQAGgBAGAAIgCAQIgKABQgFABgEACQgDADgDAEIAAA6g");
	this.shape.setTransform(71.25,31.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D356B").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_1.setTransform(63.125,31.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_2.setTransform(53.925,31.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1D356B").s().p("AgOA8QgHgCgGgFQgFgFgEgGIAOgHIAFAHQADADAFACQAFABAFAAQALAAAGgGQAGgFAAgMIAAgIQgEADgGADQgGACgIAAQgLAAgJgFQgJgGgFgKQgFgJAAgNQAAgMAFgKQAGgKAKgGQAJgFALgBQAHAAAGADQAHACADAEIADgGIAMAAIAABWQAAAKgEAIQgEAIgJAFQgJAFgMgBQgIAAgIgCgAgKgrQgGAEgEAGQgDAHAAAIQAAAIADAHQADAGAGAEQAGAEAHAAQAHgBAFgCQAGgCAEgEIAAgnQgDgEgGgDQgGgDgHAAQgGAAgGAEg");
	this.shape_3.setTransform(44.175,33.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1D356B").s().p("AgVArIAAhTIANAAIACAIIAHgGIAKgDQAEgBAHAAIgBAQIgLABQgFABgEACQgDADgDAEIAAA6g");
	this.shape_4.setTransform(37.45,31.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D356B").s().p("AgbAmQgHgGAAgLQAAgGADgFQACgFAGgDQAGgCALgDIAZgFIAAgFQAAgJgFgDQgEgDgKAAQgIAAgEACQgEACgCAFIgOgFQADgKAJgEQAKgFALAAQALAAAHADQAIAEAEAGQAEAGAAAJIAAA5IgNAAIgCgIQgIAGgGACQgGACgIAAQgLAAgIgGgAgDAJQgJACgDACQgDADAAAFQAAAFADACQAEADAGAAQAGAAAGgDQAGgDAGgEIAAgSg");
	this.shape_5.setTransform(29.575,31.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D356B").s().p("AgHA7IAAh1IAPAAIAAB1g");
	this.shape_6.setTransform(23.7,29.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_7.setTransform(13.075,31.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D356B").s().p("AAvArIAAgyQAAgMgEgEQgDgFgLABQgHAAgFACQgGADgEAEIABAKIAAAzIgPAAIAAgyQAAgMgEgEQgEgFgKABQgHAAgFADQgFACgEAGIAAA7IgQAAIAAhTIAMAAIADAIQAFgFAGgCQAGgDAIAAQAKAAAHADQAFADADAEQAFgEAHgDQAIgDAKAAQAJAAAHADQAHADAEAHQADAIAAANIAAAzg");
	this.shape_8.setTransform(1.125,31.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D356B").s().p("AgSA5QgKgGgGgKQgGgKAAgNQAAgMAGgJQAGgKAJgGQAKgFALgBQASAAAKAMQALAKAAATIAAAGIhBAAQABAGADAGQADAGAHAEQAGAEAHAAQAKAAAGgEQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgFgAAYAJQgBgJgEgDQgGgHgLAAQgHAAgGAEQgGAEgDAFIgCAGIAuAAIAAAAgAAQgiIgQgUIgPAUIgRAAIAVgbIAXAAIAVAbg");
	this.shape_9.setTransform(-10.975,29.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D356B").s().p("AAvArIAAgyQAAgMgEgEQgDgFgLABQgHAAgFACQgGADgEAEIABAKIAAAzIgPAAIAAgyQAAgMgEgEQgEgFgKABQgHAAgFADQgFACgEAGIAAA7IgQAAIAAhTIAMAAIADAIQAFgFAGgCQAGgDAIAAQAKAAAHADQAFADADAEQAFgEAHgDQAIgDAKAAQAJAAAHADQAHADAEAHQADAIAAANIAAAzg");
	this.shape_10.setTransform(-22.925,31.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_11.setTransform(-39.075,31.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D356B").s().p("AgUA3QgJgGgFgKQgFgKAAgMQAAgNAFgJQAGgKAKgFQAKgGALAAQAHAAAGABIAIAEIAAgmIAQAAIAAB2IgMAAIgDgIQgEAEgGADQgHACgIAAQgLAAgJgFgAgKgIQgGAEgEAGQgDAGAAAJQAAAIADAHQADAGAGAEQAGAEAHAAQAHAAAFgCQAGgDAEgEIAAgpQgDgEgFgCQgGgCgGAAQgIAAgGAEg");
	this.shape_12.setTransform(-48.825,29.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D356B").s().p("AgIAwQgHgHAAgMIAAgsIgPAAIAAgOIAPAAIAAgZIAQAAIAAAZIAcAAIAAAOIgcAAIAAAlQAAAKACAFQADAEAGAAIAHgBIAIgCIAEANQgFACgFABIgLABQgMAAgGgHg");
	this.shape_13.setTransform(-60.825,30.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_14.setTransform(-68.625,31.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D356B").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_15.setTransform(105.175,13.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1D356B").s().p("AgIAwQgHgHAAgMIAAgsIgPAAIAAgOIAPAAIAAgZIAQAAIAAAZIAcAAIAAAOIgcAAIAAAlQAAAKACAFQADAEAGAAIAHgBIAIgCIAEANQgFACgFABIgLABQgMAAgGgHg");
	this.shape_16.setTransform(98.175,12.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1D356B").s().p("AAUArIAAgyQAAgMgDgEQgFgEgKgBQgHAAgFAEQgFACgFAFIAAA8IgQAAIAAhTIAMAAIADAIQAFgEAHgDQAGgDAIAAQAKAAAGADQAIADAEAHQAEAIAAAMIAAA0g");
	this.shape_17.setTransform(90.3,13.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1D356B").s().p("AgbAmQgHgGAAgLQAAgGADgFQACgFAGgDQAGgCALgDIAZgFIAAgFQAAgJgFgDQgEgDgKAAQgIAAgEACQgEACgCAFIgOgFQADgKAJgEQAKgFALAAQALAAAHADQAIAEAEAGQAEAGAAAJIAAA5IgNAAIgCgIQgIAGgGACQgGACgIAAQgLAAgIgGgAgDAJQgJACgDACQgDADAAAFQAAAFADACQAEADAGAAQAGAAAGgDQAGgDAGgEIAAgSg");
	this.shape_18.setTransform(80.925,13.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1D356B").s().p("AgUA3QgJgGgFgKQgFgKAAgMQAAgNAFgJQAGgKAKgFQAKgGALAAQAHAAAGABIAIAEIAAgmIAQAAIAAB2IgMAAIgDgIQgEAEgGADQgHACgIAAQgLAAgJgFgAgKgIQgGAEgEAGQgDAGAAAJQAAAIADAHQADAGAGAEQAGAEAHAAQAHAAAFgCQAGgDAEgEIAAgpQgDgEgFgCQgGgCgGAAQgIAAgGAEg");
	this.shape_19.setTransform(71.825,12.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1D356B").s().p("AAUArIAAgyQAAgMgDgEQgEgEgMgBQgGAAgFAEQgFACgFAFIAAA8IgQAAIAAhTIAMAAIADAIQAGgEAGgDQAGgDAIAAQAKAAAGADQAIADAEAHQAEAIAAAMIAAA0g");
	this.shape_20.setTransform(62.6,13.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_21.setTransform(53.125,13.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1D356B").s().p("AgnA+IAAh5IAMAAIADAIQAEgEAHgDQAGgDAHAAQAMAAAJAGQAJAGAFAKQAFAKAAAMQAAANgGAJQgFAKgKAFQgJAGgLAAQgHAAgGgDQgFgBgEgEIAAAsgAgNgsQgGADgEAEIAAAmQADAFAGADQAGACAHAAQAGAAAGgDQAGgEAEgGQADgGAAgJQAAgIgDgHQgEgGgFgEQgGgEgHAAQgHAAgFACg");
	this.shape_22.setTransform(44.025,15.725);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1D356B").s().p("AgSA4QgKgFgGgKQgGgKAAgMQAAgNAGgJQAGgKAJgFQAKgHALAAQASABAKAKQALALAAATIAAAGIhBAAQABAGADAGQADAGAHAEQAGAEAHgBQAKABAGgEQAGgEADgFIAMAIQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYAJQgBgJgEgEQgGgGgLAAQgHAAgGAEQgGAEgDAFIgCAGIAuAAIAAAAgAgHgiIATgbIATAAIgXAbg");
	this.shape_23.setTransform(34.225,12.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1D356B").s().p("AgUA3QgJgGgFgKQgFgKAAgMQAAgNAFgJQAGgKAKgFQAKgGALAAQAHAAAGABIAIAEIAAgmIAQAAIAAB2IgMAAIgDgIQgEAEgGADQgHACgIAAQgLAAgJgFgAgKgIQgGAEgEAGQgDAGAAAJQAAAIADAHQADAGAGAEQAGAEAHAAQAHAAAFgCQAGgDAEgEIAAgpQgDgEgFgCQgGgCgGAAQgIAAgGAEg");
	this.shape_24.setTransform(24.475,12.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1D356B").s().p("AAUArIAAgyQAAgMgDgEQgFgEgLgBQgGAAgFAEQgGACgEAFIAAA8IgQAAIAAhTIAMAAIADAIQAFgEAHgDQAGgDAIAAQAKAAAGADQAIADAEAHQAEAIAAAMIAAA0g");
	this.shape_25.setTransform(15.25,13.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1D356B").s().p("AgHA8IAAhTIAPAAIAABTgAgGgpQgEgDAAgEQAAgFAEgDQADgDADAAQAFAAADADQADADAAAFQAAAEgDADQgDADgFAAQgDAAgDgDg");
	this.shape_26.setTransform(8.425,12.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_27.setTransform(-2.175,13.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1D356B").s().p("AgVArIAAhTIAMAAIADAIIAHgGIAJgCQAGgCAGAAIgCAQIgKABQgFABgEADQgDABgDAFIAAA6g");
	this.shape_28.setTransform(-8.95,13.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1D356B").s().p("AgSA4QgKgFgGgKQgGgKAAgMQAAgNAGgJQAGgKAJgFQAKgHALAAQASABAKAKQALALAAATIAAAGIhBAAQABAGADAGQADAGAHAEQAGAEAHgBQAKABAGgEQAGgEADgFIAMAIQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYAJQgBgJgEgEQgGgGgLAAQgHAAgGAEQgGAEgDAFIgCAGIAuAAIAAAAgAgHgiIgXgbIATAAIATAbg");
	this.shape_29.setTransform(-16.925,12.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1D356B").s().p("AgHA8IAAhTIAPAAIAABTgAgGgpQgEgDAAgEQAAgFAEgDQADgDADAAQAFAAADADQADADAAAFQAAAEgDADQgDADgFAAQgDAAgDgDg");
	this.shape_30.setTransform(-23.475,12.15);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1D356B").s().p("AgVArIAAhTIANAAIACAIIAHgGIAJgCQAFgCAHAAIgCAQIgKABQgFABgEADQgDABgDAFIAAA6g");
	this.shape_31.setTransform(-27.6,13.85);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1D356B").s().p("AgVArIAAhTIAMAAIADAIIAHgGIAJgCQAGgCAGAAIgCAQIgKABQgFABgEADQgDABgDAFIAAA6g");
	this.shape_32.setTransform(-33.15,13.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1D356B").s().p("AgbAmQgHgGAAgLQAAgGADgFQACgFAGgDQAGgCALgDIAZgFIAAgFQAAgJgFgDQgEgDgKAAQgIAAgEACQgEACgCAFIgOgFQADgKAJgEQAKgFALAAQALAAAHADQAIAEAEAGQAEAGAAAJIAAA5IgNAAIgCgIQgIAGgGACQgGACgIAAQgLAAgIgGgAgDAJQgJACgDACQgDADAAAFQAAAFADACQAEADAGAAQAGAAAGgDQAGgDAGgEIAAgSg");
	this.shape_33.setTransform(-41.025,13.925);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1D356B").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_34.setTransform(-52.675,13.925);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_35.setTransform(-60.875,13.925);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#1D356B").s().p("AgOA9QgHgDgGgFQgFgEgEgHIAOgHIAFAHQADADAFABQAFACAFAAQALAAAGgFQAGgHAAgKIAAgJQgEAEgGACQgGACgIAAQgLAAgJgGQgJgFgFgLQgFgIAAgNQAAgMAFgKQAGgKAKgFQAJgHALAAQAHABAGACQAHACADAEIADgHIAMAAIAABXQAAAKgEAIQgEAIgJAFQgJAEgMABQgIAAgIgCgAgKgrQgGADgEAHQgDAHAAAIQAAAJADAGQADAGAGAEQAGAEAHgBQAHAAAFgCQAGgCAEgFIAAglQgDgFgGgDQgGgDgHAAQgGAAgGAEg");
	this.shape_36.setTransform(-70.625,15.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#1D356B").s().p("AgSA4QgKgFgGgKQgGgKAAgMQAAgNAGgJQAGgKAJgFQAKgHALAAQASABAKAKQALALAAATIAAAGIhBAAQABAGADAGQADAGAHAEQAGAEAHgBQAKABAGgEQAGgEADgFIAMAIQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYAJQgBgJgEgEQgGgGgLAAQgHAAgGAEQgGAEgDAFIgCAGIAuAAIAAAAgAgHgiIgXgbIATAAIATAbg");
	this.shape_37.setTransform(-79.775,12.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#1D356B").s().p("AgHA8IAAhTIAPAAIAABTgAgGgpQgEgDAAgEQAAgFAEgDQADgDADAAQAFAAADADQADADAAAFQAAAEgDADQgDADgFAAQgDAAgDgDg");
	this.shape_38.setTransform(-86.325,12.15);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#1D356B").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_39.setTransform(-91.925,13.925);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#1D356B").s().p("AgTA2QgIgDgFgGQgFgHgCgIIAQgDQABAIAGAEQAGAEAKAAQAMAAAGgGQAGgFAAgKQAAgKgGgFQgGgGgMAAIgNAAIAAgJIAagiIgtAAIAAgPIBCAAIAAAMIgbAhQANACAHAFQAHAFADAIQADAHAAAHQAAALgFAIQgFAIgJAEQgJAFgMAAQgLAAgIgEg");
	this.shape_40.setTransform(-104.2714,12.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(-140,0,280.1,41.8), null);


(lib.txt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1B3766").s().p("AAAAGIgNAZIgLgIIAUgUIgcgFIAEgMIAaALIgEgcIANAAIgEAdIAagMIAEAMIgcAFIATAUIgKAIg");
	this.shape.setTransform(175.525,27.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1B3766").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_1.setTransform(167.375,31.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1B3766").s().p("AgVArIAAhTIANAAIACAIIAHgGIAJgDQAFgBAHAAIgCAQIgKABQgFABgEACQgDADgDAEIAAA6g");
	this.shape_2.setTransform(160.6,31.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1B3766").s().p("AgOA6QgGgDgEgEIgDAIIgMAAIAAh2IAQAAIAAApQAEgEAGgCQAGgCAHAAQAMAAAJAGQAJAFAFAKQAFAJAAANQAAAMgGAKQgFAKgKAGQgJAFgLAAQgHAAgGgCgAgNgJQgGACgEAFIAAAmQADAFAGACQAGADAHAAQAGAAAGgEQAGgEAEgGQADgHAAgIQAAgJgDgGQgEgGgFgEQgGgEgHAAQgHAAgFADg");
	this.shape_3.setTransform(152.725,29.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1B3766").s().p("AAvArIAAgyQAAgMgEgEQgDgFgLABQgHAAgFACQgGADgEAEIABAKIAAAzIgPAAIAAgyQAAgMgEgEQgEgFgKABQgHAAgFADQgFACgEAGIAAA7IgQAAIAAhTIAMAAIADAIQAFgFAGgCQAGgDAIAAQAKAAAHADQAFADADAEQAFgEAHgDQAIgDAKAAQAJAAAHADQAHADAEAHQADAIAAANIAAAzg");
	this.shape_4.setTransform(140.175,31.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1B3766").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_5.setTransform(128.075,31.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1B3766").s().p("AgIAwQgHgHAAgMIAAgsIgPAAIAAgOIAPAAIAAgZIAQAAIAAAZIAcAAIAAAOIgcAAIAAAlQAAAKACAFQADAEAGAAIAHgBIAIgCIAEANQgFACgFABIgLABQgMAAgGgHg");
	this.shape_6.setTransform(120.075,30.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1B3766").s().p("AgnA+IAAh5IAMAAIADAIQAEgEAHgDQAGgDAHAAQAMAAAJAGQAJAGAFAKQAFAKAAAMQAAANgGAJQgFAKgKAFQgJAGgLAAQgHAAgGgDQgFgBgEgEIAAAsgAgNgsQgGADgEAEIAAAmQADAFAGADQAGACAHAAQAGAAAGgDQAGgEAEgGQADgGAAgJQAAgIgDgHQgEgGgFgEQgGgEgHAAQgHAAgFACg");
	this.shape_7.setTransform(112.375,33.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1B3766").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_8.setTransform(102.575,31.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1B3766").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_9.setTransform(94.325,31.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1B3766").s().p("AgUA2QgJgDgFgIQgFgHAAgLQAAgJAFgIQAFgIAIgCQgFgEgEgGQgDgIAAgHQAAgJAEgHQAFgHAHgEQAIgDAJAAQAKAAAIADQAHAEAFAHQAEAHAAAJQAAAHgDAIQgEAGgFAEQAIACAFAIQAFAIAAAJQAAALgFAHQgFAIgJADQgJAFgMAAQgLAAgJgFgAgMAGQgFADgDAFQgDAEAAAGQAAALAHAFQAHAGAJgBQALABAGgGQAHgFAAgLQAAgGgDgEQgDgFgFgDQgGgDgHAAQgGAAgGADgAgMgnQgFAFAAAHQAAAJAFAEQAFAFAHAAQAIAAAFgFQAFgEAAgJQAAgHgFgFQgFgFgIAAQgHAAgFAFg");
	this.shape_10.setTransform(81.875,29.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1B3766").s().p("AAFA5IAAhfIgZALIAAgRIAcgMIANAAIAABxg");
	this.shape_11.setTransform(73.425,29.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1B3766").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_12.setTransform(62.175,31.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1B3766").s().p("AgbAmQgHgGAAgLQAAgGADgFQACgFAGgDQAGgCALgDIAZgFIAAgFQAAgJgFgDQgEgDgKAAQgIAAgEACQgEACgCAFIgOgFQADgKAJgEQAKgFALAAQALAAAHADQAIAEAEAGQAEAGAAAJIAAA5IgNAAIgCgIQgIAGgGACQgGACgIAAQgLAAgIgGgAgDAJQgJACgDACQgDADAAAFQAAAFADACQAEADAGAAQAGAAAGgDQAGgDAGgEIAAgSg");
	this.shape_13.setTransform(53.075,31.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1B3766").s().p("AgTA2QgIgDgFgHQgFgGgCgIIAQgDQABAHAGAFQAGAEAKAAQAHAAAGgDQAFgCADgGQADgFAAgHQAAgHgDgFQgCgFgGgDQgFgCgIAAQgHAAgGACQgGACgEAHIgNgEIALg+IA5AAIAAAPIguAAIgFAfQAEgDAFgBQAGgCAFAAQALAAAHADQAIADAEAGQAFAFACAGQACAHAAAHQAAAMgGAIQgFAJgJAEQgJAFgLAAQgLAAgIgEg");
	this.shape_14.setTransform(189.325,12.525);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1B3766").s().p("AAFA5IAAhgIgZAMIAAgQIAcgNIANAAIAABxg");
	this.shape_15.setTransform(181.025,12.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1B3766").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_16.setTransform(169.775,14.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1B3766").s().p("AgUA3QgJgGgFgKQgFgKAAgMQAAgNAFgJQAGgKAKgFQAKgGALAAQAHAAAGABIAIAEIAAgmIAQAAIAAB2IgMAAIgDgIQgEAEgGADQgHACgIAAQgLAAgJgFgAgKgIQgGAEgEAGQgDAGAAAJQAAAIADAHQADAGAGAEQAGAEAHAAQAHAAAFgCQAGgDAEgEIAAgpQgDgEgFgCQgGgCgGAAQgIAAgGAEg");
	this.shape_17.setTransform(160.025,12.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1B3766").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_18.setTransform(147.775,13.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1B3766").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_19.setTransform(139.575,13.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1B3766").s().p("AgIAwQgHgHAAgMIAAgsIgPAAIAAgOIAPAAIAAgZIAQAAIAAAZIAcAAIAAAOIgcAAIAAAlQAAAKACAFQADAEAGAAIAHgBIAIgCIAEANQgFACgFABIgLABQgMAAgGgHg");
	this.shape_20.setTransform(131.575,12.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1B3766").s().p("AgVArIAAhTIANAAIACAIIAHgGIAKgCQAEgCAHAAIgCAQIgKABQgFABgEADQgDABgDAFIAAA6g");
	this.shape_21.setTransform(126.2,13.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1B3766").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_22.setTransform(118.225,13.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1B3766").s().p("AgHAqIghhTIASAAIAWA/IAZg/IAQAAIghBTg");
	this.shape_23.setTransform(109.5,13.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1B3766").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_24.setTransform(100.575,14.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1B3766").s().p("AgVAmQgKgFgGgKQgFgKAAgNQAAgLAFgKQAGgKAKgGQAKgGALAAQAMAAAKAGQAKAGAGAKQAFAKAAALQAAANgFAKQgGAKgKAFQgKAGgMAAQgLAAgKgGgAgNgYQgGAEgEAGQgDAHAAAHQAAAIADAHQAEAHAGAEQAGADAHAAQAIAAAGgDQAGgEAEgHQADgGAAgJQAAgHgDgHQgEgGgGgEQgGgEgIAAQgHAAgGAEg");
	this.shape_25.setTransform(91.125,13.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1B3766").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_26.setTransform(78.575,13.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1B3766").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_27.setTransform(70.375,13.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1B3766").s().p("AgIAwQgHgHAAgMIAAgsIgPAAIAAgOIAPAAIAAgZIAQAAIAAAZIAcAAIAAAOIgcAAIAAAlQAAAKACAFQADAEAGAAIAHgBIAIgCIAEANQgFACgFABIgLABQgMAAgGgHg");
	this.shape_28.setTransform(62.375,12.775);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1B3766").s().p("AgVArIAAhTIANAAIACAIIAHgGIAKgCQAEgCAHAAIgCAQIgKABQgFABgEADQgDABgDAFIAAA6g");
	this.shape_29.setTransform(57,13.85);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1B3766").s().p("AgVAmQgKgFgGgKQgFgKAAgNQAAgLAFgKQAGgKAKgGQAKgGALAAQAMAAAKAGQAKAGAGAKQAFAKAAALQAAANgFAKQgGAKgKAFQgKAGgMAAQgLAAgKgGgAgNgYQgGAEgEAGQgDAHAAAHQAAAIADAHQAEAHAGAEQAGADAHAAQAIAAAGgDQAGgEAEgHQADgGAAgJQAAgHgDgHQgEgGgGgEQgGgEgIAAQgHAAgGAEg");
	this.shape_30.setTransform(48.775,13.925);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1B3766").s().p("AglA5IAAhxIAnAAQASAAAJAKQAJAJAAAQQAAAPgJAJQgJAJgSAAIgXAAIAAAtgAgVAAIAWAAQAGAAAEgDQAFgDADgEQACgFAAgGQAAgHgCgFQgDgEgFgDQgEgCgGAAIgWAAg");
	this.shape_31.setTransform(39.55,12.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(0,0,228,41.8), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D356B").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape.setTransform(134.475,13.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D356B").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_1.setTransform(126.125,14.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1D356B").s().p("AgVAmQgKgFgGgKQgFgKAAgNQAAgLAFgKQAGgKAKgGQAKgGALAAQAMAAAKAGQAKAGAGAKQAFAKAAALQAAANgFAKQgGAKgKAFQgKAGgMAAQgLAAgKgGgAgNgYQgGAEgEAGQgDAHAAAHQAAAIADAHQAEAHAGAEQAGADAHAAQAIAAAGgDQAGgEAEgHQADgGAAgJQAAgHgDgHQgEgGgGgEQgGgEgIAAQgHAAgGAEg");
	this.shape_2.setTransform(116.675,13.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1D356B").s().p("AgHAqIghhTIASAAIAWA/IAZg/IAQAAIghBTg");
	this.shape_3.setTransform(107.7,13.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_4.setTransform(94.875,13.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D356B").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_5.setTransform(85.525,14.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D356B").s().p("AAYA+IAAgrQgEADgGACQgGACgHAAQgLAAgJgGQgKgFgFgKQgFgJAAgNQAAgMAFgKQAGgKAKgGQAKgGALAAQAIAAAFACQAGADAEAEIACgHIAMAAIAAB5gAgKgqQgGAEgEAGQgDAHAAAIQAAAJADAGQADAGAGAEQAGADAHAAQAHAAAGgBQAFgCAEgFIAAgpQgDgEgFgCQgGgCgGAAQgIAAgGAEg");
	this.shape_6.setTransform(75.775,15.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D356B").s().p("AAVAqIgVgfIgVAfIgSAAIAegrIgcgoIAUAAIASAcIATgcIASAAIgcAoIAeArg");
	this.shape_7.setTransform(63.1,13.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D356B").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_8.setTransform(54.275,14.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D356B").s().p("AgSAmQgKgFgGgKQgGgKAAgNQAAgLAGgKQAGgKAJgGQAKgGALAAQASAAAKALQALALAAAUIAAAFIhBAAQABAGADAFQADAHAHAEQAGADAHAAQAKAAAGgDQAGgEADgGIAMAJQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYgIQgBgJgEgFQgGgGgLAAQgHAAgGAEQgGAEgDAGIgCAGIAuAAIAAAAg");
	this.shape_9.setTransform(45.075,13.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D356B").s().p("AgVArIAAhTIANAAIACAIIAHgGIAJgCQAGgCAGAAIgCAQIgKABQgFABgEADQgDABgDAFIAAA6g");
	this.shape_10.setTransform(38.3,13.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D356B").s().p("AgSA4QgKgFgGgKQgGgKAAgMQAAgNAGgJQAGgKAJgFQAKgHALAAQASABAKAKQALALAAATIAAAGIhBAAQABAGADAGQADAGAHAEQAGAEAHgBQAKABAGgEQAGgEADgFIAMAIQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYAJQgBgJgEgEQgGgGgLAAQgHAAgGAEQgGAEgDAFIgCAGIAuAAIAAAAgAgHgiIATgbIATAAIgXAbg");
	this.shape_11.setTransform(30.325,12.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D356B").s().p("AAVArIAAgyQAAgMgFgEQgEgEgKgBQgHAAgFAEQgGACgEAFIAAA8IgQAAIAAhTIANAAIACAIQAGgEAFgDQAHgDAIAAQAJAAAIADQAHADAEAHQAEAIAAAMIAAA0g");
	this.shape_12.setTransform(21.05,13.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D356B").s().p("AgSA4QgKgFgGgKQgGgKAAgMQAAgNAGgJQAGgKAJgFQAKgHALAAQASABAKAKQALALAAATIAAAGIhBAAQABAGADAGQADAGAHAEQAGAEAHgBQAKABAGgEQAGgEADgFIAMAIQgFAIgKAGQgJAFgNAAQgLAAgKgGgAAYAJQgBgJgEgEQgGgGgLAAQgHAAgGAEQgGAEgDAFIgCAGIAuAAIAAAAgAgHgiIATgbIATAAIgXAbg");
	this.shape_13.setTransform(11.575,12.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D356B").s().p("AgOA9QgHgDgGgFQgFgEgEgHIAOgHIAFAHQADADAFABQAFACAFAAQALAAAGgFQAGgHAAgKIAAgJQgEAEgGACQgGACgIAAQgLAAgJgGQgJgFgFgLQgFgIAAgNQAAgMAFgKQAGgKAKgFQAJgHALAAQAHABAGACQAHACADAEIADgHIAMAAIAABXQAAAKgEAIQgEAIgJAFQgJAEgMABQgIAAgIgCgAgKgrQgGADgEAHQgDAHAAAIQAAAJADAGQADAGAGAEQAGAEAHgBQAHAAAFgCQAGgCAEgFIAAglQgDgFgGgDQgGgDgHAAQgGAAgGAEg");
	this.shape_14.setTransform(1.825,15.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D356B").s().p("AgHA8IAAhTIAPAAIAABTgAgGgpQgEgDAAgEQAAgFAEgDQADgDADAAQAFAAADADQADADAAAFQAAAEgDADQgDADgFAAQgDAAgDgDg");
	this.shape_15.setTransform(-8.725,12.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1D356B").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_16.setTransform(-14.325,13.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1D356B").s().p("AgRApQgJgDgGgFIAIgMQAFAFAHACQAHACAHAAQAHAAAEgDQAEgCAAgFQAAgEgCgDQgDgDgHgCIgLgEQgKgDgGgFQgGgFAAgKQAAgHADgGQAEgFAHgDQAGgDAJAAQAIAAAIADQAIACAFAFIgJAMQgEgEgGgCQgFgCgFAAQgHAAgDADQgEADAAAEQAAADADADQADADAGACIAMAEQALADAFAFQAGAGAAAKQAAALgIAHQgIAGgPAAQgKAAgJgDg");
	this.shape_17.setTransform(-21.575,13.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1D356B").s().p("AgUAoQgHgDgEgHQgEgHAAgNIAAg0IAQAAIAAAyQAAAMAEAEQAEAFALAAQAGAAAFgDQAFgDAEgGIAAg7IAQAAIAABTIgNAAIgCgIQgFAEgGADQgGADgIAAQgJAAgHgDg");
	this.shape_18.setTransform(-29.925,14.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1D356B").s().p("AAlA5IgMghIgxAAIgMAhIgRAAIAthxIARAAIAtBxgAATAKIgTgyIgSAyIAlAAg");
	this.shape_19.setTransform(-40.225,12.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(-78,0,248,24.4), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// C4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgeBFQgNgDgNgJIAPgbQAIAFALAEQAKAEAMAAQAJAAAFgDQAGgCAAgGQgBgFgDgCIgMgGIgUgHQgMgFgIgFQgIgEgFgIQgDgJAAgMQAAgNAGgJQAIgJAMgFQAMgFAPAAQAKAAAKABQAIACAIADIAPAIIgOAcQgIgFgKgDQgKgEgJAAQgIAAgEADQgEACAAAFQAAAFACACQADADAHACIATAHQANAFAJAFQAJAEAFAIQAFAIAAANQAAAVgPALQgPALgcAAQgQAAgNgEg");
	this.shape.setTransform(179.65,14.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgeBFQgNgDgNgJIAPgbQAJAFAJAEQALAEAMAAQAKAAAFgDQAEgCAAgGQAAgFgDgCIgMgGIgUgHQgMgFgIgFQgIgEgFgIQgEgJABgMQgBgNAIgJQAHgJAMgFQAMgFAOAAQAMAAAIABQAJACAIADIAQAIIgQAcQgHgFgKgDQgJgEgLAAQgHAAgEADQgEACAAAFQAAAFACACQAEADAGACIATAHQANAFAJAFQAJAEAFAIQAFAIAAANQAAAVgPALQgPALgbAAQgRAAgNgEg");
	this.shape_1.setTransform(166.9,14.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdBDQgNgFgKgKQgKgLgGgNQgGgNAAgPQAAgOAGgOQAGgNAKgKQAKgKANgGQAOgFAPAAQAQAAAOAFQAOAGAKAKQAJAKAGAOQAFANAAAOQAAAPgFANQgGAOgJAKQgKAKgOAFQgOAGgQAAQgPAAgOgGgAgSggQgJAFgFAJQgFAIABAKQgBAKAFAIQAFAJAJAGQAIAFAKAAQAMAAAIgFQAIgFAFgJQAEgJABgKQgBgJgEgJQgEgJgJgFQgIgGgMAAQgKAAgIAGg");
	this.shape_2.setTransform(152.3,14.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AATBGIgigwIgJAAIAAAwIgkAAIAAiLIA8AAQAPAAAMAFQALAGAHALQAFAKAAAOQABANgHAKQgGAKgNAGIgEABIAoA1gAgYgFIASAAQAJAAAFgEQAGgFgBgJQABgJgGgEQgFgEgJAAIgSAAg");
	this.shape_3.setTransform(137.55,14.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgWBDQgOgFgKgKQgKgKgGgOQgFgNAAgPQAAgOAFgOQAGgNAKgKQAKgKAOgGQANgFAPAAQAUAAAQAIQARAIAJAOIgcAVQgFgIgJgEQgJgFgLAAQgKAAgIAGQgJAFgEAJQgFAIAAAKQAAAKAEAJQAFAJAJAFQAIAFAKAAQALAAAJgEQAIgFAGgHIAcAUQgKAOgQAJQgQAIgUAAQgPAAgNgGg");
	this.shape_4.setTransform(122.625,14.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AASBGIghgwIgJAAIAAAwIgkAAIAAiLIA8AAQAQAAALAFQALAGAHALQAFAKABAOQAAANgHAKQgGAKgNAGIgEABIAoA1gAgYgFIASAAQAJAAAFgEQAGgFAAgJQAAgJgGgEQgFgEgJAAIgSAAg");
	this.shape_5.setTransform(108.5,14.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgRBGIAAiLIAjAAIAACLg");
	this.shape_6.setTransform(97.4,14.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAjBGIgKgdIgzAAIgJAdIgkAAIAwiLIAvAAIAwCLgAAQAMIgQgyIgQAyIAgAAg");
	this.shape_7.setTransform(86.35,14.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgcBDQgLgFgHgHQgGgIgCgKIAigJQABAFAFAEQAFADAJAAQAFAAAFgBQAFgCADgEQABgEAAgFQAAgFgBgEQgDgEgEgCQgFgCgGAAQgFAAgGACQgFACgEAGIgfgLIANhNIBTAAIAAAfIg4AAIgEAYQAEgCAGgCQAFgBAHAAQANAAAKAEQAJAEAGAHQAFAGADAHQACAIAAAIQAAAPgHALQgGALgNAGQgMAGgRAAQgRAAgLgFg");
	this.shape_8.setTransform(68,15.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgWBDQgOgFgKgKQgKgKgGgOQgFgNAAgPQAAgOAFgOQAGgNAKgKQAKgKAOgGQANgFAPAAQAUAAAQAIQARAIAJAOIgcAVQgFgIgJgEQgJgFgLAAQgKAAgIAGQgJAFgEAJQgFAIAAAKQAAAKAEAJQAFAJAJAFQAIAFAKAAQALAAAJgEQAIgFAGgHIAcAUQgKAOgQAJQgQAIgUAAQgPAAgNgGg");
	this.shape_9.setTransform(54.575,14.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(0,0,233,29.2), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmEcQirghgxihQgUhDALhEQAKhHAqg2QBThvCZgIQCagHBfBlQAEAEgEAEIhLBGQgEAFgGgEQgRgPgTgNQgzgig6ABQg2AAguAfQguAfgTAzQgVA3AQA9QAXBXBTAdQBNAbBUgmQAGgCAAgGIAAiWQAAgGAGAAIBtAAQAFAAAAAFIAADbQAAAEgFADQhAAqhPAQQgrAIgpAAQgiAAgjgGg");
	this.shape.setTransform(53.2443,1005.2913);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ED1C24").s().p("EhSyAJOIAAybMCcTAAAQAFAAADAEIJJJIQACACgCADIAAAAIpMJKgEhKIgEeQibAIhTBvQgpA2gLBHQgKBEAUBDQAwChCrAhQBLAOBPgQQBPgQBAgqQAFgDAAgEIAAjcQAAgEgFAAIhtAAQgGAAAAAFIAACXQAAAGgFACQhUAmhPgbQhSgdgYhXQgQg9AVg3QATgzAvgfQAtgfA3AAQA6gBAzAiQATANARAPQAGAEAEgFIBMhGQADgEgDgEQhaheiMAAIgTAAg");
	this.shape_1.setTransform(529.9,1004.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjQEZQgFAAAAgFIAAooQAAgEAFAAIGhAAQAEAAABAEIAABiQgBAFgEAAIkdAAQgEAAAAAFIAACHQAAAFAEAAID6AAQAEAAABAFIAABhQgBAFgEAAIj6AAQgEAAAAAEIAADBQgBAFgEAAg");
	this.shape_2.setTransform(56.125,867.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F37021").s().p("EhJfAJOIAAybMCJsAAAQAGAAAEAEIJIJIQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAIAAAAIpGJGQgFAEgEAAgEhEEgEQIAAIoQABAFAEAAIB7AAQAEAAABgFIAAjBQAAgEAEAAID7AAQAEAAABgGIAAhgQgBgFgEAAIj7AAQgEAAAAgFIAAiIQAAgEAEAAIEeAAQAEAAABgFIAAhiQgBgEgEgBImiAAQgEABgBAEg");
	this.shape_3.setTransform(470.4,867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjVEZQgFAAAAgFIAAooQAAgEAFAAIGhAAQAEAAABAEIAABiQgBAFgEAAIkdAAQgEAAAAAFIAABsQAAAFAEAAID6AAQAEAAABAEIAABfQgBAFgEAAIj6AAQgEAAAAAEIAAB2QAAAFAEAAIEnAAQAEAAABAFIAABfQgBAFgEAAg");
	this.shape_4.setTransform(55.375,729.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FDB913").s().p("EhAWAJOIAAybMB3cAAAQAEAAACACIJJJKQAEADgEADIpHJGQgDADgEAAgEg7HgEQIAAIoQAAAFAEAAIGsAAQAEAAABgFIAAhfQgBgFgEAAIknAAQgFAAAAgFIAAh2QAAgEAFAAID6AAQAEAAABgFIAAhfQgBgEgEAAIj6AAQgFAAAAgFIAAhsQAAgFAFAAIEdAAQAEAAABgFIAAhiQgBgEgEAAImiAAQgEAAAAAEg");
	this.shape_5.setTransform(411.9125,728.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AieDhIAAhBQAAgEADgEQBbhTBYhWQAVgUAJgZQALgegPgVQgYgjg0AKQgvAKgbAfQgDAEgDgDIhFgsQgHgEAFgHQApg1BEgSQBAgSBCASQBHATAaA7QAZA7gjBCQgRAfgzAwQg5A0gXAXQgDAEAFAAICsAAQAFAAAAAGIAABRQAAAFgFAAIlHABQgGAAAAgHg");
	this.shape_6.setTransform(685.9208,580.3187);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFF200").s().p("AhsBmQgtgrAAg7QAAg7AtgqQAtgqA/AAQBAAAAtAqQAtArAAA6QAAA8gtAqQgtAqhAAAQg/AAgtgqg");
	this.shape_7.setTransform(433.825,534.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AFLEvQgFAAAAgGIgBlRQAAg0gigeQgfgbgtABQgtAAgiAbQglAfgHA0QgIBDAABkIACCpQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIijABQgEAAgCgCQgDgDAAgEIAAkkQAAidh3AJQhHAGgbA2QgUAoAABSIAAEFQAAAFgFAAIioAAQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAIAApJQAAgFAFAAICcAAQAGAAAAAGIAAAuQAAABAAABQABAAAAABQABAAAAAAQABAAABAAIACAAQBShFBuADQB0ADA9BXQAAAAABABQAAAAABAAQAAAAABAAQAAAAABgBIABAAQBbhaB3AAQBVABA9AnQBAAqAWBOQALAjAABYQACCrgBCPQgBAIgHAAg");
	this.shape_8.setTransform(885.3813,536.4187);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgjGeQihgHhghIQgFgEADgFIBBh1QACgEAEADQAvAfA/ASQBFAUA5gGQCTgNgGibQgBgIgFAFQhvBciQglQiQgkg2iCQgthpAohuQAYhCA5gwQA2guBHgSQBHgTBDAQQBJAQAzA1QADADACgDIACgDIAAg3QAAgFAFAAICaAAQAGAAAAAGIgBIBQAABGgaA+QgdBAg0AnQhTA+iNAAIghgBgAhpjiQgtAqAAA8QAAA7AtArQAtApA/AAQBAAAAtgpQAtgqAAg8QAAg7gtgrQgtgqhAAAQg/AAgtAqg");
	this.shape_9.setTransform(433.5366,547.413);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFF200").s().p("AgXD0QhOgGg4gzQg0gugUhIQgThGAThFQAUhJA6gvQBZhJByAaQB1AaAvBqQAcA/gGBBQgFA/gjA1QhHBqh+AAIgYgBg");
	this.shape_10.setTransform(632.5716,527.9062);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFF200").s().p("AkpFUIgDqnQAAgGAHAAID8AAQCMgBBlBfQBkBfABCIIAAAmQAACHhkBgQhjBgiNAAIj8ACQgGAAAAgHg");
	this.shape_11.setTransform(97.1751,532.3999);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AA2GBIAAibQAAgBAAgBQgBAAAAgBQgBAAAAAAQgBgBgBAAImVAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAgBIAAh5IABgCIFonmIADgBIC6AAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAIgBACIlGHBQAAABAAAAQgBABABAAQAAABAAAAQAAABABAAIACABIC7ABQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAiGQAAAAAAgBQABAAAAgBQAAAAABAAQABAAAAAAICpAAQABAAAAAAQABAAAAAAQABABAAAAQAAABAAAAIAACHQAAABAAABQABABAAAAQAAABABAAQAAAAABAAIB0AAQABAAABAAQAAAAABABQAAAAABABQAAAAAAABIAACQQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAIh0AAQgBAAgBABQAAAAgBAAQAAABAAAAQAAABAAABIAACaQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAgBAAIiwACQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAg");
	this.shape_12.setTransform(358.875,528);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA2GBIAAiaQAAgBAAAAQgBgBAAAAQAAAAgBgBQgBAAgBAAImVgDQAAAAgBgBQgBAAAAAAQAAAAAAgBQgBgBAAAAIAAh4IABgCIFonlQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAABIC6AAQAEgBAAAEIgBACIlGHAQgBABAAAAQAAABAAABQAAAAABABQAAAAABABIACABIC7AAQABAAAAgBQABAAAAAAQABgBAAAAQAAgBAAgBIAAiEQAAgBABgBQAAAAAAgBQAAAAABAAQABAAAAAAICnAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAABIgBCHQAAABABAAQAAABAAAAQABABAAAAQABAAABAAIB2gCQABAAABAAQAAABABAAQAAAAAAABQAAAAAAABIABAAIAACTQAAAAAAABQgBABAAAAQAAAAgBAAQgBABgBAAIh0ABQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAAAABIAACZQAAABAAABQgBAAAAABQAAAAgBAAQgBABgBAAIivABQgBAAAAgBQgBAAAAAAQgBAAAAgBQAAgBAAAAg");
	this.shape_13.setTransform(283.1167,527.9833);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgGGEQgEgBAAgFIAAprQAAgEgFAAIiRAAQgFAAAAgFIgDiIQAAgEAFAAIFHAAQAFAAAAAEIAAL8QAAAFgFABg");
	this.shape_14.setTransform(218.1,527.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhbGHQifgchbh0QhThqABiMQAAiKBThrQBbh1CfgeQCPgbCAA3QCHA6BAB/QBKCTgyCaQgzCciSBJQheAwhsAAQguAAgygJgAiYi+Qg6AwgUBJQgSBFATBGQAUBHAzAvQA4AyBPAGQCOALBOh0QAjg0AGhAQAGhBgcg/Qgwhqh0gaQgegGgcAAQhQAAhCA1g");
	this.shape_15.setTransform(632.612,527.86);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AiDFrQiBg3g/h2Qg6htAPh/QAQh/BThdQBZhlCNgZQB0gUBnAeQBwAhBKBVQAEADgEADIhtBlQgCADgEAAQgEgBgCgCQg3g/hPgSQhKgQhGAbQhIAcgpA+QgtBDAGBXQAFBTAwA6QAtA2BFAVQBEAVBGgTQBJgUA0g6QAGgHAGAGIBpBjQAIAHgHAHQhdBliOAYQgoAHgoAAQhcAAhZgmg");
	this.shape_16.setTransform(546.4693,527.9315);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABzGZIi2jjQgBgBAAAAQAAAAgBAAQgBAAAAAAQgBAAgBABIhMBMIgBADIAACQQAAAAAAABQgBABAAAAQAAABgBAAQgBAAgBAAIiqABQAAAAgBAAQgBAAAAgBQAAAAAAgBQgBgBAAAAIAAssQAAgBABgBQAAAAAAgBQAAAAABAAQABAAAAAAICoAAQABAAABABQABAAAAAAQAAABABAAQAAABAAABIADG7QAAABAAAAQAAABABAAQAAABABAAQAAAAABAAIACgBIDrjfIACgBIDOAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAABIgBACIjwD0QAAABAAAAQgBABAAAAQAAABAAAAQAAABABAAIEIFPQAAABABAAQAAABAAAAQgBABAAAAQAAABgBAAIgCABIjNABg");
	this.shape_17.setTransform(795.665,525.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AovIxQgFAAAAgFIAAxXQAAgFAFAAIIbAAQDHABCfBwQCoB3AqC9QBCEvi2DJQhUBdh9AzQh+AziVABIj+AAIj9AAgAgtlZIj8AAQgGAAAAAHIACKmQAAAHAGAAID9gBQCMgBBkhgQBkhggBiHIAAgmQAAiHhlhgQhkheiLAAIgCAAg");
	this.shape_18.setTransform(97.538,532.3625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Aj/IGQgBAAgBAAQAAgBgBAAQAAAAgBgBQAAgBAAAAIFpwIQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAICXAAQABAAABAAQAAABABAAQAAABABAAQAAABAAABIAAABIlqQIQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_19.setTransform(734.325,525.725);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFF200").s().p("EhStAScMAAAgk3MCTGAAAQAFAAADADISLSVQAEAEgEAEIyKSTQgEAEgGAAgAZQFxQAOAVgLAfQgJAYgVAVQhYBWhcBTQgDAEAAAEIAABCQAAAGAGAAIFIAAQAGAAAAgGIAAhRQAAgFgGAAIirAAQgHAAAFgFQAWgWA6g0QAygxASggQAjhCgag6QgZg7hIgTQhCgShAARQhFATgpA1QgFAGAHAFIBFAsQADACAEgDQAaggAwgJQAMgDALAAQAjAAATAbgAykFrIhBB1QgCAGAEADQBhBICgAIQCmAIBdhGQA0gmAchBQAbg9AAhHIAAoBQAAgFgFAAIibAAQgFAAAAAFIAAA2QgBAEgDAAIgDgBQgzg0hJgRQhDgPhIASQhGASg3AuQg5AwgXBCQgoBtAsBpQA3CDCQAlQCRAkBvhbQAFgFABAHQAFCbiTAOQg6AFhEgTQhAgSgvggIgDgBQAAAAgBAAQAAAAAAABQgBAAAAAAQgBABAAAAgEhMOgIsQgFAAAAAFIAARXQgBAFAGAAQD+ABD+gBQCVgBB+gzQB9gzBUhdQC3jJhDkvQgpi9ioh3QighwjIgBIkOAAIkNAAgEAhogJEIlqQHQAAABgBAAQAAABABABQAAAAAAABQABAAABAAICYADQAAAAABAAQABgBAAAAQAAAAAAgBQABAAAAgBIFqwIQABgDgDgBIiYgBQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAgACFmwQiMAYhZBlQhTBdgQCAQgPB+A6BuQA/B2CAA3QB/A2CHgXQCOgZBdhlQAHgHgIgHIhphiQgGgHgGAIQg0A6hJAUQhGAShFgUQhFgVgtg2Qgvg7gFhRQgGhYAshDQApg+BIgcQBHgcBKARQBPARA3A/QACADAEAAQADAAADgCIBthlQAEgDgEgEQhKhVhwggQg+gShDAAQgsAAgvAIgAOtmwQieAehbB1QhTBrgBCLQAACLBTBqQBaB0CfAcQCkAeCHhFQCThJAyicQAyiahJiTQhAh/iHg6QhXglhdAAQgtAAgwAJgEAoiAB3IABAAIC3DkIADABIDNgBQABgBAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgCIkIlPQgBAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBIDwj0QAAAAABgBQAAAAAAgBQAAAAAAgBQgBgBAAAAIgCgBIjOABIgCABIjsDfQgBABAAAAQgBABAAAAQgBAAgBgBQAAAAgBgBIAAgCIgDm8QAAgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBAAIiogBQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAAMsQAAABAAAAQABABAAAAQAAABABAAQAAAAABAAICqgBQABAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBIAAiQIABgCIBMhNIACgBIACABgA6lmpIlpHlIgBACIAAB5QAAABAAABQABAAAAABQAAAAABABQAAAAABAAIGWAAQABAAABAAQAAAAABAAQAAABAAAAQABABAAABIAACbQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAICwgCQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAAiaQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAIB0gBQABAAABAAQAAAAABAAQAAgBAAAAQABgBAAgBIAAiQQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIh0AAQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAiHQAAgBAAgBQAAAAgBAAQAAgBgBAAQgBAAAAAAIipAAQgBAAAAAAQgBAAAAABQAAAAgBAAQAAABAAABIAACFQAAABAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIi8gBQgBAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAgBIAAgCIFHnBQABAAAAgBQAAAAAAAAQAAgBAAgBQgBAAAAgBIgCAAIi6AAIgDABgEgmbgGpIlpHlIAAACIAAB4QAAABAAAAQAAABAAAAQABAAAAABQABAAABAAIGWADQABAAAAAAQABABAAAAQABAAAAABQAAAAAAABIAACaQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAICwgBQABAAAAAAQABgBAAAAQABgBAAAAQAAgBAAgBIAAiZQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAIB1gBQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAAiTQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBAAIh3ACQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAgBIAAiHQAAgBAAgBQAAAAgBAAQAAgBgBAAQAAAAgBAAIimAAQgBAAgBAAQAAAAgBABQAAAAAAAAQAAABAAABIAACEQAAABgBABQAAAAAAABQgBAAAAABQgBAAgBAAIi8AAQgBAAAAAAQgBgBgBAAQAAgBAAAAQAAgBAAgBIAAgCIFHnAQABgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBIgCAAIi6AAIgBgBIgCACgEA8LgBNQAiAeAAAyIABFTQAAAFAFAAICiAAQAHAAABgHQABiQgCisQAAhXgLgjQgWhNhAgqQg9gohVAAQh3gBhbBbQgBAAgBAAQAAABgBAAQgBAAAAgBQgBAAAAgBIAAAAQg+hWh0gDQhugDhSBEQgDACgCgCIgBgCIAAguQAAgGgGAAIicAAQgFAAAAAFIAAJIQAAABAAAAQAAAAAAABQAAAAABAAQAAAAABAAICoAAQAFAAAAgEIAAkGQAAhSAUgnQAbg2BHgGQB3gKAACdIAAElQAAADADADQACADAEAAICkgCQAAAAABAAQAAAAAAAAQABgBAAAAQAAgBAAAAIgCipQAAhkAIhFQAHgzAlgeQAigcAtAAIABAAQAsAAAfAbgEgzMgGqQgFAAAAAEIAECIQAAAFAEAAICRAAQAFAAAAAEIAAJrQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAICqAAQAFAAAAgFIAAr8QAAgFgFAAg");
	this.shape_20.setTransform(529.3875,531.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AALEiQiggMhMh7QgphDgBhSQgChSAnhDQAkg+BAgnQA+glBJgIQBKgIBEAYQBHAYAwA3QAEAFgFADIhNBIQgDADgDgEQhLhLhgAQQg8ALgoAsQgkApgHA4QgIA3AZAxQAaA1A4AZQBxA1BlhhQAEgEAEADIBMBGQAFAFgEAEQhWBiiKAAIgfgCg");
	this.shape_21.setTransform(54.3517,335.4084);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BFD730").s().p("EguAAJNIAAyaMBSuAAAQALAAEOEQIE4E9QABAAAAAAQABABAAAAQAAABgBAAQAAABgBAAIpIJHQgDADgGABgEglbgEcQhKAHg9AlQhBAngkA+QgnBEACBSQABBRApBDQBMB8ChALQCfAMBghrQAFgFgFgEIhNhGQgEgEgEAEQhlBhhyg0Qg3gagbg1QgYgwAHg3QAHg5AkgpQAogsA9gKQBggRBLBLQADAFADgEIBOhIQAEgDgEgEQgvg4hIgYQgygSg3AAQgSAAgTADg");
	this.shape_22.setTransform(294.45,335);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#50B848").s().p("Ah4BDQgEAAAAgEIAAh9QAAgFAEAAICeABQAkAAAaASQAZATAAAaIAAAIQAAAagaASQgZATgkAAg");
	this.shape_23.setTransform(55.475,208.725);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#50B848").s().p("AhuA7IgBh1QABgGAGAAIB/AAQAlgBAZASQAaARAAAZIAAAJQABAZgaASQgaARgkABIh/AAQgHAAAAgGg");
	this.shape_24.setTransform(54.1,185.7743);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Aj9EaQgEAAAAgFIAAolQAAgFAFgBQDCgHCLAKQAzAEAnAdQAlAbAPApQAPApgNAqQgOAtgrAhQgFADAFADQBbAqgBBcQgBBUhGAnQg3AfhaABIiTAAIiUAAgAh9AzIAAB/QAAAEAEAAICeAAQAkAAAZgSQAagSAAgbIAAgJQAAgagZgSQgagTgkAAIieAAQgEAAAAAEgAAJizIiAAAQgGAAAAAGIAAB2QAAAAABABQAAAAAAABQAAAAABABQAAABAAAAQABABAAAAQABAAAAABQABAAAAAAQABAAAAAAICAAAQAlgBAZgRQAagSAAgZIAAgKQgBgZgZgRQgZgRgjAAIgCAAg");
	this.shape_25.setTransform(55.5505,197.2938);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#50B848").s().p("EgkyAJOIAAybMBATAAAQADAAADACIJKJLQABAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAIpIJHQgDAEgGAAgEggDgETQgFAAAAAFIAAIlQAAAGAFAAQCUAACTAAQBagBA3gfQBGgoABhTQABhchbgqQgFgDAFgEQAsggAOguQAMgpgPgqQgPgoglgbQgmgdgzgEQhSgGhkAAQhIAAhRADg");
	this.shape_26.setTransform(235.45,197);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#00A651").s().p("AhQBmQgBgBgBAAQgBAAAAgBQAAAAgBgBQAAAAAAgBIAAgBIBSjDQAAgBABgBQAAAAABAAQAAgBAAAAQAAAAABABIACACIBRDDQABAAAAABQAAABAAAAQgBABAAAAQgBABgBAAIgBABg");
	this.shape_27.setTransform(53.7833,55.3375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("ACzEZQAAAAgBAAQgBgBAAAAQgBAAAAgBQAAAAgBgBIgvhyQAAgBgBAAQAAgBgBAAQAAAAgBgBQAAAAgBAAIj6AAQgBAAAAAAQgBABgBAAQAAAAAAABQgBAAAAABIgwByQAAABgBAAQAAABAAAAQgBAAAAABQgBAAgBAAIh+AAQgFgBAAgDIABgCID2opQACgDADABIB6AAQADgBACADID3IpQABAEgDACIgCAAgAgCiNIgCACIhRDDQAAABAAABQAAABAAAAQAAABABAAQAAABABAAIABAAICiAAQABAAAAAAQABgBABAAQAAgBAAAAQAAgBAAAAIAAgCIhSjDQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAAAAAIgCAAg");
	this.shape_28.setTransform(53.9111,59.3714);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#00A651").s().p("EggTAJOIAAybMA3dAAAIJIJJQACACAAADQAAADgCADIpDJCQgFAFgHAAgA18ClQAAAAABAAQABAAAAABQABAAAAAAQAAABABABIAvByQAAABABAAQAAAAAAABQABAAABAAQAAABABAAICCAAQAEgBAAgEIAAgCIj3ooQgCgDgDAAIh7AAQgDAAgCADIj2IoQgCAFAEACIACAAIB+AAQABAAABgBQAAAAABAAQAAgBAAAAQABAAAAgBIAwhyQAAgBAAgBQABAAAAAAQABgBAAAAQABAAABAAg");
	this.shape_29.setTransform(206.825,59);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#F68E92").ss(2,0,0,4).p("AkCBaQAxChCrAhQBJAOBQgQQBPgQBAgqQAFgDAAgEIAAjbQAAgFgFAAIhtAAQgGAAAAAGIAACWQAAAGgGACQhUAmhNgbQhTgdgXhXQgQg9AVg3QATgzAugfQAugfA2AAQA6gBAzAiQATANARAPQAGAEAEgFIBLhGQAEgEgEgEQhfhliaAHQiZAIhTBvQgqA2gKBHQgLBEAUBDg");
	this.shape_30.setTransform(53.2443,1005.2913);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#F9B890").ss(2,0,0,4).p("AhQioQAAgFAEAAIEdAAQAEAAABgFIAAhiQgBgEgEAAImhAAQgFAAAAAEIAAIoQAAAFAFAAIB7AAQAEAAABgFIAAjBQAAgEAEAAID6AAQAEAAABgFIAAhhQgBgFgEAAIj6AAQgEAAAAgFg");
	this.shape_31.setTransform(56.125,867.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FEDC89").ss(2,0,0,4).p("AhVioQAAgFAEAAIEdAAQAEAAABgFIAAhiQgBgEgEAAImhAAQgFAAAAAEIAAIoQAAAFAFAAIGrAAQAEAAABgFIAAhfQgBgFgEAAIknAAQgEAAAAgFIAAh2QAAgEAEAAID6AAQAEAAABgFIAAhfQgBgEgEAAIj6AAQgEAAAAgFg");
	this.shape_32.setTransform(55.375,729.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFF980").ss(2,0,0,4).p("ACaAAQAAg6gtgrQgtgqhAAAQg/AAgtAqQgtAqAAA7QAAA7AtArQAtAqA/AAQBAAAAtgqQAtgqAAg8g");
	this.shape_33.setTransform(433.825,534.925);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiXi+Qg6AvgUBJQgTBFATBGQAUBIA0AuQA4AzBOAGQCPALBOh0QAjg1AFg/QAGhBgcg/Qgvhqh1gaQhygahZBJg");
	this.shape_34.setTransform(632.5716,527.9062);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FFF980").ss(2,0,0,4).p("AkslSIADKmQAAAHAGAAID8gBQCNgBBjhgQBkhgAAiHIAAgmQgBiHhkhgQhlhfiMABIj8AAQgHAAAAAHg");
	this.shape_35.setTransform(97.1751,532.3999);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFF980").ss(2,0,0,4).p("AABCHQAXgXA5g0QAzgwARgfQAjhCgZg7Qgag7hHgTQhCgShAASQhEASgpA1QgFAHAHAEIBFAsQADADADgEQAbgfAvgKQA0gKAYAjQAPAVgLAeQgJAZgVAUQhYBWhbBTQgDAEAAAEIAABBQAAAHAGAAIFHgBQAFAAAAgFIAAhRQAAgGgFAAIisAAQgFAAADgEg");
	this.shape_36.setTransform(685.9208,580.3187);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FFF980").ss(2,0,0,4).p("AAqjUQg9hXh0gDQhugDhSBFQgDACgCgDIgBgCIAAguQAAgGgGAAIicAAQgFAAAAAFIAAJJQAAACACAAICoAAQAFAAAAgFQgBiEABiBQAAhSAUgoQAbg2BHgGQB3gJAACdQAACTAACRQAAAEADADQACACAEAAICjgBQACAAAAgDQgChwAAg5QAAhkAIhDQAHg0AlgfQAigbAtAAQAtgBAfAbQAiAeAAA0IABFRQAAAGAFAAICiAAQAHAAABgIQABiPgCirQAAhYgLgjQgWhOhAgqQg9gnhVgBQh3AAhbBaQgDACgCgCg");
	this.shape_37.setTransform(885.3813,536.4187);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFF980").ss(2,0,0,4).p("ACaBnQAGCbiTANQg5AGhFgUQg/gSgvgfQgEgDgCAEIhBB1QgDAFAFAEQBgBIChAHQCkAIBdhFQA0gnAdhAQAag+AAhGQABlVAAisQAAgGgGAAIiaAAQgFAAAAAFIAAA3QgBAEgDAAIgDgBQgzg1hJgQQhDgQhHATQhHASg2AuQg5AwgYBCQgoBuAtBpQA2CCCQAkQCQAlBvhcQAFgFABAIg");
	this.shape_38.setTransform(433.5366,547.413);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiBBIQgDAAAAgDIAAgCIFGnBQACgBgCgDIgCgBIi6AAQgCAAgBACIloHlIgBACIAAB5QAAADADAAIGVAAQAEAAAAAEIAACbQAAADADAAICwgDQADAAAAgCIAAiaQAAgEADAAIB0AAQAEAAAAgDIAAiQQAAgDgEAAIh0AAQgDAAAAgEIAAiHQAAgDgDAAIipAAQgDAAAAADIAACGQAAADgDAAg");
	this.shape_39.setTransform(358.875,528);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFF980").ss(2,0,0,4).p("AAyDkQAEAAAAADIAACaQAAADADAAICvgBQAEAAAAgEIAAiZQAAgDADAAIB0gBQAEAAAAgDIAAiTQAAgDgEAAIh2ACQgEAAAAgDIABiHQAAgDgDAAIinAAQgDAAAAADIAACEQAAAEgDAAIi7AAQgEAAAAgEIABgCIFGnAQACgDgDgCQgBgBgBABIi6AAQgBgBgBACIloHlQgBABAAABIAAB4QAAADADAAg");
	this.shape_40.setTransform(283.1167,527.9833);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFF980").ss(2,0,0,4).p("Aikj2QAAAFAEAAICRAAQAFAAAAAEIAAJsQgBABACACQACACABAAICqAAQAFAAAAgFIAAr9QAAgFgFAAIlHABQgFAAAAAEg");
	this.shape_41.setTransform(218.1,527.95);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFF980").ss(2,0,0,4).p("AhamHQifAehbB1QhTBrAACKQgBCMBTBqQBbB0CfAcQCjAeCHhFQCShJAzicQAyiahKiTQhAh/iHg6QiAg3iPAbg");
	this.shape_42.setTransform(632.612,527.86);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFF980").ss(2,0,0,4).p("AFtENQAHgHgIgHIhphjQgGgGgGAHQg0A6hJAUQhGAThEgVQhFgVgtg2Qgwg6gFhTQgGhXAthDQApg+BIgcQBGgbBKAQQBPASA3A/QACACAEABQADAAADgDIBthlQAEgDgEgDQhKhVhwghQhngeh0AUQiNAZhZBlQhTBdgQB/QgPB/A6BtQA/B2CBA3QB/A2CGgXQCOgYBdhlg");
	this.shape_43.setTransform(546.4693,527.9315);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiUEEIAAgCIBMhMQADgDABADIABAAIC3DjIACABIDOgBQACgBAAgCIAAgCIkIlPQgBgCACgCIDvj0QADgCgDgDIgCgBIjNABIgCABIjsDfQgCACgDgCIAAgCIgDm7QAAgEgDAAIipgBQgCAAAAAEIAAMrQAAAEACAAICqgBQAEAAAAgEg");
	this.shape_44.setTransform(795.65,525.7005);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFF980").ss(2,0,0,4).p("AIkiLQgqi9ioh3QifhwjHgBQkPgBkMABQgFAAAAAFIAARXQgBAFAGAAQD9ABD+gBQCVgBB+gzQB9gzBUhdQC2jJhCkvg");
	this.shape_45.setTransform(97.5309,532.3625);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFF980").ss(2,0,0,4).p("AkCIBQgCAEAEABICXACQADAAAAgCIFqwIQABgEgEgBIiYAAQgCAAgBACg");
	this.shape_46.setTransform(734.3278,525.725);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#DFEB98").ss(2,0,0,4).p("AjhCbQBMB7CgAMQCfAMBghsQAEgEgFgFIhMhGQgEgDgEAEQhlBhhxg1Qg4gZgag1QgZgxAIg3QAHg4AkgpQAogsA8gLQBggQBLBLQADAEADgDIBNhIQAFgDgEgFQgwg3hHgYQhEgYhKAIQhJAIg+AlQhAAngkA+QgnBDACBSQABBSApBDg");
	this.shape_47.setTransform(54.3517,335.4084);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Ah8g+IAAB9QAAAEAEAAICeABQAkAAAZgTQAagSAAgaIAAgIQAAgagZgTQgagSgkAAIiegBQgEAAAAAFg");
	this.shape_48.setTransform(55.475,208.725);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Ahug6IAAB1QAAACACACQABACADAAICAAAQAkgBAagRQAZgSAAgZIAAgJQAAgZgagRQgagSgjABIiAAAQgGAAAAAGg");
	this.shape_49.setTransform(54.1,185.7743);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACogNQArghAOgtQANgqgPgpQgPgpglgbQgngdgzgEQiLgKjCAHQgFABAAAFIAAIlQAAAFAEAAQCUABCTgBQBagBA3gfQBGgnABhUQABhchbgqQgFgDAFgDg");
	this.shape_50.setTransform(55.5505,197.2938);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#80D3A8").ss(2,0,0,4).p("AhUBhQgBADADABIACABIChAAQAEgBAAgDIgBgBIhRjDQgBgDgCABIgCACg");
	this.shape_51.setTransform(53.7625,55.3375);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#80D3A8").ss(2,0,0,4).p("AB8ChQACAAACADIAvByQABACADABICCAAQAEgBAAgDIAAgCIj3opQgCgDgDABIh6AAQgDgBgCADIj2IpQgCAEAEACIACAAIB+AAQADgBABgCIAwhyQABgDADAAg");
	this.shape_52.setTransform(53.9025,59.3714);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgmEcQirghgxihQgUhDALhEQAKhHAqg2QBThvCZgIQCagHBfBlQAEAEgEAEIhLBGQgEAFgGgEQgRgPgTgNQgzgig6ABQg2AAguAfQguAfgTAzQgVA3AQA9QAXBXBTAdQBNAbBUgmQAGgCAAgGIAAiWQAAgGAGAAIBtAAQAFAAAAAFIAADbQAAAEgFADQhAAqhPAQQgrAIgpAAQgiAAgjgGg");
	this.shape_53.setTransform(53.2443,1005.2913);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#ED1C24").s().p("EhSyAJOIAAybMCcTAAAQAFAAADAEIJJJIQACACgCADIAAAAIpMJKgEhKIgEeQibAIhTBvQgpA2gLBHQgKBEAUBDQAwChCrAhQBLAOBPgQQBPgQBAgqQAFgDAAgEIAAjcQAAgEgFAAIhtAAQgGAAAAAFIAACXQAAAGgFACQhUAmhPgbQhSgdgYhXQgQg9AVg3QATgzAvgfQAtgfA3AAQA6gBAzAiQATANARAPQAGAEAEgFIBMhGQADgEgDgEQhaheiMAAIgTAAg");
	this.shape_54.setTransform(529.9,1004.975);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AjQEZQgFAAAAgFIAAooQAAgEAFAAIGhAAQAEAAABAEIAABiQgBAFgEAAIkdAAQgEAAAAAFIAACHQAAAFAEAAID6AAQAEAAABAFIAABhQgBAFgEAAIj6AAQgEAAAAAEIAADBQgBAFgEAAg");
	this.shape_55.setTransform(56.125,867.375);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#F37021").s().p("EhJfAJOIAAybMCJsAAAQAGAAAEAEIJIJIQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAIAAAAIpGJGQgFAEgEAAgEhEEgEQIAAIoQABAFAEAAIB7AAQAEAAABgFIAAjBQAAgEAEAAID7AAQAEAAABgGIAAhgQgBgFgEAAIj7AAQgEAAAAgFIAAiIQAAgEAEAAIEeAAQAEAAABgFIAAhiQgBgEgEgBImiAAQgEABgBAEg");
	this.shape_56.setTransform(470.4,867);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AjVEZQgFAAAAgFIAAooQAAgEAFAAIGhAAQAEAAABAEIAABiQgBAFgEAAIkdAAQgEAAAAAFIAABsQAAAFAEAAID6AAQAEAAABAEIAABfQgBAFgEAAIj6AAQgEAAAAAEIAAB2QAAAFAEAAIEnAAQAEAAABAFIAABfQgBAFgEAAg");
	this.shape_57.setTransform(55.375,729.375);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FDB913").s().p("EhAWAJOIAAybMB3cAAAQAEAAACACIJJJKQAEADgEADIpHJGQgDADgEAAgEg7HgEQIAAIoQAAAFAEAAIGsAAQAEAAABgFIAAhfQgBgFgEAAIknAAQgFAAAAgFIAAh2QAAgEAFAAID6AAQAEAAABgFIAAhfQgBgEgEAAIj6AAQgFAAAAgFIAAhsQAAgFAFAAIEdAAQAEAAABgFIAAhiQgBgEgEAAImiAAQgEAAAAAEg");
	this.shape_58.setTransform(411.9125,728.975);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AieDhIAAhBQAAgEADgEQBbhTBYhWQAVgUAJgZQALgegPgVQgYgjg0AKQgvAKgbAfQgDAEgDgDIhFgsQgHgEAFgHQApg1BEgSQBAgSBCASQBHATAaA7QAZA7gjBCQgRAfgzAwQg5A0gXAXQgDAEAFAAICsAAQAFAAAAAGIAABRQAAAFgFAAIlHABQgGAAAAgHg");
	this.shape_59.setTransform(685.9208,580.3187);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFF200").s().p("AhsBmQgtgrAAg7QAAg7AtgqQAtgqA/AAQBAAAAtAqQAtArAAA6QAAA8gtAqQgtAqhAAAQg/AAgtgqg");
	this.shape_60.setTransform(433.825,534.925);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AFLEvQgFAAAAgGIgBlRQAAg0gigeQgfgbgtABQgtAAgiAbQglAfgHA0QgIBDAABkIACCpQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIijABQgEAAgCgCQgDgDAAgEIAAkkQAAidh3AJQhHAGgbA2QgUAoAABSIAAEFQAAAFgFAAIioAAQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAIAApJQAAgFAFAAICcAAQAGAAAAAGIAAAuQAAABAAABQABAAAAABQABAAAAAAQABAAABAAIACAAQBShFBuADQB0ADA9BXQAAAAABABQAAAAABAAQAAAAABAAQAAAAABgBIABAAQBbhaB3AAQBVABA9AnQBAAqAWBOQALAjAABYQACCrgBCPQgBAIgHAAg");
	this.shape_61.setTransform(885.3813,536.4187);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgjGeQihgHhghIQgFgEADgFIBBh1QACgEAEADQAvAfA/ASQBFAUA5gGQCTgNgGibQgBgIgFAFQhvBciQglQiQgkg2iCQgthpAohuQAYhCA5gwQA2guBHgSQBHgTBDAQQBJAQAzA1QADADACgDIACgDIAAg3QAAgFAFAAICaAAQAGAAAAAGIgBIBQAABGgaA+QgdBAg0AnQhTA+iNAAIghgBgAhpjiQgtAqAAA8QAAA7AtArQAtApA/AAQBAAAAtgpQAtgqAAg8QAAg7gtgrQgtgqhAAAQg/AAgtAqg");
	this.shape_62.setTransform(433.5366,547.413);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFF200").s().p("AgXD0QhOgGg4gzQg0gugUhIQgThGAThFQAUhJA6gvQBZhJByAaQB1AaAvBqQAcA/gGBBQgFA/gjA1QhHBqh+AAIgYgBg");
	this.shape_63.setTransform(632.5716,527.9062);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFF200").s().p("AkpFUIgDqnQAAgGAHAAID8AAQCMgBBlBfQBkBfABCIIAAAmQAACHhkBgQhjBgiNAAIj8ACQgGAAAAgHg");
	this.shape_64.setTransform(97.1751,532.3999);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AA2GBIAAibQAAgBAAgBQgBAAAAgBQgBAAAAAAQgBgBgBAAImVAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAgBIAAh5IABgCIFonmIADgBIC6AAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAIgBACIlGHBQAAABAAAAQgBABABAAQAAABAAAAQAAABABAAIACABIC7ABQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAiGQAAAAAAgBQABAAAAgBQAAAAABAAQABAAAAAAICpAAQABAAAAAAQABAAAAAAQABABAAAAQAAABAAAAIAACHQAAABAAABQABABAAAAQAAABABAAQAAAAABAAIB0AAQABAAABAAQAAAAABABQAAAAABABQAAAAAAABIAACQQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAIh0AAQgBAAgBABQAAAAgBAAQAAABAAAAQAAABAAABIAACaQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAgBAAIiwACQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAg");
	this.shape_65.setTransform(358.875,528);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AA2GBIAAiaQAAgBAAAAQgBgBAAAAQAAAAgBgBQgBAAgBAAImVgDQAAAAgBgBQgBAAAAAAQAAAAAAgBQgBgBAAAAIAAh4IABgCIFonlQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAABIC6AAQAEgBAAAEIgBACIlGHAQgBABAAAAQAAABAAABQAAAAABABQAAAAABABIACABIC7AAQABAAAAgBQABAAAAAAQABgBAAAAQAAgBAAgBIAAiEQAAgBABgBQAAAAAAgBQAAAAABAAQABAAAAAAICnAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAABIgBCHQAAABABAAQAAABAAAAQABABAAAAQABAAABAAIB2gCQABAAABAAQAAABABAAQAAAAAAABQAAAAAAABIABAAIAACTQAAAAAAABQgBABAAAAQAAAAgBAAQgBABgBAAIh0ABQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAAAABIAACZQAAABAAABQgBAAAAABQAAAAgBAAQgBABgBAAIivABQgBAAAAgBQgBAAAAAAQgBAAAAgBQAAgBAAAAg");
	this.shape_66.setTransform(283.1167,527.9833);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgGGEQgEgBAAgFIAAprQAAgEgFAAIiRAAQgFAAAAgFIgDiIQAAgEAFAAIFHAAQAFAAAAAEIAAL8QAAAFgFABg");
	this.shape_67.setTransform(218.1,527.95);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AhbGHQifgchbh0QhThqABiMQAAiKBThrQBbh1CfgeQCPgbCAA3QCHA6BAB/QBKCTgyCaQgzCciSBJQheAwhsAAQguAAgygJgAiYi+Qg6AwgUBJQgSBFATBGQAUBHAzAvQA4AyBPAGQCOALBOh0QAjg0AGhAQAGhBgcg/Qgwhqh0gaQgegGgcAAQhQAAhCA1g");
	this.shape_68.setTransform(632.612,527.86);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AiDFrQiBg3g/h2Qg6htAPh/QAQh/BThdQBZhlCNgZQB0gUBnAeQBwAhBKBVQAEADgEADIhtBlQgCADgEAAQgEgBgCgCQg3g/hPgSQhKgQhGAbQhIAcgpA+QgtBDAGBXQAFBTAwA6QAtA2BFAVQBEAVBGgTQBJgUA0g6QAGgHAGAGIBpBjQAIAHgHAHQhdBliOAYQgoAHgoAAQhcAAhZgmg");
	this.shape_69.setTransform(546.4693,527.9315);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("ABzGZIi2jjQgBgBAAAAQAAAAgBAAQgBAAAAAAQgBAAgBABIhMBMIgBADIAACQQAAAAAAABQgBABAAAAQAAABgBAAQgBAAgBAAIiqABQAAAAgBAAQgBAAAAgBQAAAAAAgBQgBgBAAAAIAAssQAAgBABgBQAAAAAAgBQAAAAABAAQABAAAAAAICoAAQABAAABABQABAAAAAAQAAABABAAQAAABAAABIADG7QAAABAAAAQAAABABAAQAAABABAAQAAAAABAAIACgBIDrjfIACgBIDOAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAABIgBACIjwD0QAAABAAAAQgBABAAAAQAAABAAAAQAAABABAAIEIFPQAAABABAAQAAABAAAAQgBABAAAAQAAABgBAAIgCABIjNABg");
	this.shape_70.setTransform(795.665,525.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AovIxQgFAAAAgFIAAxXQAAgFAFAAIIbAAQDHABCfBwQCoB3AqC9QBCEvi2DJQhUBdh9AzQh+AziVABIj+AAIj9AAgAgtlZIj8AAQgGAAAAAHIACKmQAAAHAGAAID9gBQCMgBBkhgQBkhggBiHIAAgmQAAiHhlhgQhkheiLAAIgCAAg");
	this.shape_71.setTransform(97.538,532.3625);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("Aj/IGQgBAAgBAAQAAgBgBAAQAAAAgBgBQAAgBAAAAIFpwIQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAICXAAQABAAABAAQAAABABAAQAAABABAAQAAABAAABIAAABIlqQIQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_72.setTransform(734.325,525.725);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFF200").s().p("EhStAScMAAAgk3MCTGAAAQAFAAADADISLSVQAEAEgEAEIyKSTQgEAEgGAAgAZQFxQAOAVgLAfQgJAYgVAVQhYBWhcBTQgDAEAAAEIAABCQAAAGAGAAIFIAAQAGAAAAgGIAAhRQAAgFgGAAIirAAQgHAAAFgFQAWgWA6g0QAygxASggQAjhCgag6QgZg7hIgTQhCgShAARQhFATgpA1QgFAGAHAFIBFAsQADACAEgDQAaggAwgJQAMgDALAAQAjAAATAbgAykFrIhBB1QgCAGAEADQBhBICgAIQCmAIBdhGQA0gmAchBQAbg9AAhHIAAoBQAAgFgFAAIibAAQgFAAAAAFIAAA2QgBAEgDAAIgDgBQgzg0hJgRQhDgPhIASQhGASg3AuQg5AwgXBCQgoBtAsBpQA3CDCQAlQCRAkBvhbQAFgFABAHQAFCbiTAOQg6AFhEgTQhAgSgvggIgDgBQAAAAgBAAQAAAAAAABQgBAAAAAAQgBABAAAAgEhMOgIsQgFAAAAAFIAARXQgBAFAGAAQD+ABD+gBQCVgBB+gzQB9gzBUhdQC3jJhDkvQgpi9ioh3QighwjIgBIkOAAIkNAAgEAhogJEIlqQHQAAABgBAAQAAABABABQAAAAAAABQABAAABAAICYADQAAAAABAAQABgBAAAAQAAAAAAgBQABAAAAgBIFqwIQABgDgDgBIiYgBQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAgACFmwQiMAYhZBlQhTBdgQCAQgPB+A6BuQA/B2CAA3QB/A2CHgXQCOgZBdhlQAHgHgIgHIhphiQgGgHgGAIQg0A6hJAUQhGAShFgUQhFgVgtg2Qgvg7gFhRQgGhYAshDQApg+BIgcQBHgcBKARQBPARA3A/QACADAEAAQADAAADgCIBthlQAEgDgEgEQhKhVhwggQg+gShDAAQgsAAgvAIgAOtmwQieAehbB1QhTBrgBCLQAACLBTBqQBaB0CfAcQCkAeCHhFQCThJAyicQAyiahJiTQhAh/iHg6QhXglhdAAQgtAAgwAJgEAoiAB3IABAAIC3DkIADABIDNgBQABgBAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgCIkIlPQgBAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBIDwj0QAAAAABgBQAAAAAAgBQAAAAAAgBQgBgBAAAAIgCgBIjOABIgCABIjsDfQgBABAAAAQgBABAAAAQgBAAgBgBQAAAAgBgBIAAgCIgDm8QAAgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBAAIiogBQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAABIAAMsQAAABAAAAQABABAAAAQAAABABAAQAAAAABAAICqgBQABAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBIAAiQIABgCIBMhNIACgBIACABgA6lmpIlpHlIgBACIAAB5QAAABAAABQABAAAAABQAAAAABABQAAAAABAAIGWAAQABAAABAAQAAAAABAAQAAABAAAAQABABAAABIAACbQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAICwgCQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAAiaQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAIB0gBQABAAABAAQAAAAABAAQAAgBAAAAQABgBAAgBIAAiQQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIh0AAQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAiHQAAgBAAgBQAAAAgBAAQAAgBgBAAQgBAAAAAAIipAAQgBAAAAAAQgBAAAAABQAAAAgBAAQAAABAAABIAACFQAAABAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIi8gBQgBAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAgBIAAgCIFHnBQABAAAAgBQAAAAAAAAQAAgBAAgBQgBAAAAgBIgCAAIi6AAIgDABgEgmbgGpIlpHlIAAACIAAB4QAAABAAAAQAAABAAAAQABAAAAABQABAAABAAIGWADQABAAAAAAQABABAAAAQABAAAAABQAAAAAAABIAACaQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAICwgBQABAAAAAAQABgBAAAAQABgBAAAAQAAgBAAgBIAAiZQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAIB1gBQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAAiTQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBAAIh3ACQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAgBIAAiHQAAgBAAgBQAAAAgBAAQAAgBgBAAQAAAAgBAAIimAAQgBAAgBAAQAAAAgBABQAAAAAAAAQAAABAAABIAACEQAAABgBABQAAAAAAABQgBAAAAABQgBAAgBAAIi8AAQgBAAAAAAQgBgBgBAAQAAgBAAAAQAAgBAAgBIAAgCIFHnAQABgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBIgCAAIi6AAIgBgBIgCACgEA8LgBNQAiAeAAAyIABFTQAAAFAFAAICiAAQAHAAABgHQABiQgCisQAAhXgLgjQgWhNhAgqQg9gohVAAQh3gBhbBbQgBAAgBAAQAAABgBAAQgBAAAAgBQgBAAAAgBIAAAAQg+hWh0gDQhugDhSBEQgDACgCgCIgBgCIAAguQAAgGgGAAIicAAQgFAAAAAFIAAJIQAAABAAAAQAAAAAAABQAAAAABAAQAAAAABAAICoAAQAFAAAAgEIAAkGQAAhSAUgnQAbg2BHgGQB3gKAACdIAAElQAAADADADQACADAEAAICkgCQAAAAABAAQAAAAAAAAQABgBAAAAQAAgBAAAAIgCipQAAhkAIhFQAHgzAlgeQAigcAtAAIABAAQAsAAAfAbgEgzMgGqQgFAAAAAEIAECIQAAAFAEAAICRAAQAFAAAAAEIAAJrQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAICqAAQAFAAAAgFIAAr8QAAgFgFAAg");
	this.shape_73.setTransform(529.3875,531.975);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AALEiQiggMhMh7QgphDgBhSQgChSAnhDQAkg+BAgnQA+glBJgIQBKgIBEAYQBHAYAwA3QAEAFgFADIhNBIQgDADgDgEQhLhLhgAQQg8ALgoAsQgkApgHA4QgIA3AZAxQAaA1A4AZQBxA1BlhhQAEgEAEADIBMBGQAFAFgEAEQhWBiiKAAIgfgCg");
	this.shape_74.setTransform(54.3517,335.4084);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#BFD730").s().p("EguAAJNIAAyaMBSuAAAQALAAEOEQIE4E9QABAAAAAAQABABAAAAQAAABgBAAQAAABgBAAIpIJHQgDADgGABgEglbgEcQhKAHg9AlQhBAngkA+QgnBEACBSQABBRApBDQBMB8ChALQCfAMBghrQAFgFgFgEIhNhGQgEgEgEAEQhlBhhyg0Qg3gagbg1QgYgwAHg3QAHg5AkgpQAogsA9gKQBggRBLBLQADAFADgEIBOhIQAEgDgEgEQgvg4hIgYQgygSg3AAQgSAAgTADg");
	this.shape_75.setTransform(294.45,335);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#50B848").s().p("Ah4BDQgEAAAAgEIAAh9QAAgFAEAAICeABQAkAAAaASQAZATAAAaIAAAIQAAAagaASQgZATgkAAg");
	this.shape_76.setTransform(55.475,208.725);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#50B848").s().p("AhuA7IgBh1QABgGAGAAIB/AAQAlgBAZASQAaARAAAZIAAAJQABAZgaASQgaARgkABIh/AAQgHAAAAgGg");
	this.shape_77.setTransform(54.1,185.7743);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("Aj9EaQgEAAAAgFIAAolQAAgFAFgBQDCgHCLAKQAzAEAnAdQAlAbAPApQAPApgNAqQgOAtgrAhQgFADAFADQBbAqgBBcQgBBUhGAnQg3AfhaABIiTAAIiUAAgAh9AzIAAB/QAAAEAEAAICeAAQAkAAAZgSQAagSAAgbIAAgJQAAgagZgSQgagTgkAAIieAAQgEAAAAAEgAAJizIiAAAQgGAAAAAGIAAB2QAAAAABABQAAAAAAABQAAAAABABQAAABAAAAQABABAAAAQABAAAAABQABAAAAAAQABAAAAAAICAAAQAlgBAZgRQAagSAAgZIAAgKQgBgZgZgRQgZgRgjAAIgCAAg");
	this.shape_78.setTransform(55.5505,197.2938);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#50B848").s().p("EgkyAJOIAAybMBATAAAQADAAADACIJKJLQABAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAIpIJHQgDAEgGAAgEggDgETQgFAAAAAFIAAIlQAAAGAFAAQCUAACTAAQBagBA3gfQBGgoABhTQABhchbgqQgFgDAFgEQAsggAOguQAMgpgPgqQgPgoglgbQgmgdgzgEQhSgGhkAAQhIAAhRADg");
	this.shape_79.setTransform(235.45,197);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#00A651").s().p("AhQBmQgBgBgBAAQgBAAAAgBQAAAAgBgBQAAAAAAgBIAAgBIBSjDQAAgBABgBQAAAAABAAQAAgBAAAAQAAAAABABIACACIBRDDQABAAAAABQAAABAAAAQgBABAAAAQgBABgBAAIgBABg");
	this.shape_80.setTransform(53.7833,55.3375);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("ACzEZQAAAAgBAAQgBgBAAAAQgBAAAAgBQAAAAgBgBIgvhyQAAgBgBAAQAAgBgBAAQAAAAgBgBQAAAAgBAAIj6AAQgBAAAAAAQgBABgBAAQAAAAAAABQgBAAAAABIgwByQAAABgBAAQAAABAAAAQgBAAAAABQgBAAgBAAIh+AAQgFgBAAgDIABgCID2opQACgDADABIB6AAQADgBACADID3IpQABAEgDACIgCAAgAgCiNIgCACIhRDDQAAABAAABQAAABAAAAQAAABABAAQAAABABAAIABAAICiAAQABAAAAAAQABgBABAAQAAgBAAAAQAAgBAAAAIAAgCIhSjDQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAAAAAIgCAAg");
	this.shape_81.setTransform(53.9111,59.3714);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#00A651").s().p("EggTAJOIAAybMA3dAAAIJIJJQACACAAADQAAADgCADIpDJCQgFAFgHAAgA18ClQAAAAABAAQABAAAAABQABAAAAAAQAAABABABIAvByQAAABABAAQAAAAAAABQABAAABAAQAAABABAAICCAAQAEgBAAgEIAAgCIj3ooQgCgDgDAAIh7AAQgDAAgCADIj2IoQgCAFAEACIACAAIB+AAQABAAABgBQAAAAABAAQAAgBAAAAQABAAAAgBIAwhyQAAgBAAgBQABAAAAAAQABgBAAAAQABAAABAAg");
	this.shape_82.setTransform(206.825,59);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#F68E92").ss(2,0,0,4).p("AkCBaQAxChCrAhQBJAOBQgQQBPgQBAgqQAFgDAAgEIAAjbQAAgFgFAAIhtAAQgGAAAAAGIAACWQAAAGgGACQhUAmhNgbQhTgdgXhXQgQg9AVg3QATgzAugfQAugfA2AAQA6gBAzAiQATANARAPQAGAEAEgFIBLhGQAEgEgEgEQhfhliaAHQiZAIhTBvQgqA2gKBHQgLBEAUBDg");
	this.shape_83.setTransform(53.2443,1005.2913);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#F9B890").ss(2,0,0,4).p("AhQioQAAgFAEAAIEdAAQAEAAABgFIAAhiQgBgEgEAAImhAAQgFAAAAAEIAAIoQAAAFAFAAIB7AAQAEAAABgFIAAjBQAAgEAEAAID6AAQAEAAABgFIAAhhQgBgFgEAAIj6AAQgEAAAAgFg");
	this.shape_84.setTransform(56.125,867.375);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#FEDC89").ss(2,0,0,4).p("AhVioQAAgFAEAAIEdAAQAEAAABgFIAAhiQgBgEgEAAImhAAQgFAAAAAEIAAIoQAAAFAFAAIGrAAQAEAAABgFIAAhfQgBgFgEAAIknAAQgEAAAAgFIAAh2QAAgEAEAAID6AAQAEAAABgFIAAhfQgBgEgEAAIj6AAQgEAAAAgFg");
	this.shape_85.setTransform(55.375,729.375);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#FFF980").ss(2,0,0,4).p("ACaAAQAAg6gtgrQgtgqhAAAQg/AAgtAqQgtAqAAA7QAAA7AtArQAtAqA/AAQBAAAAtgqQAtgqAAg8g");
	this.shape_86.setTransform(433.825,534.925);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiXi+Qg6AvgUBJQgTBFATBGQAUBIA0AuQA4AzBOAGQCPALBOh0QAjg1AFg/QAGhBgcg/Qgvhqh1gaQhygahZBJg");
	this.shape_87.setTransform(632.5716,527.9062);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#FFF980").ss(2,0,0,4).p("AkslSIADKmQAAAHAGAAID8gBQCNgBBjhgQBkhgAAiHIAAgmQgBiHhkhgQhlhfiMABIj8AAQgHAAAAAHg");
	this.shape_88.setTransform(97.1751,532.3999);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#FFF980").ss(2,0,0,4).p("AABCHQAXgXA5g0QAzgwARgfQAjhCgZg7Qgag7hHgTQhCgShAASQhEASgpA1QgFAHAHAEIBFAsQADADADgEQAbgfAvgKQA0gKAYAjQAPAVgLAeQgJAZgVAUQhYBWhbBTQgDAEAAAEIAABBQAAAHAGAAIFHgBQAFAAAAgFIAAhRQAAgGgFAAIisAAQgFAAADgEg");
	this.shape_89.setTransform(685.9208,580.3187);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#FFF980").ss(2,0,0,4).p("AAqjUQg9hXh0gDQhugDhSBFQgDACgCgDIgBgCIAAguQAAgGgGAAIicAAQgFAAAAAFIAAJJQAAACACAAICoAAQAFAAAAgFQgBiEABiBQAAhSAUgoQAbg2BHgGQB3gJAACdQAACTAACRQAAAEADADQACACAEAAICjgBQACAAAAgDQgChwAAg5QAAhkAIhDQAHg0AlgfQAigbAtAAQAtgBAfAbQAiAeAAA0IABFRQAAAGAFAAICiAAQAHAAABgIQABiPgCirQAAhYgLgjQgWhOhAgqQg9gnhVgBQh3AAhbBaQgDACgCgCg");
	this.shape_90.setTransform(885.3813,536.4187);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#FFF980").ss(2,0,0,4).p("ACaBnQAGCbiTANQg5AGhFgUQg/gSgvgfQgEgDgCAEIhBB1QgDAFAFAEQBgBIChAHQCkAIBdhFQA0gnAdhAQAag+AAhGQABlVAAisQAAgGgGAAIiaAAQgFAAAAAFIAAA3QgBAEgDAAIgDgBQgzg1hJgQQhDgQhHATQhHASg2AuQg5AwgYBCQgoBuAtBpQA2CCCQAkQCQAlBvhcQAFgFABAIg");
	this.shape_91.setTransform(433.5366,547.413);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiBBIQgDAAAAgDIAAgCIFGnBQACgBgCgDIgCgBIi6AAQgCAAgBACIloHlIgBACIAAB5QAAADADAAIGVAAQAEAAAAAEIAACbQAAADADAAICwgDQADAAAAgCIAAiaQAAgEADAAIB0AAQAEAAAAgDIAAiQQAAgDgEAAIh0AAQgDAAAAgEIAAiHQAAgDgDAAIipAAQgDAAAAADIAACGQAAADgDAAg");
	this.shape_92.setTransform(358.875,528);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#FFF980").ss(2,0,0,4).p("AAyDkQAEAAAAADIAACaQAAADADAAICvgBQAEAAAAgEIAAiZQAAgDADAAIB0gBQAEAAAAgDIAAiTQAAgDgEAAIh2ACQgEAAAAgDIABiHQAAgDgDAAIinAAQgDAAAAADIAACEQAAAEgDAAIi7AAQgEAAAAgEIABgCIFGnAQACgDgDgCQgBgBgBABIi6AAQgBgBgBACIloHlQgBABAAABIAAB4QAAADADAAg");
	this.shape_93.setTransform(283.1167,527.9833);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#FFF980").ss(2,0,0,4).p("Aikj2QAAAFAEAAICRAAQAFAAAAAEIAAJsQgBABACACQACACABAAICqAAQAFAAAAgFIAAr9QAAgFgFAAIlHABQgFAAAAAEg");
	this.shape_94.setTransform(218.1,527.95);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#FFF980").ss(2,0,0,4).p("AhamHQifAehbB1QhTBrAACKQgBCMBTBqQBbB0CfAcQCjAeCHhFQCShJAzicQAyiahKiTQhAh/iHg6QiAg3iPAbg");
	this.shape_95.setTransform(632.612,527.86);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#FFF980").ss(2,0,0,4).p("AFtENQAHgHgIgHIhphjQgGgGgGAHQg0A6hJAUQhGAThEgVQhFgVgtg2Qgwg6gFhTQgGhXAthDQApg+BIgcQBGgbBKAQQBPASA3A/QACACAEABQADAAADgDIBthlQAEgDgEgDQhKhVhwghQhngeh0AUQiNAZhZBlQhTBdgQB/QgPB/A6BtQA/B2CBA3QB/A2CGgXQCOgYBdhlg");
	this.shape_96.setTransform(546.4693,527.9315);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiUEEIAAgCIBMhMQADgDABADIABAAIC3DjIACABIDOgBQACgBAAgCIAAgCIkIlPQgBgCACgCIDvj0QADgCgDgDIgCgBIjNABIgCABIjsDfQgCACgDgCIAAgCIgDm7QAAgEgDAAIipgBQgCAAAAAEIAAMrQAAAEACAAICqgBQAEAAAAgEg");
	this.shape_97.setTransform(795.65,525.7005);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#FFF980").ss(2,0,0,4).p("AIkiLQgqi9ioh3QifhwjHgBQkPgBkMABQgFAAAAAFIAARXQgBAFAGAAQD9ABD+gBQCVgBB+gzQB9gzBUhdQC2jJhCkvg");
	this.shape_98.setTransform(97.5309,532.3625);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#FFF980").ss(2,0,0,4).p("AkCIBQgCAEAEABICXACQADAAAAgCIFqwIQABgEgEgBIiYAAQgCAAgBACg");
	this.shape_99.setTransform(734.3278,525.725);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#DFEB98").ss(2,0,0,4).p("AjhCbQBMB7CgAMQCfAMBghsQAEgEgFgFIhMhGQgEgDgEAEQhlBhhxg1Qg4gZgag1QgZgxAIg3QAHg4AkgpQAogsA8gLQBggQBLBLQADAEADgDIBNhIQAFgDgEgFQgwg3hHgYQhEgYhKAIQhJAIg+AlQhAAngkA+QgnBDACBSQABBSApBDg");
	this.shape_100.setTransform(54.3517,335.4084);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Ah8g+IAAB9QAAAEAEAAICeABQAkAAAZgTQAagSAAgaIAAgIQAAgagZgTQgagSgkAAIiegBQgEAAAAAFg");
	this.shape_101.setTransform(55.475,208.725);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Ahug6IAAB1QAAACACACQABACADAAICAAAQAkgBAagRQAZgSAAgZIAAgJQAAgZgagRQgagSgjABIiAAAQgGAAAAAGg");
	this.shape_102.setTransform(54.1,185.7743);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACogNQArghAOgtQANgqgPgpQgPgpglgbQgngdgzgEQiLgKjCAHQgFABAAAFIAAIlQAAAFAEAAQCUABCTgBQBagBA3gfQBGgnABhUQABhchbgqQgFgDAFgDg");
	this.shape_103.setTransform(55.5505,197.2938);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#80D3A8").ss(2,0,0,4).p("AhUBhQgBADADABIACABIChAAQAEgBAAgDIgBgBIhRjDQgBgDgCABIgCACg");
	this.shape_104.setTransform(53.7625,55.3375);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#80D3A8").ss(2,0,0,4).p("AB8ChQACAAACADIAvByQABACADABICCAAQAEgBAAgDIAAgCIj3opQgCgDgDABIh6AAQgDgBgCADIj2IpQgCAEAEACIACAAIB+AAQADgBABgCIAwhyQABgDADAAg");
	this.shape_105.setTransform(53.9025,59.3714);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,1059.8,1064), null);


(lib.subRandom3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape.setTransform(121.125,17.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_1.setTransform(117.425,17.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3E424A").s().p("AgKATQgDgCgBgDQgCgEAAgGIAAgXIAIAAIAAAXQAAAFACACQABACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgCABgEAAQgEAAgEgBg");
	this.shape_2.setTransform(113.05,17.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_3.setTransform(109.925,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_4.setTransform(108.075,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEABgGQgBgFADgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_5.setTransform(104.9,17.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAEAFQAFAEAAAHQAAAIgFADQgEAFgIAAIgKAAIAAAVgAgJAAIAKAAIAEgBIAEgDQABgCAAgEQAAgDgBgCQgBAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgEgBIgKAAg");
	this.shape_6.setTransform(100.55,16.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3E424A").s().p("AgHATQgFgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCAEAAQADAAAEACIAGADIgEAFIgEgCIgFgBQgDAAgCABQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgHAAQgEAAgEgCg");
	this.shape_7.setTransform(96.25,17.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgFABIgFAEIAAAbIgHAAIAAgmIAFAAIABAEQADgDADgBQADgBAEAAQAEAAAEABQACACACADQACADABAHIAAAXg");
	this.shape_8.setTransform(92.35,17.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_9.setTransform(89.15,16.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAGgDAEAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_10.setTransform(85.95,17.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AATAbIAAgiIgQAiIgFAAIgQgiIAAAiIgIAAIAAg1IAGAAIAUArIAVgrIAGAAIAAA1g");
	this.shape_11.setTransform(80.275,16.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_12.setTransform(75.775,17.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(72.075,17.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_14.setTransform(67.925,17.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgMASQgEgDAAgFQAAgDACgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQABADAAAFIAAAaIgGAAIgBgEIgGAEIgGABQgFAAgEgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAFgBIAFgDIAAgIg");
	this.shape_15.setTransform(63.7,17.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_16.setTransform(60.925,16.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQADgCADgBQADgCACAAQAGAAAEADQAEADACAEQADAFAAAGQAAAFgDAEQgDAFgEACQgEADgFAAQgDAAgDgBIgEgDIAAAVgAgGgUIgEADIAAARIAEAEQACACAEAAQADAAADgDQACgBABgCQACgDABgEQAAgEgCgEQgBgDgDgBQgDgCgDAAIgGABg");
	this.shape_17.setTransform(57.85,18.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_18.setTransform(53.275,16.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3E424A").s().p("AgWAbIAAg1IATAAQAFAAAFACQAFACADAEQAEAEACAFQACAEAAAFQAAAFgCAFQgCAFgEAEQgDAEgFACQgFACgFAAgAgPAUIAMAAQADAAAEgCQADgBADgDIAEgGQABgEAAgEQAAgDgBgDQgCgEgCgDQgDgDgDgBQgEgCgDAAIgMAAg");
	this.shape_19.setTransform(48.425,16.525);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(43.225,17.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3E424A").s().p("AgJAaQgFgCgEgDIAEgGQADADAEABIAHACQAFAAADgCQADgCAAgEQAAgDgCgCQgCgCgEgCIgHgDQgEgBgDgBIgEgEQgCgDABgEQgBgFADgDQADgDADgCQAEgCAEAAIAGABIAFACIAGADIgFAFIgFgDIgHgBQgDAAgCACQgDACAAAEQAAADACACIAGADIAGACIAHADQADACACADQABACAAAFQAAAHgFAEQgFAEgIAAQgGAAgEgCg");
	this.shape_21.setTransform(38.9,16.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3E424A").s().p("AAAAdIAFgOIgSAAIgEAOIgIAAIAFgOIgIAAIAAgGIAKAAIAFgRIgJAAIAAgGIALAAIAEgOIAHAAIgEAOIATAAIAEgOIAHAAIgFAOIAIAAIAAAGIgKAAIgFARIAJAAIAAAGIgLAAIgEAOgAgLAJIASAAIAFgRIgSAAg");
	this.shape_22.setTransform(33.7,16.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3E424A").s().p("AgCAEQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAAAAAg");
	this.shape_23.setTransform(27.8,18.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAGAAIABAEQACgDADgBQADgBADAAQAFAAADABQAEACACADQACADAAAHIAAAXg");
	this.shape_24.setTransform(24.7,17.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3E424A").s().p("AgJATQgDgCgDgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQADAAACgBIAEgEIAAgbIAIAAIAAAmIgGAAIgCgEIgFAEQgDABgCAAQgFAAgDgBg");
	this.shape_25.setTransform(20.2,17.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3E424A").s().p("AAWAUIAAgXQAAgFgBgCQgCgCgFAAIgGABIgEADIAAAFIAAAXIgHAAIAAgXQAAgFgCgCQgBgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQACABABADIAGgEQAEgBAFAAQAEAAADABQADACACADQACADAAAHIAAAXg");
	this.shape_26.setTransform(14.525,17.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3E424A").s().p("AAWAUIAAgXQAAgFgBgCQgCgCgFAAIgGABIgEADIAAAFIAAAXIgHAAIAAgXQAAgFgCgCQgBgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQACABABADIAGgEQAEgBAFAAQAEAAADABQADACACADQACADAAAHIAAAXg");
	this.shape_27.setTransform(7.525,17.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQADAAAEgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgEgCgDAAQgDAAgDACg");
	this.shape_28.setTransform(1.75,17.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_29.setTransform(-2.525,17.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQAEACABADQACADAAAHIAAAXg");
	this.shape_30.setTransform(-8.75,17.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_31.setTransform(-13.175,17.225);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQACgDADgBQADgCADAAQAFAAADACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_32.setTransform(105,7.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_33.setTransform(101.725,7.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_34.setTransform(99.125,7.575);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAFgDAFAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgFAAgFgDgAgFgLQgEACgBADQgCADAAADQAAAEACADQABADAEACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_35.setTransform(95.3,7.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgDADgBQADgBADAAQAFAAAFADQAEACADAFQACAFAAAGQAAAFgCAFQgDAEgFACQgEAEgFAAQgDgBgDgBIgEgDIAAAVgAgGgUQgDABgBACIAAARQABADADABQADABADABQADAAADgCQACgCACgCQABgDAAgEQABgEgCgDQgCgEgCgCQgDgBgDAAIgGABg");
	this.shape_36.setTransform(90.85,8.45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3E424A").s().p("AgIATQgEgBgCgDIADgFIAGADIAGABQADAAADgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgDgBIgFgCQgFgCgDgBQgDgDABgFQgBgDACgCQACgDADgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgEAEQgEADgIAAQgDAAgFgCg");
	this.shape_37.setTransform(86.65,7.625);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAHAAIABAEQACgDADgBQADgBADAAQAFAAADABQAEACACADQACADAAAHIAAAXg");
	this.shape_38.setTransform(82.75,7.575);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAFgDQAEgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgFAAgEgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_39.setTransform(78.35,7.625);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_40.setTransform(75.425,7.575);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIADgBIADAGIgFACg");
	this.shape_41.setTransform(72.275,7.075);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQACgDADgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgEAAgEgCg");
	this.shape_42.setTransform(67.1,7.625);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_43.setTransform(63.275,7.625);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_44.setTransform(60.175,6.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#3E424A").s().p("AgPAUIAAgGIAVgaIgUAAIAAgHIAdAAIAAAGIgVAaIAWAAIAAAHg");
	this.shape_45.setTransform(55.6,7.625);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_46.setTransform(51.675,7.625);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgFABIgEAEIAAAbIgIAAIAAgmIAHAAIABAEQACgDADgBQADgBADAAQAFAAADABQADACADADQACADAAAHIAAAXg");
	this.shape_47.setTransform(47.3,7.575);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_48.setTransform(42.875,7.625);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_49.setTransform(39.625,7.575);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgDAEgBQADgBACAAQAFAAAFADQAEACACAFQADAFAAAGQAAAFgDAFQgDAEgEACQgEAEgFAAQgDgBgDgBIgFgDIAAAVgAgGgUIgFADIAAARQACADADABQADABADABQADAAADgCQACgCABgCQADgDAAgEQAAgEgCgDQgCgEgCgCQgDgBgDAAIgGABg");
	this.shape_50.setTransform(35.9,8.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#3E424A").s().p("AgFAJIAFgSIAGAAIgGASg");
	this.shape_51.setTransform(30.8,9.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAGAAIABAEQACgDADgBQADgBADAAQAFAAADABQAEACACADQACADAAAHIAAAXg");
	this.shape_52.setTransform(27.85,7.575);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_53.setTransform(23.425,7.625);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3E424A").s().p("AgDAcIAAgmIAHAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_54.setTransform(20.35,6.775);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#3E424A").s().p("AgIAZQgFgCgCgEQgDgGAAgFQAAgGADgEQACgFAFgCQAFgDAFAAIAGABIADABIAAgSIAIAAIAAA4IgGAAIgBgFIgFAEQgDABgEABQgEAAgEgEgAgEgEQgDACgBADQgCADAAAEIABAHIAEAFQADACADAAIAGgBIAEgEIAAgTQAAAAAAAAQgBgBAAAAQgBAAAAgBQgBAAAAAAIgGgBQgDAAgDABg");
	this.shape_55.setTransform(16.95,6.85);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_56.setTransform(13.9,6.775);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_57.setTransform(11.375,7.075);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQADAAAEgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgEgCgDAAQgDAAgDACg");
	this.shape_58.setTransform(7.6,7.625);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#3E424A").s().p("AgJATQgDgCgDgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQADAAACgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_59.setTransform(3.1,7.675);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#3E424A").s().p("AAMAdIAAgUIgGADIgGABQgEAAgFgEQgEgCgDgEQgCgFAAgFQAAgGACgFQADgFAFgCQAEgDAFAAIAGABQADABACADIABgEIAGAAIAAA4gAgEgUQgDACgCAEQgBADgBAEIACAHIAFAEQADACACAAIAGgBIAFgDIAAgTIgFgDIgGgBQgCAAgDABg");
	this.shape_60.setTransform(-1.55,8.45);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#3E424A").s().p("AgJATQgEgCgCgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_61.setTransform(-7.8,7.675);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#3E424A").s().p("AASAbIgHgQIgWAAIgGAQIgIAAIAVg1IAIAAIAWA1gAAJAFIgJgXIgIAXIARAAg");
	this.shape_62.setTransform(-12.65,6.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg copy
	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#DCDCDC").s().p("ArKBmIAAjKIUFAAIAABSICQAAIAAB4g");
	this.shape_63.setTransform(53.5,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_63).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom3, new cjs.Rectangle(-18,0,143,23.2), null);


(lib.subRandom2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape.setTransform(93.175,17.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_1.setTransform(89.675,17.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3E424A").s().p("AgKATQgCgCgCgDQgCgEAAgGIAAgXIAHAAIAAAXQABAFACACQABACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgFAEQgDABgEAAQgEAAgEgBg");
	this.shape_2.setTransform(85.5,17.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_3.setTransform(82.575,16.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_4.setTransform(80.925,16.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAGgDAEAAQAGAAAFADQAEADADAEQADAFAAAFQAAAGgDAFQgDAEgEADQgFADgGAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgCACg");
	this.shape_5.setTransform(77.95,17.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAFAFQAEAEAAAHQAAAIgEADQgFAFgIAAIgLAAIAAAVgAgKAAIALAAIAEgBIADgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgEgBIgLAAg");
	this.shape_6.setTransform(73.8,16.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQABAAABAAQAAAAABABIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_7.setTransform(69.7,17.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAGAAIABAEQACgDADgBQADgBADAAQAFAAAEABQACACADADQACADAAAHIAAAXg");
	this.shape_8.setTransform(66,17.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3E424A").s().p("AgDAcIAAgmIAHAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_9.setTransform(63,16.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEABgGQgBgFADgFQADgEAFgDQAEgDAFAAQAFAAAFADQAFADACAEQADAFAAAFQAAAGgDAFQgCAEgFADQgFADgFAAQgFAAgEgDgAgGgLQgCACgCADQgCADAAADQAAAEACADQACADACACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_10.setTransform(60,17.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AATAbIAAgiIgQAiIgFAAIgQgiIAAAiIgIAAIAAg1IAGAAIAUArIAVgrIAGAAIAAA1g");
	this.shape_11.setTransform(54.525,16.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_12.setTransform(50.225,17.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(46.725,17.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_14.setTransform(42.775,17.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgFAAgEgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_15.setTransform(38.75,17.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_16.setTransform(36.175,16.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQADgCADgBQADgCACAAQAFAAAFADQAEADACAEQADAFAAAGQAAAGgDAEQgDAEgEADQgEADgFAAQgDgBgDgBIgFgCIAAAUgAgGgUQgDABgCADIAAARIAFADQACACAEgBQACAAADgBQADgCACgCQACgDAAgEQgBgEgBgDQgCgEgDgCQgCgBgDAAIgGABg");
	this.shape_17.setTransform(33.3,18.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_18.setTransform(28.925,16.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3E424A").s().p("AgWAbIAAg1IATAAQAFAAAFACQAFACADAEQAEAEACAFQACAEAAAFQAAAFgCAFQgCAFgEAEQgDAEgFACQgFACgFAAgAgPAUIAMAAQADAAAEgCQADgBADgDIAEgGQABgEAAgEQAAgDgBgDQgCgEgCgDQgDgDgDgBQgEgCgDAAIgMAAg");
	this.shape_19.setTransform(24.275,16.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(19.275,17.275);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3E424A").s().p("AgJAaQgEgCgFgDIAEgGQADADAEABIAHACQAFAAADgCQADgCAAgEQAAgDgCgCQgCgCgFgCIgGgDQgEgBgCgBIgFgEQgCgDABgEQgBgFADgDQADgDADgCQAEgCAEAAIAGABIAFACIAGADIgFAFIgFgDIgHgBQgDAAgDACQgCACAAAEQAAADACACIAGADIAGACIAHADQADACACADQABACAAAFQAAAHgFAEQgFAEgIAAQgFAAgFgCg");
	this.shape_21.setTransform(15.15,16.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3E424A").s().p("AAAAdIAFgOIgSAAIgFAOIgHAAIAFgOIgIAAIAAgGIAJAAIAGgRIgJAAIAAgGIALAAIAEgOIAHAAIgEAOIATAAIAEgOIAHAAIgEAOIAHAAIAAAGIgKAAIgFARIAJAAIAAAGIgLAAIgFAOgAgLAJIASAAIAGgRIgTAAg");
	this.shape_22.setTransform(10.15,16.575);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3E424A").s().p("AgDAEQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAg");
	this.shape_23.setTransform(72.65,9.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_24.setTransform(70.875,7.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_25.setTransform(67.375,7.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_26.setTransform(64.325,7.625);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3E424A").s().p("AgKATQgDgCgBgDQgCgEAAgGIAAgXIAHAAIAAAXQABAFACACQABACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgFAEQgDABgEAAQgEAAgEgBg");
	this.shape_27.setTransform(60.75,7.725);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAAAABABQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_28.setTransform(57.175,7.125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_29.setTransform(54.95,6.825);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEAAgGQAAgFADgFQADgEAFgDQAFgDAEAAQAGAAAFADQAEADADAEQACAFAAAFQAAAGgCAFQgDAEgEADQgFADgGAAQgEAAgFgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgCACg");
	this.shape_30.setTransform(51.95,7.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3E424A").s().p("AgDAUIgPgnIAIAAIAKAdIAMgdIAHAAIgPAng");
	this.shape_31.setTransform(47.925,7.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEAAgGQAAgFACgFQADgEAEgDQAFgDAFAAQAFAAAFADQAFADACAEQADAFABAFQgBAGgDAFQgCAEgFADQgFADgFAAQgFAAgFgDgAgFgLQgEACgBADQgCADAAADQAAAEACADQABADAEACQACACADAAQAEAAACgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgCgCgEAAQgDAAgCACg");
	this.shape_32.setTransform(43.9,7.675);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_33.setTransform(39.825,7.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3E424A").s().p("AgMAaQgDgDAAgFQAAgDABgCQABgCADgCIAIgCIALgDIAAgCQAAgEgCgBQgCgBgFAAIgFAAIgDAEIgGgCQABgFAEgCQAFgCAFAAQAFAAADABQAEACABADQACADAAADIAAAbIgFAAIgCgEIgGAEIgGABQgFAAgEgDgAgBANQgEAAgBACQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABIAEABIAGgBIAFgEIAAgIgAgCgPIgKgNIAJAAIAIANg");
	this.shape_34.setTransform(34.1,6.825);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3E424A").s().p("AgPAUIAAgGIAVgaIgUAAIAAgHIAdAAIAAAGIgVAaIAWAAIAAAHg");
	this.shape_35.setTransform(29,7.675);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_36.setTransform(25.275,7.675);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3E424A").s().p("AgHATQgFgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCAEAAQADAAAEACIAGADIgEAFIgEgCIgFgBQgDAAgCABQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgHAAQgEAAgEgCg");
	this.shape_37.setTransform(21.55,7.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAGAAIABAEQACgDADgBQADgBADAAQAFAAADABQADACADADQACADAAAHIAAAXg");
	this.shape_38.setTransform(17.85,7.625);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_39.setTransform(13.625,7.675);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAFAFQAEAEAAAHQAAAIgEADQgFAFgIAAIgKAAIAAAVgAgJAAIAJAAIAGgBIACgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAAAAAIgGgBIgJAAg");
	this.shape_40.setTransform(9.6,6.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg copy
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#DCDCDC").s().p("AnLBmIAAh3IAAAAIAAhTILHAAIAABTIDQAAIAAB3g");
	this.shape_41.setTransform(50.65,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom2, new cjs.Rectangle(4.7,0.1,92,23.2), null);


(lib.subRandom1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape.setTransform(111.075,17.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_1.setTransform(107.575,17.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3E424A").s().p("AgKATQgCgCgCgDQgCgEAAgGIAAgXIAHAAIAAAXQAAAFADACQABACAFAAQACAAADgBIAEgEIAAgbIAIAAIAAAmIgGAAIgCgEIgEAEQgEABgDAAQgEAAgEgBg");
	this.shape_2.setTransform(103.4,17.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_3.setTransform(100.475,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_4.setTransform(98.825,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAGgDAEAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_5.setTransform(95.85,17.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAFAFQAEAEAAAHQAAAIgEADQgFAFgIAAIgLAAIAAAVgAgKAAIAKAAIAFgBIADgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgFgBIgKAAg");
	this.shape_6.setTransform(91.7,16.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3E424A").s().p("AgHATQgFgBgDgDIAEgFIAGADIAGABQADAAADgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgFgCQgEgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCAEAAQADAAAEACIAGADIgEAFIgFgCIgEgBQgDAAgCABQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQgBAFgEAEQgDADgHAAQgEAAgEgCg");
	this.shape_7.setTransform(87.6,17.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAFAAIACAEQACgDADgBQADgBAEAAQAEAAAEABQACACACADQADADAAAHIAAAXg");
	this.shape_8.setTransform(83.9,17.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3E424A").s().p("AgDAcIAAgmIAHAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_9.setTransform(80.9,16.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEABgGQgBgFADgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_10.setTransform(77.9,17.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AATAbIAAgiIgQAiIgFAAIgQgiIAAAiIgIAAIAAg1IAGAAIAUArIAVgrIAGAAIAAA1g");
	this.shape_11.setTransform(72.425,16.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_12.setTransform(68.125,17.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(64.625,17.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_14.setTransform(60.675,17.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgEAAIgGABIgCADIgHgCQABgEAFgDQAEgCAFAAQAFAAAEACQADABACADQACADAAAFIAAAaIgHAAIAAgEIgHAEIgGABQgFAAgEgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_15.setTransform(56.65,17.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_16.setTransform(54.075,16.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgCAEgBQADgCACAAQAGAAAEADQAEADACAEQADAFAAAGQAAAFgDAEQgDAFgEACQgEADgFAAQgDAAgDgBIgFgDIAAAVgAgGgUIgFADIAAARIAFAEQADACADAAQADAAACgDQADgBABgCQADgDAAgEQAAgEgCgEQgCgDgDgBQgCgCgDAAIgGABg");
	this.shape_17.setTransform(51.2,18.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_18.setTransform(46.825,16.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3E424A").s().p("AgWAbIAAg1IATAAQAFAAAFACQAFACADAEQAEAEACAFQACAEAAAFQAAAFgCAFQgCAFgEAEQgDAEgFACQgFACgFAAgAgPAUIAMAAQADAAAEgCQADgBADgDIAEgGQABgEAAgEQAAgDgBgDQgCgEgCgDQgDgDgDgBQgEgCgDAAIgMAAg");
	this.shape_19.setTransform(42.175,16.525);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(37.175,17.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3E424A").s().p("AgJAaQgFgCgEgDIAEgGQADADAEABIAHACQAFAAADgCQADgCAAgEQAAgDgCgCQgCgCgFgCIgGgDQgEgBgDgBIgEgEQgCgDABgEQgBgFADgDQADgDADgCQAEgCAEAAIAGABIAGACIAFADIgFAFIgFgDIgHgBQgDAAgCACQgDACAAAEQAAADACACIAGADIAGACIAHADQADACACADQABACAAAFQAAAHgFAEQgFAEgIAAQgGAAgEgCg");
	this.shape_21.setTransform(33.05,16.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3E424A").s().p("AAAAdIAFgOIgSAAIgFAOIgHAAIAFgOIgIAAIAAgGIAKAAIAFgRIgJAAIAAgGIALAAIAEgOIAHAAIgEAOIATAAIAEgOIAHAAIgEAOIAHAAIAAAGIgKAAIgFARIAJAAIAAAGIgLAAIgEAOgAgLAJIASAAIAGgRIgTAAg");
	this.shape_22.setTransform(28.05,16.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3E424A").s().p("AgCAEQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAAAAAg");
	this.shape_23.setTransform(22.55,18.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEAAgGQAAgFACgFQADgEAEgDQAFgDAFAAQAFAAAFADQAFADACAEQADAFABAFQgBAGgDAFQgCAEgFADQgFADgFAAQgFAAgFgDgAgFgLQgEACgBADQgCADAAADQAAAEACADQABADAEACQACACADAAQAEAAACgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgCgCgEAAQgDAAgCACg");
	this.shape_24.setTransform(19.6,17.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_25.setTransform(16.575,16.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_26.setTransform(13.725,16.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3E424A").s().p("AgDAUIgPgnIAIAAIAKAdIAMgdIAHAAIgPAng");
	this.shape_27.setTransform(9.825,17.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_28.setTransform(4.225,17.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_29.setTransform(1.325,16.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3E424A").s().p("AgJATQgEgCgCgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_30.setTransform(-3.3,17.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAGgDAEAAQAGAAAFADQAEADADAEQADAFAAAFQAAAGgDAFQgDAEgEADQgFADgGAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgCACg");
	this.shape_31.setTransform(-7.55,17.225);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_32.setTransform(-13.475,17.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3E424A").s().p("AAKAcIAAgYQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAcIgIAAIAAg3IAIAAIAAAVQACgDADgBQADgCAEAAQAEAAAEACQADABABAEQACADAAAFIAAAZg");
	this.shape_33.setTransform(-17.65,16.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_34.setTransform(-21.725,17.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_35.setTransform(-24.725,17.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3E424A").s().p("AgMASQgEgDAAgFQAAgDACgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQABADAAAFIAAAaIgGAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAFgBIAFgDIAAgIg");
	this.shape_36.setTransform(-28.2,17.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3E424A").s().p("AAWAUIAAgXQAAgFgBgCQgCgCgFAAIgGABIgEADIAAAFIAAAXIgHAAIAAgXQAAgFgCgCQgBgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQACABABADIAGgEQAEgBAFAAQAEAAADABQADACACADQACADAAAHIAAAXg");
	this.shape_37.setTransform(-33.325,17.175);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_38.setTransform(-40.45,17.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_39.setTransform(-43.025,16.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3E424A").s().p("AgPAUIAAgGIAVgaIgUAAIAAgHIAdAAIAAAGIgVAaIAWAAIAAAHg");
	this.shape_40.setTransform(60.45,7.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_41.setTransform(56.725,7.625);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_42.setTransform(53.85,6.775);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#3E424A").s().p("AgGAcQgDgBgDgCQgDgCgBgEIAGgCIACACIAEADIAEAAQAGAAACgCQADgDABgFIAAgEIgFACQgDACgEAAQgEAAgFgDQgEgDgDgFQgCgDAAgGQAAgGACgEQADgFAFgDQAEgCAEAAIAHABIAFACIABgCIAGAAIAAAnQAAAGgCADQgCAEgEACQgEADgGgBIgHgBgAgEgUIgFAFQgBADAAAEQAAAEABADQACACADACQADACACAAIAGgBIAFgDIAAgSIgFgDIgGgCQgCAAgDACg");
	this.shape_43.setTransform(50.65,8.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_44.setTransform(46.575,6.775);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_45.setTransform(43.675,6.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_46.setTransform(42.05,6.775);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#3E424A").s().p("AgDAUIgPgnIAIAAIAKAdIAMgdIAHAAIgPAng");
	this.shape_47.setTransform(39.375,7.625);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#3E424A").s().p("AgDAcIAAgmIAHAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_48.setTransform(36.7,6.775);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_49.setTransform(34.875,7.575);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgDADgBQADgBADAAQAGAAAEADQAEACADAFQACAFAAAGQAAAFgCAFQgEAEgEACQgEAEgFAAQgDgBgDgBIgEgDIAAAVgAgGgUQgDABgBACIAAARQABADADABQADABADABQACAAADgCQADgCACgCQABgDAAgEQABgEgCgDQgBgEgEgCQgCgBgDAAIgGABg");
	this.shape_50.setTransform(31.35,8.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#3E424A").s().p("AgFAJIAEgSIAHAAIgGASg");
	this.shape_51.setTransform(28.35,9.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#3E424A").s().p("AgHATQgFgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCAEAAQADAAAEACIAGADIgEAFIgEgCIgFgBQgDAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgHAAQgEAAgEgCg");
	this.shape_52.setTransform(26.05,7.625);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_53.setTransform(22.975,7.075);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_54.setTransform(20.575,7.575);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#3E424A").s().p("AgKATQgCgCgCgDQgCgEAAgGIAAgXIAHAAIAAAXQAAAFADACQABACAFAAQACAAADgBIAEgEIAAgbIAIAAIAAAmIgGAAIgCgEIgEAEQgEABgDAAQgEAAgEgBg");
	this.shape_55.setTransform(17,7.675);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEABgGQgBgFADgFQADgEAEgDQAFgDAFAAQAFAAAFADQAFADACAEQADAFAAAFQAAAGgDAFQgCAEgFADQgFADgFAAQgFAAgFgDgAgGgLQgCACgCADQgCADAAADQAAAEACADQACADACACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_56.setTransform(12.75,7.625);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_57.setTransform(8.675,7.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQACgDADgBQADgCADAAQAFAAADACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_58.setTransform(3.3,7.625);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_59.setTransform(0.225,7.075);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_60.setTransform(-3.225,7.625);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#3E424A").s().p("AgGAlIgDgBIABgHIADABIADAAQAAAAABAAQABAAAAAAQAAAAAAAAQAAgBAAAAQACgBAAgEIAAgrIAHAAIAAAsQAAAFgCAEQgEAEgFgBgAACgcQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAIABADIgBAEQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAABQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_61.setTransform(-6.7,7.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_62.setTransform(-8.95,7.625);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_63.setTransform(-11.675,7.575);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_64.setTransform(-14.625,7.075);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_65.setTransform(-19.4,7.625);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_66.setTransform(-23.025,7.625);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_67.setTransform(-25.925,6.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_68.setTransform(-29.425,7.575);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#3E424A").s().p("AgJATQgEgCgCgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgCABgDAAQgFAAgDgBg");
	this.shape_69.setTransform(-33,7.675);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAGgDAEAAQAGAAAFADQAEADADAEQADAFAAAFQAAAGgDAFQgDAEgEADQgFADgGAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgCACg");
	this.shape_70.setTransform(-37.25,7.625);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAFAFQAEAEAAAHQAAAIgEADQgFAFgIAAIgLAAIAAAVgAgKAAIALAAIAEgBIADgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgEgBIgLAAg");
	this.shape_71.setTransform(-41.4,6.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg copy
	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#DCDCDC").s().p("AspBmIAAjKIRyAAIAABSIHhAAIAAB4g");
	this.shape_72.setTransform(34.05,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_72).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom1, new cjs.Rectangle(-46.9,0,162,23.2), null);


(lib.sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgHAQQgEgCgDgFQgCgEAAgFQAAgEACgEQADgEAEgDQAEgCADAAQAIAAAEAFQAFAEAAAIIAAABIgaAAIABAGQABACAEABQACACACAAQAFAAACgCIADgDIAGADIgHAGQgEACgFAAQgEAAgEgCgAAKgDQAAgEgCgCQgDgCgEAAQgDAAgCABIgEAFIAAACIASAAIAAAAg");
	this.shape.setTransform(72.5,6.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgIASIAAgiIAFAAIABADIADgCIADgBIAFgBIAAAHIgFAAIgDACIgDACIAAAYg");
	this.shape_1.setTransform(69.85,6.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgGAZIAAgcIgFAAIAAgGIAFAAIAAgDQAAgFADgEQADgDAGAAIADAAIAEABIgCAGIgDgBIgCAAQgDAAgCACQgBABAAAEIAAACIAJAAIAAAGIgJAAIAAAcg");
	this.shape_2.setTransform(67.65,6.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAZIAAgcIgGAAIAAgGIAGAAIAAgDQAAgFADgEQADgDAFAAIAFAAIACABIgBAGIgCgBIgDAAQgDAAgCACQgBABAAAEIAAACIAKAAIAAAGIgKAAIAAAcg");
	this.shape_3.setTransform(65.55,6.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgIAQQgEgCgDgFQgCgEAAgFQAAgEACgEQADgEAEgDQAEgCAEAAQAFAAAEACQAEADADAEQACAEAAAEQAAAGgCADQgDAFgEACQgEACgFAAQgEAAgEgCgAgFgKIgEAFIgBAFIABAHIAEADQADACACAAQAEAAACgCIAEgDIABgHIgBgFIgEgFQgCgBgEAAQgCAAgDABg");
	this.shape_4.setTransform(62.4,6.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgBAIIgBgPIAFAAIgBAPg");
	this.shape_5.setTransform(59.925,4.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgCAXIAAgtIAFAAIAAAtg");
	this.shape_6.setTransform(58.475,6.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgHAQQgEgCgDgFQgCgEAAgFQAAgEACgEQADgEAEgDQAEgCAEAAQAHAAAEAFQAFAEAAAIIAAABIgaAAIACAGQABACACABQADACADAAQAEAAACgCIADgDIAGADIgGAGQgEACgGAAQgEAAgEgCgAAKgDQgBgEgBgCQgDgCgEAAQgDAAgCABIgEAFIAAACIASAAIAAAAg");
	this.shape_7.setTransform(54.3,6.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgHAXQgEgDgCgEQgDgEAAgFQAAgFADgDQACgEAEgDQAEgCAEAAIAFABIAEABIAAgQIAHAAIAAAwIgGAAIgBgDQgBACgDABIgGABQgEAAgDgCgAgEgDIgDAEQgCACAAAEIABAGIAEAEQADACACAAIAFgBIAEgDIAAgQQAAAAgBgBQAAAAAAAAQgBgBgBAAQAAAAgBAAIgFgBIgFABg");
	this.shape_8.setTransform(50.425,6.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgHARQgDgBgCgCIACgFIAGACIAEACIAGgCQAAAAAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgCIgEgCIgEgDQgEAAgDgCQgCgCAAgFIABgEQABgCAEgCQADgBACAAIAHABIAFADIgEAFIgDgCIgFgBIgDABQgBAAAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABIADACIAFABQAEABACACQACADABADQgBAFgDADQgDACgHAAIgHgBg");
	this.shape_9.setTransform(45.7,6.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgCAYIAAgvIAFAAIAAAvg");
	this.shape_10.setTransform(43.575,6.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgCAZIAAgiIAGAAIAAAigAgCgQIgBgDQAAgBAAAAQAAgBAAAAQAAAAAAgBQABAAAAAAIACgCQABAAAAAAQAAAAABABQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAABIgCADQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCgBg");
	this.shape_11.setTransform(42.1,6.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKAQQgDgDAAgEIABgFIADgDIAHgBIAKgCIAAgCQAAgFgCgBQgCgBgEAAIgEABQgBAAAAAAQAAABgBAAQAAAAAAABQAAAAgBABIgFgCQABgEAEgCQADgCAFAAQAEAAADABQADABACADQABADAAADIAAAXIgFAAIgBgDIgGADIgFABQgEAAgDgCgAgBAEIgFACIgBADQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIAEACIAEgCIAFgDIAAgHg");
	this.shape_12.setTransform(39.625,6.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgDAUQgCgDAAgFIAAgSIgHAAIAAgFIAHAAIAAgLIAFAAIAAALIAMAAIAAAFIgMAAIAAAPIABAGQAAABABAAQAAAAABAAQAAABABAAQAAAAABAAIADAAIADgBIACAFIgEABIgFABQgEAAgDgDg");
	this.shape_13.setTransform(36.775,6.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgHAXQgEgCgCgEQgDgEAAgFQAAgGADgCQACgEAEgDQADgCAFAAQAHgBAFAFQAEAEAAAIIAAACIgaAAIACAFQABACACACQADABADABQADgBACgBIAFgEIAEAEIgFAFQgEADgGAAQgEAAgEgDgAAKADQgBgDgCgBQgCgDgEAAQgCAAgDACIgEAEIgBABIATAAIAAAAgAgDgNIAIgLIAIAAIgKALg");
	this.shape_14.setTransform(33.75,6.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgHAXQgEgDgCgEQgDgEAAgFQAAgFADgDQACgEAEgDQAEgCAEAAIAFABIAEABIAAgQIAHAAIAAAwIgGAAIgBgDQgBACgDABIgGABQgEAAgDgCgAgEgDQgCACgBACQgCACAAAEIABAGIAEAEQADACACAAIAFgBIAEgDIAAgQQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAAAgBAAIgFgBIgFABg");
	this.shape_15.setTransform(29.875,6.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgIASIAAgiIAFAAIABADIADgCIADgBIAFgBIAAAHIgFAAIgDACIgDACIAAAYg");
	this.shape_16.setTransform(25.75,6.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgCAZIAAgiIAFAAIAAAigAgCgQIgCgDQAAgBABAAQAAgBAAAAQAAAAAAgBQABAAAAAAIACgCQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQAAAAAAABIgBADQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAIgCgBg");
	this.shape_17.setTransform(23.7,6.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgIAQQgEgCgCgFQgDgEAAgFQAAgEADgEQACgEAEgDQAEgCAEAAQAFAAAEACQAEADACAEQADAEAAAEQAAAGgDADQgCAFgEACQgEACgFAAQgEAAgEgCgAgFgKIgEAFIgBAFIABAHIAEADQADACACAAQADAAADgCIAEgDIABgHIgBgFIgEgFQgDgBgDAAQgCAAgDABg");
	this.shape_18.setTransform(21.05,6.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgDAXIgRgtIAHAAIANAmIAOgmIAHAAIgRAtg");
	this.shape_19.setTransform(17.025,6.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAAADIgFAKIgEgEIAIgIIgMgBIACgFIALAEIgCgLIAFAAIgCAMIALgFIACAFIgMABIAIAJIgFADg");
	this.shape_20.setTransform(12.025,5.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub3, new cjs.Rectangle(8.5,0,77.5,12.4), null);


(lib.sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape.setTransform(85.725,7.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQAEACACADQABADAAAHIAAAXg");
	this.shape_1.setTransform(82.15,7.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAFgDQAEgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_2.setTransform(77.9,7.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgSAdIAAg4IAGAAIABAEQADgDADgBQADgBACAAQAGAAAEADQAEACACAFQADAFAAAGQAAAFgDAFQgDAEgEACQgEAEgFAAQgDgBgDgBIgEgDIAAAVgAgGgUIgEADIAAARQACADACABQACABAEABQADAAADgCQACgCABgCQACgDABgEQAAgEgCgDQgBgEgDgCQgDgBgDAAIgGABg");
	this.shape_3.setTransform(74.05,8.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgDAcIAAgmIAGAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_4.setTransform(70.85,6.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_5.setTransform(68.075,7.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_6.setTransform(65.2,6.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIADgBIADAGIgFACg");
	this.shape_7.setTransform(62.825,7.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_8.setTransform(60.375,7.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgMASQgEgDAAgFQAAgDACgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADgBAFIAAAaIgGAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAFgBIAFgDIAAgIg");
	this.shape_9.setTransform(56.85,7.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgSAdIAAg4IAGAAIABAEQACgDAEgBQADgBACAAQAGAAAEADQAEACACAFQADAFAAAGQAAAFgDAFQgDAEgEACQgEAEgFAAQgDgBgDgBIgFgDIAAAVgAgGgUIgFADIAAARQACADADABQADABADABQADAAADgCQACgCABgCQADgDAAgEQAAgEgCgDQgCgEgCgCQgDgBgDAAIgGABg");
	this.shape_10.setTransform(53,8.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgJATQgDgCgDgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQADAAACgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_11.setTransform(46.75,7.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgMASQgDgDAAgFQAAgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgEAAIgGABIgCADIgHgCQABgEAFgDQAEgCAFAAQAFAAAEACQADABABADQADADAAAFIAAAaIgGAAIgBgEIgHAEIgGABQgGAAgDgDgAgBAEQgEABgBABQgBABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_12.setTransform(42.6,7.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(38.775,7.625);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgIATQgEgBgCgDIADgFIAGADIAGABQADAAACgBQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgDgBIgFgCQgFgCgDgBQgDgDABgFQgBgDACgCQACgDADgBQADgCADAAQAFAAADACIAGADIgEAFIgFgCIgFgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADgBAEQAAAFgDAEQgEADgIAAQgDAAgFgCg");
	this.shape_14.setTransform(35,7.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_15.setTransform(31.325,6.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_16.setTransform(28.225,7.575);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAAEABQADACABADQACADAAAHIAAAXg");
	this.shape_17.setTransform(22.85,7.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAGgDAEAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_18.setTransform(18.45,7.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_19.setTransform(15.375,6.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(12.475,7.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQACgDADgBQADgCADAAQAFAAADACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_21.setTransform(8.7,7.625);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAAADIgGAMIgFgEIAKgKIgOgBIADgGIAMAFIgCgNIAFAAIgCANIANgFIACAGIgOABIAJAKIgFAEg");
	this.shape_22.setTransform(3.75,5.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub1, new cjs.Rectangle(0,0,126.5,13.6), null);


(lib.offer2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// layer_1 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgFADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape.setTransform(53.1,123.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_1.setTransform(48.925,123.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_2.setTransform(46.15,122.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIACAFIACgDIAGgCIAFgBIAAAJIgGAAIgFACIgCADIAAAfg");
	this.shape_3.setTransform(44.15,123.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_4.setTransform(40.175,124.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQAEgFAFgDQAEgDAGAAQAJAAAGAFQAGAGgBALIAAACIghAAIACAGQACADADACQADACAEAAQAFAAADgCIAFgEIAGAEQgDAEgEADQgGADgHAAQgFAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_5.setTransform(35.15,123.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIACAFIACgDIAGgCIAGgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_6.setTransform(31.75,123.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgEgFAAgHQAAgGAEgFQADgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQABADAEACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgFADQgFADgGAAQgGAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgEADgBADIgCADIAZAAIAAAAg");
	this.shape_7.setTransform(25.75,123.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgCAFAAIAHAAIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDACQgEABgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_8.setTransform(20.775,122.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgIAAIAAgsIAGAAIACAFIAGgEQADgCADAAQAGAAADACQAEABACAEQACAEAAAHIAAAbg");
	this.shape_9.setTransform(14.1,123.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgKAUQgGgDgDgFQgDgFAAgHQAAgGADgFQADgFAGgDQAEgDAGAAQAGAAAFADQAGADADAFQADAFAAAGQAAAHgDAFQgDAFgGADQgFADgGAAQgGAAgEgDgAgHgNQgDADgBADQgCADAAAEQAAAEACAEQABADADACQAEACADAAQAEAAAEgBQACgCADgEQACgEAAgEQAAgDgCgEQgDgDgCgCQgEgDgEAAQgDAAgEACg");
	this.shape_10.setTransform(9.15,123.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_11.setTransform(5.7,122.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_12.setTransform(3.075,122.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_13.setTransform(0.5,122.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgCAFAAIAHAAIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDACQgEABgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_14.setTransform(-3.075,122.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgFAAQgDAAgDABQgDACgCADIAAAfIgIAAIAAgsIAGAAIACAFIAFgEQAEgCADAAQAFAAAEACQAEABADAEQABAEABAHIAAAbg");
	this.shape_15.setTransform(-7.8,123.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgKAUQgGgDgDgFQgDgFAAgHQAAgGADgFQADgFAGgDQAFgDAFAAQAGAAAFADQAFADAEAFQADAFAAAGQAAAHgDAFQgEAFgFADQgEADgHAAQgFAAgFgDgAgHgNQgDADgCADQgCADAAAEQAAAEACAEQACADADACQADACAEAAQAEAAAEgBQADgCABgEQACgEAAgEQAAgDgCgEQgBgDgDgCQgEgDgEAAQgEAAgDACg");
	this.shape_16.setTransform(-12.75,123.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgDgFAAgHQAAgGADgFQADgFAFgDQAFgDAFAAQAIAAAEADQAFADADAGIgHADIgFgGQgDgCgFAAQgDAAgDACIgFAGQgCADAAAEQAAAEADAEQABADADACQAEACADAAQAFAAADgCQADgCACgDIAGAFQgDAEgFADQgFADgHAAQgFAAgFgDg");
	this.shape_17.setTransform(-17.35,123.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_18.setTransform(-23.425,123.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQACAEAAAHIAAAbg");
	this.shape_19.setTransform(-27.65,123.325);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgOAUQgDgDAAgGQgBgDACgDIAFgEIAJgCIAMgDIAAgDQAAgEgCgCQgDgCgFAAIgGABQgCABAAADIgIgCQABgGAFgCQAFgCAFAAQAGAAAEABQAEACADADQABAEAAAFIAAAdIgHAAIgBgEQgDADgEABQgDABgEAAQgFAAgFgDgAgBAFIgGACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_20.setTransform(-32.45,123.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgKAdQgFgCgFgEIAEgGIAIAEQAEACAEAAQAGAAADgCQADgCAAgFQAAgDgCgCQgCgDgFgCIgIgCIgHgDQgDgCgCgDQgCgDAAgFQAAgFADgEQADgDAEgDQAEgBAFAAIAHAAIAGADIAGADIgFAHQgDgDgDgBQgDgBgFgBQgDAAgDACQgDACAAAFQAAAEACACQACABAEACIAIADIAIADIAFAFQABADAAAFQAAAIgFAFQgGAEgJAAQgGAAgFgCg");
	this.shape_21.setTransform(-36.825,122.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_22.setTransform(55.075,112.575);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQADAEAAAHIAAAbg");
	this.shape_23.setTransform(50.85,112.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgGABQgCABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACACADQABAEAAAFIAAAdIgHAAIgBgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_24.setTransform(46.05,112.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAMAeIAAgKIggAAIAAgGIAZgrIAJAAIgYApIAWAAIAAgMIAJAAIAAAeg");
	this.shape_25.setTransform(39.65,111.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_26.setTransform(33.825,111.975);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_27.setTransform(29.8,112.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgFABQgDABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACABADQACAEAAAFIAAAdIgGAAIgCgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQABABAEAAIAGgBIAGgEIAAgJg");
	this.shape_28.setTransform(25,112.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgDAFAAIAHABIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDABQgEACgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_29.setTransform(20.375,111.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQACAEABAHIAAAbg");
	this.shape_30.setTransform(15.65,112.525);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgFADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_31.setTransform(10.8,112.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_32.setTransform(6.175,113.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgKAdQgFgCgFgEIAEgGIAIAEQAEACAEAAQAGAAADgCQADgCAAgFQAAgDgCgCQgCgDgFgCIgIgCIgHgDQgDgCgCgDQgCgDAAgFQAAgFADgEQADgDAEgDQAEgBAFAAIAHAAIAGADIAGADIgFAHQgDgDgDgBQgDgBgFgBQgDAAgDACQgDACAAAFQAAAEACACQACABAEACIAIADIAIADIAFAFQABADAAAFQAAAIgFAFQgGAEgJAAQgGAAgFgCg");
	this.shape_33.setTransform(-0.825,111.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgTAeIAAg7IAnAAIAAAIIgeAAIAAARIAaAAIAAAHIgaAAIAAATIAeAAIAAAIg");
	this.shape_34.setTransform(-5.325,111.775);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgDAeIAAgzIgUAAIAAgIIAvAAIAAAIIgUAAIAAAzg");
	this.shape_35.setTransform(-10.45,111.775);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AALAeIgQgXIgHAAIAAAXIgIAAIAAg7IAUAAQAFAAAEACQAFADACAEQACAEAAAFQAAAFgCAFQgCADgFACIgFACIASAYgAgMAAIALAAQAFAAACgDQADgCAAgGQAAgFgDgDQgCgDgFAAIgLAAg");
	this.shape_36.setTransform(-15.15,111.775);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgTAeIAAg7IAnAAIAAAIIgeAAIAAARIAaAAIAAAHIgaAAIAAATIAeAAIAAAIg");
	this.shape_37.setTransform(-20.225,111.775);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgSAeIAAg7IAlAAIAAAIIgdAAIAAASIAaAAIAAAHIgaAAIAAAag");
	this.shape_38.setTransform(-24.975,111.775);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgSAeIAAg7IAlAAIAAAIIgdAAIAAASIAaAAIAAAHIgaAAIAAAag");
	this.shape_39.setTransform(-29.675,111.775);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgLAdQgGgDgEgEQgEgFgDgFQgCgGAAgGQAAgFACgHQADgFAEgEQAEgFAGgCQAFgCAGAAQAGAAAHACQAFACAEAFQAFAEABAGQADAGAAAFQAAAHgDAFQgBAFgFAFQgEAEgFADQgHACgGAAQgGAAgFgCgAgLgSQgEADgDAEQgDAGAAAFQAAAFADAGQADAFAEADQAFAEAGgBQAGAAAGgCQAFgEACgFQADgFAAgGQAAgFgDgFQgCgFgFgDQgGgEgGAAQgGAAgFAEg");
	this.shape_40.setTransform(-35.75,111.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQAEgFAEgDQAFgDAGAAQAJAAAGAFQAGAGAAALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgGADgHAAQgFAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_41.setTransform(41.1,101.775);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgDgFAAgHQAAgGADgFQADgFAFgDQAFgDAFAAQAIAAAEADQAFADADAGIgHADIgFgGQgDgCgFAAQgDAAgDACIgFAGQgCADAAAEQAAAEADAEQABADADACQAEACADAAQAFAAADgCQADgCACgDIAGAFQgDAEgFADQgFADgHAAQgFAAgFgDg");
	this.shape_42.setTransform(36.65,101.775);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQADAEAAAHIAAAbg");
	this.shape_43.setTransform(31.95,101.725);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgCgCQgCgCgGAAIgGABQgCABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACACADQABAEAAAFIAAAdIgHAAIgBgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_44.setTransform(27.15,101.775);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_45.setTransform(23.475,101.175);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_46.setTransform(20.025,101.775);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_47.setTransform(17.25,100.825);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_48.setTransform(14.475,101.775);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_49.setTransform(10.825,101.775);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AAUAeIgHgRIgZAAIgHARIgJAAIAYg7IAJAAIAYA7gAAKAFIgKgZIgJAZIATAAg");
	this.shape_50.setTransform(6.075,100.975);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgRAdQgFgCgCgEQgDgDAAgGQAAgEACgDIAGgGIAEgBIgFgGQgDgEAAgGQAAgDACgEQACgDAEgCQAEgCAGAAQAFAAADABQADADACADQACADAAAEQAAAFgCADQgCADgEACIgFADIANANIABgDQACgEABgGIAHAAQgBAKgEAHIAAABIAMAMIgKAAIgHgGIgEAEQgGADgHAAQgGAAgFgCgAgLAEIgGAFQgCACAAADQAAAEABACIAFACQADACAEAAQAEAAACgCIAGgDIgQgQgAgLgXIgDADIgBAFQAAADADADIAEAFIAEgCQADgCABgCQADgCAAgEQAAgDgDgDQgBgBgEAAIgGAAg");
	this.shape_51.setTransform(-1.575,101);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQAEgFAFgDQAEgDAGAAQAJAAAGAFQAGAGgBALIAAACIghAAIACAGQABADAEACQADACAEAAQAFAAADgCIAFgEIAGAEQgDAEgEADQgGADgHAAQgFAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgEADgBADIgBADIAYAAIAAAAg");
	this.shape_52.setTransform(-8.95,101.775);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAABABQgBAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_53.setTransform(-12.25,100.825);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_54.setTransform(-14.875,101.175);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQADAEAAAHIAAAbg");
	this.shape_55.setTransform(-18.9,101.725);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgGABQgCABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACABADQACAEAAAFIAAAdIgHAAIgBgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_56.setTransform(-23.7,101.775);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIACAFIACgDIAGgCIAGgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_57.setTransform(-26.75,101.725);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgOAUQgDgDAAgGQgBgDACgDIAEgEIAJgCIANgDIAAgDQAAgEgCgCQgCgCgFAAIgHABQgBABgBADIgIgCQABgGAFgCQAFgCAGAAQAFAAAEABQAFACACADQACAEAAAFIAAAdIgIAAIgBgEQgDADgEABQgDABgEAAQgFAAgFgDgAgBAFIgGACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_58.setTransform(-30.75,101.775);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgJAdQgFgDgFgEQgEgFgCgFQgDgGAAgGQAAgFADgGQACgGAEgEQAFgFAFgCQAGgCAGAAQAIAAAGADQAHAEAEAFIgHAFQgDgEgEgDQgFgCgGAAQgGAAgFAEQgFADgDAEQgDAGAAAFQAAAGADAFQADAFAFAEQAFACAGAAQAGABAFgDIAGgFIAAgKIgRAAIAAgGIAaAAIAAAUQgFAFgGAEQgHADgIAAQgGAAgGgCg");
	this.shape_59.setTransform(-35.975,101);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AAZAXIAAgaQAAgGgCgDQgCgCgFAAQgFAAgCABIgFAEIAAAFIAAAbIgIAAIAAgaQAAgGgCgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIACAFIAFgEQAEgCAEAAQAFAAADACQADABABADIAHgEQAEgCAGAAQAEAAAEACQADABACAEQACAEABAHIAAAbg");
	this.shape_60.setTransform(48.9,90.925);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AAIAgIgSgVIAAAVIgIAAIAAg+IAIAAIAAAiIARgQIAKAAIgTAUIAVAYg");
	this.shape_61.setTransform(43.225,90.05);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgLAbQgFgEgCgGQgDgIAAgJQAAgIADgHQACgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQADAHAAAIQAAAJgDAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGABAKQgBALAEAGQAEAGAFgBQAHABADgGQAEgGAAgLQAAgKgEgGQgDgGgHAAQgFAAgEAGg");
	this.shape_62.setTransform(36.15,90.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgLAbQgFgEgDgGQgCgIAAgJQAAgIACgHQADgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHABAIQgBAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGABAKQgBALAEAGQAEAGAFgBQAGABAEgGQADgGABgLQgBgKgDgGQgEgGgGAAQgFAAgEAGg");
	this.shape_63.setTransform(30.85,90.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgLAbQgFgEgDgGQgCgIAAgJQAAgIACgHQADgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHABAIQgBAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgDAGAAAKQAAALADAGQAEAGAFgBQAGABAEgGQADgGABgLQgBgKgDgGQgEgGgGAAQgFAAgEAGg");
	this.shape_64.setTransform(25.55,90.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgLAbQgFgEgCgGQgEgIAAgJQAAgIAEgHQACgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHAAAIQAAAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGAAAKQAAALAEAGQAEAGAFgBQAHABADgGQAEgGgBgLQABgKgEgGQgDgGgHAAQgFAAgEAGg");
	this.shape_65.setTransform(18.3,90.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AANAeIAAgKIghAAIAAgGIAZgrIAJAAIgYApIAXAAIAAgMIAIAAIAAAeg");
	this.shape_66.setTransform(13.2,90.175);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgPAnIAWhNIAJAAIgXBNg");
	this.shape_67.setTransform(9.425,90.825);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_68.setTransform(6.225,90.975);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_69.setTransform(3.45,90.025);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgKAUQgGgDgDgFQgDgFAAgHQAAgGADgFQADgFAGgDQAEgDAGAAQAGAAAFADQAGADADAFQADAFAAAGQAAAHgDAFQgDAFgGADQgFADgGAAQgGAAgEgDgAgHgNQgDADgBADQgCADgBAEQABAEACAEQABADADACQADACAEAAQAEAAAEgBQACgCACgEQADgEAAgEQAAgDgDgEQgCgDgCgCQgEgDgEAAQgEAAgDACg");
	this.shape_70.setTransform(0.05,90.975);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AAZAXIAAgaQAAgGgCgDQgCgCgFAAQgFAAgDABIgEAEIAAAFIAAAbIgHAAIAAgaQgBgGgCgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQACABABADIAHgEQAEgCAGAAQAEAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_71.setTransform(-6.25,90.925);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgKAdQgFgCgDgFQgCgEAAgFQAAgFACgEQADgEAEgBQgDgCgBgDQgCgEAAgEQAAgFACgEQACgDAFgCQAEgCAEAAQAFAAAEACQAEACADADQACAEAAAFQAAAEgCAEQgCADgDACQAFABACAEQADAEAAAFQAAAFgDAEQgCAFgFACQgFACgGAAQgFAAgFgCgAgGADQgDACgBACQgCACAAADQAAAGAEADQADADAFAAQAFAAAEgDQAEgDAAgGQAAgDgCgCIgFgEQgCgCgEABQgDgBgDACgAgGgVQgDADAAAEQAAAEADADQADADADgBQAEABADgDQACgDAAgEQAAgEgCgDQgDgCgEAAQgDAAgDACg");
	this.shape_72.setTransform(-14.525,90.2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AANAeIAAgKIghAAIAAgGIAZgrIAJAAIgYApIAXAAIAAgMIAIAAIAAAeg");
	this.shape_73.setTransform(-19.45,90.175);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgZAeIAAg7IAVAAQAGAAAFACQAGADAEAEQAEAEADAFQACAGAAAFQAAAGgCAGQgDAFgEAEQgEAFgGACQgFACgGAAgAgRAWIANAAQAEAAAEgBIAHgFIAEgHQACgEAAgFQAAgDgCgEIgEgHQgDgEgEgBQgEgCgEAAIgNAAg");
	this.shape_74.setTransform(-26.475,90.175);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgSAeIAAg7IAIAAIAAAzIAdAAIAAAIg");
	this.shape_75.setTransform(-31.825,90.175);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgSAeIAAg7IAIAAIAAAzIAdAAIAAAIg");
	this.shape_76.setTransform(-36.475,90.175);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgFAdQgGgDgEgEQgDgFgCgFIgBgBIgGAAIAAgIIAEAAIAAgDIAAgDIgEAAIAAgHIAGAAIABgBQACgGADgEQAEgFAGgCQAFgCAGAAQAHAAAFADQAHADADAGIgHAFQgCgEgEgDQgEgCgFAAQgGAAgEAEQgFADgCAEIAAABIAYAAIgBAHIgaAAIAAADIAAADIAYAAIgBAIIgUAAIAAAAQACAFAFAEQAEACAGAAQAFABAEgDQAEgDACgDIAHAFQgDAFgHAEQgFADgHAAQgGAAgFgCg");
	this.shape_77.setTransform(87.35,79.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgLAbQgFgEgCgGQgDgIAAgJQAAgIADgHQACgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQADAHAAAIQAAAJgDAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgDAGAAAKQAAALADAGQAEAGAFgBQAGABAEgGQAEgGAAgLQAAgKgEgGQgEgGgGAAQgFAAgEAGg");
	this.shape_78.setTransform(79.7,79.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgLAbQgFgEgCgGQgDgIAAgJQAAgIADgHQACgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQADAHAAAIQAAAJgDAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGABAKQgBALAEAGQAEAGAFgBQAHABADgGQAEgGAAgLQAAgKgEgGQgDgGgHAAQgFAAgEAGg");
	this.shape_79.setTransform(74.4,79.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgLAbQgFgEgDgGQgCgIAAgJQAAgIACgHQADgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHABAIQgBAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGABAKQgBALAEAGQAEAGAFgBQAHABADgGQADgGABgLQgBgKgDgGQgDgGgHAAQgFAAgEAGg");
	this.shape_80.setTransform(69.1,79.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AAMAeIAAgKIggAAIAAgGIAYgrIAJAAIgXApIAWAAIAAgMIAJAAIAAAeg");
	this.shape_81.setTransform(62.05,79.375);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgEgFAAgHQAAgGAEgFQACgFAGgDQAFgDAFAAQAKAAAFAFQAFAGAAALIAAACIghAAIACAGQABADAEACQAEACADAAQAFAAADgCIAFgEIAGAEQgCAEgGADQgFADgGAAQgGAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgEADgBADIgCADIAZAAIAAAAg");
	this.shape_82.setTransform(55.55,80.175);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgCAFgBIAHABIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDABQgEACgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_83.setTransform(50.575,79.3);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIACAFIACgDIAGgCIAGgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_84.setTransform(45.25,80.125);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQADgFAFgDQAFgDAGAAQAKAAAFAFQAGAGAAALIAAACIgiAAIACAGQACADADACQADACAEAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgGADgHAAQgFAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_85.setTransform(41.2,80.175);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgLAgIAIgUIgSgrIAKAAIALAhIANghIAJAAIgYA/g");
	this.shape_86.setTransform(36.725,81.175);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgLAUQgFgDgDgFQgDgFAAgHQAAgGADgFQADgFAFgDQAGgDAFAAQAGAAAFADQAFADAEAFQADAFAAAGQAAAHgDAFQgEAFgFADQgEADgHAAQgFAAgGgDgAgGgNQgEADgCADQgCADAAAEQAAAEACAEQACADAEACQADACADAAQAEAAAEgBQADgCABgEQACgEAAgEQAAgDgCgEQgBgDgDgCQgEgDgEAAQgDAAgDACg");
	this.shape_87.setTransform(32.15,80.175);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgDAgIAAg+IAHAAIAAA+g");
	this.shape_88.setTransform(28.725,79.25);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIABAFIAEgDIAEgCIAHgBIgBAJIgGAAIgEACIgDADIAAAfg");
	this.shape_89.setTransform(24.75,80.125);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgFADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_90.setTransform(20.7,80.175);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_91.setTransform(17.4,79.225);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AAZAXIAAgaQAAgGgCgDQgCgCgFAAQgFAAgDABIgEAEIAAAFIAAAbIgHAAIAAgaQgBgGgCgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQACABABADIAHgEQAEgCAGAAQAEAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_92.setTransform(12.65,80.125);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgEgFAAgHQAAgGAEgFQADgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQABADAEACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgFADQgFADgGAAQgGAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgEADgBADIgCADIAZAAIAAAAg");
	this.shape_93.setTransform(6.4,80.175);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIABAFIAEgDIAEgCIAGgBIAAAJIgGAAIgEACIgDADIAAAfg");
	this.shape_94.setTransform(3,80.125);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_95.setTransform(-0.975,81.125);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_96.setTransform(-8,80.125);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgKAVQgEgBgCgEQgCgEAAgHIAAgbIAIAAIAAAaQAAAGACADQADACAFAAQADAAACgBIAFgFIAAgfIAJAAIAAAsIgHAAIgBgFIgGAEQgDACgEAAQgFAAgDgCg");
	this.shape_97.setTransform(-12.925,80.225);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_98.setTransform(-19.075,80.175);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgJAeQgGgDgDgFQgCgFAAgHQAAgHACgEQAEgFAEgEQAFgCAGgBQAJABAGAFQAGAGAAAJIAAAEIgiAAIACAFQACAEADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgGADgHAAQgFAAgFgDgAANAFQgBgFgCgCQgDgDgGAAQgDAAgDACQgDACgCADIgBADIAYAAIAAAAgAgDgRIgNgPIAKAAIAKAPg");
	this.shape_99.setTransform(-23.25,79.2);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIABAFIADgDIAFgCIAHgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_100.setTransform(-26.65,80.125);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_101.setTransform(-30.625,81.125);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AAUAeIgHgRIgZAAIgHARIgJAAIAYg7IAJAAIAYA7gAAKAFIgKgZIgJAZIATAAg");
	this.shape_102.setTransform(-36.225,79.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.offer2, new cjs.Rectangle(-41.3,71.9,183.5,58), null);


(lib.offer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D356B").s().p("AABALIgPAYIgMgJIAQgWIgagHIAFgOIAZAJIAAgaIAMAAIAAAaIAagJIAFAOIgZAHIAPAWIgMAJg");
	this.shape.setTransform(-68.75,-17.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2 copy 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D356B").s().p("AgPAmQgJgDgFgFIAHgKQAFADAGACQAHADAGAAQAHAAAEgDQADgCAAgFQAAgDgCgDQgCgDgHgCIgKgDQgKgDgFgEQgGgGAAgJQABgGADgFQADgFAGgCQAGgDAIAAQAIAAAHACQAGADAFAEIgHAKIgJgFIgLgBQgFAAgEACQgDADAAADQABAEACACQADADAFACIALADQAKAEAFAEQAFAGAAAIQAAAKgHAGQgHAGgOAAQgKAAgHgCg");
	this.shape_1.setTransform(-69.4,17.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1D356B").s().p("AgHA3IAAhMIAOAAIAABMgAgGglQgDgEAAgDQAAgFADgCQADgDADAAQAEAAADADQADACAAAFQAAADgDAEQgDADgEAAQgDAAgDgDg");
	this.shape_2.setTransform(-74.075,16.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1D356B").s().p("AgTAjQgJgFgGgJQgFgJAAgMQAAgKAFgJQAGgJAJgGQAJgFAKAAQALAAAJAFQAJAFAFAKQAGAJAAAKQAAAMgGAJQgFAJgJAFQgJAFgLAAQgKAAgJgFgAgMgWQgGADgDAGQgDAGAAAHQAAAIADAGQADAGAGAEQAGADAGAAQAHAAAGgDQAGgEADgGQADgGAAgIQAAgGgDgHQgDgGgGgDQgGgEgHAAQgGAAgGAEg");
	this.shape_3.setTransform(-79.925,17.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1D356B").s().p("AAsAnIAAguQAAgKgEgEQgDgEgKAAQgHAAgFACQgEADgEAEIABAIIAAAvIgOAAIAAguQAAgKgEgEQgDgEgKAAQgGAAgFACQgEADgEAFIAAA2IgPAAIAAhLIAMAAIACAHQAFgEAFgCQAGgDAIAAQAIAAAGADQAFABADAGQAFgFAGgCQAHgDAJAAQAJAAAGADQAGACAEAHQADAGAAAMIAAAvg");
	this.shape_4.setTransform(-90.775,17.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D356B").s().p("AgaBEIAniHIAPAAIgoCHg");
	this.shape_5.setTransform(-100.15,17.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer_2 copy
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D356B").s().p("AgTBcQgRgHgNgOQgNgOgHgSIgCgEIgTAAIAAgXIAPAAIgBgMIABgKIgPAAIAAgXIATAAIACgFQAHgSANgOQANgNARgIQARgIATAAQAXAAAUALQATAKAMASIgWAQQgIgNgOgHQgNgIgRAAQgTAAgOALQgPAKgHAQIgBACIBRAAIgFAXIhSAAIgBAKIABAMIBPAAIgEAXIhFAAIABABQAHARAPAKQAOAKATAAQARAAANgIQAOgIAIgMIAWAQQgMASgTAKQgUALgXAAQgTAAgRgIg");
	this.shape_6.setTransform(-84.45,-6.075);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	// Layer_2
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D356B").s().p("AhECnIBOhuIgRABQgiAAgbgNQgagOgPgZQgQgXABgjQgBggAQgZQAOgaAcgQQAcgPAnAAQAoAAAcAPQAcAPAPAaQAPAaAAAgQAAASgIAXQgHAWgVAdIhaB/gAgsheQgRAQAAAaQAAAaARARQAQAOAdAAQAdAAAQgOQAQgRABgaQgBgagQgQQgQgQgegBQgdABgPAQg");
	this.shape_7.setTransform(-115.8,4.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D356B").s().p("Ag9CdQgYgLgOgSQgPgTgFgXIA7gRQADASAPALQAPALAbAAQAbAAAPgOQAPgNAAgXQAAgYgPgNQgPgMgbAAIgnAAIAAgmIBAhSIh+AAIAAg4IDMAAIAAAuIhDBTQAeAFASAOQATAPAJAUQAJAVgBAXQAAAfgPAYQgOAYgbANQgbAOgnAAQgiAAgZgKg");
	this.shape_8.setTransform(-143.4737,4.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D356B").s().p("AhtCnIAAgwIB8h/IARgTQAHgKADgIQADgJAAgJQAAgUgLgMQgLgMgXAAQgZgBgMAMQgLAMgCAVIg+gKQAFgcANgVQANgVAXgMQAXgLAjAAQAhAAAYAMQAYANANAVQANAWAAAcQAAAPgDAOQgDAPgKAPQgKAPgSARIhVBbICHAAIAAA3g");
	this.shape_9.setTransform(-169.625,4.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]}).wait(1));

	// text
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgQAiQgJgGgFgJQgFgIAAgLQAAgKAFgJQAFgIAJgGQAIgFAKABQAPAAAKAJQAJAJAAASIAAAEIg5AAQABAGACAEQAEAGAFADQAGAEAGAAQAIAAAGgEQAFgDADgFIAKAHQgEAIgJAFQgIAEgLAAQgKAAgJgEgAAWgIQgBgHgFgEQgEgGgKAAQgGAAgFADQgGAEgDAFIgCAFIAqAAIAAAAg");
	this.shape_10.setTransform(-113.85,-21.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AgRAwQgJgFgEgJQgFgIABgLQAAgLAEgIQAFgJAJgFQAJgFAJAAIALABIAIAEIAAgiIAPAAIAABoIgMAAIgCgHQgEADgGADQgFACgHAAQgKAAgHgFgAgJgHQgFAEgDAEQgEAGAAAIQAAAHAEAGQACAGAGADQAEADAHAAQAFAAAFgCQAFgCAEgEIAAgjQgDgEgFgCQgEgBgGAAQgGAAgGADg");
	this.shape_11.setTransform(-122.65,-22.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgSAmIAAhKIALAAIACAIIAGgFIAIgDIAKgBIgBAOIgJABQgFABgDACIgFAFIAAA0g");
	this.shape_12.setTransform(-132.675,-21.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgGA1IAAhJIANAAIAABJgAgGgkQgDgDAAgEQAAgEADgCQADgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDADgEAAQgDAAgDgDg");
	this.shape_13.setTransform(-137.55,-22.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgHAqQgGgGAAgLIAAgnIgNAAIAAgMIANAAIAAgWIAOAAIAAAWIAZAAIAAAMIgZAAIAAAhQAAAJACAEQABAEAHAAIAGgBIAGgCIAFALQgFADgFABIgJABQgLAAgFgHg");
	this.shape_14.setTransform(-142.45,-22.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgSAmIAAhKIALAAIACAIIAGgFIAIgDIAKgBIgBAOIgJABQgFABgDACIgFAFIAAA0g");
	this.shape_15.setTransform(-147.475,-21.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgXAiQgHgGAAgKQAAgFADgEQACgEAFgEQAGgBAJgCIAWgGIAAgEQAAgHgEgEQgEgCgIAAQgIAAgDABQgDACgCAFIgNgEQADgJAIgEQAIgEAKABQAKAAAGACQAHADADAFQAEAGAAAIIAAAyIgMAAIgCgHQgGAEgGACQgFACgHAAQgKAAgGgEgAgDAIQgHABgDACQgDADAAAEQAAAFAEACQADACAFAAQAFAAAFgCQAGgDAFgEIAAgPg");
	this.shape_16.setTransform(-154.625,-21.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgjA2IAAhqIALAAIADAHQADgEAHgCQAFgCAGAAQAKAAAIAEQAIAGAFAIQAEAJAAALQAAALgEAIQgGAJgIAFQgIAFgJAAQgGAAgGgDQgFgBgDgDIAAAmgAgMgnQgFACgDAEIAAAiQADAEAFADQAFACAGAAQAGAAAFgDQAFgEADgEQADgGAAgIQAAgHgDgGQgCgGgGgDQgFgEgGAAQgGAAgFACg");
	this.shape_17.setTransform(-162.3,-19.625);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AAhBDIgMgdIgqAAIgLAdIgPAAIAnhjIAQAAIAoBjgAARAaIgRgsIgRAsIAiAAgAgGgqIgVgYIARAAIARAYg");
	this.shape_18.setTransform(-175.9,-24.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.offer, new cjs.Rectangle(-184.8,-33.7,463.2,100.7), null);


(lib.logo_Citroen_horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// white_left
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhTD2QgmgUgeglQgdglgRgwQgRgyAAg2QAAg1ARgyQARgwAdglQAeglAmgUQApgVAqAAQAsAAAoAVQAnAUAdAlQAeAlAQAwQARAyAAA1QAAA2gRAyQgQAwgeAlQgdAlgnAUQgoAVgsAAQgqAAgpgVgAiaCLIAAABQAbAwApAbQApAbAtAAQAuAAApgbQApgbAbgwIABgBIichzgACwBdIAAgBQAEgOADgPIACgNIi5iIIi3CIIgBAAIACANQADAPAFAOIAAABICuiCgAC+gIIAAAAQgBgvgPgrQgPgqgbghQgbghgigRQgigSglAAQgkAAgiASQgiARgaAhQgbAhgPAqQgPArgCAvIAAAAIC9iMg");
	this.shape.setTransform(21.5,26.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXBaQgsgBgbgZQgbgZAAgnIAAAAQAAgRAHgRQAGgQANgMQANgNATgHQASgGAWgBIAAAAIAkgBIBIAAIAlAAIAAAjIhqgBIgYABIgLAAIgBAAIgBAAQgaABgQAPQgPAQAAAXQgBAZARAPQAPAOAbABIAiABIBsAAIAAAiIg7ABQhEAAgSgBg");
	this.shape_1.setTransform(70.85,28.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibBFQgcAAgVgUQgUgUAAgcQAAgcAUgUQAUgVAdAAIE4AAQAcAAAVAVQATAUABAcQgBAcgTAUQgVAUgcAAg");
	this.shape_2.setTransform(196.1933,16.2232,0.19,0.1902);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ApGHfIAAu9ISNAAIAAC1Iu3AAIAADPINCAAIAACtItCAAIAADXIO3AAIAAC1g");
	this.shape_3.setTransform(201.4089,28.8991,0.19,0.1902);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjAHzQjsgFiRiKQiRiJAAjaIAAgBQAAhmAlhZQAkhbBFhCQBHhGBigmQBhgmB1gEIADAAIAzgCQBBgCBGAAQBdAABoAEQDsAKCRCJQCRCKAADVIAAABQAABmglBaQgkBZhFBDQhHBGhiAmQhhAnh1ADIgDAAQhKAEhwAAQhuAAhXgEgAmWjhQhUBUAACLQAACMBVBUQBVBUCSAEIADAAQBdAEBcAAQBtAAAugEIAIAAQCRgGBUhUQBUhUABiKIAAgBQAAiMhVhTQhVhTiVgHIgJAAQhUgEg5AAQhEAAhEACIg2ACIgEAAIgFAAQiRAHhUBUg");
	this.shape_4.setTransform(171.3933,28.8991,0.19,0.1902);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AqpHfIAAu9IPCAAQCmAABdBOQBdBNAACJQAACYhWA/QhYBCjbAFIhqAAIIkF3Ik3AAIqRnbIAAg3IIbAAQBdADAmgoQAcgeAAg8QAAg5ghgcQghgdhAgBIrtAAIAAMIg");
	this.shape_5.setTransform(140.7364,28.8991,0.19,0.1902);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AibBFQgcAAgVgUQgUgUgBgcQABgcAUgUQAUgVAdAAIE5AAQAcAAATAVQAUAUAAAcQAAAbgUAVQgTAUgcAAg");
	this.shape_6.setTransform(206.5675,16.2232,0.19,0.1902);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AGnHfIAAncQAAihhYhJQhQhCigAAIoFAAIAAMIIjVAAIAAu9IMNAAQD1ABCBCDQB0B3AADMIAAH2g");
	this.shape_7.setTransform(230.2513,28.8991,0.19,0.1902);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhqHfIAAu9IDVAAIAAO9g");
	this.shape_8.setTransform(91.749,28.8278,0.19,0.1902);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgUBbIAAiTIhmAAIAAgiID1AAIAAAiIhnAAIAACTg");
	this.shape_9.setTransform(110.8,28.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_Citroen_horizontal, new cjs.Rectangle(0,0,242.4,53.5), null);


(lib.img11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img11, new cjs.Rectangle(0,0,600,400), null);


(lib.hero = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// heroFR.png
	this.instance = new lib.heroFR();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.hero, new cjs.Rectangle(0,0,600,400), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIA+AAIAAARIgsAAIAAAVIAoAAIAAAPIgoAAIAAAXIAtAAIAAARg");
	this.shape.setTransform(181.3,21.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAvIgXgiIgKAAIAAAiIgSAAIAAhdIAkAAQAJAAAHAEQAHADAEAIQAEAGAAAIQAAAJgEAHQgEAGgIADIgFADIAbAkgAgSgCIAQAAQAGAAAEgDQAEgEAAgHQAAgHgEgEQgEgEgGABIgQAAg");
	this.shape_1.setTransform(172.825,21.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLAvIghhdIATAAIAZBKIAahKIATAAIghBdg");
	this.shape_2.setTransform(163.15,21.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVArQgJgFgEgJQgEgJAAgNIAAg2IASAAIAAA2QAAAIACAFQADAFAEADQAFACAGAAQAHAAAFgCQAEgDADgFQACgFAAgIIAAg2IASAAIAAA2QAAANgEAJQgEAJgJAFQgJAFgNAAQgMAAgJgFg");
	this.shape_3.setTransform(153.475,21.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAtQgJgEgHgHQgHgGgDgJQgEgJAAgKQAAgJAEgJQADgIAHgIQAHgGAJgEQAIgDAKAAQAKAAAJADQAJAEAHAHQAGAHAEAIQAEAJAAAJQAAAKgEAJQgEAJgGAGQgHAHgJAEQgJAEgKAAQgKAAgIgEgAgPgaQgGAFgEAHQgEAHAAAHQAAAIAEAHQAEAHAGAEQAHAFAIAAQAJAAAHgFQAGgDAEgHQAEgIAAgIQAAgHgEgHQgEgHgGgEQgHgEgJAAQgIAAgHADg");
	this.shape_4.setTransform(143.025,21.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOAtQgJgEgGgHQgHgGgEgJQgDgJAAgKQAAgJADgJQAEgJAHgGQAGgHAJgEQAJgDAJAAQANAAALAFQAKAFAGAJIgOALQgEgGgHgDQgGgDgIAAQgIAAgHADQgHAFgEAHQgDAHAAAHQAAAIADAIQAEAHAHADQAHAFAHAAQAJAAAGgEQAHgDAEgGIAOALQgGAJgLAFQgKAFgNABQgJAAgJgEg");
	this.shape_5.setTransform(132.775,21.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfA/IAAhdIA+AAIAAARIgsAAIAAAUIAoAAIAAAQIgoAAIAAAXIAtAAIAAARgAgIgmIAPgYIAVAAIgVAYg");
	this.shape_6.setTransform(123.85,19.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpAvIAAhdIAkAAQAJAAAJAEQAJAEAGAGQAHAHAEAIQADAIAAAJQAAAJgDAJQgEAJgGAHQgHAGgJADQgJAEgJAAgAgXAfIASAAQAFAAAGgDQAFgCAEgEQAEgFACgFQACgGAAgGQAAgFgCgFQgCgFgEgFQgEgEgFgDQgGgCgFAAIgSAAg");
	this.shape_7.setTransform(114.575,21.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIA+AAIAAARIgsAAIAAAVIAoAAIAAAPIgoAAIAAAXIAtAAIAAARg");
	this.shape_8.setTransform(102,21.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgNAvIgHgBIAFgQIAEABIADAAQAGAAACgCQACgDAAgGIAAhDIATAAIAABEQAAAMgHAIQgHAHgMAAg");
	this.shape_9.setTransform(94.4,21.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7A99AC").s().p("AmZCyQhJAAg1g1Qg0gzAAhKQAAhIA0g1QA1g0BJAAIMzAAQBJAAA0A0QA1A1AABIQAABKg1AzQg0A1hJAAg");
	this.shape_10.setTransform(140.275,20.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(50,2.9,180.6,36.6), null);


(lib.arcRightUp = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsEK8QgHhpAhiAQBfmBEOkWQEtkSGXjlIG/ACQsGGBjxDcQkvD6gVDRQgzDBB1CMg");
	mask.setTransform(426.4189,69.775);

	// Layer_2 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AiHO1QnmhGlUikQjziGgnjOQgdiDAuivQBemAEPkXQEskSGYjkIG/ABQsFGBjyDcQkvD8gWDQQhEEDDqCjQEHDCPvAqINhAbIAAG7Qq7g0qzhhg");
	mask_1.setTransform(474.4908,109.55);

	// Layer_1
	this.instance = new lib.img2();
	this.instance.setTransform(0,0,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arcRightUp, new cjs.Rectangle(349,0,251,219.3), null);


(lib.arcLeftUp = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Aq/TTIgwgsQrcB2HgqtQENpKG+oYQF1mCHPlcIKGgCQqaGloAHKQpVHxgMG+QAUGJErDNIgFAxg");
	mask.setTransform(262.0683,122.5);

	// Layer_2 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AIVfKQwEnotYpXQiwifiEi2QhIgjgdgVIiEhvQrcB2HgqsQENpKG+oYQF2mDHPlcIKFgBQqZGkoAHLQpWHygMG9QAUGIFGDoIgBgBIAOAMQGpFqOmEYQSHGDSoFDIgIDyg");
	mask_1.setTransform(376.1683,201.65);

	// Layer_1
	this.instance = new lib.img2();
	this.instance.setTransform(0,0,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arcLeftUp, new cjs.Rectangle(142.7,0,457.3,400), null);


(lib.subRandom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// subRandom3
	this.subRandom3 = new lib.subRandom3();
	this.subRandom3.name = "subRandom3";
	this.subRandom3.setTransform(80.1,16.4,1,1,0,0,0,61.1,16.9);

	this.timeline.addTween(cjs.Tween.get(this.subRandom3).wait(1));

	// subRandom2
	this.subRandom2 = new lib.subRandom2();
	this.subRandom2.name = "subRandom2";
	this.subRandom2.setTransform(112.95,12.05,1,1,0,0,0,47.6,12.6);

	this.timeline.addTween(cjs.Tween.get(this.subRandom2).wait(1));

	// subRandom1
	this.subRandom1 = new lib.subRandom1();
	this.subRandom1.name = "subRandom1";
	this.subRandom1.setTransform(103.05,16.4,1,1,0,0,0,56.1,16.9);

	this.timeline.addTween(cjs.Tween.get(this.subRandom1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom, new cjs.Rectangle(0,-0.5,162,23.2), null);


(lib.nota = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.instance = new lib.Symbol1();
	this.instance.setTransform(0.1,0.05,1,1,0,0,0,529.9,532);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.nota, new cjs.Rectangle(-530,-532,1060,1064), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A/LfMQs7s7AAyRQAAyQM7s7QM6s7SRAAQSRAAM7M7QM7M7AASQQAASRs7M7Qs7M7yRAAQyRAAs6s7g");
	mask.setTransform(343.35,155.15);

	// arcRightUp
	this.arcRightUp = new lib.arcRightUp();
	this.arcRightUp.name = "arcRightUp";
	this.arcRightUp.setTransform(600,400,1,1,0,0,0,600,400);

	var maskedShapeInstanceList = [this.arcRightUp];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.arcRightUp).wait(1));

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Eg4tA4uUgXggXgAAAghOUAAAghNAXggXgUAXggXgAhNAAAUAhPAAAAXfAXgUAXgAXgAAAAhNUAAAAhOgXgAXgUgXfAXgghPAAAUghNAAAgXggXgg");
	mask_1.setTransform(136.9,235.375);

	// arcLeftUp
	this.arcLeftUp = new lib.arcLeftUp();
	this.arcLeftUp.name = "arcLeftUp";
	this.arcLeftUp.setTransform(600,400,1,1,0,0,0,600,400);

	var maskedShapeInstanceList = [this.arcLeftUp];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.arcLeftUp).wait(1));

	// img11
	this.img11 = new lib.img11();
	this.img11.name = "img11";
	this.img11.setTransform(300,200,1,1,0,0,0,300,200);

	this.timeline.addTween(cjs.Tween.get(this.img11).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_1, new cjs.Rectangle(0,-0.9,609.7,405.2), null);


(lib.ani = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// hero
	this.hero = new lib.hero();
	this.hero.name = "hero";
	this.hero.setTransform(217,170.8,1,1,0,0,0,217,170.8);

	this.timeline.addTween(cjs.Tween.get(this.hero).wait(1));

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(263.95,168.95,1.1032,1.1032,0,0,0,263.9,171.9);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ani, new cjs.Rectangle(-442.5,-327.4,1132.7,1132.8), null);


(lib.aniBox = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// aniGuide
	this.aniGuide = new lib.ani();
	this.aniGuide.name = "aniGuide";
	this.aniGuide.setTransform(-83.75,-55.5,0.73,0.73);

	this.timeline.addTween(cjs.Tween.get(this.aniGuide).wait(1));

	// ani
	this.ani = new lib.ani();
	this.ani.name = "ani";
	this.ani.setTransform(-174.25,-57);

	this.timeline.addTween(cjs.Tween.get(this.ani).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aniBox, new cjs.Rectangle(-616.7,-384.4,1132.6,1132.8), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var aniBox = this.aniBox;
		var ani = this.aniBox.ani;
		var aniGuide = this.aniBox.aniGuide;
		var hero = this.aniBox.ani.hero;
		var img1 = this.aniBox.ani.img1;
		var arcRightUp = this.aniBox.ani.img1.arcRightUp;
		var arcRightDown = this.aniBox.ani.img1.arcRightDown;
		var arcLeftUp = this.aniBox.ani.img1.arcLeftUp;
		var arcLeftDown = this.aniBox.ani.img1.arcLeftDown;
		var img11 = this.aniBox.ani.img1.img11;
		
		
		var img3=this.img3;
		var img4=this.img4;
		var nota = this.nota;
		
		var white = this.white;
		var white2 = this.white2;
		
		var txt1 = this.txt1;
		var txt1Guide = this.txt1Guide;
		var txt2 = this.txt2;
		var txt3 = this.txt3;
		var txt3 = this.txt3;
		var txt4 = this.txt4;
		var txt5 = this.txt5;
		
		var offer= this.offer;
		var offer2= this.offer2;
		
		var sub1= this.sub1;
		var sub2= this.sub2;
		var sub3= this.sub3;
		
		var cta = this.cta;
		
		var logo= this.logo;
		var logo_black = logo.logo_black;
		
		var r = 0;
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf);
			}
		}
		
		
		var subRandom = this.subRandom;
		subRandom.visible = false;
		var toRandom = [subRandom.subRandom1, subRandom.subRandom2, subRandom.subRandom3];
		function randomSub() {
			
			var r = Math.floor(Math.random() * toRandom.length) + 1;
			for (var i = 0; i < toRandom.length; i++) {
				if(r-1==i) {
					toRandom[i].visible = true;
				} else { 
					toRandom[i].visible = false;
				}
			}
			
			console.log(r + " / " + toRandom.length + " - " + toRandom[r-1]);
			//TweenMax.set([cta] ,{x: ctaGuide.x, y: ctaGuide.y});
			//TweenMax.set([sub2] ,{x: sub2Guide.x, y: sub2Guide.y});
			TweenMax.set([subRandom] ,{visible: true});
			
		}
		
		
		
		this.tl = tl = new TimelineMax({onStart:getTime, repeat: 1, repeatDelay:2, onRepeat:randomSub, onComplete:autoShot, onCompleteParams:[true]});
		this.tlBg = tlBg = new TimelineMax({paused: true, repeat:0, repeatDelay: 0});
		
		
		
		tl
			.set([aniGuide,txt1Guide], {visible: false})
		
		
			
			.add("frame1", "+=0")
			.from([logo], .5, {alpha: 0 }, "frame1")
			.add(function(){tlBg.play(0);}, "frame1")
			.add(autoShot)
		
			.add("frame2", "frame1+=3")
			.to([ani], .5, {x: aniGuide.x, y: aniGuide.y, scaleX: aniGuide.scaleX, scaleY: aniGuide.scaleY, ease: Power1.easeOut}, "frame2")
			.from([white], .5, {y:h, ease: Power1.easeOut}, "frame2")
			.from(nota, .5, {y: "+=20", alpha: 0, ease: Power1.easeOut}, "frame2")
			.from([txt1, txt2], .5, {y: "+=40", alpha: 0,  ease: Power2.easeOut}, "frame2+=.5")
			.add(autoShot)
		
			.add("frame2a", "frame2+=3")
			.to([txt2, nota], .5, {y: "+=20", alpha: 0,  ease: Power2.easeOut}, "frame2a")
			.from([txt3, sub1], .5, {y: "+=10", alpha: 0,  ease: Power2.easeOut}, "frame2a")
			.add(autoShot)
		
			.add("frame3", "frame2a+=3")
			.to([txt3, sub1], .5, {y: "+=20", alpha: 0,  ease: Power2.easeOut}, "frame3")
			.to([txt2, sub1], .5, {x: "-="+w, alpha: 0,  ease: Power2.easeOut}, "frame3")
			.from([txt4], .5, {y: "+="+w, alpha: 0,  ease: Power2.easeOut}, "frame3")
			.add(autoShot)
		
			/*
			.add("frame4", "frame3+=2.5")
			.to([txt4], .5, {alpha: 0,  ease: Power2.easeOut}, "frame4")
			.from([txt5], .5, {x: "-="+w, alpha: 0,  ease: Power2.easeOut}, "frame4")
			.add(autoShot)
			*/
		
			.add("frame5", "frame3+=3")
			.to([txt4], .5, {alpha: 0,  ease: Power2.easeOut}, "frame5")
			.to([txt1], .5, {y:"-="+42 , ease: Power2.easeOut}, "frame5")
			//.to([txt5], .5, {alpha: 0,  ease: Power2.easeOut}, "frame5")
			.from([offer, offer2, sub3], .5, {y: "+="+10, alpha: 0,  ease: Power2.easeOut}, "frame5")
			.add(autoShot)
		
			.add("frame6", "frame5+=3")
			.to([offer, offer2], .5, {x:"+="+(w/2),  ease: Power2.easeOut}, "frame6")
			//.to([sub3], .5, {x:"+="+210,  ease: Power2.easeOut}, "frame6+=.5")
			.from([cta], .5, {scaleY:0, ease: Power2.easeOut}, "frame6+=.5")
			.from([subRandom], .5, {y: "+="+(h/3), alpha: 0, ease: Power1.easeOut}, "frame6+=.5")
			
		
			
			
			//tlBg.timeScale(0.3);
			tlBg
			.to([img11], 1.25, {alpha: .75, /*yoyo:true, repeat:1,*/  ease: Power3.easeOut}, "frame1")
			.to([img11], 1.25, {alpha: 1, /*yoyo:true, repeat:1,*/  ease: Power3.easeOut}, "frame1+1.25")
			.from([img1], 2.5, {scaleX: 5, scaleY: 5,  ease: Power3.easeOut}, "frame1")
			.from([hero], 1, {scaleX: .5, scaleY: .5,  ease: Power2.easeOut}, "frame1+=.25")
			.from([hero], .25, {alpha: 0,  ease: Power2.easeOut}, "frame1+=.25")
			.from([arcRightUp.mask], 3.5, {scaleX: 0, scaleY: 0, ease: Power2.easeOut}, "frame1+=1.25")
			.from([arcLeftUp.mask], 3.5, {scaleX: 0, scaleY: 0, ease: Power2.easeOut}, "frame1+=1.25")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logo = new lib.logo_Citroen_horizontal();
	this.logo.name = "logo";
	this.logo.setTransform(13.45,12.75,0.6,0.6,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(79.45,489.85,1.1378,1.1378,0,0,0,140.2,20.8);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// subRandom
	this.subRandom = new lib.subRandom();
	this.subRandom.name = "subRandom";
	this.subRandom.setTransform(91,578.4,1,1,0,0,0,81,11.1);

	this.timeline.addTween(cjs.Tween.get(this.subRandom).wait(1));

	// nota
	this.nota = new lib.nota();
	this.nota.name = "nota";
	this.nota.setTransform(60.4,346.55,0.0806,0.0804);

	this.timeline.addTween(cjs.Tween.get(this.nota).wait(1));

	// sub3
	this.sub3 = new lib.sub3();
	this.sub3.name = "sub3";
	this.sub3.setTransform(48.7,581.7,1,1,0,0,0,47.2,7.2);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub1
	this.sub1 = new lib.sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(73.35,581.05,1,1,0,0,0,63.2,6.8);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	// offer2
	this.offer2 = new lib.offer2();
	this.offer2.name = "offer2";
	this.offer2.setTransform(220.3,492.45,1.07,1.07,0,0,0,27.4,100.9);

	this.timeline.addTween(cjs.Tween.get(this.offer2).wait(1));

	// offer
	this.offer = new lib.offer();
	this.offer.name = "offer";
	this.offer.setTransform(72.35,493.55,1.05,1.05,0,0,0,-124.5,2.1);

	this.timeline.addTween(cjs.Tween.get(this.offer).wait(1));

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(150,495.95,1,1,0,0,0,0,20.9);

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	// txt3
	this.txt3 = new lib.txt3();
	this.txt3.name = "txt3";
	this.txt3.setTransform(36,475.05);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(150,487.25,1,1,0,0,0,46,12.2);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(33.5,450.5);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// white
	this.white = new lib.white();
	this.white.name = "white";
	this.white.setTransform(0,400);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgV3AtUMAAAhanMArvAAAMAAABang");
	mask.setTransform(150,300);

	// aniBox
	this.aniBox = new lib.aniBox();
	this.aniBox.name = "aniBox";
	this.aniBox.setTransform(169.05,292.2,1.4682,1.4682,0,0,0,149.9,125);

	var maskedShapeInstanceList = [this.aniBox];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.aniBox).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(126.8,53,173.2,647);
// library properties:
lib.properties = {
	id: '1C1E05274011C24EBDE45892271DAE73',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"heroFR.png?1721981397034", id:"heroFR"},
		{src:"img1.jpg?1721981397034", id:"img1"},
		{src:"img2.jpg?1721981397034", id:"img2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1C1E05274011C24EBDE45892271DAE73'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;