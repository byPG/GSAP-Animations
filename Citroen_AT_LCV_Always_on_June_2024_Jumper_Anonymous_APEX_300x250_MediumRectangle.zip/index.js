(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,581,422);


(lib.img2 = function() {
	this.initialize(img.img2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,596,500);


(lib.img3 = function() {
	this.initialize(img.img3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,450);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAACIgEAJIgEgDIAHgHIgJgBIABgEIAJAEIgBgKIADAAIgBAKIAJgEIABAEIgJABIAGAHIgDADg");
	this.shape.setTransform(58.475,26.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAIAfIgSgUIAAAUIgIAAIAAg+IAIAAIAAAjIARgQIAKAAIgTAUIAVAXg");
	this.shape_1.setTransform(55.575,29);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgFAAQgDAAgDABQgDACgCADIAAAfIgIAAIAAgsIAGAAIACAFIAFgEQAEgCADAAQAFAAAEACQAEABADAEQACAEAAAHIAAAbg");
	this.shape_2.setTransform(50.7,29.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgNAUQgEgDgBgGQAAgDACgDIAEgEIAJgCIANgDIAAgDQAAgEgDgCQgCgCgEAAIgGABQgCABgCADIgHgCQABgGAFgCQAFgCAGAAQAFAAAFABQADACACADQACAEABAFIAAAdIgHAAIgBgEQgEADgEABQgDABgDAAQgGAAgEgDgAgBAFIgGACQgBAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAABABAAQABABAEAAIAGgBIAGgEIAAgJg");
	this.shape_3.setTransform(45.9,29.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUAeIAAg7IAUAAQAFAAAFACQADACACAEIACAIQAAAEgCADQgCADgDACQAFABADADQADAEAAAGQAAAGgDAEQgDAEgEABQgGACgEAAgAgMAXIANAAIAFgBIAFgDQABgDAAgDQAAgEgBgCIgFgDIgGgBIgMAAgAgMgEIAMAAIAEAAIADgDIABgGIgBgFIgDgDIgEgBIgMAAg");
	this.shape_4.setTransform(41.5,29.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_5.setTransform(34.875,29.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_6.setTransform(32.1,28.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_7.setTransform(29.475,29.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIACAFIAGgEQADgCAEAAQAEAAAFACQADABACAEQACAEAAAHIAAAbg");
	this.shape_8.setTransform(25.45,29.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgOAUQgDgDAAgGQgBgDACgDIAFgEIAJgCIAMgDIAAgDQAAgEgCgCQgDgCgEAAIgHABQgBABgBADIgIgCQABgGAFgCQAFgCAGAAQAFAAAEABQAEACADADQACAEAAAFIAAAdIgIAAIgBgEQgDADgEABQgDABgEAAQgFAAgFgDgAgBAFIgGACQgBAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_9.setTransform(20.65,29.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgDAfIAAg+IAHAAIAAA+g");
	this.shape_10.setTransform(17.725,29);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgDAfIAAg+IAHAAIAAA+g");
	this.shape_11.setTransform(15.825,29);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgJAUQgFgDgEgFQgCgFAAgHQAAgGACgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQADACAEAAQAFAAADgCIAFgEIAHAEQgDAEgFADQgFADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_12.setTransform(12.5,29.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_13.setTransform(8.475,29.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgKAdQgFgBgFgFIAEgGIAIAFQAEABAEAAQAGAAADgCQADgCAAgEQAAgEgCgDQgCgCgFgBIgIgDIgHgDQgDgCgCgDQgCgDAAgFQAAgFADgDQADgFAEgCQAEgBAFAAIAHABIAGABIAGAEIgFAGQgDgCgDgBQgDgCgFABQgDAAgDACQgDACAAAEQAAADACACQACACAEACIAIADIAIACIAFAGQABAEAAAEQAAAJgFADQgGAFgJAAQgGAAgFgCg");
	this.shape_14.setTransform(4.475,29.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgFADQgEADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_15.setTransform(81,19.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_16.setTransform(77.7,18.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgGAAgGQAAgHADgEQADgGAFgCQAFgDAFAAIAHABIAFACIAAgVIAIAAIAAA+IgGAAIgCgFQgCADgDACQgEABgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_17.setTransform(74.125,18.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIACAFIACgDIAGgCIAFgBIAAAJIgGAAIgFACIgCADIAAAfg");
	this.shape_18.setTransform(68.8,19.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgDgFAAgHQAAgGADgFQACgFAGgDQAEgDAGAAQAJAAAGAFQAGAGgBALIAAACIghAAIACAGQACADADACQADACAEAAQAFAAADgCIAFgEIAGAEQgCAEgGADQgEADgIAAQgFAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_19.setTransform(64.75,19.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgHAfIgFgFIgCAFIgGAAIAAg+IAIAAIAAAWIAGgDIAGgBQAGAAAFADQAFACACAGQADAEAAAHQAAAGgDAGQgDAFgFADQgFADgFAAQgEAAgDgBgAgHgEQgDAAgCADIAAAUIAFAEIAHABQADAAADgBQADgCACgEQACgEAAgEQAAgFgCgDQgCgCgDgCQgDgDgDAAQgEAAgDACg");
	this.shape_20.setTransform(60.125,18.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgKAfQgEgCgCgEQgCgEAAgGIAAgbIAIAAIAAAaQAAAGACACQADADAFAAQADAAACgCIAFgEIAAgfIAJAAIAAArIgHAAIgBgEIgGAEQgDABgEAAQgFAAgDgBgAAFgWQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAgBAAAAQAAAAABgBIAEgBQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABABAAQAAAAAAABQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAIgEgCgAgLgWQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAgBAAAAQAAAAABgBIAEgBQAAAAABAAQAAAAABAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAQgBAAAAAAIgEgCg");
	this.shape_21.setTransform(55.025,18.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgHAgQgEgBgDgCQgDgDgBgEIAHgDIACADIAFADIAFABQAFAAADgEQAEgCAAgHIAAgEQgCACgEABQgDABgEAAQgFAAgFgDQgFgCgCgGQgDgEAAgHQAAgGADgGQADgFAFgDQAFgDAFAAIAHABIAFAEIACgEIAGAAIAAAtQAAAGgCAEQgCAEgFACQgEADgHAAIgIgBgAgFgXQgDACgCAEQgCAEAAAEQAAAFACADQACACADACQADACADAAIAHgBIAFgDIAAgUIgFgEQgDgBgEAAQgDAAgDABg");
	this.shape_22.setTransform(48.075,20.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgIAAIAAgsIAGAAIACAFIAGgEQADgCADAAQAGAAADACQAEABACAEQACAEAAAHIAAAbg");
	this.shape_23.setTransform(43.35,19.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgKAVQgEgBgCgEQgCgEAAgHIAAgbIAIAAIAAAaQAAAGACADQADACAFAAQADAAACgBIAFgFIAAgfIAJAAIAAAsIgHAAIgBgFIgGAEQgDACgEAAQgFAAgDgCg");
	this.shape_24.setTransform(38.425,19.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIACAFIACgDIAFgCIAHgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_25.setTransform(35,19.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgJAUQgFgDgEgFQgCgFAAgHQAAgGACgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQADACAEAAQAFAAADgCIAFgEIAHAEQgDAEgFADQgFADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_26.setTransform(30.95,19.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_27.setTransform(27.65,18.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgRAWIAAgGIAYgeIgXAAIAAgHIAhAAIAAAGIgYAeIAZAAIAAAHg");
	this.shape_28.setTransform(24.775,19.125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgCgCgGAAQgDAAgDABQgDACgCADIAAAfIgIAAIAAgsIAGAAIABAFIAGgEQAEgCAEAAQAEAAAFACQADABADAEQACAEAAAHIAAAbg");
	this.shape_29.setTransform(20.45,19.075);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQAAgDACgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgFABQgCABgCADIgHgCQABgGAFgCQAFgCAFAAQAGAAAFABQAEACABADQACAEAAAFIAAAdIgGAAIgBgEQgFADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAQABABAEAAIAGgBIAGgEIAAgJg");
	this.shape_30.setTransform(15.65,19.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQADAEAAAHIAAAbg");
	this.shape_31.setTransform(11.25,19.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_32.setTransform(7.8,18.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgSAeIAAg7IAlAAIAAAIIgdAAIAAASIAaAAIAAAHIgaAAIAAAag");
	this.shape_33.setTransform(4.825,18.325);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_34.setTransform(92.3,7.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgJAUQgFgDgEgFQgCgFgBgHQABgGACgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQADACAEAAQAFAAADgCIAFgEIAHAEQgDAEgFADQgFADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_35.setTransform(89,8.325);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgHAfIgFgFIgCAFIgGAAIAAg+IAIAAIAAAWIAGgDIAGgBQAGAAAFADQAFACACAGQADAEAAAHQAAAGgDAGQgDAFgFADQgFADgFAAQgEAAgDgBgAgHgEQgDAAgCADIAAAUIAFAEIAHABQADAAADgBQADgCACgEQACgEAAgEQAAgFgCgDQgCgCgDgCQgDgDgDAAQgEAAgDACg");
	this.shape_36.setTransform(84.375,7.45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgFADQgEADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_37.setTransform(77.4,8.325);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_38.setTransform(74.1,7.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_39.setTransform(71.475,7.725);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgGAAQgCAAgDABQgDACgCADIAAAfIgIAAIAAgsIAGAAIACAFIAFgEQAEgCADAAQAGAAADACQAEABADAEQABAEAAAHIAAAbg");
	this.shape_40.setTransform(67.45,8.275);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgNAUQgEgDAAgGQAAgDABgDIAEgEIAJgCIANgDIAAgDQAAgEgDgCQgCgCgEAAIgGABQgCABgBADIgIgCQABgGAFgCQAFgCAGAAQAFAAAFABQADACACADQADAEAAAFIAAAdIgHAAIgBgEQgFADgDABQgDABgEAAQgFAAgEgDgAgBAFIgGACQgBAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_41.setTransform(62.65,8.325);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIABAFIAEgDIAEgCIAGgBIAAAJIgGAAIgEACIgDADIAAAfg");
	this.shape_42.setTransform(59.6,8.275);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgFABQgDABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACABADQACAEAAAFIAAAdIgGAAIgCgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAQABABAEAAIAGgBIAGgEIAAgJg");
	this.shape_43.setTransform(55.6,8.325);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgJAdQgFgDgFgEQgEgEgCgGQgDgGAAgGQAAgGADgFQACgGAEgEQAFgEAFgDQAGgCAGAAQAIAAAGADQAHADAEAGIgHAFQgDgEgEgDQgFgBgGAAQgGAAgFACQgFADgDAFQgDAGAAAFQAAAGADAFQADAFAFAEQAFADAGAAQAGgBAFgCIAGgFIAAgJIgRAAIAAgHIAaAAIAAATQgFAGgGADQgHAEgIAAQgGAAgGgCg");
	this.shape_44.setTransform(50.375,7.55);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQAEgFAFgDQAEgDAGAAQAJAAAGAFQAGAGAAALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgGADgHAAQgFAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_45.setTransform(42.9,8.325);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIACAFIACgDIAFgCIAHgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_46.setTransform(39.5,8.275);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AALAfIAAgbQAAgEgCgDQgDgCgFgBQgDABgDABQgDABgCADIAAAfIgIAAIAAg+IAIAAIAAAYQACgDADgCQAEgBADAAQAFAAAEABQAEACADAEQACAEAAAFIAAAcg");
	this.shape_47.setTransform(35.4,7.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgNAUQgEgDgBgGQAAgDACgDIAEgEIAJgCIANgDIAAgDQAAgEgDgCQgCgCgEAAIgGABQgCABgCADIgHgCQABgGAFgCQAFgCAGAAQAFAAAFABQADACACADQACAEABAFIAAAdIgHAAIgBgEQgEADgEABQgDABgDAAQgGAAgEgDgAgBAFIgGACQgBAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAABABAAQABABAEAAIAGgBIAGgEIAAgJg");
	this.shape_48.setTransform(30.6,8.325);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgHAeIgEgBIACgHIADABIADAAQADAAACgCQACgCAAgFIAAgsIAIAAIAAAtQAAAHgEAEQgEAFgHAAg");
	this.shape_49.setTransform(26.725,7.575);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AAMAeIAAgKIggAAIAAgGIAYgrIAJAAIgXApIAWAAIAAgMIAJAAIAAAeg");
	this.shape_50.setTransform(21.1,7.525);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAgBAAAAIAEACQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgEABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAg");
	this.shape_51.setTransform(16.025,10.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgDAfIAAg+IAHAAIAAA+g");
	this.shape_52.setTransform(14.175,7.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AAIAfIgSgUIAAAUIgIAAIAAg+IAIAAIAAAjIARgQIAKAAIgTAUIAVAXg");
	this.shape_53.setTransform(11.425,7.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIACAFIAGgEQADgCAEAAQAEAAAFACQADABACAEQACAEAAAHIAAAbg");
	this.shape_54.setTransform(6.55,8.275);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_55.setTransform(3.1,7.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(0,0,100,36.4), null);


(lib.txt3a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AARApIAAgwQAAgIgDgEQgDgDgKAAQgEAAgFACIgIAGIAAA3IgUAAIAAhPIAQAAIACAIQAFgFAGgCQAHgDAHAAQAJAAAGADQAHADAEAGQADAHAAAMIAAAyg");
	this.shape.setTransform(185.2,13.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSAkQgJgFgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgGQAJgFAKAAQASAAAKAKQAKALAAASIAAAHIg6AAIADAIQADAGAFADQAGADAFAAQAJAAAFgDQAFgEADgEIAOAJQgGAIgJAGQgIAFgNAAQgLAAgKgGgAAUgJQAAgGgEgEQgFgFgJAAQgGAAgFADQgFADgCAFIgCAEIAmAAIAAAAg");
	this.shape_1.setTransform(175.975,13.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AApApIAAgxQAAgIgDgDQgDgDgIAAQgGAAgEACQgEACgDADIAAAFIAAAzIgSAAIAAgxQAAgIgEgDQgCgDgJAAQgFAAgEACIgIAGIAAA3IgTAAIAAhPIAPAAIACAIQAFgFAFgCQAHgDAIAAQAHAAAHADQAEACADAFIAMgHQAGgDAKAAQAIAAAHADQAGADAEAGQADAHAAALIAAAzg");
	this.shape_2.setTransform(164.45,13.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgVAmQgGgCgEgIQgEgGABgMIAAgyIATAAIAAAwQAAAIADAEQAEAEAHAAQAFAAAFgCIAHgHIAAg3IAUAAIAABPIgPAAIgDgHQgEADgHAEQgGACgGAAQgJAAgHgDg");
	this.shape_3.setTransform(152.65,13.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgJA4IAAhvIATAAIAABvg");
	this.shape_4.setTransform(146.025,11.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUAkQgKgFgGgKQgFgJAAgMQAAgLAFgKQAGgJAKgFQAJgGALAAQAMAAAJAGQAKAFAFAKQAGAJAAALQAAAMgGAJQgFAKgKAFQgJAGgMAAQgLAAgJgGgAgLgUQgFADgDAFQgDAGAAAGQAAAHADAFQADAGAFADQAFADAGAAQAGAAAGgDQAFgDACgGQADgFAAgHQAAgGgDgFQgCgGgFgDQgGgDgGAAQgGAAgFADg");
	this.shape_5.setTransform(139.225,13.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgIAoIgghPIAWAAIATA4IAUg4IATAAIgeBPg");
	this.shape_6.setTransform(130.25,13.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgSAkQgJgFgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgGQAJgFAKAAQASAAAKAKQAKALAAASIAAAHIg6AAIADAIQADAGAFADQAGADAFAAQAJAAAFgDQAFgEADgEIAOAJQgGAIgJAGQgIAFgNAAQgLAAgKgGgAAUgJQAAgGgEgEQgFgFgJAAQgGAAgFADQgFADgCAFIgCAEIAmAAIAAAAg");
	this.shape_7.setTransform(121.575,13.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgUAzQgIgFgFgJQgGgKAAgMQAAgMAGgIQAFgKAJgFQAJgGAKABQAHAAAFABQAFABADADIAAgkIAUAAIAABvIgQAAIgCgHQgEAEgGADQgGACgGAAQgLAAgJgGgAgIgFQgFADgDAFQgDAFAAAHQAAAHADAGQADAFAFAEQAEADAGAAQAFgBAFgBQAFgCADgEIAAgjQgDgDgEgBQgFgCgFAAQgGAAgFAEg");
	this.shape_8.setTransform(112.075,11.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgbAkQgHgGAAgLQAAgGACgFQADgFAGgDQAGgCAKgCIAXgEIAAgDQgBgIgDgDQgEgDgIAAQgGAAgDACQgEACgCAEIgRgFQADgJAJgFQAJgFAMAAQALAAAIADQAHADAEAGQAEAGAAAKIAAA1IgQAAIgBgIQgHAFgGADQgGACgHAAQgMAAgHgGgAgCAJQgHABgDADQgDACAAAEQAAADADACQACACAFAAQAFAAAFgCQAGgCAFgEIAAgNg");
	this.shape_9.setTransform(103.1,13.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgjA1IAAhqIAVAAIAABYIAyAAIAAASg");
	this.shape_10.setTransform(95.15,11.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgMAhQgFgCgDgEQgDgEgCgFIANgDQAAAEAEABQADADAFAAQAFAAAEgDQADgDAAgFQAAgEgDgEQgEgCgFAAIgIAAIAAgIIAOgRIgaAAIAAgLIAqAAIAAAJIgOASQAGABAEADQAEADACADQACAFAAAEQAAAHgDAGQgEAEgFAEQgGADgIAAQgHgBgFgCg");
	this.shape_11.setTransform(83.4,8.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AApApIAAgxQAAgIgDgDQgDgDgIAAQgGAAgEACQgEACgDADIAAAFIAAAzIgTAAIAAgxQAAgIgCgDQgDgDgIAAQgGAAgEACIgIAGIAAA3IgUAAIAAhPIAQAAIACAIQAFgFAGgCQAGgDAHAAQAJAAAGADQAEACAEAFIALgHQAHgDAJAAQAIAAAGADQAHADAEAGQADAHABALIAAAzg");
	this.shape_12.setTransform(73.5,13.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgfA1IAthWIgzAAIAAgUIBLAAIAAARIguBZg");
	this.shape_13.setTransform(58.375,11.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AABA1IAAhUIgWAKIAAgVIAZgLIASAAIAABqg");
	this.shape_14.setTransform(50.625,11.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgVAmQgGgCgEgIQgDgGAAgMIAAgyIATAAIAAAwQAAAIADAEQAEAEAHAAQAFAAAEgCIAIgHIAAg3IATAAIAABPIgOAAIgDgHQgEADgHAEQgGACgGAAQgJAAgHgDg");
	this.shape_15.setTransform(39.6,13.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AghAoIAAgPIApgvIgnAAIAAgRIA/AAIAAAOIgpAxIArAAIAAAQg");
	this.shape_16.setTransform(31.2,13.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgRAnQgIgDgGgFIAIgOQAFAEAHADQAGACAGAAQAHAAADgCQADgCAAgEQAAgDgCgCQgCgCgGgCIgLgDQgKgEgFgEQgGgGAAgJQAAgIAEgFQADgFAHgDQAHgDAIAAQAJAAAHACQAIADAFAEIgJANIgKgFQgFgBgFAAQgFAAgDACQgCACAAADQAAADABACIAHADIALAEQALAEAGAEQAFAGAAAJQAAAMgIAGQgIAHgPAAQgJAAgJgDg");
	this.shape_17.setTransform(19.875,13.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgJA5IAAhPIASAAIAABPgAgIgjQgDgEAAgFQAAgFADgEQAEgDAEAAQAFAAADADQAEAEAAAFQAAAFgEAEQgDADgFAAQgEAAgEgDg");
	this.shape_18.setTransform(14.2,11.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgnA1IAAhqIAoAAQALAAAIAFQAGADAEAHQADAGAAAHQAAAHgDAHQgCAGgIADQAKABAFAHQAFAGAAAKQAAALgFAHQgFAHgJADQgIADgKAAgAgSAlIATAAQAGAAAEgCQADgBADgDQACgEAAgFQAAgGgCgDQgDgEgEgBQgEgCgGAAIgSAAgAgSgJIASAAIAFgBQAEgCABgDQACgCAAgFQAAgGgCgCQgCgEgDgBIgGgBIgRAAg");
	this.shape_19.setTransform(7.4,11.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3a, new cjs.Rectangle(0,0,192.1,23.2), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AARA4IAAgxQAAgHgEgDQgCgEgJAAQgGAAgDACQgFACgEADIAAA4IgTAAIAAhvIATAAIAAAnQAEgEAGgCQAGgCAHAAQAJAAAGACQAHADADAHQAFAGAAALIAAAzg");
	this.shape.setTransform(155.9,11.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSAkQgJgFgFgKQgGgJAAgMQAAgLAGgKQAFgJAJgFQAJgGALAAQAPAAAIAGQAJAGAFAKIgRAIQgDgGgEgDQgFgDgIAAQgFAAgFADQgFADgCAFQgDAGAAAGQAAAGADAGQADAGAFADQAFADAFAAQAIAAAFgDQAFgEADgFIAPAKQgGAJgJAFQgJAGgNAAQgLAAgJgGg");
	this.shape_1.setTransform(147.025,13.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgRAnQgIgDgGgFIAIgOQAFAEAHADQAGACAGAAQAHAAADgCQADgCAAgEQAAgDgCgCQgCgCgGgCIgLgDQgKgEgFgEQgGgGAAgJQAAgIAEgFQADgFAHgDQAHgDAIAAQAJAAAHACQAIADAFAEIgJANIgKgFQgFgBgFAAQgFAAgDACQgCACAAADQAAADABACIAHADIALAEQALAEAGAEQAFAGAAAJQAAAMgIAGQgIAHgPAAQgJAAgJgDg");
	this.shape_2.setTransform(138.875,13.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgJA5IAAhPIATAAIAABPgAgHgjQgEgEAAgFQAAgFAEgEQADgDAEAAQAFAAADADQAEAEAAAFQAAAFgEAEQgDADgFAAQgEAAgDgDg");
	this.shape_3.setTransform(133.2,11.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgVApIAAhPIAPAAIACAIIAHgFIAJgEIAKgBIgBATIgJABIgIADIgGAFIAAA1g");
	this.shape_4.setTransform(128.7,13.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgKAtQgGgGAAgMIAAgnIgOAAIAAgRIAOAAIAAgWIATAAIAAAWIAZAAIAAARIgZAAIAAAhQAAAHACAEQACADAFAAIAGgBIAHgCIAGAPQgFADgGABIgLABQgMAAgHgHg");
	this.shape_5.setTransform(121.925,12.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AANA4IgegkIAAAkIgUAAIAAhvIAUAAIAAA+IAcgeIAXAAIgiAkIAmArg");
	this.shape_6.setTransform(114.725,11.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgSAkQgJgFgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgGQAJgFAKAAQASAAAKAKQAKALAAASIAAAHIg6AAIADAIQADAGAFADQAGADAFAAQAJAAAFgDQAFgEADgEIAOAJQgGAIgJAGQgIAFgNAAQgLAAgKgGgAAUgJQAAgGgEgEQgFgFgJAAQgGAAgFADQgFADgCAFIgCAEIAmAAIAAAAg");
	this.shape_7.setTransform(105.375,13.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgJA4IAAhvIATAAIAABvg");
	this.shape_8.setTransform(98.825,11.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgSAkQgJgFgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgGQAJgFAKAAQASAAAKAKQAKALAAASIAAAHIg6AAIADAIQADAGAFADQAGADAFAAQAJAAAFgDQAFgEADgEIAOAJQgGAIgJAGQgIAFgNAAQgLAAgKgGgAAUgJQAAgGgEgEQgFgFgJAAQgGAAgFADQgFADgCAFIgCAEIAmAAIAAAAg");
	this.shape_9.setTransform(92.275,13.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAUA0QgHgEgDgGQgEgGAAgIQAAgIAEgGQADgHAHgDQAGgEAIAAQAIAAAHAEQAGADAEAHQAEAGAAAIQAAAIgEAGQgEAGgGAEQgHAEgIAAQgIAAgGgEgAAZASQgEAEAAAGQAAAGAEAEQAEAEAFAAQAGAAAEgEQAEgEAAgGQAAgGgEgEQgEgEgGAAQgFAAgEAEgAgtA2IBJhqIARAAIhJBqgAgwgDQgHgDgDgGQgEgHAAgIQAAgIAEgGQADgGAHgEQAGgEAIAAQAJAAAGAEQAGAEAEAGQAEAGAAAIQAAAIgEAHQgEAGgGADQgGADgJAAQgIAAgGgDgAgrgkQgEAEAAAFQAAAGAEAEQADAEAGAAQAGAAAEgEQAEgEAAgGQAAgFgEgEQgEgEgGAAQgGAAgDAEg");
	this.shape_10.setTransform(77.275,11.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgVAxQgJgHgFgNQgGgMAAgRQAAgQAGgMQAFgNAJgHQAJgGAMAAQANAAAJAGQAKAHAFANQAFAMAAAQQAAARgFAMQgFANgKAHQgJAGgNAAQgMAAgJgGgAgOgaQgFAJAAARQAAARAFAJQAGAJAIAAQAKABAFgKQAGgJAAgRQAAgRgGgJQgFgIgKgBQgIABgGAIg");
	this.shape_11.setTransform(65.425,11.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgVAxQgJgHgFgNQgGgMAAgRQAAgQAGgMQAFgNAJgHQAJgGAMAAQANAAAJAGQAKAHAFANQAFAMAAAQQAAARgFAMQgFANgKAHQgJAGgNAAQgMAAgJgGgAgOgaQgFAJAAARQAAARAFAJQAGAJAIAAQAKABAFgKQAGgJAAgRQAAgRgGgJQgFgIgKgBQgIABgGAIg");
	this.shape_12.setTransform(55.375,11.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AABA1IAAhUIgWAKIAAgVIAZgLIASAAIAABqg");
	this.shape_13.setTransform(46.825,11.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AARA4IAAgxQAAgHgDgDQgDgEgKAAQgEAAgFACIgIAFIAAA4IgUAAIAAhvIAUAAIAAAnQAEgEAGgCQAGgCAHAAQAJAAAGACQAHADAEAHQADAGAAALIAAAzg");
	this.shape_14.setTransform(35.8,11.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgSAkQgJgFgFgKQgGgJAAgMQAAgLAGgKQAFgJAJgFQAJgGALAAQAPAAAIAGQAJAGAFAKIgRAIQgDgGgEgDQgFgDgIAAQgFAAgFADQgFADgCAFQgDAGAAAGQAAAGADAGQADAGAFADQAFADAFAAQAIAAAFgDQAFgEADgFIAPAKQgGAJgJAFQgJAGgNAAQgLAAgJgGg");
	this.shape_15.setTransform(26.925,13.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgVAmQgGgCgEgIQgDgGAAgMIAAgyIATAAIAAAwQAAAIADAEQADAEAJAAQAEAAAFgCIAHgHIAAg3IAUAAIAABPIgQAAIgCgHQgFADgFAEQgGACgIAAQgIAAgHgDg");
	this.shape_16.setTransform(17.85,13.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAfA1IgJgaIgrAAIgJAaIgWAAIAohqIAaAAIAnBqgAAPAJIgPgrIgPArIAeAAg");
	this.shape_17.setTransform(7.65,11.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(0,0,162.8,23.2), null);


(lib.txt1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE0000").s().p("AgRAnQgIgDgGgFIAIgOQAFAEAHADQAGACAGAAQAHAAADgCQADgCAAgEQAAgDgCgCQgCgCgGgCIgLgDQgKgEgFgEQgGgGAAgJQAAgIAEgFQADgFAHgDQAHgDAIAAQAJAAAHACQAIADAFAEIgJANIgKgFQgFgBgFAAQgFAAgDACQgCACAAADQAAADABACIAHADIALAEQALAEAGAEQAFAGAAAJQAAAMgIAGQgIAHgPAAQgJAAgJgDg");
	this.shape.setTransform(111.075,13.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EE0000").s().p("AgJA5IAAhPIATAAIAABPgAgHgjQgEgEAAgFQAAgFAEgEQADgDAEAAQAFAAAEADQADAEAAAFQAAAFgDAEQgEADgFAAQgEAAgDgDg");
	this.shape_1.setTransform(105.4,11.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EE0000").s().p("AgRA5IAAg+IgLAAIAAgRIALAAIAAgFQAAgNAIgIQAIgIAOAAIAJAAIAHACIgDARIgGgBIgGgBQgGAAgEADQgCADAAAIIAAADIAWAAIAAARIgWAAIAAA+g");
	this.shape_2.setTransform(100.75,11.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EE0000").s().p("AgUAkQgKgFgGgKQgFgJAAgMQAAgLAFgKQAGgJAKgFQAJgGALAAQAMAAAJAGQAKAFAFAKQAGAJAAALQAAAMgGAJQgFAKgKAFQgJAGgMAAQgLAAgJgGgAgLgUQgFADgDAFQgDAGAAAGQAAAHADAFQADAGAFADQAFADAGAAQAGAAAGgDQAFgDACgGQADgFAAgHQAAgGgDgFQgCgGgFgDQgGgDgGAAQgGAAgFADg");
	this.shape_3.setTransform(92.825,13.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EE0000").s().p("AgVApIAAhPIAPAAIACAIIAHgFIAIgEIAMgBIgCATIgKABIgHADIgGAFIAAA1g");
	this.shape_4.setTransform(85.65,13.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EE0000").s().p("AgmA1IAAhqIApAAQARABAKAIQAJAKAAAQQAAAPgJAJQgKAJgSAAIgTAAIAAAmgAgRgBIARAAQAGAAADgCQAEgCACgEQACgEAAgFQAAgGgCgEQgCgEgEgCQgDgCgGAAIgRAAg");
	this.shape_5.setTransform(77.825,11.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EE0000").s().p("AgWApIAAhPIAQAAIACAIIAHgFIAJgEIAKgBIgBATIgJABIgJADIgFAFIAAA1g");
	this.shape_6.setTransform(66.35,13.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EE0000").s().p("AgVA3QgGgDgEgHQgDgGAAgMIAAgyIATAAIAAAwQAAAIADAEQADAEAJAAQAEAAAFgDIAHgGIAAg3IAUAAIAABPIgQAAIgCgIQgFAEgFADQgGADgIAAQgIAAgHgDgAAJglQgDgEgBgEQABgFADgDQADgEAFAAQAFAAADAEQADADABAFQgBAEgDAEQgDADgFAAQgFAAgDgDgAgWglQgDgEAAgEQAAgFADgDQADgEAFAAQAEAAAEAEQADADAAAFQAAAEgDAEQgEADgEAAQgFAAgDgDg");
	this.shape_7.setTransform(58.35,11.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EE0000").s().p("AgRA5IAAg+IgLAAIAAgRIALAAIAAgFQAAgNAIgIQAIgIAOAAIAJAAIAHACIgDARIgGgBIgGgBQgGAAgEADQgCADAAAIIAAADIAWAAIAAARIgWAAIAAA+g");
	this.shape_8.setTransform(51.25,11.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EE0000").s().p("AgRAnQgIgDgGgFIAIgOQAFAEAHADQAGACAGAAQAHAAADgCQADgCAAgEQAAgDgCgCQgCgCgGgCIgLgDQgKgEgFgEQgGgGAAgJQAAgIAEgFQADgFAHgDQAHgDAIAAQAJAAAHACQAIADAFAEIgJANIgKgFQgFgBgFAAQgFAAgDACQgCACAAADQAAADABACIAHADIALAEQALAEAGAEQAFAGAAAJQAAAMgIAGQgIAHgPAAQgJAAgJgDg");
	this.shape_9.setTransform(40.575,13.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EE0000").s().p("AgJA5IAAhPIASAAIAABPgAgIgjQgDgEAAgFQAAgFADgEQAEgDAEAAQAFAAADADQAEAEAAAFQAAAFgEAEQgDADgFAAQgEAAgEgDg");
	this.shape_10.setTransform(34.9,11.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#EE0000").s().p("AgRA5IAAg+IgMAAIAAgRIAMAAIAAgFQAAgNAIgIQAHgIAPAAIAJAAIAIACIgFARIgFgBIgGgBQgHAAgDADQgCADAAAIIAAADIAVAAIAAARIgVAAIAAA+g");
	this.shape_11.setTransform(30.25,11.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EE0000").s().p("AgUAkQgKgFgGgKQgFgJAAgMQAAgLAFgKQAGgJAKgFQAJgGALAAQAMAAAJAGQAKAFAFAKQAGAJAAALQAAAMgGAJQgFAKgKAFQgJAGgMAAQgLAAgJgGgAgLgUQgFADgDAFQgDAGAAAGQAAAHADAFQADAGAFADQAFADAGAAQAGAAAGgDQAFgDACgGQADgFAAgHQAAgGgDgFQgCgGgFgDQgGgDgGAAQgGAAgFADg");
	this.shape_12.setTransform(22.325,13.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EE0000").s().p("AgWApIAAhPIAQAAIACAIIAHgFIAIgEIALgBIgBATIgKABIgIADIgFAFIAAA1g");
	this.shape_13.setTransform(15.15,13.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EE0000").s().p("AgmA1IAAhqIApAAQARABAKAIQAJAKAAAQQAAAPgJAJQgKAJgSAAIgTAAIAAAmgAgRgBIARAAQAGAAADgCQAEgCACgEQACgEAAgFQAAgGgCgEQgCgEgEgCQgDgCgGAAIgRAAg");
	this.shape_14.setTransform(7.325,11.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1b, new cjs.Rectangle(0,0,117,23.2), null);


(lib.txt1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE0000").s().p("AARApIAAgwQAAgIgDgEQgEgDgIAAQgFAAgFACIgIAGIAAA3IgUAAIAAhPIAQAAIACAIQAFgFAHgCQAFgDAIAAQAIAAAHADQAHADAEAGQADAHAAAMIAAAyg");
	this.shape.setTransform(139.4,13.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EE0000").s().p("AgUAkQgKgFgGgKQgFgJAAgMQAAgLAFgKQAGgJAKgFQAJgGALAAQAMAAAJAGQAKAFAFAKQAGAJAAALQAAAMgGAJQgFAKgKAFQgJAGgMAAQgLAAgJgGgAgLgUQgFADgDAFQgDAGAAAGQAAAHADAFQADAGAFADQAFADAGAAQAGAAAGgDQAFgDACgGQADgFAAgHQAAgGgDgFQgCgGgFgDQgGgDgGAAQgGAAgFADg");
	this.shape_1.setTransform(129.925,13.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EE0000").s().p("AgJAoIgehPIAVAAIASA4IAVg4IAUAAIgfBPg");
	this.shape_2.setTransform(120.95,13.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EE0000").s().p("AARApIAAgwQAAgIgDgEQgEgDgIAAQgFAAgFACIgIAGIAAA3IgUAAIAAhPIAQAAIACAIQAFgFAHgCQAFgDAIAAQAIAAAHADQAHADAEAGQADAHAAAMIAAAyg");
	this.shape_3.setTransform(108.35,13.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EE0000").s().p("AgSAkQgJgFgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgGQAJgFAKAAQASAAAKAKQAKALAAASIAAAHIg6AAIADAIQADAGAFADQAGADAFAAQAJAAAFgDQAFgEADgEIAOAJQgGAIgJAGQgIAFgNAAQgLAAgKgGgAAUgJQAAgGgEgEQgFgFgJAAQgGAAgFADQgFADgCAFIgCAEIAmAAIAAAAg");
	this.shape_4.setTransform(99.125,13.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EE0000").s().p("AgWApIAAhPIAQAAIACAIIAHgFIAJgEIALgBIgCATIgJABIgIADIgGAFIAAA1g");
	this.shape_5.setTransform(92.25,13.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EE0000").s().p("AARA4IAAgxQAAgHgEgDQgDgEgIAAQgGAAgDACQgFACgEADIAAA4IgTAAIAAhvIATAAIAAAnQAEgEAGgCQAGgCAHAAQAJAAAGACQAHADADAHQAFAGAAALIAAAzg");
	this.shape_6.setTransform(84.25,11.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EE0000").s().p("AgbAkQgHgGAAgLQAAgGADgFQACgFAGgDQAGgCAKgCIAWgEIAAgDQAAgIgDgDQgEgDgIAAQgGAAgEACQgCACgCAEIgRgFQACgJAJgFQAJgFANAAQAKAAAIADQAIADADAGQAEAGAAAKIAAA1IgPAAIgDgIQgGAFgGADQgGACgIAAQgLAAgHgGgAgCAJQgHABgDADQgDACAAAEQAAADADACQADACAFAAQAEAAAFgCQAGgCAEgEIAAgNg");
	this.shape_7.setTransform(75.05,13.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EE0000").s().p("AgPA1IgHgBIAEgSIAFABIAEAAQAHAAACgCQACgDAAgHIAAhNIAVAAIAABOQAAANgHAJQgIAJgOgBg");
	this.shape_8.setTransform(67.475,11.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EE0000").s().p("AgVAxQgJgHgFgNQgGgMAAgRQAAgQAGgMQAFgNAJgHQAJgGAMAAQANAAAJAGQAKAHAFANQAFAMAAAQQAAARgFAMQgFANgKAHQgJAGgNAAQgMAAgJgGgAgOgaQgFAJAAARQAAARAFAJQAGAJAIAAQAKABAFgKQAGgJAAgRQAAgRgGgJQgFgIgKgBQgIABgGAIg");
	this.shape_9.setTransform(56.075,11.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EE0000").s().p("AgVAxQgJgHgFgNQgGgMAAgRQAAgQAGgMQAFgNAJgHQAJgGAMAAQANAAAJAGQAKAHAFANQAFAMAAAQQAAARgFAMQgFANgKAHQgJAGgNAAQgMAAgJgGgAgOgaQgFAJAAARQAAARAFAJQAGAJAIAAQAKABAFgKQAGgJAAgRQAAgRgGgJQgFgIgKgBQgIABgGAIg");
	this.shape_10.setTransform(46.025,11.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#EE0000").s().p("AABA1IAAhUIgWAKIAAgVIAZgLIASAAIAABqg");
	this.shape_11.setTransform(37.475,11.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EE0000").s().p("AgKAtQgGgGAAgMIAAgnIgOAAIAAgRIAOAAIAAgWIATAAIAAAWIAZAAIAAARIgZAAIAAAhQAAAHACAEQACADAFAAIAGgBIAHgCIAGAPQgFADgGABIgLABQgMAAgHgHg");
	this.shape_12.setTransform(27.675,12.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EE0000").s().p("AgJA5IAAhPIASAAIAABPgAgIgjQgDgEAAgFQAAgFADgEQAEgDAEAAQAFAAADADQAEAEAAAFQAAAFgEAEQgDADgFAAQgEAAgEgDg");
	this.shape_13.setTransform(22.3,11.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EE0000").s().p("AgSAkQgJgFgGgJQgFgKAAgMQAAgMAFgJQAGgJAJgGQAJgFAKAAQASAAAKAKQAKALAAASIAAAHIg6AAIADAIQADAGAFADQAGADAFAAQAJAAAFgDQAFgEADgEIAOAJQgGAIgJAGQgIAFgNAAQgLAAgKgGgAAUgJQAAgGgEgEQgFgFgJAAQgGAAgFADQgFADgCAFIgCAEIAmAAIAAAAg");
	this.shape_14.setTransform(15.725,13.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#EE0000").s().p("AgVA1QgJgEgKgGIAKgRQAHAFAIADQAHADAIAAQAJAAAFgDQAEgCABgHQAAgFgDgDQgEgDgIgDIgPgFQgIgDgFgDQgGgEgDgGQgDgGAAgIQAAgKAEgGQAGgHAIgEQAJgDAJAAIAOAAQAGACAGACIALAGIgKARQgFgEgIgDQgGgCgIAAQgGAAgEACQgEAEgBAFQAAAFADADQAEADAGACIAOAFQAJAEAHADQAGADADAGQAEAGgBAJQAAAPgKAIQgKAIgUAAQgLAAgKgCg");
	this.shape_15.setTransform(6.6,11.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1a, new cjs.Rectangle(0,0,169.6,23.2), null);


(lib.title = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOBAIgcgqIgGAAIAAAqIglAAIAAh/IA5AAQAPAAAKAGQALAFAGAKQAGAJAAANQAAANgGAIQgHAKgMAFIgBABIAkAvgAgUgFIAOAAQAHAAAEgEQAFgDAAgHQAAgHgFgEQgEgDgHAAIgOAAg");
	this.shape.setTransform(143.975,13.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgtBAIAAh/IBbAAIAAAiIg2AAIAAAPIAvAAIAAAcIgvAAIAAAQIA3AAIAAAig");
	this.shape_1.setTransform(131.25,13.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0BAIAAh/IA4AAQAXAAANAMQANAMAAAUQAAAUgNAMQgNAMgZAAIgRAAIAAAngAgPgEIAOAAQAFAAADgBQAEgCACgDQACgEAAgFQAAgFgCgDQgCgDgEgBQgDgCgFAAIgOAAg");
	this.shape_2.setTransform(119.35,13.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAnBAIAAhDIgYBDIgcAAIgZhDIAABDIgkAAIAAh/IAtAAIAdBSIAfhSIAsAAIAAB/g");
	this.shape_3.setTransform(103.85,13.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeA6QgMgGgHgMQgGgNAAgRIAAhKIAlAAIAABJQAAAHACAFQADAFAEACQAEACAGAAQAGAAAEgCQAEgCADgFQACgFAAgHIAAhJIAkAAIAABKQAAARgHANQgGAMgNAGQgMAHgRAAQgSAAgNgHg");
	this.shape_4.setTransform(88.3,13.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUBAIgKgCIAHggIAEABIAFAAQAEAAADgCQACgCAAgEIAAhXIAkAAIAABZQAAASgKALQgJALgVAAg");
	this.shape_5.setTransform(77.375,13.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOBAIgcgqIgGAAIAAAqIglAAIAAh/IA5AAQAPAAAKAGQALAFAGAKQAGAJAAANQAAANgGAIQgHAKgMAFIgBABIAkAvgAgUgFIAOAAQAHAAAEgEQAFgDAAgHQAAgHgFgEQgEgDgHAAIgOAAg");
	this.shape_6.setTransform(64.025,13.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AguBAIAAh/IBcAAIAAAiIg3AAIAAAPIAwAAIAAAcIgwAAIAAAQIA4AAIAAAig");
	this.shape_7.setTransform(51.3,13.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgeA6QgMgGgGgMQgHgNAAgRIAAhKIAlAAIAABJQAAAHACAFQACAFAFACQAEACAFAAQAHAAAEgCQAEgCACgFQADgFAAgHIAAhJIAkAAIAABKQAAARgGANQgHAMgMAGQgMAHgTAAQgQAAgOgHg");
	this.shape_8.setTransform(38.6,13.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AguBAIAAh/IBcAAIAAAiIg3AAIAAAPIAwAAIAAAcIgwAAIAAAQIA3AAIAAAig");
	this.shape_9.setTransform(26.35,13.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAYBAIgshCIAABCIglAAIAAh/IAhAAIAtBCIAAhCIAlAAIAAB/g");
	this.shape_10.setTransform(13.225,13.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Warstwa_1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#EE0000").s().p("AsGCDIAAkFIYNAAIAAEFg");
	this.shape_11.setTransform(78.475,13.075);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title, new cjs.Rectangle(1,0,155,26.8), null);


(lib.offer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgGApQgEgCgDgCIgCAEIgQAAIAAhTIAVAAIAAAZIAGgCIAHgBQAJAAAGADQAGAFAEAGQAEAHAAAKQAAAJgEAIQgEAHgGAEQgIAEgIAAQgEAAgEgCgAgGgBIgEACIAAAVIAEACIAGABQADAAACgCQADgCABgDQACgDAAgEQAAgEgCgDIgDgEQgDgCgDAAIgGABg");
	this.shape.setTransform(14.8,10.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARAoIgEgOIgbAAIgEAOIgXAAIAahPIAfAAIAaBPgAAHAHIgHgZIgIAZIAPAAg");
	this.shape_1.setTransform(6.475,10.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Warstwa_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EE0000").s().p("AgkCBQgagKgTgUQgUgTgKgZIgBgDIgbAAIAAgnIASAAIAAgNIAAgGIgSAAIAAgpIAaAAIACgHQAKgZAUgTQATgTAagMQAagKAeAAQAoAAAfAQQAgARARAbIg9AsQgJgOgOgJQgPgHgUgBQgTABgPAIIgOAKIA8AAIgHApIhHAAIgBAGIACANIBDAAIgHAnIglAAIAIAGQAOAJAUgBQAUABAOgJQAPgHAJgOIA8AqQgSAcgfAQQgfARgnAAQgeAAgagLg");
	this.shape_2.setTransform(142.65,31.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EE0000").s().p("Ag5CBQgZgKgPgTQgOgTAAgbQAAgVALgQQAKgRASgHQgMgHgHgOQgIgOAAgRQAAgXANgSQANgSAXgLQAWgKAcAAQAdAAAWAKQAXALAMASQANASAAAXQAAARgHAOQgIAOgLAHQASAHAKARQALAQAAAVQAAAbgOATQgOATgaAKQgZALghAAQggAAgZgLgAgSAXQgIAEgFAGQgEAHAAAJQAAAOAKAIQAKAIAPAAQAQAAAKgIQAKgIAAgOQAAgJgFgHQgEgGgIgEQgIgDgLAAQgKAAgIADgAgShJQgHAHAAALQAAALAHAHQAHAIALAAQALAAAIgIQAHgHAAgLQAAgLgHgHQgIgHgLAAQgLAAgHAHg");
	this.shape_3.setTransform(114.775,31.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EE0000").s().p("AhkCJIAAg6IBhhTIARgRIAIgLIADgLQAAgIgGgHQgFgHgNAAQgQAAgGAKQgFAJgCAOIhKgMQAEgbALgVQAMgVAWgMQAVgLAhAAQAgAAAWAKQAWALAMASQALASAAAYQAAAQgFAQQgEAOgMAPQgMAQgXAUIgkAfIBfAAIAABAg");
	this.shape_4.setTransform(90.125,30.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EE0000").s().p("AgNCGIAAi9IgwAXIAAhMIA1gZIBGAAIAAELg");
	this.shape_5.setTransform(69.35,31.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EE0000").s().p("AgbAdQgNgMAAgRQAAgQANgLQALgMAQAAQARAAAMAMQAMALgBAQQABARgMAMQgMALgRAAQgQAAgLgLg");
	this.shape_6.setTransform(56.65,41.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EE0000").s().p("Ag6B7QgagRgOgfQgNggAAgrQAAgqANggQAOgfAagRQAYgRAiAAQAiAAAZARQAaARANAfQAOAgAAAqQAAArgOAgQgNAfgaARQgZARgiAAQgiAAgYgRgAgYgwQgJARAAAfQAAAgAJARQAJARAPAAQAQAAAJgRQAJgRAAggQAAgfgJgRQgJgRgQAAQgPAAgJARg");
	this.shape_7.setTransform(38.6,31.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EE0000").s().p("Ag2CAQgVgJgMgPQgNgPgFgSIBGgbQACAKAJAHQAJAFAPAAQAOAAAIgFQAIgHAAgMQAAgMgIgFQgJgHgNAAIghAAIAAgrIAjgtIhdAAIAAhCIC3AAIAAA6IgnAxQAPADAMAJQAMAKAHAPQAHAQAAAVQAAAagMAVQgMAVgYAMQgZAMgkAAQgeAAgVgJg");
	this.shape_8.setTransform(13.675,31.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.offer, new cjs.Rectangle(0,1.5,159.7,55.1), null);


(lib.logosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Am3UOQjLhqidjDQidjDhWj8QhZkFAAkdQAAkcBZkFQBWj8CdjDQCdjCDLhrQDShvDlAAQDmAADSBvQDLBqCdDDQCdDCBWD9QBZEEAAEdQAAEdhZEFQhWD9idDCQidDDjLBqQjSBvjmAAQjlAAjShvgAswLbIACADQCND9DXCPQDYCODyABQDzgBDYiOQDYiPCOj9IACgDIsypdgAvLEGIgBACIAAAAIAKBCQAPBRAYBIIABAEIOaqtIObKsIABgDQAXhJAPhQIAKhCIAAgBIvMrPgAPmgsIAAgFQgIj3hOjfQhPjfiMisQiMitizhbQizhdjDAAQjCAAizBdQizBbiNCtQiLCshPDfQhPDfgID3IAAAFIPmrlg");
	this.shape.setTransform(113.2,140.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah/HaQjngGiOiCQiOiCAAjPIAAgBQAAhgAjhWQAkhUBDhAQBHhCBfgkQBggkBygEIADAAIDFgCQDhgCCWAAQBvAABUACIAAC0IowgCQhDAAhCACIg1ACIgIAAQiLAFhUBQQhUBQAACAQAACBBVBPQBUBPCOADQBQAEBngBQH8AAA8gBIAAC4Ik6ABQlxAAhXgEg");
	this.shape_1.setTransform(373,151.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibBFQgdAAgUgUQgVgUAAgcQAAgcAVgUQAUgVAdAAIE4AAQAdAAAUAVQAUAUAAAcQAAAcgVAUQgUAUgcAAg");
	this.shape_2.setTransform(1032.625,85.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ApGHfIAAu9ISNAAIAAC1Iu3AAIAADPINCAAIAACsItCAAIAADXIO3AAIAAC2g");
	this.shape_3.setTransform(1060.075,151.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjAHzQjsgFiRiKQiQiJAAjaIAAgBQAAhlAkhZQAkhbBEhDQBHhFBignQBiglB0gFIAEAAIA0gCQBAgBBGAAQBuAABWADQDtAKCRCKQCRCJgBDVIAAABQAABlgkBaQglBahEBDQhHBFhiAnQhhAnh1ADIgDAAQhKAEhwAAQh5AAhMgEgAmVjhQhUBUAACMQAACLBVBUQBVBUCSADIADAAQBNAFBrAAQBrAAAwgFIAJAAQCQgFBUhUQBUhUABiJIgBAAIAAgCQAAiMhVhSQhUhTiWgHIgIAAQhGgFhHAAQhEAAhEACIg2ADIgIAAQiRAFhUBVg");
	this.shape_4.setTransform(902.1251,151.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AqpHeIAAu7IPCAAQCmAABdBMQBdBNAACKQAACYhWA/QhYBBjbAFIAAgBIhqAAIIkF4Ik2AAIqSnbIAAg3IIbAAQBeADAlgnQAcgeAAg9QAAhyiBAAIruAAIAAMHg");
	this.shape_5.setTransform(740.775,152.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AibBFQgdAAgUgUQgVgUAAgcQAAgcAVgUQAUgVAdAAIE6AAQAbAAAUAVQAUAUAAAcQAAAcgUAUQgUAUgbAAg");
	this.shape_6.setTransform(1087.275,85.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AGnHfIAAndQAAihhYhIQhPhBihAAIoFAAIAAMHIjWAAIAAu8IMMAAQD2AACCCDQB0B3ABDLIAAH3g");
	this.shape_7.setTransform(1212,151.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhqHgIAAu/IDVAAIAAO/g");
	this.shape_8.setTransform(482.975,151.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhpHfIAAsHIogAAIAAi2IUTAAIAAC2IoeAAIAAMHg");
	this.shape_9.setTransform(583.05,151.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1275.7,281);


(lib.legal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// legal
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape.setTransform(178.35,173.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIAAQAJAAAEgDQAEgEAAgJQAAgIgEgEQgEgEgJAAQgIABgEAEg");
	this.shape_1.setTransform(173.675,171.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAQAAIAAAHIgQAAIAAAWQAAAGABACQADABAFAAIAHAAIAAAIIgIAAQgJABgEgEg");
	this.shape_2.setTransform(168.55,170.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIAAQAJAAAEgDQAEgEAAgJQAAgIgEgEQgEgEgJAAQgIABgEAEg");
	this.shape_3.setTransform(163.525,171.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgKAiIAAgmIgGAAIAAgGIAGgCIAAgEQABgJADgEQAFgEAJAAIAJAAIAAAIIgIAAQgGAAgCACQgBACAAAFIAAAEIAPAAIAAAIIgPAAIAAAmg");
	this.shape_4.setTransform(159,170.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_5.setTransform(155.7,170.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIAAQAJAAAEgDQAEgEAAgJQAAgIgEgEQgEgEgJAAQgIABgEAEg");
	this.shape_6.setTransform(151.375,171.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAWQAJgDAIgBQAXABAAAYQAAAZgXAAQgIAAgKgFgAgPgDIAAAZQAIAEAHAAQAIAAAEgEQAEgEAAgIQAAgJgEgEQgEgDgIAAQgHAAgIADg");
	this.shape_7.setTransform(145.225,170.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_8.setTransform(136.875,171.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgXAgIAAgHIAHAAQAGgBADgBQACgBABgEIACgEIgEAAIgUgtIAJAAIARAlIABAAIARglIAKAAIgYAyQgDAHgDAEQgEADgIAAIgJgBg");
	this.shape_9.setTransform(128.9,172.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgaAgIAAgKQANADANABQAKgBAEgBQAEgDAAgFQAAgHgDgBQgDgDgMgBQgPgCgGgDQgFgEgBgKQABgKAGgEQAHgFAOAAQALAAAMADIAAAJQgNgDgKAAQgKAAgEACQgDACgBAFQAAAGAEACIANAEQARABAFADQAGAFgBAKQAAAKgGAGQgHAEgOAAQgOAAgMgDg");
	this.shape_10.setTransform(122.55,170.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_11.setTransform(115,173.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_12.setTransform(110.225,171.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgSATQgFgGgBgNQABgMAFgGQAHgGALAAQAMAAAGAFQAGAFABAMIAAAFIgoAAQABAIAEADQAEACAIAAIAUgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgEgCQgDgDgIAAQgGAAgEADQgDACgCAIIAeAAIAAAAg");
	this.shape_13.setTransform(104.1,171.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAPAAIAAAHIgPAAIAAAWQAAAGACACQABABAHAAIAGAAIAAAIIgHAAQgKABgEgEg");
	this.shape_14.setTransform(99.1,170.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_15.setTransform(95.9,170.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgXAJQABgIAEgCQAEgDAJAAIAUAAIAAgDQAAgFgDgCQgDgCgJAAIgTACIAAgIQAJgCAKAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAAAgQgAgLAEQgCACgBAEQABAEACACQADACAFAAQAKAAAIgEIAAgLIgSAAQgGAAgCABg");
	this.shape_16.setTransform(91.55,171.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_17.setTransform(85.325,170.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGAMAAQALAAAGAFQAGAFAAAMIAAAFIgmAAQAAAIADADQAFACAJAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_18.setTransform(79.2,171.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAWQAJgDAIgBQAXABAAAYQAAAZgXAAQgIAAgKgFgAgPgDIAAAZQAIAEAHAAQAIAAAEgEQAEgEAAgIQAAgJgEgEQgEgDgIAAQgHAAgIADg");
	this.shape_19.setTransform(73.225,170.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_20.setTransform(68.325,171.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIAAQAJAAAEgDQAEgEAAgJQAAgIgEgEQgEgEgJAAQgIABgEAEg");
	this.shape_21.setTransform(63.225,171.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgGAYIgVguIAKAAIARAmIAAAAIASgmIAKAAIgVAug");
	this.shape_22.setTransform(57.125,171.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_23.setTransform(50.125,171.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAFABAMIAAAFIgnAAQAAAIAEADQADACAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgDgCQgEgDgIAAQgGAAgEADQgEACAAAIIAdAAIAAAAg");
	this.shape_24.setTransform(45.25,171.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_25.setTransform(41,170.225);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_26.setTransform(36.525,170.225);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAFABAMIAAAFIgnAAQAAAIAEADQADACAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgDgCQgEgDgIAAQgGAAgEADQgEACAAAIIAdAAIAAAAg");
	this.shape_27.setTransform(30.4,171.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgKAiIAAgmIgFAAIAAgGIAFgCIAAgEQAAgJAFgEQAEgEAJAAIAIAAIAAAIIgHAAQgGAAgCACQgBACgBAFIAAAEIAQAAIAAAIIgQAAIAAAmg");
	this.shape_28.setTransform(26,170.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgWAYIAAgIIAggfIgfAAIAAgHIArAAIAAAHIggAfIAhAAIAAAIg");
	this.shape_29.setTransform(21.125,171.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAPAAIAAAHIgPAAIAAAWQAAAGACACQABABAHAAIAGAAIAAAIIgHAAQgKABgEgEg");
	this.shape_30.setTransform(16.3,170.75);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgWAJQAAgIAEgCQAEgDAKAAIATAAIAAgDQAAgFgDgCQgDgCgJAAIgTACIAAgIQAJgCAKAAQANAAAGAEQAEAEAAAIIAAAgIgGAAIgBgEQgJAFgKAAQgUAAABgQgAgLAEQgDACABAEQgBAEADACQADACAFAAQAKAAAIgEIAAgLIgSAAQgGAAgCABg");
	this.shape_31.setTransform(11.25,171.25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgaAgIAAgKQANADAMABQALgBAEgBQAEgDAAgFQAAgHgDgBQgDgDgMgBQgPgCgGgDQgGgEAAgKQAAgKAHgEQAHgFAPAAQAKAAAMADIAAAJQgNgDgJAAQgLAAgEACQgEACAAAFQABAGADACIANAEQARABAFADQAGAFgBAKQABAKgHAGQgHAEgPAAQgNAAgMgDg");
	this.shape_32.setTransform(4.85,170.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgYAKQAAgYAYAAQAGAAAKADIAAgWIAJAAIAABCIgGAAIgBgDQgMAFgGgBQgYABAAgZgAgLgDQgEAEAAAJQAAAIAEAEQAEAEAHABQAJgBAHgEIAAgZQgHgDgJAAQgHAAgEADg");
	this.shape_33.setTransform(258.8,159.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_34.setTransform(252.575,160.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQAAAKAMAAQAIAAAKgFIAAgiIAIAAIAAAuIgGAAIgCgEQgKAFgIAAQgLAAgGgFg");
	this.shape_35.setTransform(246.05,160.425);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_36.setTransform(238.725,160.35);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_37.setTransform(234.525,159.325);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgPATQgGgGAAgNQAAgMAGgGQAGgGANAAQAIAAAJADIAAAIQgJgDgIAAQgJAAgDAEQgEAEAAAIQAAAJAEAEQADADAJABIASgCIAAAIQgJACgJAAQgNAAgGgGg");
	this.shape_38.setTransform(228.675,160.35);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgSATQgGgEAAgIIAAgeIAJAAIAAAdQABAKANAAQAHAAAKgFIAAgiIAJAAIAAAuIgGAAIgCgEQgLAFgIAAQgLAAgFgFg");
	this.shape_39.setTransform(222.7,160.425);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_40.setTransform(217.875,160.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgdAiIAAhDIAbAAQARAAAIAIQAHAIAAARQAAASgHAIQgIAIgRAAgAgUAZIASAAQAMAAAGgGQAFgFAAgOQAAgMgFgGQgGgGgMAAIgSAAg");
	this.shape_41.setTransform(212.275,159.325);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_42.setTransform(204.2,162.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_43.setTransform(201.075,160.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAEAAANIAAADIgoAAQABAIAEAEQADADAJAAIAUgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgHAAQgIAAgDADQgEACgBAIIAeAAIAAAAg");
	this.shape_44.setTransform(196.15,160.35);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_45.setTransform(189.925,160.275);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAQAAIAAAHIgQAAIAAAXQAAAFABACQACACAGgBIAHAAIAAAIIgIABQgJAAgEgFg");
	this.shape_46.setTransform(184.65,159.85);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_47.setTransform(181.175,160.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgXAJQAAgHAFgDQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTABIAAgHQAKgCAJAAQANAAAFAEQAFAEABAIIAAAgIgGAAIgCgEQgJAFgKAAQgTAAgBgQgAgLAEQgDABAAAFQAAAEADACQACACAHAAQAJAAAIgEIAAgMIgSAAQgGAAgCACg");
	this.shape_48.setTransform(176,160.35);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgcAiIAAhDIAeAAQAOAAAHAGQAFAFAAANQAAAMgFAFQgHAFgOAAIgUAAIAAAVgAgSAFIAUAAQAKAAADgDQAEgDAAgIQAAgJgEgDQgDgDgKAAIgUAAg");
	this.shape_49.setTransform(169.8,159.325);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_50.setTransform(160.275,160.275);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgSAbQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAGQAGAEABAMIAAAEIgnAAQAAAIAEAEQADACAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPAEQAAgHgDgCQgEgDgIAAQgGAAgEADQgEACAAAHIAdAAIAAAAgAAHgYIAAgIIAHAAIAAAIgAgLgYIAAgIIAHAAIAAAIg");
	this.shape_51.setTransform(154.15,159.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIABQAJgBAEgDQAEgEAAgJQAAgIgEgEQgEgEgJAAQgIAAgEAFg");
	this.shape_52.setTransform(148.075,160.35);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_53.setTransform(143.425,160.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAQAAIAAAHIgQAAIAAAXQAAAFACACQABACAHgBIAGAAIAAAIIgHABQgKAAgEgFg");
	this.shape_54.setTransform(139.35,159.85);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_55.setTransform(136.175,159.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgXAbQgIgJAAgSQAAgSAIgIQAIgIAQAAQANAAAHAFQAIAFACALIgKAAQgCgGgEgEQgFgDgJAAQgMAAgFAHQgFAFAAAOQAAAOAFAGQAFAGAMAAQAQAAAEgMIAKAAQgCAKgIAFQgHAGgNAAQgQAAgIgIg");
	this.shape_56.setTransform(131.35,159.35);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_57.setTransform(120.075,160.275);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAGgGAMAAQAMAAAFAGQAHAEgBANIAAADIgmAAQAAAIADAEQAFADAJAAIATgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_58.setTransform(112.15,160.35);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_59.setTransform(107.625,160.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_60.setTransform(102.325,159.325);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_61.setTransform(97.7,159.325);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_62.setTransform(92.525,159.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAFgGANAAQAMAAAFAGQAHAEgBANIAAADIgnAAQABAIADAEQAFADAJAAIATgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgCAIIAeAAIAAAAg");
	this.shape_63.setTransform(88.4,160.35);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAWQAJgDAIAAQAXAAAAAYQAAAZgXgBQgIABgKgFgAgPgDIAAAZQAIAEAHAAQAIAAAEgEQAEgEAAgIQAAgJgEgEQgEgDgIAAQgHAAgIADg");
	this.shape_64.setTransform(82.425,159.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgWAXIAAgIQAMACAKAAQAIAAADgBQACgBAAgEQABgEgDgBQgDgCgIAAQgMgCgEgCQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAALADIAAAHQgLgCgJAAIgLABQgDACAAADQABADACABQACACAJABQANAAAEADQAEADAAAIQAAAHgEAEQgFADgMAAQgMAAgLgCg");
	this.shape_65.setTransform(73.9,160.35);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_66.setTransform(69.8,159.325);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_67.setTransform(67.325,159.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgXAJQAAgHAFgDQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTABIAAgHQAKgCAJAAQANAAAGAEQAEAEABAIIAAAgIgGAAIgCgEQgJAFgKAAQgTAAgBgQgAgLAEQgDABAAAFQAAAEADACQACACAHAAQAJAAAIgEIAAgMIgSAAQgGAAgCACg");
	this.shape_68.setTransform(62.95,160.35);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAPAAIAAAHIgPAAIAAAXQAAAFACACQACACAFgBIAHAAIAAAIIgIABQgJAAgEgFg");
	this.shape_69.setTransform(57.95,159.85);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgRATQgGgGgBgNQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAEABANIAAADIgoAAQABAIAEAEQAEADAIAAIAUgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgIAAQgGAAgEADQgEACgBAIIAeAAIAAAAg");
	this.shape_70.setTransform(53.15,160.35);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgdAiIAAhDIAbAAQARAAAIAIQAHAIAAARQAAASgHAIQgIAIgRAAgAgUAZIASAAQAMAAAGgGQAFgFAAgOQAAgMgFgGQgGgGgMAAIgSAAg");
	this.shape_71.setTransform(46.575,159.325);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAEAAANIAAADIgoAAQABAIAEAEQADADAJAAIAUgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgHAAQgIAAgDADQgDACgCAIIAeAAIAAAAg");
	this.shape_72.setTransform(37.2,160.35);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_73.setTransform(32.675,160.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAEAAANIAAADIgoAAQABAIAEAEQADADAJAAIAUgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgHAAQgIAAgDADQgDACgCAIIAeAAIAAAAg");
	this.shape_74.setTransform(27.75,160.35);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAQAAIAAAHIgQAAIAAAXQAAAFABACQADACAFgBIAHAAIAAAIIgIABQgJAAgEgFg");
	this.shape_75.setTransform(22.75,159.85);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_76.setTransform(19.575,159.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAFgGANAAQAMAAAFAGQAHAEgBANIAAADIgmAAQAAAIADAEQAFADAJAAIATgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_77.setTransform(15.5,160.35);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AARAiIgQg6IgBAAIgQA6IgRAAIgShDIAJAAIARA6IABAAIAQg6IARAAIAPA6IADAAIAPg6IALAAIgTBDg");
	this.shape_78.setTransform(6.95,159.325);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_79.setTransform(262.45,151.35);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgYAaQgIgIAAgSQAAgRAIgJQAIgIAQAAQAOAAAIAFQAHAFADALIgKAAQgCgGgFgDQgGgDgJAAQgMAAgFAFQgFAHAAANQAAAOAFAGQAGAGAMAAQALAAAGgEQAFgEAAgKIAAgCIgXAAIAAgIIAhAAIAAAKQAAAbggAAQgRAAgIgJg");
	this.shape_80.setTransform(257.025,148.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_81.setTransform(251.625,149.45);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAPAiIghghIAAAhIgJAAIAAhDIAJAAIAAAeIAhgeIAMAAIgjAgIAkAjg");
	this.shape_82.setTransform(246.575,148.475);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgHAiIgahDIAKAAIAXA6IABAAIAXg6IAKAAIgaBDg");
	this.shape_83.setTransform(239.2,148.475);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_84.setTransform(228.025,149.425);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgSATQgFgFgBgOQABgMAFgGQAGgGAMAAQAMAAAGAFQAGAFABAMIAAAFIgoAAQABAHAEADQAEADAIAAIAUgBIAAAHQgJADgLAAQgOAAgGgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgEADgBAGIAeAAIAAAAg");
	this.shape_85.setTransform(220.1,149.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgYAJQAAgYAXAAQAHAAAKAFIAAgYIAJAAIAABDIgGAAIgBgDQgLAEgIABQgXAAAAgagAgLgCQgEACAAAJQAAAJAEAFQAEAEAIgBQAHABAIgEIAAgZQgIgEgHAAQgIAAgEAEg");
	this.shape_86.setTransform(213.85,148.55);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgIIAAgYIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACABQABACAHAAIAGAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_87.setTransform(206.3,149);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_88.setTransform(201.125,148.475);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgPATQgGgFAAgOQAAgNAGgFQAGgGANAAQAIAAAJACIAAAJQgJgCgIAAQgJgBgDAEQgEAEAAAIQAAAJAEAEQADADAJAAIASgBIAAAHQgJADgJAAQgNAAgGgGg");
	this.shape_89.setTransform(195.275,149.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_90.setTransform(191.275,148.55);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_91.setTransform(186.775,149.425);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgIIAAgYIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGABABQADACAFAAIAHAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_92.setTransform(179.05,149);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgCQADgDAAgGIAAgCQgJAEgIAAQgXAAAAgXQAAgZAXAAQAIAAAKAEIABgCIAHAAIAAArQAAALgGAFQgGAEgNAAQgKAAgJgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAJAAAHgEIAAgYQgIgEgIABQgHgBgEAEg");
	this.shape_93.setTransform(173.85,150.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAGgGAMAAQAMAAAFAFQAHAFgBAMIAAAFIgmAAQAAAHADADQAFADAJAAIATgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_94.setTransform(167.95,149.5);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_95.setTransform(163.725,148.55);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAIAAIAABDg");
	this.shape_96.setTransform(161.2,148.475);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_97.setTransform(158.425,149.45);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgRATQgGgFgBgOQABgMAGgGQAFgGAMAAQAMAAAGAFQAGAFABAMIAAAFIgoAAQABAHAEADQAEADAIAAIAUgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgEADgBAGIAeAAIAAAAg");
	this.shape_98.setTransform(153.5,149.5);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgIIAAgYIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACABQABACAHAAIAGAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_99.setTransform(148.5,149);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_100.setTransform(143.375,149.425);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgSATQgFgEgBgIIAAgeIAJAAIAAAdQAAAKAOAAQAHAAAKgFIAAgiIAJAAIAAAuIgHAAIgBgEQgLAFgIAAQgLAAgFgFg");
	this.shape_101.setTransform(136.85,149.575);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_102.setTransform(129.575,149.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_103.setTransform(122.275,148.475);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgPATQgGgFAAgOQAAgNAGgFQAGgGANAAQAIAAAJACIAAAJQgJgCgIAAQgJgBgDAEQgEAEAAAIQAAAJAEAEQADADAJAAIASgBIAAAHQgJADgJAAQgNAAgGgGg");
	this.shape_104.setTransform(116.425,149.5);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_105.setTransform(112.425,148.55);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAFAAAMIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_106.setTransform(108.3,149.5);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_107.setTransform(103.775,149.45);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_108.setTransform(100.175,149.45);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAFAAAMIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_109.setTransform(95.25,149.5);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgIIAAgYIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGABABQADACAFAAIAHAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_110.setTransform(90.25,149);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgVAWIAAgIQALADAKAAQAIAAACgBQADgBABgDQAAgEgDgCQgCgBgJgBQgNgCgEgCQgEgDAAgHQAAgIAFgDQAFgDALAAQALAAAJACIAAAIQgJgCgLAAIgJABQgDABAAADQAAAEACABQADABAHABQANACAFACQAFADAAAIQgBAIgEADQgFADgNAAQgMAAgJgDg");
	this.shape_111.setTransform(85.55,149.5);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgYAgQgJgIABgSQgBgRAJgJQAHgIARAAQARAAAIAIQAIAJAAARQAAASgIAIQgIAJgRAAQgRAAgHgJgAgRgOQgGAHAAANQAAAOAGAGQAFAGAMAAQANAAAGgGQAFgGAAgOQAAgNgFgHQgGgFgNAAQgMAAgFAFgAAGghIAAgHIAHAAIAAAHgAgNghIAAgHIAIAAIAAAHg");
	this.shape_112.setTransform(78.85,147.9);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAADgCQAEgDAAgGIAAgCQgKAEgGAAQgYAAAAgXQAAgZAYAAQAHAAAKAEIACgCIAGAAIAAArQAAALgGAFQgGAEgMAAQgKAAgKgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAIAAQAHAAAIgEIAAgYQgIgEgHABQgIgBgEAEg");
	this.shape_113.setTransform(69.15,150.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_114.setTransform(62.875,149.425);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgSATQgFgEgBgIIAAgeIAJAAIAAAdQAAAKAOAAQAHAAAKgFIAAgiIAJAAIAAAuIgHAAIgBgEQgKAFgJAAQgLAAgFgFg");
	this.shape_115.setTransform(56.4,149.575);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgVAWIAAgIQALADAKAAQAIAAACgBQADgBABgDQAAgEgDgCQgCgBgJgBQgNgCgEgCQgEgDAAgHQAAgIAFgDQAFgDALAAQALAAAJACIAAAIQgJgCgLAAIgJABQgDABAAADQAAAEACABQADABAHABQANACAFACQAFADAAAIQgBAIgEADQgFADgNAAQgMAAgJgDg");
	this.shape_116.setTransform(50.45,149.5);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgWAWIAAgIQAMADAKAAQAIAAADgBQACgBAAgDQAAgEgCgCQgDgBgIgBQgNgCgDgCQgFgDAAgHQAAgIAFgDQAFgDALAAQAKAAAKACIAAAIQgJgCgKAAIgKABQgEABAAADQAAAEADABQACABAJABQANACAEACQAFADgBAIQAAAIgEADQgGADgLAAQgMAAgLgDg");
	this.shape_117.setTransform(44.85,149.5);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgXAJQABgHAEgDQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTACIAAgIQAJgCAKAAQANAAAGAEQAEAEAAAJIAAAeIgFAAIgCgDQgJAFgKAAQgUAAAAgQgAgLAEQgCACgBAEQABAEACACQADACAFAAQAKAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_118.setTransform(38.9,149.5);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_119.setTransform(34.65,148.475);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_120.setTransform(31.875,149.45);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAFAAAMIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgEADgBAGIAeAAIAAAAg");
	this.shape_121.setTransform(26.95,149.5);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgYAJQAAgYAYAAQAHAAAJAFIAAgYIAJAAIAABDIgGAAIgBgDQgMAEgGABQgYAAAAgagAgLgCQgEACAAAJQAAAJAEAFQAEAEAIgBQAIABAHgEIAAgZQgHgEgIAAQgIAAgEAEg");
	this.shape_122.setTransform(20.65,148.55);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAFAAAMIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgEADgBAGIAeAAIAAAAg");
	this.shape_123.setTransform(14.8,149.5);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_124.setTransform(10.575,148.55);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AASAiIgmg2IAAA2IgJAAIAAhDIAMAAIAmA2IAAg2IAJAAIAABDg");
	this.shape_125.setTransform(5.325,148.475);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AAYAiIgHgTIghAAIgHATIgKAAIAahDIAPAAIAaBDgAANAGIgMgfIgBAAIgNAfIAaAAg");
	this.shape_126.setTransform(221.7,137.575);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgZAgIAAgKQAMAEAMgBQAKAAAFgCQAEgBAAgHQAAgFgEgDQgDgCgLgBQgQgCgFgDQgGgEAAgKQAAgKAHgEQAHgFAPAAQAKAAAMADIAAAJQgNgDgJAAQgLAAgEACQgDACAAAGQAAAFADACIAOAEQAQABAFADQAGAFAAAKQAAAKgHAGQgHAEgPAAQgNAAgLgDg");
	this.shape_127.setTransform(214.65,137.6);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_128.setTransform(205.975,137.575);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_129.setTransform(199.575,138.525);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgWAJQAAgIAEgCQAEgDAKAAIATAAIAAgDQAAgFgDgCQgDgCgJAAIgTACIAAgIQAKgCAJAAQANAAAGAEQAEAEAAAJIAAAeIgFAAIgCgDQgJAFgKAAQgUAAABgQgAgLAEQgCACAAAEQAAAEACACQADACAFAAQAKAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_130.setTransform(193.15,138.6);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgbAiIAAhDIAfAAQALAAAGAEQAFAEAAAKQAAANgKACQAMACAAAOQAAAKgFAEQgGAEgNAAgAgSAZIAWAAQAIAAADgCQADgCAAgGQAAgGgDgDQgDgCgHAAIgXAAgAgSgEIAWAAQAHAAADgCQADgCAAgGQAAgGgDgCQgDgCgIAAIgVAAg");
	this.shape_131.setTransform(186.8,137.575);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgVAXIAAgJQALADAKAAQAIAAACgBQADgBABgDQAAgFgDgBQgCgCgJAAQgNgBgEgDQgEgDAAgHQAAgIAFgDQAFgDALAAQALAAAJADIAAAHQgJgCgLAAIgJABQgDABAAADQAAAEACABQADABAHACQANABAFACQAFADAAAIQgBAIgEADQgFADgNAAQgMAAgJgCg");
	this.shape_132.setTransform(177.8,138.6);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_133.setTransform(173.725,137.65);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACABQACACAFAAIAHAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_134.setTransform(170.45,138.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_135.setTransform(165.325,138.525);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgXAJQAAgIAFgCQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgDgCgIAAIgTACIAAgIQAKgCAJAAQANAAAFAEQAFAEABAJIAAAeIgGAAIgCgDQgJAFgKAAQgTAAgBgQgAgLAEQgDACAAAEQAAAEADACQACACAHAAQAJAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_136.setTransform(158.9,138.6);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAIAAIAABDg");
	this.shape_137.setTransform(154.65,137.575);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAIAAIAABDg");
	this.shape_138.setTransform(152.2,137.575);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgSATQgFgFgBgOQABgMAFgGQAGgGAMAAQAMAAAGAFQAGAGABALIAAAFIgoAAQABAHAEADQAEADAIAAIAUgBIAAAIQgJACgLAAQgOAAgGgGgAAPgDQAAgHgEgDQgDgDgIAAQgGAAgEADQgEADgBAHIAeAAIAAAAg");
	this.shape_139.setTransform(148.1,138.6);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACABQABACAHAAIAGAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_140.setTransform(143.1,138.1);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgaAgIAAgKQANAEANgBQAKAAAEgCQAEgBAAgHQAAgFgDgDQgEgCgLgBQgPgCgGgDQgFgEgBgKQABgKAGgEQAHgFAOAAQALAAAMADIAAAJQgNgDgKAAQgKAAgEACQgDACgBAGQAAAFADACIAOAEQARABAFADQAFAFAAAKQAAAKgGAGQgHAEgOAAQgNAAgNgDg");
	this.shape_141.setTransform(137.75,137.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_142.setTransform(130.225,138.55);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAFgGANAAQAMAAAFAFQAHAGgBALIAAAFIgmAAQAAAHADADQAFADAJAAIATgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgDgDQgEgDgHAAQgIAAgDADQgDADgBAHIAdAAIAAAAg");
	this.shape_143.setTransform(125.3,138.6);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgYAKQAAgZAYAAQAGAAAKAFIAAgYIAJAAIAABDIgGAAIgBgDQgMAEgGABQgYAAAAgZgAgLgCQgEACAAAKQAAAJAEADQAEAFAIAAQAHAAAIgFIAAgYQgIgEgHAAQgIAAgEAEg");
	this.shape_144.setTransform(119,137.65);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_145.setTransform(110.275,138.525);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIgBQAJABAEgEQAEgEAAgJQAAgIgEgEQgEgEgJABQgIAAgEADg");
	this.shape_146.setTransform(103.925,138.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgGAXIgVgtIAKAAIARAmIAAAAIASgmIAKAAIgVAtg");
	this.shape_147.setTransform(97.875,138.6);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGABABQADACAFAAIAHAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_148.setTransform(90.4,138.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIgBQAJABAEgEQAEgEAAgJQAAgIgEgEQgEgEgJABQgIAAgEADg");
	this.shape_149.setTransform(85.375,138.6);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhDIAJAAIAAAYQAJgFAIAAQAXAAAAAZQAAAZgXAAQgIgBgKgEgAgPgCIAAAYQAIAEAHAAQAIAAAEgEQAEgDAAgJQAAgKgEgCQgEgEgIAAQgHAAgIAEg");
	this.shape_150.setTransform(79.275,137.65);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAFgGANAAQAMAAAFAFQAHAGgBALIAAAFIgmAAQAAAHADADQAFADAIAAIAUgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgDgDQgEgDgHAAQgIAAgDADQgDADgBAHIAdAAIAAAAg");
	this.shape_151.setTransform(73.1,138.6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgTAgIAAgJQAKACAJAAQAJAAAEgCQADgDAAgGIAAgCQgJAEgIAAQgXAAAAgYQAAgXAXgBQAIAAAKAEIABgCIAHAAIAAArQAAALgGAFQgGAEgNAAQgJAAgKgBgAgLgUQgEAEAAAIQAAAJAEADQAEAEAHAAQAJAAAHgDIAAgZQgIgEgIABQgHgBgEAEg");
	this.shape_152.setTransform(66.85,139.4);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_153.setTransform(60.575,138.525);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AAYAiIgHgTIghAAIgHATIgKAAIAahDIAPAAIAaBDgAANAGIgMgfIgBAAIgNAfIAaAAg");
	this.shape_154.setTransform(53.75,137.575);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_155.setTransform(46.05,140.45);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_156.setTransform(41.275,138.525);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_157.setTransform(36.475,138.55);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AgRATQgGgFgBgOQABgMAGgGQAFgGAMAAQAMAAAGAFQAGAGABALIAAAFIgoAAQABAHAEADQAEADAIAAIAUgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgEgDQgDgDgIAAQgGAAgEADQgEADgBAHIAeAAIAAAAg");
	this.shape_158.setTransform(31.55,138.6);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_159.setTransform(25.325,138.525);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGABABQADACAFAAIAHAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_160.setTransform(20.05,138.1);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_161.setTransform(16.575,138.55);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AgWAJQgBgIAFgCQAEgDAKAAIATAAIAAgDQAAgFgEgCQgDgCgIAAIgTACIAAgIQAKgCAJAAQANAAAFAEQAGAEAAAJIAAAeIgHAAIgBgDQgJAFgKAAQgTAAAAgQgAgLAEQgCACAAAEQAAAEACACQADACAGAAQAJAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_162.setTransform(11.4,138.6);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AgcAiIAAhDIAfAAQANAAAHAGQAFAFAAANQAAAMgFAFQgHAFgNAAIgWAAIAAAVgAgTAFIAWAAQAIAAAEgDQAEgDAAgIQAAgJgEgDQgEgDgIAAIgWAAg");
	this.shape_163.setTransform(5.2,137.575);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_164.setTransform(263.675,127.625);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AgSAbQgFgFgBgOQABgMAFgGQAHgGALAAQAMAAAGAFQAGAGABAKIAAAGIgoAAQABAHAEAEQAEACAIAAIAUgBIAAAIQgJACgLAAQgNAAgHgGgAAPAEQAAgGgEgDQgDgDgIAAQgGAAgEADQgDADgCAGIAeAAIAAAAgAAHgYIAAgIIAHAAIAAAIgAgLgYIAAgIIAHAAIAAAIg");
	this.shape_165.setTransform(257.55,126.9);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEAEAIgBQAJABAEgEQAEgEAAgJQAAgIgEgEQgEgDgJAAQgIAAgEAEg");
	this.shape_166.setTransform(251.475,127.7);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_167.setTransform(246.825,127.65);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgFIAGgCIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACACQABABAHAAIAGAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_168.setTransform(242.75,127.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_169.setTransform(239.575,126.75);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("AgXAaQgIgIAAgSQAAgSAIgIQAIgIAQAAQANAAAHAFQAIAFACALIgKAAQgBgGgGgDQgEgEgJAAQgLABgGAGQgFAFAAAOQAAAOAFAGQAGAGALAAQAQAAAEgMIAKAAQgCALgIAFQgHAFgNAAQgQAAgIgJg");
	this.shape_170.setTransform(234.75,126.7);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_171.setTransform(225.275,127.625);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGAMAAQALAAAGAFQAGAGAAALIAAAFIgmAAQAAAHADAEQAFACAJAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgDgDQgEgDgHAAQgIAAgDADQgDADgBAHIAdAAIAAAAg");
	this.shape_172.setTransform(219.15,127.7);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AgYAKQAAgZAYAAQAGAAAKAFIAAgXIAJAAIAABCIgGAAIgBgDQgMAFgGAAQgYAAAAgZgAgLgDQgEAEAAAJQAAAJAEADQAEAFAHAAQAJAAAHgFIAAgZQgHgDgJAAQgHAAgEADg");
	this.shape_173.setTransform(212.9,126.75);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_174.setTransform(206.625,127.625);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAGABALIAAAFIgnAAQAAAHAEAEQADACAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgDgDQgEgDgIAAQgGAAgEADQgEADAAAHIAdAAIAAAAg");
	this.shape_175.setTransform(200.5,127.7);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_176.setTransform(192.475,127.625);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_177.setTransform(184.225,126.675);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAGAAALIAAAFIgmAAQAAAHADAEQAEACAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgDgDQgEgDgIAAQgGAAgEADQgEADAAAHIAdAAIAAAAg");
	this.shape_178.setTransform(178.1,127.7);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_179.setTransform(171.875,127.625);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAJAAIAABDg");
	this.shape_180.setTransform(167.4,126.675);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_181.setTransform(164.925,126.75);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FFFFFF").s().p("AgSATQgFgFgBgOQABgMAFgGQAHgGALAAQAMAAAGAFQAGAGABALIAAAFIgoAAQABAHAEAEQAEACAIAAIAUgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgEgDQgDgDgIAAQgGAAgEADQgDADgCAHIAeAAIAAAAg");
	this.shape_182.setTransform(160.8,127.7);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgFIAGgCIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACACQABABAHAAIAGAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_183.setTransform(155.8,127.2);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_184.setTransform(150.125,126.75);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAGAAALIAAAFIgmAAQAAAHAEAEQADACAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgDgDQgEgDgIAAQgGAAgEADQgEADAAAHIAdAAIAAAAg");
	this.shape_185.setTransform(146.05,127.7);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAXQAJgFAIAAQAXAAAAAZQAAAZgXAAQgIAAgKgFgAgPgDIAAAZQAIAEAHAAQAIAAAEgEQAEgDAAgJQAAgJgEgEQgEgDgIAAQgHAAgIADg");
	this.shape_186.setTransform(140.025,126.75);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FFFFFF").s().p("AARAiIAAgPIgqAAIAAgHIAZgtIAJAAIgXArIAfAAIAAgOIAJAAIAAAmg");
	this.shape_187.setTransform(130.975,126.675);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_188.setTransform(125.075,126.625);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgSAGgIQAHgIANAAQAPAAAFAIQAHAIAAASQAAATgHAHQgFAJgPAAQgNAAgHgJgAgNgTQgEAFAAAOQAAAOAEAHQAEAFAJAAQAJAAAFgFQADgHAAgOQAAgOgDgFQgFgGgJgBQgJABgEAGg");
	this.shape_189.setTransform(118.95,126.7);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_190.setTransform(112.825,126.625);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_191.setTransform(108.15,129.55);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#FFFFFF").s().p("AgTAbQgGgIAAgTQAAgSAHgIQAHgIAQAAQAIAAAIACIAAAJQgIgDgIAAQgLABgFAFQgFAEAAAOQAKgEAJgBQANABAFAFQAFADAAAMQAAALgHAFQgGAFgMAAQgOAAgGgIgAgQAEQABANADAFQAEAFAJgBQAIABAEgDQAEgDAAgHQAAgHgDgDQgEgEgJAAQgHAAgKAEg");
	this.shape_192.setTransform(103.525,126.7);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgSAGgIQAGgIAOAAQAPAAAGAIQAGAIAAASQAAATgGAHQgGAJgPAAQgOAAgGgJgAgNgTQgEAFAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAFgHAAgOQAAgOgFgFQgDgGgKgBQgJABgEAGg");
	this.shape_193.setTransform(97.4,126.7);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_194.setTransform(92.75,129.55);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgSAGgIQAHgIANAAQAPAAAFAIQAHAIAAASQAAATgHAHQgFAJgPAAQgNAAgHgJgAgNgTQgEAFAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAFgHAAgOQAAgOgFgFQgDgGgKgBQgJABgEAGg");
	this.shape_195.setTransform(88.15,126.7);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#FFFFFF").s().p("AgYAhIAAgIQAKACALAAQAKAAAFgCQAEgDAAgGQAAgHgEgDQgEgCgIAAIgQAAIAAgIIAQAAQAIAAADgCQADgDAAgGQAAgGgDgDQgEgCgJgBQgLAAgKACIAAgHQAKgCALAAQAOAAAGAEQAGAFAAAJQAAAOgLACQAMACAAAOQAAAKgHAFQgGAEgPAAQgMAAgJgCg");
	this.shape_196.setTransform(82.025,126.7);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FFFFFF").s().p("AgVAXIAAgIQALACAKAAQAIAAADgBQADgBAAgDQgBgFgCgBQgCgCgJAAQgMgBgFgDQgEgDAAgHQAAgIAFgCQAFgEALAAQALAAAKADIAAAHQgLgCgKAAIgKABQgCABAAADQgBAEADABQADABAHACQAOABAEACQAEADABAIQAAAIgGADQgFADgMAAQgLAAgKgCg");
	this.shape_197.setTransform(73.7,127.7);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_198.setTransform(69.625,126.75);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAXQAJgFAIAAQAXAAAAAZQAAAZgXAAQgIAAgKgFgAgPgDIAAAZQAIAEAHAAQAIAAAEgEQAEgDAAgJQAAgJgEgEQgEgDgIAAQgHAAgIADg");
	this.shape_199.setTransform(65.375,126.75);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#FFFFFF").s().p("AgTAgIAAgJQAKACAJAAQAJAAADgCQAEgDAAgGIAAgCQgKAEgGAAQgYAAAAgYQAAgXAYgBQAHABAKADIABgCIAHAAIAAArQAAALgGAEQgGAFgNAAQgKAAgJgBgAgLgUQgEAEAAAIQAAAJAEADQAEAEAHAAQAJAAAHgDIAAgZQgIgDgIAAQgHAAgEADg");
	this.shape_200.setTransform(56.3,128.5);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FFFFFF").s().p("AgXAJQABgIAEgCQAEgDAJAAIAUAAIAAgDQAAgFgDgCQgDgCgJAAIgTACIAAgIQAJgCAKAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAAAgQgAgLAEQgCACgBAEQABAEACACQADACAFAAQAKAAAIgEIAAgLIgSAAQgGAAgCABg");
	this.shape_201.setTransform(50.15,127.7);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_202.setTransform(45.575,127.65);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgFIAGgCIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACACQABABAHAAIAGAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_203.setTransform(41.5,127.2);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_204.setTransform(38.025,127.65);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAGAAALIAAAFIgmAAQAAAHAEAEQADACAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgDgDQgEgDgIAAQgGAAgEADQgEADAAAHIAdAAIAAAAg");
	this.shape_205.setTransform(33.1,127.7);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#FFFFFF").s().p("AgGAYIgVguIAKAAIARAmIAAAAIASgmIAKAAIgVAug");
	this.shape_206.setTransform(27.175,127.7);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FFFFFF").s().p("AgJAiIAAgmIgHAAIAAgGIAHgCIAAgEQAAgJADgEQAFgEAJAAIAJAAIAAAIIgIAAQgGAAgCACQgBACAAAFIAAAEIAPAAIAAAIIgPAAIAAAmg");
	this.shape_207.setTransform(22.8,126.625);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FFFFFF").s().p("AgSATQgGgEAAgIIAAgeIAJAAIAAAdQABAKANAAQAHAAAKgFIAAgiIAJAAIAAAuIgGAAIgCgEQgLAFgIAAQgLAAgFgFg");
	this.shape_208.setTransform(17.5,127.775);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FFFFFF").s().p("AgXAJQABgIAEgCQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTACIAAgIQAKgCAJAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAAAgQgAgLAEQgCACgBAEQABAEACACQACACAGAAQAKAAAIgEIAAgLIgSAAQgGAAgCABg");
	this.shape_209.setTransform(11.1,127.7);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#FFFFFF").s().p("AAPAiIghghIAAAhIgJAAIAAhDIAJAAIAAAeIAhgeIAMAAIgjAgIAkAjg");
	this.shape_210.setTransform(5.125,126.675);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_211.setTransform(265.825,115.9);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAGQAGAFAAAMIAAADIgmAAQAAAJAEACQADAEAKAAIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgIAAQgGAAgEADQgEADAAAGIAdAAIAAAAg");
	this.shape_212.setTransform(261.7,116.85);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhDIAJAAIAAAXQAJgDAIAAQAXgBAAAYQAAAZgXAAQgIAAgKgEgAgPgCIAAAZQAIADAHAAQAIAAAEgDQAEgFAAgJQAAgIgEgDQgEgEgIAAQgHAAgIAEg");
	this.shape_213.setTransform(255.675,115.9);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAADgDQAEgCAAgHIAAgBQgKAEgGAAQgYAAAAgXQAAgYAYgBQAHAAAKAFIABgEIAHAAIAAAsQAAALgGAFQgGAEgNAAQgKAAgJgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIAAQgHAAgEADg");
	this.shape_214.setTransform(246.65,117.65);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_215.setTransform(242.375,115.9);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAQAAIAAAIIgQAAIAAAXQAAAFABABQACADAGAAIAHgBIAAAIIgIABQgJgBgEgEg");
	this.shape_216.setTransform(239.1,116.35);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAIAAIAABDg");
	this.shape_217.setTransform(235.9,115.825);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#FFFFFF").s().p("AgSAcQgFgEgBgIIAAgfIAJAAIAAAeQAAAJAOABQAHAAAKgFIAAgjIAJAAIAAAuIgHAAIgBgDQgKAFgJAAQgLAAgFgFgAAGgYIAAgIIAHAAIAAAIgAgMgYIAAgIIAIAAIAAAIg");
	this.shape_218.setTransform(231.45,116.05);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FFFFFF").s().p("AgYAbQgIgIAAgTQAAgRAIgJQAIgIAQAAQAOAAAIAFQAHAFADALIgKAAQgCgHgFgDQgGgCgJAAQgMAAgFAFQgFAHAAANQAAAOAFAGQAGAGAMAAQALAAAGgEQAFgFAAgIIAAgDIgXAAIAAgIIAhAAIAAALQAAAaggAAQgRAAgIgIg");
	this.shape_219.setTransform(224.375,115.85);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_220.setTransform(216.5,118.7);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FFFFFF").s().p("AgLAoQAHgHAEgKQADgLAAgMQAAgYgOgPIAJAAQAOAQAAAXQAAAYgOAQg");
	this.shape_221.setTransform(213.075,116.45);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#FFFFFF").s().p("AAVAiIAAgeIgpAAIAAAeIgJAAIAAhDIAJAAIAAAdIApAAIAAgdIAJAAIAABDg");
	this.shape_222.setTransform(207.8,115.825);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhDIAJAAIAAAXQAJgDAIAAQAXgBAAAYQAAAZgXAAQgIAAgKgEgAgPgCIAAAZQAIADAHAAQAIAAAEgDQAEgFAAgJQAAgIgEgDQgEgEgIAAQgHAAgIAEg");
	this.shape_223.setTransform(200.825,115.9);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_224.setTransform(192.475,116.775);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FFFFFF").s().p("AgYAbQgIgIAAgTQAAgRAIgJQAIgIAQAAQAOAAAIAFQAHAFADALIgKAAQgCgHgFgDQgGgCgJAAQgMAAgFAFQgFAHAAANQAAAOAFAGQAGAGAMAAQALAAAGgEQAFgFAAgIIAAgDIgXAAIAAgIIAhAAIAAALQAAAaggAAQgRAAgIgIg");
	this.shape_225.setTransform(183.625,115.85);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_226.setTransform(174.075,115.825);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#FFFFFF").s().p("AgPATQgGgGAAgNQAAgMAGgGQAGgGANAAQAIAAAJACIAAAIQgJgBgIAAQgJAAgDADQgEAEAAAIQAAAJAEAEQADAEAJAAIASgCIAAAHQgJADgJAAQgNAAgGgGg");
	this.shape_227.setTransform(168.175,116.85);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_228.setTransform(164.175,115.9);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAFAAAMIAAADIgoAAQABAJAEACQADAEAJAAIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_229.setTransform(160.05,116.85);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgDAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_230.setTransform(155.525,116.8);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgDAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_231.setTransform(151.925,116.8);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAFAAAMIAAADIgoAAQABAJAEACQADAEAJAAIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_232.setTransform(147,116.85);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAQAAIAAAIIgQAAIAAAXQAAAFABABQADADAFAAIAHgBIAAAIIgIABQgJgBgEgEg");
	this.shape_233.setTransform(142,116.35);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#FFFFFF").s().p("AgWAWIAAgIQAMADAKAAQAIAAADgBQACgBAAgEQABgDgDgCQgDgBgIgBQgMgBgEgDQgFgCAAgIQAAgHAFgEQAFgDALAAQAKAAALACIAAAIQgLgCgJAAIgLABQgDABAAAEQABADACABQACACAJAAQANABAEADQAEADAAAIQAAAHgEADQgFAEgMAAQgMAAgLgDg");
	this.shape_234.setTransform(137.35,116.85);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#FFFFFF").s().p("AgYAhQgJgJABgSQgBgRAJgJQAHgIARAAQARAAAIAIQAIAJAAARQAAASgIAJQgIAIgRAAQgRAAgHgIgAgRgOQgGAHAAANQAAAOAGAGQAFAGAMAAQANAAAGgGQAFgGAAgOQAAgNgFgHQgGgFgNAAQgMAAgFAFgAAGghIAAgHIAHAAIAAAHgAgNghIAAgHIAIAAIAAAHg");
	this.shape_235.setTransform(130.6,115.25);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_236.setTransform(120.975,116.775);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#FFFFFF").s().p("AgRAbQgHgGABgNQgBgMAHgGQAGgGAMAAQAMAAAFAGQAHAFgBALIAAAEIgmAAQAAAJADACQAFAEAJAAIATgCIAAAHQgJADgLAAQgOAAgFgGgAAPADQAAgFgDgDQgEgDgHAAQgIAAgDADQgDADgBAFIAdAAIAAAAgAAGgYIAAgIIAHAAIAAAIgAgMgYIAAgIIAIAAIAAAIg");
	this.shape_237.setTransform(114.85,116.05);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIAAQAJAAAEgEQAEgEAAgJQAAgIgEgEQgEgDgJAAQgIAAgEADg");
	this.shape_238.setTransform(108.775,116.85);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgDAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_239.setTransform(104.125,116.8);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAQAAIAAAIIgQAAIAAAXQAAAFABABQACADAGAAIAHgBIAAAIIgIABQgJgBgEgEg");
	this.shape_240.setTransform(100.05,116.35);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_241.setTransform(96.875,115.9);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#FFFFFF").s().p("AgXAbQgHgJAAgSQAAgRAHgJQAIgIAPAAQAOAAAIAFQAHAFADALIgKAAQgCgHgFgDQgFgCgKAAQgLAAgFAFQgFAHAAANQAAAOAFAGQAFAGALAAQASAAAEgNIAKAAQgDAMgHAFQgIAFgOAAQgPAAgIgIg");
	this.shape_242.setTransform(92.05,115.85);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgDAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_243.setTransform(84.275,116.8);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#FFFFFF").s().p("AgSATQgFgGgBgNQABgMAFgGQAHgGALAAQAMAAAGAGQAGAFABAMIAAADIgoAAQABAJAEACQAEAEAIAAIAUgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgDADgCAGIAeAAIAAAAg");
	this.shape_244.setTransform(79.35,116.85);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#FFFFFF").s().p("AgYAJQAAgYAYABQAHAAAJADIAAgXIAJAAIAABDIgGAAIgCgDQgKAEgHAAQgYAAAAgZgAgLgCQgEADAAAIQAAAJAEAFQAEADAHAAQAJAAAHgDIAAgZQgHgEgJAAQgHAAgEAEg");
	this.shape_245.setTransform(73.05,115.9);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_246.setTransform(64.325,116.775);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#FFFFFF").s().p("AgSATQgFgGgBgNQABgMAFgGQAHgGALAAQAMAAAGAGQAGAFABAMIAAADIgoAAQABAJAEACQAEAEAIAAIAUgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgDADgCAGIAeAAIAAAAg");
	this.shape_247.setTransform(58.2,116.85);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAADgDQAEgCAAgHIAAgBQgKAEgGAAQgYAAAAgXQAAgYAYgBQAHAAAKAFIACgEIAGAAIAAAsQAAALgGAFQgGAEgMAAQgKAAgKgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAIAAQAHAAAIgEIAAgYQgIgDgHAAQgIAAgEADg");
	this.shape_248.setTransform(51.95,117.65);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_249.setTransform(45.725,116.775);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#FFFFFF").s().p("AgSATQgFgEgBgIIAAgeIAJAAIAAAdQAAAKAOAAQAHAAAKgFIAAgiIAJAAIAAAuIgHAAIgBgEQgLAFgIAAQgLAAgFgFg");
	this.shape_250.setTransform(39.2,116.925);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAADgDQAEgCAAgHIAAgBQgKAEgGAAQgYAAAAgXQAAgYAYgBQAHAAAKAFIACgEIAGAAIAAAsQAAALgGAFQgGAEgMAAQgKAAgKgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAIAAQAHAAAIgEIAAgYQgIgDgHAAQgIAAgEADg");
	this.shape_251.setTransform(32.7,117.65);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_252.setTransform(26.475,116.775);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_253.setTransform(21.975,115.9);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#FFFFFF").s().p("AgYAJQAAgYAYABQAGAAAKADIAAgXIAJAAIAABDIgGAAIgBgDQgMAEgGAAQgYAAAAgZgAgLgCQgEADAAAIQAAAJAEAFQAEADAIAAQAHAAAIgDIAAgZQgIgEgHAAQgIAAgEAEg");
	this.shape_254.setTransform(17.4,115.9);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAGQAGAFABAMIAAADIgnAAQAAAJAEACQADAEAKAAIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgIAAQgGAAgEADQgEADAAAGIAdAAIAAAAg");
	this.shape_255.setTransform(11.5,116.85);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#FFFFFF").s().p("AgbAiIAAhDIAfAAQAMAAAFAEQAFAEAAAKQAAANgKACQAMACAAAOQAAAKgGAEQgFAEgNAAgAgSAZIAWAAQAIAAADgCQADgCABgGQgBgGgDgDQgDgCgHAAIgXAAgAgSgEIAWAAQAHAAACgCQADgCABgGQgBgGgDgCQgCgCgIAAIgVAAg");
	this.shape_256.setTransform(5.15,115.825);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_257.setTransform(267.775,105.875);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAFgGANAAQAMAAAFAGQAHAFgBALIAAAFIgmAAQAAAIADACQAFADAIABIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_258.setTransform(261.65,105.95);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#FFFFFF").s().p("AgYAJQAAgYAXAAQAIABAJAEIAAgYIAJAAIAABDIgGAAIgCgDQgKAEgIABQgXAAAAgagAgLgCQgEADAAAIQAAAJAEAFQAEADAHAAQAJAAAHgDIAAgZQgHgEgJAAQgHAAgEAEg");
	this.shape_259.setTransform(255.4,105);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#FFFFFF").s().p("AgFAiIAAgIIAHABQAHgBADgCQAEgCAAgHQAAgHgEgCQgDgEgIAAIgGAAIAAgFIAGAAQAHAAADgDQADgCAAgHQAAgFgEgDQgDgCgHgBQgIABgDACQgEACAAAGIAAAxIgJAAIAAgxQAAgJAGgEQAFgGANAAQALAAAGAFQAGAEAAAJQAAAOgLACQANACAAAOQAAAKgGAEQgFAEgKABIgJgBg");
	this.shape_260.setTransform(246.875,104.9);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#FFFFFF").s().p("AgXARQABgHAEgEQAEgDAJAAIAUAAIAAgDQAAgEgDgCQgDgCgJAAIgTACIAAgJQAJgBAKAAQANAAAGAEQAEAEAAAIIAAAfIgFAAIgCgDQgJAFgKAAQgUAAAAgQgAgLAMQgCACgBAEQABAEACACQADACAFAAQAKAAAIgFIAAgKIgSAAQgGAAgCABgAAGgYIAAgIIAIAAIAAAIgAgLgYIAAgIIAHAAIAAAIg");
	this.shape_261.setTransform(240.5,105.15);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_262.setTransform(232.425,105.875);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGAMAAQALAAAGAGQAGAFAAALIAAAFIgmAAQAAAIADACQAFADAJABIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_263.setTransform(224.55,105.95);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAADgDQAEgCAAgHIAAgBQgKAEgGAAQgYAAAAgXQAAgZAYAAQAHAAAKAEIABgDIAHAAIAAAsQAAALgGAFQgGAEgNAAQgKAAgJgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIAAQgHAAgEADg");
	this.shape_264.setTransform(218.3,106.75);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgIAAQgXAAAAgXQAAgZAXAAQAIAAAKAEIABgDIAHAAIAAAsQAAALgGAFQgGAEgNAAQgJAAgKgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIAAQgHAAgEADg");
	this.shape_265.setTransform(209.5,106.75);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_266.setTransform(203.225,105.875);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQgBAKANAAQAIAAAKgFIAAgiIAIAAIAAAuIgFAAIgDgEQgJAFgKAAQgKAAgGgFg");
	this.shape_267.setTransform(196.75,106.025);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_268.setTransform(191.975,105.9);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAFAAALIAAAFIgoAAQABAIAEACQADADAJABIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_269.setTransform(187.05,105.95);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgIAAQgXAAAAgXQAAgZAXAAQAIAAAKAEIABgDIAHAAIAAAsQAAALgGAFQgGAEgNAAQgJAAgKgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAIAAAIgEIAAgYQgIgDgIAAQgHAAgEADg");
	this.shape_270.setTransform(180.8,106.75);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_271.setTransform(174.525,105.875);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#FFFFFF").s().p("AgXARQABgHAEgEQAEgDAJAAIAUAAIAAgDQAAgEgEgCQgCgCgJAAIgTACIAAgJQAKgBAJAAQANAAAGAEQAEAEAAAIIAAAfIgFAAIgCgDQgJAFgKAAQgUAAAAgQgAgLAMQgCACgBAEQABAEACACQACACAGAAQAKAAAIgFIAAgKIgSAAQgGAAgCABgAAHgYIAAgIIAHAAIAAAIgAgLgYIAAgIIAHAAIAAAIg");
	this.shape_272.setTransform(168.15,105.15);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAIAAIAABDg");
	this.shape_273.setTransform(163.9,104.925);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_274.setTransform(161.125,105.9);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#FFFFFF").s().p("AgRATQgGgFgBgOQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAFABALIAAAFIgoAAQABAIAEACQAEADAIABIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgEADgBAGIAeAAIAAAAg");
	this.shape_275.setTransform(156.2,105.95);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#FFFFFF").s().p("AgGAXIgVguIAKAAIARAoIAAAAIASgoIAKAAIgVAug");
	this.shape_276.setTransform(150.275,105.95);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGAMAAQALAAAGAGQAGAFAAALIAAAFIgmAAQAAAIADACQAFADAJABIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_277.setTransform(144.45,105.95);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_278.setTransform(140.225,105);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAQAAIAAAIIgQAAIAAAXQAAAFABABQACACAGABIAHgBIAAAIIgIAAQgJAAgEgEg");
	this.shape_279.setTransform(136.95,105.45);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_280.setTransform(131.825,105.875);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#FFFFFF").s().p("AgXAJQABgHAEgDQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTACIAAgJQAKgBAJAAQANAAAGAEQAEAEAAAJIAAAeIgFAAIgCgDQgJAFgKAAQgUAAAAgQgAgLAEQgCACgBAEQABAEACACQACACAGAAQAKAAAIgFIAAgKIgSAAQgGAAgCABg");
	this.shape_281.setTransform(125.4,105.95);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_282.setTransform(120.875,105.9);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#FFFFFF").s().p("AgXAJQAAgHAFgDQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTACIAAgJQAKgBAJAAQANAAAFAEQAFAEABAJIAAAeIgGAAIgCgDQgJAFgKAAQgTAAgBgQgAgLAEQgDACAAAEQAAAEADACQACACAHAAQAJAAAIgFIAAgKIgSAAQgGAAgCABg");
	this.shape_283.setTransform(115.7,105.95);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#FFFFFF").s().p("AgYAbQgIgJAAgSQAAgRAIgJQAIgIAQAAQAOAAAIAFQAHAFADALIgKAAQgCgHgFgCQgGgDgJAAQgMAAgFAFQgFAHAAANQAAAOAFAGQAGAGAMAAQALAAAGgEQAFgFAAgIIAAgDIgXAAIAAgIIAhAAIAAALQAAAaggAAQgRAAgIgIg");
	this.shape_284.setTransform(108.875,104.95);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#FFFFFF").s().p("AADAoQgOgQAAgYQAAgXAOgQIAJAAQgHAHgEAKQgDALAAALQAAAZAOAPg");
	this.shape_285.setTransform(103.675,105.55);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_286.setTransform(94.325,105.875);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_287.setTransform(86.575,104.925);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAGgIAOAAQAOAAAHAIQAGAJAAARQAAASgGAJQgHAIgOAAQgOAAgGgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAKAAAEgFQADgHAAgOQAAgOgDgGQgEgFgKAAQgJAAgEAFg");
	this.shape_288.setTransform(77.85,104.95);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAHgIANAAQAPAAAFAIQAHAJAAARQAAASgHAJQgFAIgPAAQgNAAgHgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAJAAAFgFQADgHAAgOQAAgOgDgGQgFgFgJAAQgJAAgEAFg");
	this.shape_289.setTransform(71.7,104.95);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAGgIAOAAQAOAAAHAIQAGAJAAARQAAASgGAJQgHAIgOAAQgOAAgGgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAKAAAEgFQADgHAAgOQAAgOgDgGQgEgFgKAAQgJAAgEAFg");
	this.shape_290.setTransform(65.6,104.95);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_291.setTransform(60.95,107.8);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAGgIAOAAQAPAAAFAIQAHAJAAARQAAASgHAJQgFAIgPAAQgOAAgGgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAJAAAFgFQAEgHAAgOQAAgOgEgGQgFgFgJAAQgJAAgEAFg");
	this.shape_292.setTransform(56.3,104.95);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAHgIANAAQAOAAAHAIQAGAJAAARQAAASgGAJQgHAIgOAAQgNAAgHgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAJAAAFgFQADgHAAgOQAAgOgDgGQgFgFgJAAQgJAAgEAFg");
	this.shape_293.setTransform(50.2,104.95);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#FFFFFF").s().p("AAIAiIAAg6IgVALIgEgHIAZgNIAJAAIAABDg");
	this.shape_294.setTransform(44.35,104.925);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#FFFFFF").s().p("AgPAoIAXhPIAIAAIgXBPg");
	this.shape_295.setTransform(40.675,105.55);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAGgGAMAAQAMAAAFAGQAHAFgBALIAAAFIgmAAQAAAIADACQAFADAJABIATgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_296.setTransform(36.1,105.95);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAQAAIAAAIIgQAAIAAAXQAAAFABABQADACAFABIAHgBIAAAIIgHAAQgKAAgEgEg");
	this.shape_297.setTransform(31.1,105.45);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#FFFFFF").s().p("AgWAJQgBgHAFgDQAEgDAKAAIATAAIAAgDQAAgFgDgCQgEgCgIAAIgTACIAAgJQAJgBAKAAQANAAAFAEQAGAEAAAJIAAAeIgHAAIgBgDQgJAFgKAAQgTAAAAgQgAgLAEQgDACABAEQgBAEADACQADACAGAAQAJAAAIgFIAAgKIgSAAQgGAAgCABg");
	this.shape_298.setTransform(26,105.95);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_299.setTransform(19.825,105.875);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIAAQAJAAAEgEQAEgEAAgJQAAgIgEgEQgEgDgJAAQgIAAgEADg");
	this.shape_300.setTransform(13.475,105.95);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#FFFFFF").s().p("AAaAiIAAg2IgUAnIgLAAIgUgnIAAA2IgKAAIAAhDIAOAAIAVAqIABAAIAVgqIAOAAIAABDg");
	this.shape_301.setTransform(5.875,104.925);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#FFFFFF").s().p("AgTAfQgHgFAAgKQAAgNANgDQgLgDAAgNQAAgKAGgEQAGgEAMAAQAOAAAGAEQAGAEAAAKQAAANgLADQAMADAAANQAAAKgGAFQgHAEgOAAQgNAAgGgEgAgMAGQgEACAAAHQAAAGADACQAEADAJAAQAKAAAEgDQAEgCAAgGQAAgHgFgCQgDgDgKABQgIgBgEADgAgMgXQgDADAAAGQAAAFAEADQADACAIAAQAJAAAEgCQADgDAAgFQAAgGgDgDQgEgCgJAAQgIAAgEACg");
	this.shape_302.setTransform(203.175,94.05);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#FFFFFF").s().p("AARAiIAAgPIgqAAIAAgHIAZgtIAJAAIgXArIAfAAIAAgOIAJAAIAAAmg");
	this.shape_303.setTransform(196.875,94.025);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_304.setTransform(189.975,95);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#FFFFFF").s().p("AgTAcQgEgEgBgIIAAgeIAJAAIAAAcQAAAKAOAAQAHABAKgFIAAgiIAJAAIAAAtIgHAAIgBgDQgKAFgJAAQgLAAgGgFgAAGgYIAAgIIAHAAIAAAIgAgMgYIAAgIIAIAAIAAAIg");
	this.shape_305.setTransform(184.65,94.25);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#FFFFFF").s().p("AgKAiIAAgmIgFAAIAAgGIAFgCIAAgEQAAgJAFgEQAEgEAJAAIAIAAIAAAIIgHAAQgGAAgCACQgCACAAAFIAAAEIAQAAIAAAIIgQAAIAAAmg");
	this.shape_306.setTransform(180,93.975);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#FFFFFF").s().p("AgVAWIAAgIQALADAKAAQAIAAADgBQADgBAAgDQgBgEgCgCQgCgBgJgBQgMgCgFgCQgEgDAAgHQAAgIAFgDQAFgDALAAQALAAAKACIAAAIQgLgCgKAAIgKABQgCABAAADQgBAEADABQADABAHABQAOACAEACQAEADABAIQAAAIgGADQgFADgMAAQgLAAgKgDg");
	this.shape_307.setTransform(172.7,95.05);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_308.setTransform(168.675,94.1);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgIIAAgYIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGABABQADACAFAAIAHAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_309.setTransform(165.4,94.55);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#FFFFFF").s().p("AgXAJQABgHAEgDQAEgDAJAAIAUAAIAAgDQAAgFgDgCQgDgCgJAAIgTACIAAgIQAKgCAJAAQANAAAGAEQAEAEAAAJIAAAeIgFAAIgCgDQgJAFgKAAQgUAAAAgQgAgLAEQgCACAAAEQAAAEACACQADACAFAAQAKAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_310.setTransform(160.3,95.05);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_311.setTransform(155.775,95);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#FFFFFF").s().p("AgTAgIAAgJQAKACAJAAQAJAAAEgCQADgDAAgGIAAgCQgJAEgHAAQgYAAAAgXQAAgZAYAAQAHAAAKAEIABgCIAHAAIAAArQAAALgGAFQgGAEgNAAQgKAAgJgBgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAJAAAHgDIAAgZQgIgEgIABQgHgBgEAEg");
	this.shape_312.setTransform(150.45,95.85);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_313.setTransform(139.875,94.975);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#FFFFFF").s().p("AgSATQgGgEABgIIAAgeIAJAAIAAAdQgBAKANAAQAIAAAKgFIAAgiIAIAAIAAAuIgFAAIgCgEQgKAFgKAAQgKAAgFgFg");
	this.shape_314.setTransform(131.6,95.125);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_315.setTransform(127.125,94.1);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_316.setTransform(120.825,94.975);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAGAAALIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgEADgBAGIAeAAIAAAAg");
	this.shape_317.setTransform(112.9,95.05);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_318.setTransform(108.375,95);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#FFFFFF").s().p("AgbAiIAAhDIAdAAQAOAAAHAGQAFAFAAANQAAAMgFAFQgHAFgOAAIgUAAIAAAVgAgSAFIAUAAQAKAAADgDQAEgDAAgIQAAgJgEgDQgDgDgKAAIgUAAg");
	this.shape_319.setTransform(103.1,94.025);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAGAAALIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_320.setTransform(93.9,95.05);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgEAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_321.setTransform(89.375,95);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#FFFFFF").s().p("AgXAJQAAgHAFgDQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTACIAAgIQAKgCAJAAQANAAAFAEQAFAEABAJIAAAeIgGAAIgCgDQgJAFgKAAQgTAAgBgQgAgLAEQgDACAAAEQAAAEADACQACACAHAAQAJAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_322.setTransform(84.2,95.05);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#FFFFFF").s().p("AgXAaQgIgIAAgSQAAgRAIgJQAIgIAQAAQANAAAHAFQAIAFACALIgKAAQgBgGgGgDQgFgDgIAAQgLAAgGAFQgFAHAAANQAAAOAFAGQAGAGALAAQARAAADgMIAKAAQgCAKgIAGQgHAFgNAAQgQAAgIgJg");
	this.shape_323.setTransform(77.6,94.05);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#FFFFFF").s().p("AgYAJQAAgYAYAAQAHAAAJAFIAAgYIAJAAIAABDIgGAAIgCgDQgKAEgHABQgYAAAAgagAgLgCQgEACAAAJQAAAJAEAFQAEAEAHAAQAJAAAHgEIAAgZQgHgEgJAAQgHAAgEAEg");
	this.shape_324.setTransform(68.1,94.1);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAGgGAMAAQAMAAAFAFQAHAGgBALIAAAFIgmAAQAAAHADADQAFADAJAAIATgBIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_325.setTransform(62.2,95.05);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#FFFFFF").s().p("AgYAJQAAgYAXAAQAHAAAKAFIAAgYIAJAAIAABDIgGAAIgBgDQgLAEgIABQgXAAAAgagAgLgCQgEACAAAJQAAAJAEAFQAEAEAIAAQAHAAAIgEIAAgZQgIgEgHAAQgIAAgEAEg");
	this.shape_326.setTransform(55.9,94.1);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_327.setTransform(49.675,94.975);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAGAAALIAAAFIgmAAQAAAHADADQAEADAKAAIATgBIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgIAAQgGAAgEADQgEADAAAGIAdAAIAAAAg");
	this.shape_328.setTransform(43.55,95.05);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgIIAAgYIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGACABQABACAHAAIAGAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_329.setTransform(38.55,94.55);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#FFFFFF").s().p("AAQAXIgQgSIgPASIgLAAIAVgXIgUgWIALAAIAOARIAPgRIALAAIgUAWIAVAXg");
	this.shape_330.setTransform(33.7,95.05);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#FFFFFF").s().p("AgYAiIAAhDIAxAAIAAAJIgoAAIAAAUIAkAAIAAAIIgkAAIAAAVIAoAAIAAAJg");
	this.shape_331.setTransform(27.75,94.025);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_332.setTransform(20.25,96.9);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_333.setTransform(17.45,94.025);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_334.setTransform(13.525,94.025);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_335.setTransform(7.125,94.975);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_336.setTransform(2.625,94.1);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACABQABACAHAAIAGAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_337.setTransform(275.05,83.65);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIgBQAJABAEgEQAEgEAAgJQAAgIgEgEQgEgEgJABQgIAAgEADg");
	this.shape_338.setTransform(270.025,84.15);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhDIAJAAIAAAYQAJgFAIAAQAXAAAAAZQAAAZgXAAQgIgBgKgEgAgPgCIAAAYQAIAEAHAAQAIAAAEgEQAEgDAAgJQAAgKgEgCQgEgEgIAAQgHAAgIAEg");
	this.shape_339.setTransform(263.875,83.2);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAGAAALIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgEgDQgDgDgHAAQgIAAgDADQgDADgCAHIAeAAIAAAAg");
	this.shape_340.setTransform(257.7,84.15);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#FFFFFF").s().p("AgTAgIAAgJQAKACAJAAQAJAAAEgCQADgDAAgGIAAgCQgJAEgIAAQgXAAAAgYQAAgXAXgBQAIAAAKAEIABgCIAHAAIAAArQAAALgGAFQgGAEgNAAQgJAAgKgBgAgLgUQgEAEAAAIQAAAJAEADQAEAEAHAAQAIAAAIgDIAAgZQgIgEgIABQgHgBgEAEg");
	this.shape_341.setTransform(251.45,84.95);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_342.setTransform(245.225,84.075);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#FFFFFF").s().p("AAYAiIgHgTIghAAIgHATIgKAAIAahDIAPAAIAaBDgAANAGIgMgfIgBAAIgNAfIAaAAg");
	this.shape_343.setTransform(238.35,83.125);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_344.setTransform(230.7,86);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_345.setTransform(227.575,84.1);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_346.setTransform(222.275,83.125);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#FFFFFF").s().p("AgWAJQgBgIAFgCQAEgDAKAAIATAAIAAgDQAAgFgDgCQgEgCgIAAIgTACIAAgIQAJgCAKAAQANAAAFAEQAGAEgBAJIAAAeIgGAAIgBgDQgJAFgKAAQgTAAAAgQgAgLAEQgDACABAEQgBAEADACQADACAGAAQAJAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_347.setTransform(215.9,84.15);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#FFFFFF").s().p("AgLAiIAAgIIAEAAQAGAAACgDQABgCABgFIAAgxIAJAAIAAAxQAAAKgEAEQgEAEgKAAg");
	this.shape_348.setTransform(210.8,83.175);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIgBQAJABAEgEQAEgEAAgJQAAgIgEgEQgEgEgJABQgIAAgEADg");
	this.shape_349.setTransform(203.825,84.15);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_350.setTransform(199.175,84.1);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#FFFFFF").s().p("AgYAgIAAg+IAGAAIACADQAKgEAIgBQAXAAAAAaQAAAYgXAAQgHAAgKgFIAAATgAgPgTIAAAYQAJAEAGAAQAIAAAEgEQAEgDAAgIQAAgKgEgDQgEgEgIAAQgHAAgIAEg");
	this.shape_351.setTransform(194.075,84.9);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_352.setTransform(183.225,84.075);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_353.setTransform(175.525,83.125);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgRAGgJQAGgIAOAAQAPAAAFAIQAHAJAAARQAAATgHAHQgFAJgPAAQgOAAgGgJgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAFgHAAgOQAAgOgFgGQgDgFgKgBQgJABgEAFg");
	this.shape_354.setTransform(166.8,83.15);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgRAGgJQAGgIAOAAQAOAAAHAIQAGAJAAARQAAATgGAHQgHAJgOAAQgOAAgGgJgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAKAAAEgFQADgHAAgOQAAgOgDgGQgEgFgKgBQgJABgEAFg");
	this.shape_355.setTransform(160.65,83.15);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgRAGgJQAGgIAOAAQAPAAAGAIQAGAJAAARQAAATgGAHQgGAJgPAAQgOAAgGgJgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAFgHAAgOQAAgOgFgGQgDgFgKgBQgJABgEAFg");
	this.shape_356.setTransform(154.55,83.15);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_357.setTransform(149.9,86);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#FFFFFF").s().p("AgYAgIAAgIQAKACAMAAQAJAAAFgEQADgCAAgHQAAgGgDgDQgEgCgJgBIgUAAIAAgjIArAAIAAAJIgiAAIAAATIAMAAQAOAAAFAFQAGAEAAAKQAAAMgHAEQgGAGgOAAQgMgBgKgCg");
	this.shape_358.setTransform(145.25,83.2);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_359.setTransform(139.175,83.075);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#FFFFFF").s().p("AgTAgIAAgJQAKACAJAAQAJAAAEgCQADgDAAgGIAAgCQgJAEgIAAQgXAAAAgYQAAgXAXgBQAIAAAKAEIABgCIAHAAIAAArQAAALgGAFQgGAEgNAAQgJAAgKgBgAgLgUQgEAEAAAIQAAAJAEADQAEAEAHAAQAJAAAHgDIAAgZQgIgEgIABQgHgBgEAEg");
	this.shape_360.setTransform(130.3,84.95);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_361.setTransform(124.025,84.075);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQgBAKANAAQAIAAAKgFIAAgiIAIAAIAAAuIgFAAIgDgEQgJAFgKAAQgKAAgGgFg");
	this.shape_362.setTransform(117.55,84.225);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGABABQADACAFAAIAHAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_363.setTransform(112.3,83.65);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#FFFFFF").s().p("AgVAXIAAgJQALADAKAAQAIAAACgBQADgBABgDQAAgFgDgBQgCgCgJAAQgNgBgEgDQgEgDAAgHQAAgIAFgDQAFgDALAAQALAAAJADIAAAHQgJgCgLAAIgJABQgDABAAADQAAAEACABQADABAHACQANABAFACQAFADAAAIQgBAIgEADQgFADgNAAQgMAAgJgCg");
	this.shape_364.setTransform(107.6,84.15);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_365.setTransform(103.575,83.2);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGAMAAQALAAAGAFQAGAGAAALIAAAFIgmAAQAAAHADADQAFADAJAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgDgDQgEgDgHAAQgIAAgDADQgDADgBAHIAdAAIAAAAg");
	this.shape_366.setTransform(99.45,84.15);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_367.setTransform(95.2,83.125);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_368.setTransform(92.425,84.1);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAFgGANAAQAMAAAFAFQAHAGgBALIAAAFIgmAAQAAAHADADQAFADAJAAIATgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgDgDQgEgDgHAAQgIAAgDADQgDADgBAHIAdAAIAAAAg");
	this.shape_369.setTransform(87.5,84.15);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGABABQACACAGAAIAHAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_370.setTransform(82.5,83.65);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#FFFFFF").s().p("AgRATQgHgFAAgOQAAgMAHgGQAFgGANAAQAMAAAFAFQAHAGAAALIAAAFIgoAAQABAHAEADQADADAJAAIAUgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgEgDQgDgDgHAAQgIAAgDADQgDADgCAHIAeAAIAAAAg");
	this.shape_371.setTransform(77.7,84.15);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_372.setTransform(69.675,84.075);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIgBQAJABAEgEQAEgEAAgJQAAgIgEgEQgEgEgJABQgIAAgEADg");
	this.shape_373.setTransform(61.525,84.15);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_374.setTransform(57.15,83.125);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_375.setTransform(54.725,83.2);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#FFFFFF").s().p("AAPAiIghghIAAAhIgJAAIAAhDIAJAAIAAAeIAhgeIAMAAIgjAgIAkAjg");
	this.shape_376.setTransform(50.425,83.125);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#FFFFFF").s().p("AgIAeIAIgZIAJAAIgJAZgAgBgUIAAgJIAJAAIAAAJg");
	this.shape_377.setTransform(42.475,84.95);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACABQACACAFAAIAHAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_378.setTransform(39.05,83.65);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_379.setTransform(35.875,83.2);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGALAAQAMAAAGAFQAGAGABALIAAAFIgnAAQAAAHAEADQADADAKAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgHgDgDQgEgDgIAAQgGAAgEADQgEADAAAHIAdAAIAAAAg");
	this.shape_380.setTransform(31.75,84.15);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#FFFFFF").s().p("AgWAXIAAgHIAggfIgfAAIAAgHIArAAIAAAHIggAfIAhAAIAAAHg");
	this.shape_381.setTransform(25.975,84.15);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#FFFFFF").s().p("AgJAiIAAgmIgHAAIAAgGIAHgCIAAgEQAAgJADgEQAFgEAJAAIAIAAIAAAIIgHAAQgGAAgCACQgBACAAAFIAAAEIAPAAIAAAIIgPAAIAAAmg");
	this.shape_382.setTransform(21.75,83.075);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQAAAKANAAQAHAAAKgFIAAgiIAIAAIAAAuIgGAAIgCgEQgJAFgJAAQgLAAgGgFg");
	this.shape_383.setTransform(16.45,84.225);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#FFFFFF").s().p("AgWAJQgBgIAFgCQAEgDAKAAIATAAIAAgDQAAgFgEgCQgDgCgIAAIgTACIAAgIQAJgCAKAAQANAAAFAEQAGAEAAAJIAAAeIgHAAIgBgDQgJAFgKAAQgTAAAAgQgAgLAEQgCACAAAEQAAAEACACQADACAGAAQAJAAAIgFIAAgKIgSAAQgGgBgCACg");
	this.shape_384.setTransform(10.05,84.15);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#FFFFFF").s().p("AgVAiIAAhDIAJAAIAAA6IAiAAIAAAJg");
	this.shape_385.setTransform(4.575,83.125);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAGgGAMAAQAMAAAFAGQAHAEgBANIAAADIgmAAQAAAJADACQAFAEAJAAIATgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_386.setTransform(259.75,73.3);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAQAAIAAAIIgQAAIAAAXQAAAFABACQADACAFAAIAHgBIAAAIIgHABQgKAAgEgFg");
	this.shape_387.setTransform(254.75,72.8);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#FFFFFF").s().p("AgXAJQAAgIAFgCQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTABIAAgIQAKgBAJAAQANAAAGAEQAEAEABAJIAAAfIgGAAIgCgEQgJAFgKAAQgTAAgBgQgAgLAEQgDABAAAFQAAAEADACQACACAHAAQAJAAAIgFIAAgLIgSAAQgGABgCABg");
	this.shape_388.setTransform(249.7,73.3);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_389.setTransform(243.475,73.225);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIABQAJgBAEgDQAEgEAAgJQAAgIgEgEQgEgDgJgBQgIAAgEAFg");
	this.shape_390.setTransform(237.125,73.3);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#FFFFFF").s().p("AAaAiIAAg2IgUAnIgLAAIgUgnIAAA2IgKAAIAAhDIAOAAIAVAqIABAAIAVgqIAOAAIAABDg");
	this.shape_391.setTransform(229.575,72.275);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#FFFFFF").s().p("AgTAeQgHgEAAgKQAAgOANgCQgLgCAAgOQAAgJAGgFQAGgEAMAAQAOAAAGAEQAGAFAAAJQAAAOgLACQAMACAAAOQAAAKgGAEQgHAFgOAAQgNAAgGgFgAgMAGQgEADAAAGQAAAGADACQAEADAJAAQAKAAAEgDQAEgCAAgGQAAgGgFgDQgDgCgKgBQgIABgEACgAgMgXQgDADAAAFQAAAGAEADQADACAIAAQAJAAAEgCQADgDAAgGQAAgFgDgDQgEgDgJABQgIgBgEADg");
	this.shape_392.setTransform(219.475,72.3);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#FFFFFF").s().p("AARAiIAAgPIgqAAIAAgHIAZgtIAJAAIgXArIAfAAIAAgOIAJAAIAAAmg");
	this.shape_393.setTransform(213.175,72.275);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#FFFFFF").s().p("AgIANIAIgYIAIAAIgIAYg");
	this.shape_394.setTransform(206.25,75.85);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_395.setTransform(203.1,75.15);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAWQAJgDAIAAQAXAAAAAXQAAAZgXAAQgIABgKgFgAgPgCIAAAZQAIADAHAAQAIAAAEgDQAEgEAAgKQAAgIgEgDQgEgEgIAAQgHAAgIAEg");
	this.shape_396.setTransform(198.475,72.35);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAFgGANAAQAMAAAFAGQAHAEgBANIAAADIgmAAQAAAJADACQAFAEAJAAIATgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_397.setTransform(192.35,73.3);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgIAAQgXAAAAgXQAAgYAXgBQAIAAAKAFIABgEIAHAAIAAAsQAAALgGAFQgGAEgNAAQgJAAgKgCgAgLgUQgEAEAAAJQAAAIAEADQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIgBQgHABgEADg");
	this.shape_398.setTransform(186.1,74.1);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#FFFFFF").s().p("AgWAWIAAgHQAMACAKAAQAIAAADgBQACgBAAgEQAAgEgCgBQgDgBgIgBQgNgBgDgDQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAAKACIAAAIQgKgCgJAAIgKABQgEABAAAEQAAADADABQACABAJABQANACAEACQAFADgBAIQAAAHgEADQgGAEgLAAQgMAAgLgDg");
	this.shape_399.setTransform(180.3,73.3);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAQAAIAAAIIgQAAIAAAXQAAAFABACQADACAGAAIAGgBIAAAIIgHABQgKAAgEgFg");
	this.shape_400.setTransform(175.45,72.8);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#FFFFFF").s().p("AgJAiIAAgmIgGAAIAAgGIAGgCIAAgEQAAgJADgEQAFgEAJAAIAJAAIAAAIIgIAAQgGAAgCACQgBACAAAFIAAAEIAPAAIAAAIIgPAAIAAAmg");
	this.shape_401.setTransform(172.1,72.225);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#FFFFFF").s().p("AgXARQAAgIAFgDQAEgDAJAAIAUAAIAAgDQAAgEgEgCQgCgCgJAAIgTABIAAgIQAKgBAJAAQANAAAFAEQAFAEABAIIAAAgIgGAAIgCgEQgJAFgKAAQgTAAgBgQgAgLAMQgDABAAAFQAAAEADACQACACAHAAQAJAAAIgFIAAgLIgSAAQgGABgCABgAAHgYIAAgIIAHAAIAAAIgAgLgYIAAgIIAHAAIAAAIg");
	this.shape_402.setTransform(166.9,72.5);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_403.setTransform(160.675,72.275);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#FFFFFF").s().p("AgPATQgGgGAAgNQAAgMAGgGQAGgGANAAQAIAAAJACIAAAIQgJgCgIAAQgJABgDADQgEAEAAAIQAAAJAEAEQADADAJABIASgCIAAAHQgJADgJAAQgNAAgGgGg");
	this.shape_404.setTransform(154.775,73.3);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#FFFFFF").s().p("AgVAWIAAgHQALACAKAAQAIAAADgBQADgBAAgEQgBgEgCgBQgCgBgJgBQgMgBgFgDQgEgCAAgIQAAgHAFgDQAFgEALAAQALAAAKACIAAAIQgLgCgKAAIgKABQgCABAAAEQgBADADABQADABAHABQAOACAEACQAEADABAIQAAAHgGADQgFAEgMAAQgLAAgKgDg");
	this.shape_405.setTransform(149.3,73.3);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#FFFFFF").s().p("AgSATQgFgGgBgNQABgMAFgGQAGgGAMAAQAMAAAGAGQAGAEABANIAAADIgoAAQABAJAEACQAEAEAIAAIAUgCIAAAHQgJADgLAAQgOAAgGgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgEADgBAGIAeAAIAAAAg");
	this.shape_406.setTransform(143.6,73.3);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgKAEgHAAQgXAAAAgXQAAgYAXgBQAIAAAKAFIACgEIAGAAIAAAsQAAALgGAFQgGAEgMAAQgKAAgKgCgAgLgUQgEAEAAAJQAAAIAEADQAEAEAIAAQAHAAAIgEIAAgYQgIgDgHgBQgIABgEADg");
	this.shape_407.setTransform(137.35,74.1);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#FFFFFF").s().p("AgWAWIAAgHQAMACAKAAQAIAAADgBQACgBAAgEQABgEgDgBQgDgBgIgBQgMgBgEgDQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAALACIAAAIQgKgCgKAAIgKABQgEABAAAEQABADACABQACABAJABQANACAEACQAFADgBAIQAAAHgEADQgGAEgLAAQgMAAgLgDg");
	this.shape_408.setTransform(131.6,73.3);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAQAAIAAAIIgQAAIAAAXQAAAFACACQABACAHAAIAGgBIAAAIIgHABQgKAAgEgFg");
	this.shape_409.setTransform(126.75,72.8);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_410.setTransform(121.575,72.275);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#FFFFFF").s().p("AgPATQgGgGAAgNQAAgMAGgGQAGgGANAAQAIAAAJACIAAAIQgJgCgIAAQgJABgDADQgEAEAAAIQAAAJAEAEQADADAJABIASgCIAAAHQgJADgJAAQgNAAgGgGg");
	this.shape_411.setTransform(115.725,73.3);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAEAAANIAAADIgoAAQABAJAEACQADAEAJAAIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_412.setTransform(110.1,73.3);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#FFFFFF").s().p("AARAiIgMgWIgDAAIgUAAIAAAWIgJAAIAAhDIAdAAQAOAAAHAFQAFAGAAAMQABAKgEAEQgDAFgIACIAOAXgAgSAEIAUAAQAKAAADgDQAEgCAAgJQAAgIgEgDQgDgDgKAAIgUAAg");
	this.shape_413.setTransform(103.65,72.275);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_414.setTransform(95.75,75.15);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_415.setTransform(92.95,72.275);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgIAAQgXAAAAgXQAAgYAXgBQAIAAAKAFIABgEIAHAAIAAAsQAAALgGAFQgGAEgNAAQgJAAgKgCgAgLgUQgEAEAAAJQAAAIAEADQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIgBQgHABgEADg");
	this.shape_416.setTransform(88.45,74.1);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#FFFFFF").s().p("AgWAYIAAgIIAggfIgfAAIAAgIIArAAIAAAIIggAfIAhAAIAAAIg");
	this.shape_417.setTransform(82.625,73.3);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#FFFFFF").s().p("AgWAYIAAgIIAggfIgfAAIAAgIIArAAIAAAIIggAfIAhAAIAAAIg");
	this.shape_418.setTransform(77.025,73.3);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#FFFFFF").s().p("AgHANIAHgYIAJAAIgJAYg");
	this.shape_419.setTransform(70.15,75.85);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAADgDQAEgCAAgHIAAgBQgKAEgGAAQgYAAAAgXQAAgYAYgBQAHAAAKAFIABgEIAHAAIAAAsQAAALgGAFQgGAEgNAAQgKAAgJgCgAgLgUQgEAEAAAJQAAAIAEADQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIgBQgHABgEADg");
	this.shape_420.setTransform(65.3,74.1);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_421.setTransform(59.025,73.225);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQAAAKAMAAQAIAAAKgFIAAgiIAIAAIAAAuIgGAAIgCgEQgKAFgIAAQgLAAgGgFg");
	this.shape_422.setTransform(52.55,73.375);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAQAAIAAAIIgQAAIAAAXQAAAFABACQADACAFAAIAHgBIAAAIIgHABQgKAAgEgFg");
	this.shape_423.setTransform(47.3,72.8);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#FFFFFF").s().p("AgVAWIAAgHQALACAKAAQAIAAADgBQADgBAAgEQgBgEgCgBQgCgBgJgBQgMgBgFgDQgEgCAAgIQAAgHAFgDQAFgEALAAQALAAAKACIAAAIQgLgCgKAAIgKABQgCABAAAEQgBADADABQADABAHABQAOACAEACQAEADABAIQAAAHgGADQgFAEgMAAQgLAAgKgDg");
	this.shape_424.setTransform(42.65,73.3);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_425.setTransform(38.575,72.35);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAGQAGAEABANIAAADIgnAAQAAAJADACQAEAEAKAAIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgIAAQgGAAgEADQgEADAAAGIAdAAIAAAAg");
	this.shape_426.setTransform(34.45,73.3);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_427.setTransform(30.2,72.275);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_428.setTransform(25.775,73.225);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAEAAANIAAADIgoAAQABAJAEACQADAEAJAAIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_429.setTransform(19.65,73.3);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgIAAQgXAAAAgXQAAgYAXgBQAIAAAKAFIABgEIAHAAIAAAsQAAALgGAFQgGAEgNAAQgJAAgKgCgAgLgUQgEAEAAAJQAAAIAEADQAEAEAHAAQAIAAAIgEIAAgYQgIgDgIgBQgHABgEADg");
	this.shape_430.setTransform(13.4,74.1);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_431.setTransform(9.125,72.35);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#FFFFFF").s().p("AgYAiIAAhDIAxAAIAAAJIgoAAIAAAUIAkAAIAAAIIgkAAIAAAVIAoAAIAAAJg");
	this.shape_432.setTransform(4.8,72.275);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#FFFFFF").s().p("AAIAfQgEgDAAgHQAAgJAEgDQAEgDAIAAQAIAAAEADQAEADAAAJQAAAHgEADQgEAEgIAAQgIAAgEgEgAAOAOQgCACAAAFQAAAEACACQACACAEAAQAEAAACgCQACgCAAgEQAAgFgCgCQgCgCgEAAQgEAAgCACgAgbAhIAvhCIAJAAIgvBCgAgfgIQgEgEAAgIQAAgIAEgDQAEgDAIAAQAIAAAEADQAEADAAAIQAAAIgEAEQgEACgIAAQgIAAgEgCgAgZgaQgCACAAAEQAAAFACABQACACAEAAQAEAAACgCQACgBAAgFQAAgEgCgCQgCgCgEAAQgEAAgCACg");
	this.shape_433.setTransform(265.725,61.4);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#FFFFFF").s().p("AgUAbQgGgIAAgTQAAgRAGgJQAHgIANAAQAPAAAFAIQAHAJAAARQAAATgHAIQgFAIgPAAQgNAAgHgIgAgNgUQgEAGAAAOQAAAPAEAGQAEAFAJAAQAJAAAFgFQADgGAAgPQAAgOgDgGQgFgFgJAAQgJAAgEAFg");
	this.shape_434.setTransform(258.9,61.4);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#FFFFFF").s().p("AgYAgIAAgHQAKACALAAQAKAAAFgDQAEgCAAgHQAAgGgEgDQgEgCgIgBIgQAAIAAgHIAQAAQAIAAADgCQADgCAAgHQAAgGgDgDQgEgCgJAAQgLAAgKACIAAgIQAKgCALAAQAOAAAGAEQAGAFAAAJQAAANgLADQAMADAAAOQAAAJgHAEQgGAFgPAAQgMAAgJgDg");
	this.shape_435.setTransform(252.775,61.4);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#FFFFFF").s().p("AgHANIAHgYIAJAAIgJAYg");
	this.shape_436.setTransform(245.65,64.95);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#FFFFFF").s().p("AAYAiIgHgTIghAAIgHATIgKAAIAahDIAPAAIAaBDgAANAGIgMgfIgBAAIgMAfIAZAAg");
	this.shape_437.setTransform(240.45,61.375);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#FFFFFF").s().p("AgHAiIgahDIAKAAIAXA6IABAAIAXg6IAKAAIgaBDg");
	this.shape_438.setTransform(233.25,61.375);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#FFFFFF").s().p("AgZAbQgHgJAAgSQAAgRAHgJQAIgIARAAQASAAAHAIQAJAJAAARQAAASgJAJQgHAIgSAAQgRAAgIgIgAgSgUQgFAHAAANQAAAOAFAGQAGAGAMAAQANAAAFgGQAGgGAAgOQAAgNgGgHQgFgFgNAAQgMAAgGAFg");
	this.shape_439.setTransform(225.7,61.4);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#FFFFFF").s().p("AASAiIgmg2IAAA2IgJAAIAAhDIAMAAIAmA2IAAg2IAJAAIAABDg");
	this.shape_440.setTransform(217.775,61.375);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_441.setTransform(209.75,64.25);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_442.setTransform(206.9,61.375);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_443.setTransform(203.025,61.375);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_444.setTransform(196.575,62.325);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_445.setTransform(192.125,61.45);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#FFFFFF").s().p("AgWAeQgHgEAAgKQAAgQANAAQgMgDAAgOQAAgIAGgFQAHgEAOAAQALAAAJADIAAAIQgJgDgLAAQgKAAgEADQgEACAAAGQAAAGAEADQADABAKAAIABAAIAAAHIgBAAQgLAAgDACQgEADAAAIQAAAGAEADQAEADALAAQALAAAEgDQAEgDAAgHQAAgKgNgCIAAgHIAZAAIAAAHIgLAAQAHAEAAAJQAAALgGAEQgHAFgOAAQgPAAgGgFg");
	this.shape_446.setTransform(185.1,61.4);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_447.setTransform(177.55,64.25);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAQAAIAAAIIgQAAIAAAXQAAAFABABQADADAFAAIAHgBIAAAIIgIABQgJgBgEgEg");
	this.shape_448.setTransform(173.95,61.9);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#FFFFFF").s().p("AgWAWIAAgIQAMADAKAAQAIAAADgBQACgBAAgEQABgDgDgCQgDgBgIgBQgMgBgEgDQgFgCAAgIQAAgHAFgEQAFgDALAAQAKAAALACIAAAIQgLgCgJAAIgLABQgDABAAAEQABADACABQACACAJAAQANABAEADQAEADAAAIQAAAHgEADQgFAEgMAAQgMAAgLgDg");
	this.shape_449.setTransform(169.3,62.4);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#FFFFFF").s().p("AgWAcQgHgGAAgPIAAgpIAKAAIAAApQAAAKAEAFQAFADAKAAQALAAAFgDQAEgFAAgKIAAgpIAKAAIAAApQAAAPgHAGQgHAGgQAAQgPAAgHgGg");
	this.shape_450.setTransform(162.675,61.45);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#FFFFFF").s().p("AAIAfQgEgDAAgHQAAgJAEgDQAEgDAIAAQAIAAAEADQAEADAAAJQAAAHgEADQgEAEgIAAQgIAAgEgEgAAOAOQgCACAAAFQAAAEACACQACACAEAAQAEAAACgCQACgCAAgEQAAgFgCgCQgCgCgEAAQgEAAgCACgAgbAhIAvhCIAJAAIgvBCgAgfgIQgEgEAAgIQAAgIAEgDQAEgDAIAAQAIAAAEADQAEADAAAIQAAAIgEAEQgEACgIAAQgIAAgEgCgAgZgaQgCACAAAEQAAAFACABQACACAEAAQAEAAACgCQACgBAAgFQAAgEgCgCQgCgCgEAAQgEAAgCACg");
	this.shape_451.setTransform(152.575,61.4);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#FFFFFF").s().p("AgUAbQgGgIAAgTQAAgRAGgJQAHgIANAAQAPAAAFAIQAHAJAAARQAAATgHAIQgFAIgPAAQgNAAgHgIgAgNgUQgEAGAAAOQAAAPAEAGQAEAFAJAAQAKAAADgFQAFgGAAgPQAAgOgFgGQgDgFgKAAQgJAAgEAFg");
	this.shape_452.setTransform(145.75,61.4);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_453.setTransform(139.625,61.325);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_454.setTransform(132.5,64.25);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_455.setTransform(129.65,61.375);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_456.setTransform(125.725,61.375);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#FFFFFF").s().p("AAQAXIgQgSIgPASIgLAAIAVgXIgUgXIALAAIAOARIAPgRIALAAIgUAXIAVAXg");
	this.shape_457.setTransform(119.65,62.4);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#FFFFFF").s().p("AgRATQgGgGgBgNQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAFABAMIAAADIgoAAQABAJAEACQAEAEAIAAIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgEADgBAGIAeAAIAAAAg");
	this.shape_458.setTransform(113.9,62.4);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAPAAIAAAIIgPAAIAAAXQAAAFACABQABADAHAAIAGgBIAAAIIgHABQgKgBgEgEg");
	this.shape_459.setTransform(106.4,61.9);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIAAQAJAAAEgEQAEgEAAgJQAAgIgEgEQgEgDgJgBQgIABgEADg");
	this.shape_460.setTransform(101.375,62.4);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhDIAJAAIAAAYQAJgEAIAAQAXgBAAAYQAAAZgXAAQgIAAgKgEgAgPgCIAAAZQAIADAHAAQAIAAAEgDQAEgFAAgJQAAgIgEgDQgEgEgIAAQgHAAgIAEg");
	this.shape_461.setTransform(95.275,61.45);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGAMAAQALAAAGAGQAGAFAAAMIAAADIgmAAQAAAJADACQAFAEAJAAIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_462.setTransform(89.1,62.4);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAADgDQAEgCAAgHIAAgBQgKAEgGAAQgYAAAAgXQAAgYAYgBQAHAAAKAFIABgEIAHAAIAAAsQAAALgGAFQgGAEgNAAQgKAAgJgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIgBQgHABgEADg");
	this.shape_463.setTransform(82.85,63.2);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_464.setTransform(76.575,62.325);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#FFFFFF").s().p("AgWAJQAAgHAEgDQAEgDAKAAIATAAIAAgDQAAgFgDgCQgDgCgJAAIgTABIAAgIQAJgBAKAAQANAAAGAEQAEAEAAAJIAAAeIgGAAIgBgDQgJAFgKAAQgUAAABgQgAgLAEQgDACABAEQgBAEADACQADACAFAAQAKAAAIgFIAAgLIgSAAQgGABgCABg");
	this.shape_465.setTransform(70.2,62.4);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgDAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_466.setTransform(65.675,62.35);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGAMAAQALAAAGAGQAGAFAAAMIAAADIgmAAQAAAJADACQAFAEAJAAIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgHAAQgIAAgDADQgDADgBAGIAdAAIAAAAg");
	this.shape_467.setTransform(60.75,62.4);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_468.setTransform(52.675,62.325);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_469.setTransform(44.425,61.375);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#FFFFFF").s().p("AgRATQgGgGgBgNQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAFABAMIAAADIgoAAQABAJAEACQAEAEAIAAIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgEADgBAGIAeAAIAAAAg");
	this.shape_470.setTransform(38.3,62.4);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_471.setTransform(32.075,62.325);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgDAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_472.setTransform(27.275,62.35);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAFAAAMIAAADIgoAAQABAJAEACQADAEAJAAIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgHAAQgIAAgDADQgDADgCAGIAeAAIAAAAg");
	this.shape_473.setTransform(22.35,62.4);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgGIAGgCIAAgKIAJAAIAAAKIAPAAIAAAIIgPAAIAAAXQAAAFABABQADADAFAAIAHgBIAAAIIgIABQgJgBgEgEg");
	this.shape_474.setTransform(17.35,61.9);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_475.setTransform(12.225,62.325);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#FFFFFF").s().p("AgWAcQgHgGAAgPIAAgpIAKAAIAAApQAAAKAEAFQAFADAKAAQALAAAFgDQAEgFAAgKIAAgpIAKAAIAAApQAAAPgHAGQgHAGgQAAQgPAAgHgGg");
	this.shape_476.setTransform(5.175,61.45);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#FFFFFF").s().p("AgIAMIAIgXIAJAAIgJAXg");
	this.shape_477.setTransform(276.35,54.05);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_478.setTransform(273.5,50.475);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAIAAIAABDg");
	this.shape_479.setTransform(271,50.475);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#FFFFFF").s().p("AgRATQgGgFgBgOQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAFABALIAAAFIgoAAQABAIAEACQAEADAIABIAUgCIAAAHQgJADgLAAQgOAAgFgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgEADgBAGIAeAAIAAAAg");
	this.shape_480.setTransform(266.9,51.5);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#FFFFFF").s().p("AgSATQgFgEgBgIIAAgeIAJAAIAAAdQAAAKAOAAQAHAAAKgFIAAgiIAJAAIAAAuIgHAAIgBgEQgKAFgJAAQgLAAgFgFg");
	this.shape_481.setTransform(260.7,51.575);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_482.setTransform(254.225,51.425);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#FFFFFF").s().p("AgWAJQgBgHAFgDQAEgDAKAAIATAAIAAgDQAAgFgDgCQgEgCgIAAIgTACIAAgJQAJgBAKAAQANAAAFAEQAGAEAAAJIAAAeIgHAAIgBgDQgJAFgKAAQgTAAAAgQgAgLAEQgDACABAEQgBAEADACQADACAGAAQAJAAAIgFIAAgKIgSAAQgGAAgCABg");
	this.shape_483.setTransform(247.85,51.5);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#FFFFFF").s().p("AAaAiIAAg2IgUAnIgLAAIgUgnIAAA2IgKAAIAAhDIAOAAIAVAqIABAAIAVgqIAOAAIAABDg");
	this.shape_484.setTransform(240.375,50.475);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgHAAQgYAAAAgXQAAgZAYAAQAHAAAKAEIABgDIAHAAIAAAsQAAALgGAFQgGAEgNAAQgKAAgJgCgAgLgUQgEAEAAAJQAAAHAEAEQAEAEAHAAQAJAAAHgEIAAgYQgIgDgIAAQgHAAgEADg");
	this.shape_485.setTransform(230.1,52.3);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_486.setTransform(223.875,51.425);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#FFFFFF").s().p("AgWAJQAAgHAEgDQAEgDAKAAIATAAIAAgDQAAgFgDgCQgDgCgJAAIgTACIAAgJQAKgBAJAAQANAAAGAEQAEAEAAAJIAAAeIgFAAIgCgDQgJAFgKAAQgUAAABgQgAgLAEQgCACAAAEQAAAEACACQADACAFAAQAKAAAIgFIAAgKIgSAAQgGAAgCABg");
	this.shape_487.setTransform(217.45,51.5);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#FFFFFF").s().p("AgYAbQgIgJAAgSQAAgRAIgJQAIgIAQAAQAOAAAIAFQAHAFADALIgKAAQgCgHgFgCQgGgDgJAAQgMAAgFAFQgFAHAAANQAAAOAFAGQAGAGAMAAQALAAAGgEQAFgFAAgIIAAgDIgXAAIAAgIIAhAAIAAALQAAAaggAAQgRAAgIgIg");
	this.shape_488.setTransform(210.675,50.5);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#FFFFFF").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_489.setTransform(205.225,51.5);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#FFFFFF").s().p("AgTAbQgGgIAAgTQAAgSAHgIQAHgIAQAAQAIAAAIACIAAAJQgIgCgIAAQgLAAgFAEQgFAFAAANQAKgDAJAAQANAAAFAEQAFAFAAAKQAAAMgHAFQgGAFgMAAQgOAAgGgIgAgQAEQABANADAFQAEAFAJAAQAIAAAEgDQAEgDAAgHQAAgIgDgCQgEgDgJAAQgHgBgKAEg");
	this.shape_490.setTransform(200.575,50.5);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#FFFFFF").s().p("AgaAfIAAgJQANADANAAQAKAAAEgCQAEgBAAgHQAAgFgDgDQgEgBgLgCQgQgCgFgDQgFgEAAgKQAAgKAGgFQAHgEAOAAQALAAAMADIAAAJQgMgDgLAAQgKAAgEACQgDACAAAGQAAAFACACIAPAEQAQABAFAEQAFADABALQgBALgGAFQgHAEgOAAQgNAAgNgEg");
	this.shape_491.setTransform(191.65,50.5);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#FFFFFF").s().p("AgXAfQgGgFAAgKQAAgQANgBQgMgCAAgOQAAgJAGgEQAGgEAQAAQAKAAAJADIAAAIQgJgDgKAAQgLAAgEADQgEACAAAGQAAAGAEADQADABAKABIABAAIAAAGIgBAAQgKAAgEACQgEADAAAIQAAAHAEACQAEADAMAAQAKAAAEgDQAEgDAAgHQAAgKgOgCIAAgGIAaAAIAAAGIgLAAQAHAEABAJQgBALgGAFQgHAEgNAAQgQAAgHgEg");
	this.shape_492.setTransform(184.9,50.5);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#FFFFFF").s().p("AgaAfIAAgJQANADAMAAQALAAAEgCQAEgBAAgHQAAgFgDgDQgDgBgMgCQgPgCgGgDQgFgEgBgKQABgKAGgFQAHgEAOAAQAMAAALADIAAAJQgMgDgLAAQgKAAgEACQgEACAAAGQAAAFAEACIANAEQARABAFAEQAGADgBALQABALgHAFQgHAEgPAAQgNAAgMgEg");
	this.shape_493.setTransform(178,50.5);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAHgIANAAQAOAAAHAIQAGAJAAARQAAASgGAJQgHAIgOAAQgNAAgHgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAJAAAFgFQADgHAAgOQAAgOgDgGQgFgFgJAAQgJAAgEAFg");
	this.shape_494.setTransform(169,50.5);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_495.setTransform(162.875,50.425);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#FFFFFF").s().p("AAIAiIAAg6IgVALIgEgHIAagNIAJAAIAABDg");
	this.shape_496.setTransform(157,50.475);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_497.setTransform(151.325,50.55);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#FFFFFF").s().p("AgdAiIAAhDIAbAAQARAAAIAIQAHAIAAARQAAASgHAIQgIAIgRAAgAgUAZIASAAQAMAAAGgGQAFgFAAgOQAAgMgFgGQgGgGgMAAIgSAAg");
	this.shape_498.setTransform(146.475,50.475);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#FFFFFF").s().p("AAUAiIAAgeIgnAAIAAAeIgJAAIAAhDIAJAAIAAAdIAnAAIAAgdIAJAAIAABDg");
	this.shape_499.setTransform(138.55,50.475);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#FFFFFF").s().p("AgSATQgFgFAAgOQAAgMAFgGQAHgGALAAQAMAAAGAGQAGAFAAALIAAAFIgmAAQAAAIADACQAEADAKABIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgIAAQgGAAgEADQgEADAAAGIAdAAIAAAAg");
	this.shape_500.setTransform(131.75,51.5);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#FFFFFF").s().p("AgSATQgGgEAAgIIAAgeIAJAAIAAAdQABAKANAAQAHAAAKgFIAAgiIAJAAIAAAuIgGAAIgCgEQgLAFgIAAQgLAAgFgFg");
	this.shape_501.setTransform(125.5,51.575);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_502.setTransform(121.05,50.475);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#FFFFFF").s().p("AgbAiIAAhDIAfAAQALAAAGAEQAFAEAAAKQAAANgKACQAMACAAAOQAAAKgGAEQgFAEgNAAgAgSAZIAWAAQAIAAADgCQADgCABgGQgBgGgDgDQgDgCgHAAIgXAAgAgSgEIAWAAQAHAAACgCQAEgCAAgGQAAgGgEgCQgCgCgIAAIgVAAg");
	this.shape_503.setTransform(116.4,50.475);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#FFFFFF").s().p("AAIAiIAAg6IgVALIgEgHIAZgNIAJAAIAABDg");
	this.shape_504.setTransform(107.35,50.475);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#FFFFFF").s().p("AAVAiIAAgeIgoAAIAAAeIgJAAIAAhDIAJAAIAAAdIAoAAIAAgdIAJAAIAABDg");
	this.shape_505.setTransform(101.5,50.475);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#FFFFFF").s().p("AAIAiIAAg6IgVALIgEgHIAZgNIAJAAIAABDg");
	this.shape_506.setTransform(94.75,50.475);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#FFFFFF").s().p("AgVAiIAAhDIAJAAIAAA6IAiAAIAAAJg");
	this.shape_507.setTransform(90.275,50.475);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAGgIAOAAQAOAAAHAIQAGAJAAARQAAASgGAJQgHAIgOAAQgOAAgGgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAEgHABgOQgBgOgEgGQgDgFgKAAQgJAAgEAFg");
	this.shape_508.setTransform(81.55,50.5);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#FFFFFF").s().p("AgUAbQgGgJAAgSQAAgRAGgJQAGgIAOAAQAPAAAFAIQAHAJAAARQAAASgHAJQgFAIgPAAQgOAAgGgIgAgNgUQgEAGAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAFgHAAgOQAAgOgFgGQgDgFgKAAQgJAAgEAFg");
	this.shape_509.setTransform(75.45,50.5);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#FFFFFF").s().p("AgTAfQgHgFAAgKQAAgNANgDQgLgDAAgNQAAgJAGgFQAGgEAMAAQAOAAAGAEQAGAFAAAJQAAANgLADQAMADAAANQAAAKgGAFQgHAEgOAAQgNAAgGgEgAgMAGQgEACAAAHQAAAGADACQAEADAJAAQAKAAAEgDQAEgCAAgGQAAgHgFgCQgDgCgKAAQgIAAgEACgAgMgXQgDADAAAGQAAAFAEADQADACAIAAQAJAAAEgCQADgDAAgFQAAgGgDgDQgEgCgJAAQgIAAgEACg");
	this.shape_510.setTransform(69.275,50.5);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_511.setTransform(63.225,50.425);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#FFFFFF").s().p("AARAiIgQg6IgBAAIgQA6IgRAAIgThDIAKAAIARA6IABAAIAQg6IARAAIAQA6IACAAIAQg6IAKAAIgTBDg");
	this.shape_512.setTransform(52.05,50.475);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#FFFFFF").s().p("AAPAiIghghIAAAhIgJAAIAAhDIAJAAIAAAeIAhgeIAMAAIgjAgIAkAjg");
	this.shape_513.setTransform(43.475,50.475);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgDAJgBIAAAJQgJAAgHADIAAAjg");
	this.shape_514.setTransform(35.675,51.45);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#FFFFFF").s().p("AgSATQgFgFgBgOQABgMAFgGQAHgGALAAQAMAAAGAGQAGAFABALIAAAFIgoAAQABAIAEACQAEADAIABIAUgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgDADgCAGIAeAAIAAAAg");
	this.shape_515.setTransform(30.75,51.5);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#FFFFFF").s().p("AgYAhIAAg/IAGAAIACADQAKgFAIAAQAXAAAAAZQAAAZgXAAQgHAAgKgEIAAATgAgPgTIAAAZQAJADAGAAQAIAAAEgDQAEgFAAgIQAAgIgEgEQgEgEgIAAQgHAAgIAEg");
	this.shape_516.setTransform(24.775,52.25);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_517.setTransform(16.375,51.425);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQgBAKANAAQAIAAAKgFIAAgiIAIAAIAAAuIgFAAIgDgEQgJAFgKAAQgKAAgGgFg");
	this.shape_518.setTransform(8.1,51.575);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#FFFFFF").s().p("AgLAiIAAgIIAEAAQAGAAABgDQACgCAAgFIAAgxIAKAAIAAAxQAAAKgEAEQgEAEgKAAg");
	this.shape_519.setTransform(2.75,50.525);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_520.setTransform(280.775,40.6);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#FFFFFF").s().p("AgSAcQgGgEAAgIIAAgeIAJAAIAAAdQAAAKAOgBQAHAAAKgEIAAgiIAJAAIAAAuIgHAAIgBgEQgLAFgIAAQgLAAgFgFgAAGgYIAAgIIAHAAIAAAIgAgMgYIAAgIIAHAAIAAAIg");
	this.shape_521.setTransform(275.45,39.85);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#FFFFFF").s().p("AgKAiIAAgmIgFAAIAAgGIAFgCIAAgEQAAgJAFgEQAEgEAJAAIAIAAIAAAIIgHAAQgGAAgCACQgBACgBAFIAAAEIAQAAIAAAIIgQAAIAAAmg");
	this.shape_522.setTransform(270.8,39.575);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#FFFFFF").s().p("AgSATQgFgGgBgNQABgMAFgGQAHgGALAAQAMAAAGAGQAGAEABANIAAADIgoAAQABAIAEAEQAEACAIAAIAUgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgEgCQgDgDgIAAQgGAAgEADQgDACgCAIIAeAAIAAAAg");
	this.shape_523.setTransform(263.4,40.65);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAQAAIAAAHIgQAAIAAAXQAAAFABACQADACAFgBIAHAAIAAAIIgHABQgKAAgEgFg");
	this.shape_524.setTransform(258.35,40.15);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#FFFFFF").s().p("AgXAJQAAgHAFgDQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTABIAAgHQAKgCAJAAQANAAAGAEQAEAEABAIIAAAgIgGAAIgCgEQgJAFgKAAQgTAAgBgQgAgLAEQgDABAAAFQAAAEADACQACACAHAAQAJAAAIgEIAAgMIgSAAQgGAAgCACg");
	this.shape_525.setTransform(253.3,40.65);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_526.setTransform(248.775,40.6);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#FFFFFF").s().p("AgTAgIAAgJQAKACAJAAQAJAAAEgCQADgDAAgGIAAgCQgJAEgIAAQgXAAAAgYQAAgYAXAAQAIABAKAEIACgDIAGAAIAAArQAAALgGAEQgGAFgMAAQgLAAgJgBgAgLgUQgEAEAAAIQAAAJAEADQAEAEAIAAQAHAAAIgDIAAgZQgIgEgHAAQgIAAgEAEg");
	this.shape_527.setTransform(243.45,41.45);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_528.setTransform(237.175,40.575);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_529.setTransform(232.725,39.7);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#FFFFFF").s().p("AgWAXIAAgIQAMACAKAAQAIAAADgBQACgBAAgEQABgEgDgBQgDgCgIAAQgMgCgEgCQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAALADIAAAHQgLgCgJAAIgLABQgDACAAADQABADACABQACACAJABQANAAAEADQAEADAAAIQAAAHgEAEQgGADgLAAQgMAAgLgCg");
	this.shape_530.setTransform(228.7,40.65);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#FFFFFF").s().p("AgWAJQAAgHAEgDQAEgDAKAAIATAAIAAgDQAAgFgDgCQgDgCgJAAIgTABIAAgHQAJgCAKAAQANAAAGAEQAEAEAAAIIAAAgIgGAAIgBgEQgJAFgKAAQgUAAABgQgAgLAEQgDABABAFQgBAEADACQADACAFAAQAKAAAIgEIAAgMIgSAAQgGAAgCACg");
	this.shape_531.setTransform(222.75,40.65);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGAMAAQALAAAGAGQAGAEAAANIAAADIgmAAQAAAIADAEQAFACAJAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_532.setTransform(216.9,40.65);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#FFFFFF").s().p("AgVAiIAAhDIAJAAIAAA6IAiAAIAAAJg");
	this.shape_533.setTransform(211.425,39.625);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_534.setTransform(204.15,42.5);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_535.setTransform(199.375,40.575);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAFgGANAAQAMAAAFAGQAHAEgBANIAAADIgmAAQAAAIADAEQAFACAJAAIATgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_536.setTransform(193.25,40.65);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_537.setTransform(187.025,39.625);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGAMAAQALAAAGAGQAGAEAAANIAAADIgmAAQAAAIADAEQAFACAJAAIATgBIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_538.setTransform(180.9,40.65);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAQAAIAAAHIgQAAIAAAXQAAAFABACQADACAGgBIAGAAIAAAIIgHABQgKAAgEgFg");
	this.shape_539.setTransform(175.9,40.15);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#FFFFFF").s().p("AgVAXIAAgIQALACAKAAQAIAAACgBQAEgBAAgEQgBgEgCgBQgCgCgJAAQgMgCgFgCQgEgCAAgIQAAgHAFgDQAFgEALAAQALAAAKADIAAAHQgKgCgLAAIgKABQgCACAAADQgBADADABQADACAHABQANAAAFADQAEADABAIQAAAHgGAEQgEADgNAAQgLAAgKgCg");
	this.shape_540.setTransform(171.25,40.65);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_541.setTransform(166.875,40.6);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAEAAANIAAADIgoAAQABAIAEAEQADACAJAAIAUgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgHAAQgIAAgDADQgEACgBAIIAeAAIAAAAg");
	this.shape_542.setTransform(161.95,40.65);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#FFFFFF").s().p("AgGAYIgVguIAKAAIARAmIAAAAIASgmIAKAAIgVAug");
	this.shape_543.setTransform(156.025,40.65);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#FFFFFF").s().p("AgSATQgGgEABgIIAAgeIAJAAIAAAdQgBAKANAAQAIAAAKgFIAAgiIAIAAIAAAuIgFAAIgCgEQgKAFgKAAQgKAAgFgFg");
	this.shape_544.setTransform(147.35,40.725);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#FFFFFF").s().p("AgWAYIAAgIIAggfIgfAAIAAgHIArAAIAAAHIggAfIAhAAIAAAIg");
	this.shape_545.setTransform(141.325,40.65);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGAMAAQANAAAFAGQAHAEAAANIAAADIgoAAQABAIAEAEQADACAJAAIAUgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgIAAQgHAAgDADQgEACgBAIIAeAAIAAAAg");
	this.shape_546.setTransform(133.15,40.65);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAPAAIAAAHIgPAAIAAAXQAAAFACACQACACAFgBIAHAAIAAAIIgIABQgJAAgEgFg");
	this.shape_547.setTransform(128.15,40.15);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_548.setTransform(124.675,40.6);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#FFFFFF").s().p("AgRATQgGgGgBgNQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAEABANIAAADIgoAAQABAIAEAEQAEACAIAAIAUgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgIAAQgGAAgEADQgEACgBAIIAeAAIAAAAg");
	this.shape_549.setTransform(119.75,40.65);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#FFFFFF").s().p("AAOAYIgOgoIgNAoIgOAAIgPguIAKAAIAMAnIAAAAIAOgnIANAAIAOAnIAAgBIALgmIAKAAIgOAug");
	this.shape_550.setTransform(112.25,40.65);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgJIAAgXIgGAAIAAgFIAGgCIAAgMIAJAAIAAAMIAPAAIAAAHIgPAAIAAAXQAAAFACACQABACAHgBIAGAAIAAAIIgIABQgJAAgEgFg");
	this.shape_551.setTransform(105.75,40.15);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_552.setTransform(100.575,39.625);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#FFFFFF").s().p("AgPATQgGgGAAgNQAAgMAGgGQAGgGANAAQAIAAAJADIAAAIQgJgDgIAAQgJAAgDAEQgEAEAAAIQAAAJAEAEQADADAJAAIASgBIAAAIQgJACgJAAQgNAAgGgGg");
	this.shape_553.setTransform(94.725,40.65);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_554.setTransform(90.725,39.7);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#FFFFFF").s().p("AARAiIgMgWIgDAAIgUAAIAAAWIgJAAIAAhDIAdAAQAOAAAHAFQAFAGAAAMQABAKgEAEQgDAFgIACIAOAXgAgSAEIAUAAQAKAAADgDQAEgCAAgJQAAgIgEgDQgDgDgKAAIgUAAg");
	this.shape_555.setTransform(86,39.625);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#FFFFFF").s().p("AgVAXIAAgIQALACAKAAQAIAAADgBQADgBAAgEQgBgEgCgBQgCgCgJAAQgNgCgDgCQgFgCAAgIQAAgHAFgDQAFgEALAAQALAAAKADIAAAHQgLgCgJAAIgLABQgCACgBADQABADACABQACACAJABQANAAAEADQAEADABAIQAAAHgGAEQgFADgLAAQgMAAgKgCg");
	this.shape_556.setTransform(76.95,40.65);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAHAAIAABDg");
	this.shape_557.setTransform(72.9,39.625);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#FFFFFF").s().p("AgWAJQAAgHAEgDQAEgDAKAAIATAAIAAgDQAAgFgDgCQgDgCgJAAIgTABIAAgHQAKgCAJAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAABgQgAgLAEQgCABAAAFQAAAEACACQADACAFAAQAKAAAIgEIAAgMIgSAAQgGAAgCACg");
	this.shape_558.setTransform(68.5,40.65);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_559.setTransform(61.475,40.6);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#FFFFFF").s().p("AgSATQgGgEAAgIIAAgeIAJAAIAAAdQABAKANAAQAHAAAKgFIAAgiIAJAAIAAAuIgGAAIgCgEQgLAFgIAAQgLAAgFgFg");
	this.shape_560.setTransform(56.2,40.725);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_561.setTransform(49.725,40.575);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#FFFFFF").s().p("AgYAKQAAgYAYAAQAGAAAKADIAAgWIAJAAIAABCIgGAAIgBgDQgMAFgGgBQgYABAAgZgAgLgDQgEAEAAAJQAAAIAEAEQAEAEAIABQAHgBAIgEIAAgZQgIgDgHAAQgIAAgEADg");
	this.shape_562.setTransform(40.7,39.7);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_563.setTransform(34.425,40.575);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_564.setTransform(29.975,39.7);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#FFFFFF").s().p("AgWAXIAAgIQAMACAKAAQAIAAADgBQACgBAAgEQAAgEgCgBQgDgCgIAAQgNgCgDgCQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAAKADIAAAHQgKgCgJAAIgKABQgEACAAADQAAADADABQACACAJABQANAAAEADQAFADgBAIQAAAHgEAEQgGADgLAAQgMAAgLgCg");
	this.shape_565.setTransform(25.95,40.65);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#FFFFFF").s().p("AgYAKQAAgYAXAAQAIAAAJADIAAgWIAJAAIAABCIgGAAIgCgDQgKAFgIgBQgXABAAgZgAgLgDQgEAEAAAJQAAAIAEAEQAEAEAHABQAJgBAHgEIAAgZQgHgDgJAAQgHAAgEADg");
	this.shape_566.setTransform(17.35,39.7);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_567.setTransform(11.075,40.575);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQgBAKANAAQAIAAAKgFIAAgiIAIAAIAAAuIgFAAIgDgEQgJAFgKAAQgKAAgGgFg");
	this.shape_568.setTransform(4.6,40.725);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAQAAIAAAIIgQAAIAAAXQAAAFABACQADACAGAAIAGgBIAAAIIgHABQgKAAgEgFg");
	this.shape_569.setTransform(273.55,29.25);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#FFFFFF").s().p("AgEAiIAAhDIAIAAIAABDg");
	this.shape_570.setTransform(270.4,28.725);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAGQAGAEAAANIAAADIgmAAQAAAIADAEQAEADAKAAIATgCIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgDgCQgEgDgIAAQgGAAgEADQgEACAAAIIAdAAIAAAAg");
	this.shape_571.setTransform(266.3,29.75);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAQAAIAAAIIgQAAIAAAXQAAAFACACQABACAHAAIAGgBIAAAIIgHABQgKAAgEgFg");
	this.shape_572.setTransform(261.3,29.25);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAPAAIAAAIIgPAAIAAAXQAAAFACACQACACAFAAIAHgBIAAAIIgIABQgJAAgEgFg");
	this.shape_573.setTransform(257.3,29.25);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_574.setTransform(254.175,28.8);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_575.setTransform(247.825,29.675);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_576.setTransform(241.225,29.7);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#FFFFFF").s().p("AgRATQgGgGgBgNQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAEABANIAAADIgoAAQABAIAEAEQAEADAIAAIAUgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgIAAQgGAAgEADQgEACgBAIIAeAAIAAAAg");
	this.shape_577.setTransform(236.3,29.75);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#FFFFFF").s().p("AgbAiIAAhDIAdAAQAOAAAGAGQAHAFgBANQABAMgHAFQgGAFgOAAIgUAAIAAAVgAgSAFIAUAAQAKAAADgDQAEgDAAgIQAAgJgEgDQgDgDgKAAIgUAAg");
	this.shape_578.setTransform(227.65,28.725);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#FFFFFF").s().p("AgEAiIAAg6IgZAAIAAgJIA7AAIAAAJIgZAAIAAA6g");
	this.shape_579.setTransform(220.525,28.725);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#FFFFFF").s().p("AgVAiIAAhDIAJAAIAAA6IAiAAIAAAJg");
	this.shape_580.setTransform(214.725,28.725);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#FFFFFF").s().p("AARAiIgRg6IAAAAIgRA6IgQAAIgShDIAJAAIAQA6IACAAIAQg6IAQAAIAQA6IACAAIAQg6IAKAAIgSBDg");
	this.shape_581.setTransform(206,28.725);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_582.setTransform(196.375,29.7);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAFgGANAAQAMAAAFAGQAHAEgBANIAAADIgmAAQAAAIADAEQAFADAJAAIATgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_583.setTransform(191.45,29.75);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#FFFFFF").s().p("AgYAKQAAgYAYAAQAGAAAKADIAAgWIAJAAIAABCIgGAAIgBgDQgMAFgGgBQgYAAAAgYgAgLgDQgEADAAAKQAAAIAEAFQAEADAIAAQAHAAAIgDIAAgaQgIgDgHAAQgIAAgEADg");
	this.shape_584.setTransform(185.15,28.8);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#FFFFFF").s().p("AgFAhIAAgIIAHABQAHAAADgCQAEgDAAgGQAAgHgEgCQgDgDgIAAIgGAAIAAgGIAGAAQAHgBADgCQADgDAAgFQAAgHgEgCQgDgDgHAAQgIAAgDADQgEADAAAFIAAAxIgJAAIAAgxQAAgJAGgFQAFgEANAAQALAAAGAEQAGAEAAAJQAAAOgLACQANABAAAOQAAALgGAEQgFAFgKgBIgJgBg");
	this.shape_585.setTransform(176.675,28.7);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#FFFFFF").s().p("AgXARQABgHAEgEQAEgDAJAAIAUAAIAAgDQAAgEgEgCQgCgCgJAAIgTABIAAgIQAJgBAKAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAAAgQgAgLAMQgCABgBAFQABAEACACQADACAFAAQAKAAAIgEIAAgMIgSAAQgGAAgCACgAAGgYIAAgIIAIAAIAAAIgAgLgYIAAgIIAHAAIAAAIg");
	this.shape_586.setTransform(170.3,28.95);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_587.setTransform(162.225,29.675);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#FFFFFF").s().p("AgRATQgHgGAAgNQAAgMAHgGQAFgGANAAQAMAAAFAGQAHAEAAANIAAADIgoAAQABAIAEAEQADADAJAAIAUgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgHAAQgIAAgDADQgEACgBAIIAeAAIAAAAg");
	this.shape_588.setTransform(154.3,29.75);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgIAAQgXAAAAgXQAAgZAXAAQAIAAAKAFIACgEIAGAAIAAAsQAAALgGAEQgGAFgMAAQgLAAgJgCgAgLgUQgEAEAAAJQAAAIAEADQAEAEAIAAQAHAAAIgEIAAgYQgIgDgHgBQgIABgEADg");
	this.shape_589.setTransform(148.05,30.55);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_590.setTransform(139.325,29.675);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGAMAAQALAAAGAGQAGAEAAANIAAADIgmAAQAAAIADAEQAFADAJAAIATgCIAAAIQgJACgLAAQgNAAgHgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_591.setTransform(133.2,29.75);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#FFFFFF").s().p("AgYAKQAAgYAYAAQAGAAAKADIAAgWIAJAAIAABCIgGAAIgCgDQgLAFgGgBQgYAAAAgYgAgLgDQgEADAAAKQAAAIAEAFQAEADAHAAQAJAAAHgDIAAgaQgHgDgJAAQgHAAgEADg");
	this.shape_592.setTransform(126.95,28.8);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_593.setTransform(122.375,29.7);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#FFFFFF").s().p("AgSATQgFgEgBgIIAAgeIAJAAIAAAdQAAAKAOAAQAHAAAKgFIAAgiIAJAAIAAAuIgHAAIgBgEQgLAFgIAAQgLAAgFgFg");
	this.shape_594.setTransform(117.05,29.825);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#FFFFFF").s().p("AAPAYIgPgoIgNAoIgOAAIgPgvIAKAAIAMAoIABAAIANgoIANAAIAOAoIAAAAIAMgoIAKAAIgPAvg");
	this.shape_595.setTransform(109.3,29.75);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#FFFFFF").s().p("AgRATQgGgGgBgNQABgMAGgGQAFgGAMAAQAMAAAGAGQAGAEABANIAAADIgoAAQABAIAEAEQAEADAIAAIAUgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgEgCQgDgDgIAAQgGAAgEADQgEACgBAIIAeAAIAAAAg");
	this.shape_596.setTransform(99.5,29.75);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAQAAIAAAIIgQAAIAAAXQAAAFABACQADACAGAAIAGgBIAAAIIgHABQgKAAgEgFg");
	this.shape_597.setTransform(94.45,29.25);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_598.setTransform(90.975,29.7);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#FFFFFF").s().p("AgRATQgHgGABgNQgBgMAHgGQAGgGAMAAQAMAAAFAGQAHAEgBANIAAADIgmAAQAAAIADAEQAFADAJAAIATgCIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgIgDgCQgEgDgHAAQgIAAgDADQgDACgBAIIAdAAIAAAAg");
	this.shape_599.setTransform(86.05,29.75);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#FFFFFF").s().p("AAOAYIgOgoIgNAoIgOAAIgPgvIAKAAIAMAoIABAAIANgoIANAAIAOAoIAAAAIALgoIALAAIgPAvg");
	this.shape_600.setTransform(78.6,29.75);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#FFFFFF").s().p("AgVAXIAAgIQALACAKAAQAIAAACgBQAEgBAAgEQgBgEgCgBQgCgCgJAAQgMgCgFgCQgEgCAAgIQAAgHAFgDQAFgEALAAQALAAAKADIAAAHQgKgCgLAAIgKABQgCACAAADQgBADADABQADABAHACQANAAAFADQAEADABAIQAAAHgGADQgEAEgNAAQgLAAgKgCg");
	this.shape_601.setTransform(71.35,29.75);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_602.setTransform(65.325,29.675);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIABQAJgBAEgDQAEgEAAgJQAAgIgEgEQgEgDgJgBQgIAAgEAFg");
	this.shape_603.setTransform(58.975,29.75);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_604.setTransform(54.625,28.8);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#FFFFFF").s().p("AgVAXIAAgIQALACAKAAQAIAAACgBQAEgBAAgEQgBgEgCgBQgCgCgJAAQgMgCgFgCQgEgCAAgIQAAgHAFgDQAFgEALAAQALAAAKADIAAAHQgKgCgLAAIgKABQgCACAAADQgBADADABQADABAHACQANAAAFADQAEADABAIQAAAHgGADQgEAEgNAAQgLAAgKgCg");
	this.shape_605.setTransform(50.65,29.75);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#FFFFFF").s().p("AgWAXIAAgIQAMACAKAAQAIAAADgBQACgBAAgEQABgEgDgBQgDgCgIAAQgMgCgEgCQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAALADIAAAHQgLgCgJAAIgLABQgDACAAADQABADACABQACABAJACQANAAAEADQAEADAAAIQAAAHgEADQgFAEgMAAQgMAAgLgCg");
	this.shape_606.setTransform(45.1,29.75);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_607.setTransform(41.025,28.8);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_608.setTransform(34.725,29.675);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#FFFFFF").s().p("AgXAiIAAhDIAvAAIAAAJIgmAAIAAAUIAkAAIAAAIIgkAAIAAAVIAmAAIAAAJg");
	this.shape_609.setTransform(26.55,28.725);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#FFFFFF").s().p("AgYAKQAAgYAXAAQAIAAAJADIAAgWIAJAAIAABCIgGAAIgCgDQgKAFgIgBQgXAAAAgYgAgLgDQgEADAAAKQAAAIAEAFQAEADAHAAQAJAAAHgDIAAgaQgHgDgJAAQgHAAgEADg");
	this.shape_610.setTransform(17.35,28.8);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_611.setTransform(11.075,29.675);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQgBAKANAAQAIAAAKgFIAAgiIAIAAIAAAuIgFAAIgDgEQgJAFgKAAQgKAAgGgFg");
	this.shape_612.setTransform(4.6,29.825);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#FFFFFF").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_613.setTransform(266.025,18.85);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#FFFFFF").s().p("AgWAWIAAgHQAMACAKAAQAIAAADgBQACgBAAgEQAAgEgCgBQgDgBgIgBQgNgBgDgDQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAAKACIAAAIQgJgCgKAAIgKABQgEABAAAEQAAADADABQACABAJABQANACAEACQAFADgBAIQAAAHgEADQgGAEgLAAQgMAAgLgDg");
	this.shape_614.setTransform(261.75,18.85);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_615.setTransform(255.725,17.825);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#FFFFFF").s().p("AgPATQgGgGAAgNQAAgMAGgGQAGgGANAAQAIAAAJACIAAAIQgJgCgIAAQgJABgDADQgEAEAAAIQAAAJAEAEQADADAJABIASgCIAAAHQgJADgJAAQgNAAgGgGg");
	this.shape_616.setTransform(249.825,18.85);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#FFFFFF").s().p("AgTATQgEgEAAgIIAAgeIAJAAIAAAdQAAAKAMAAQAIAAAKgFIAAgiIAIAAIAAAuIgGAAIgCgEQgKAFgIAAQgLAAgGgFg");
	this.shape_617.setTransform(243.8,18.925);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#FFFFFF").s().p("AgXAJQABgIAEgCQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTABIAAgIQAKgBAJAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAAAgQgAgLAEQgCABgBAFQABAEACACQACACAGAAQAKAAAIgFIAAgLIgSAAQgGABgCABg");
	this.shape_618.setTransform(237.45,18.85);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_619.setTransform(232.925,18.8);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAWQAJgDAIAAQAXAAAAAXQAAAZgXAAQgIABgKgFgAgPgCIAAAZQAIADAHAAQAIAAAEgDQAEgEAAgKQAAgIgEgDQgEgEgIAAQgHAAgIAEg");
	this.shape_620.setTransform(227.825,17.9);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_621.setTransform(222.975,18.8);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgNQAAgMAFgGQAHgGALAAQAMAAAGAGQAGAEAAANIAAADIgmAAQAAAJAEACQADAEAKAAIATgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgDgDQgEgDgIAAQgGAAgEADQgEADAAAGIAdAAIAAAAg");
	this.shape_622.setTransform(218.05,18.85);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#FFFFFF").s().p("AgHAiIgahDIAKAAIAXA6IABAAIAXg6IAKAAIgaBDg");
	this.shape_623.setTransform(211.45,17.825);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_624.setTransform(203.75,20.7);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_625.setTransform(197.125,18.775);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_626.setTransform(189.425,17.825);

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#FFFFFF").s().p("AgPAoIAXhPIAIAAIgXBPg");
	this.shape_627.setTransform(184.525,18.45);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#FFFFFF").s().p("AgTAfIAAgIQAKACAJAAQAJAAAEgDQADgCAAgHIAAgBQgJAEgIAAQgXAAAAgXQAAgYAXgBQAIAAAKAFIACgEIAGAAIAAAsQAAALgGAFQgGAEgMAAQgLAAgJgCgAgLgUQgEAEAAAJQAAAIAEADQAEAEAIAAQAHAAAIgEIAAgYQgIgDgHgBQgIABgEADg");
	this.shape_628.setTransform(179.55,19.65);

	this.shape_629 = new cjs.Shape();
	this.shape_629.graphics.f("#FFFFFF").s().p("AgTAiIAjg6IgpAAIAAgJIAzAAIAAAHIgiA8g");
	this.shape_629.setTransform(170.975,17.825);

	this.shape_630 = new cjs.Shape();
	this.shape_630.graphics.f("#FFFFFF").s().p("AgYAgIAAgIQAKABAMAAQAKAAADgCQAFgDAAgGQAAgHgFgDQgDgCgJAAIgUAAIAAgjIArAAIAAAIIgiAAIAAATIAMAAQANAAAGAFQAGADAAAMQAAALgHAFQgGAEgOAAQgMABgKgDg");
	this.shape_630.setTransform(164.85,17.9);

	this.shape_631 = new cjs.Shape();
	this.shape_631.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_631.setTransform(158.775,17.775);

	this.shape_632 = new cjs.Shape();
	this.shape_632.graphics.f("#FFFFFF").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_632.setTransform(151.575,18.85);

	this.shape_633 = new cjs.Shape();
	this.shape_633.graphics.f("#FFFFFF").s().p("AgTAiIAjg6IgpAAIAAgJIAzAAIAAAHIgiA8g");
	this.shape_633.setTransform(144.475,17.825);

	this.shape_634 = new cjs.Shape();
	this.shape_634.graphics.f("#FFFFFF").s().p("AAIAiIAAg6IgVALIgDgHIAYgNIAJAAIAABDg");
	this.shape_634.setTransform(138.6,17.825);

	this.shape_635 = new cjs.Shape();
	this.shape_635.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_635.setTransform(133.625,17.775);

	this.shape_636 = new cjs.Shape();
	this.shape_636.graphics.f("#FFFFFF").s().p("AgEAYIAAgLIAJAAIAAALgAgEgNIAAgKIAJAAIAAAKg");
	this.shape_636.setTransform(126.45,18.85);

	this.shape_637 = new cjs.Shape();
	this.shape_637.graphics.f("#FFFFFF").s().p("AgFAZQgEgDAAgIIAAgYIgGAAIAAgFIAGgDIAAgLIAJAAIAAALIAPAAIAAAIIgPAAIAAAXQAAAFACACQABACAHAAIAGgBIAAAIIgIABQgJAAgEgFg");
	this.shape_637.setTransform(122.85,18.35);

	this.shape_638 = new cjs.Shape();
	this.shape_638.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABADQAIgEAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_638.setTransform(119.375,18.8);

	this.shape_639 = new cjs.Shape();
	this.shape_639.graphics.f("#FFFFFF").s().p("AgSATQgFgGgBgNQABgMAFgGQAHgGALAAQAMAAAGAGQAGAEABANIAAADIgoAAQABAJAEACQAEAEAIAAIAUgCIAAAHQgJADgLAAQgNAAgHgGgAAPgEQAAgGgEgDQgDgDgIAAQgGAAgEADQgDADgCAGIAeAAIAAAAg");
	this.shape_639.setTransform(114.45,18.85);

	this.shape_640 = new cjs.Shape();
	this.shape_640.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_640.setTransform(110.225,17.9);

	this.shape_641 = new cjs.Shape();
	this.shape_641.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_641.setTransform(105.775,18.775);

	this.shape_642 = new cjs.Shape();
	this.shape_642.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_642.setTransform(101.275,17.9);

	this.shape_643 = new cjs.Shape();
	this.shape_643.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAWQAJgDAIAAQAXAAAAAXQAAAZgXAAQgIABgKgFgAgPgCIAAAZQAIADAHAAQAIAAAEgDQAEgEAAgKQAAgIgEgDQgEgEgIAAQgHAAgIAEg");
	this.shape_643.setTransform(97.025,17.9);

	this.shape_644 = new cjs.Shape();
	this.shape_644.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_644.setTransform(88.625,18.775);

	this.shape_645 = new cjs.Shape();
	this.shape_645.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIABQAJgBAEgDQAEgEAAgJQAAgIgEgEQgEgDgJgBQgIAAgEAFg");
	this.shape_645.setTransform(80.475,18.85);

	this.shape_646 = new cjs.Shape();
	this.shape_646.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_646.setTransform(74.725,17.825);

	this.shape_647 = new cjs.Shape();
	this.shape_647.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_647.setTransform(65.825,18.775);

	this.shape_648 = new cjs.Shape();
	this.shape_648.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgLQgEADAAAIQAAAJAEAEQAEADAIABQAJgBAEgDQAEgEAAgJQAAgIgEgEQgEgDgJgBQgIAAgEAFg");
	this.shape_648.setTransform(59.475,18.85);

	this.shape_649 = new cjs.Shape();
	this.shape_649.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_649.setTransform(55.125,17.9);

	this.shape_650 = new cjs.Shape();
	this.shape_650.graphics.f("#FFFFFF").s().p("AgWAWIAAgHQAMACAKAAQAIAAADgBQACgBAAgEQAAgEgCgBQgDgBgIgBQgNgBgDgDQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAAKACIAAAIQgJgCgKAAIgKABQgEABAAAEQAAADADABQACABAJABQANACAEACQAFADgBAIQAAAHgEADQgGAEgLAAQgMAAgLgDg");
	this.shape_650.setTransform(51.15,18.85);

	this.shape_651 = new cjs.Shape();
	this.shape_651.graphics.f("#FFFFFF").s().p("AgWAWIAAgHQAMACAKAAQAIAAADgBQACgBAAgEQABgEgDgBQgDgBgIgBQgMgBgEgDQgFgCAAgIQAAgHAFgDQAFgEALAAQAKAAALACIAAAIQgLgCgJAAIgLABQgDABAAAEQABADACABQACABAJABQANACAEACQAEADAAAIQAAAHgEADQgFAEgMAAQgMAAgLgDg");
	this.shape_651.setTransform(45.55,18.85);

	this.shape_652 = new cjs.Shape();
	this.shape_652.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_652.setTransform(41.525,17.9);

	this.shape_653 = new cjs.Shape();
	this.shape_653.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_653.setTransform(35.175,18.775);

	this.shape_654 = new cjs.Shape();
	this.shape_654.graphics.f("#FFFFFF").s().p("AgYAiIAAhDIAxAAIAAAJIgoAAIAAAUIAkAAIAAAIIgkAAIAAAVIAoAAIAAAJg");
	this.shape_654.setTransform(27.05,17.825);

	this.shape_655 = new cjs.Shape();
	this.shape_655.graphics.f("#FFFFFF").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_655.setTransform(22.025,18.85);

	this.shape_656 = new cjs.Shape();
	this.shape_656.graphics.f("#FFFFFF").s().p("AgPAWIAAgIQAAgEABgCIAGgFIAMgGIAEgDIABgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgGAAIgNACIAAgGIAOgBQAIAAAEACQAEADAAAGQAAAEgCADIgHAEIgMAHIgDADIgBADIAAADIAZAAIAAAFg");
	this.shape_656.setTransform(18.525,19.775);

	this.shape_657 = new cjs.Shape();
	this.shape_657.graphics.f("#FFFFFF").s().p("AgYAbQgJgJABgSQgBgRAJgJQAHgIARAAQASAAAHAIQAJAJgBARQABASgJAJQgHAIgSAAQgRAAgHgIgAgSgTQgFAFAAAOQAAAOAFAGQAGAGAMAAQANAAAGgGQAFgGAAgOQAAgOgFgFQgGgHgNABQgMgBgGAHg");
	this.shape_657.setTransform(12.6,17.85);

	this.shape_658 = new cjs.Shape();
	this.shape_658.graphics.f("#FFFFFF").s().p("AgXAbQgIgJABgSQgBgRAIgJQAIgIAPAAQAOAAAIAFQAHAFADALIgKAAQgDgHgEgDQgGgCgJAAQgLgBgFAHQgFAFAAAOQAAAOAFAGQAFAGALAAQARAAAFgNIAKAAQgDAMgHAEQgIAGgOAAQgPAAgIgIg");
	this.shape_658.setTransform(5.1,17.85);

	this.shape_659 = new cjs.Shape();
	this.shape_659.graphics.f("#FFFFFF").s().p("AgIAMIAIgYIAIAAIgIAYg");
	this.shape_659.setTransform(282.75,10.55);

	this.shape_660 = new cjs.Shape();
	this.shape_660.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_660.setTransform(276.075,7.925);

	this.shape_661 = new cjs.Shape();
	this.shape_661.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_661.setTransform(268.375,6.975);

	this.shape_662 = new cjs.Shape();
	this.shape_662.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgSAGgIQAGgIAOAAQAPAAAFAIQAHAIAAASQAAATgHAHQgFAJgPAAQgOAAgGgJgAgNgTQgEAFAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAFgHAAgOQAAgOgFgFQgDgGgKgBQgJABgEAGg");
	this.shape_662.setTransform(262.1,7);

	this.shape_663 = new cjs.Shape();
	this.shape_663.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgSAGgIQAHgIANAAQAPAAAFAIQAHAIAAASQAAATgHAHQgFAJgPAAQgNAAgHgJgAgNgTQgEAFAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAFgHAAgOQAAgOgFgFQgDgGgKgBQgJABgEAGg");
	this.shape_663.setTransform(256,7);

	this.shape_664 = new cjs.Shape();
	this.shape_664.graphics.f("#FFFFFF").s().p("AAIAiIAAg6IgVALIgDgHIAZgNIAJAAIAABDg");
	this.shape_664.setTransform(250.15,6.975);

	this.shape_665 = new cjs.Shape();
	this.shape_665.graphics.f("#FFFFFF").s().p("AgPAoIAXhPIAIAAIgXBPg");
	this.shape_665.setTransform(246.475,7.6);

	this.shape_666 = new cjs.Shape();
	this.shape_666.graphics.f("#FFFFFF").s().p("AgDAiIAAhDIAIAAIAABDg");
	this.shape_666.setTransform(243.5,6.975);

	this.shape_667 = new cjs.Shape();
	this.shape_667.graphics.f("#FFFFFF").s().p("AgTAfQgHgFAAgKQAAgOANgCQgLgCAAgOQAAgJAGgFQAGgEAMAAQAOAAAGAEQAGAFAAAJQAAAOgLACQAMACAAAOQAAAKgGAFQgHAEgOAAQgNAAgGgEgAgMAGQgEADAAAGQAAAGADADQAEACAJAAQAKAAAEgCQAEgDAAgGQAAgGgFgDQgDgCgKAAQgIAAgEACgAgMgXQgDACAAAHQAAAGAEACQADACAIAAQAJAAAEgCQADgCAAgGQAAgHgDgCQgEgDgJAAQgIAAgEADg");
	this.shape_667.setTransform(236.725,7);

	this.shape_668 = new cjs.Shape();
	this.shape_668.graphics.f("#FFFFFF").s().p("AgIAMIAIgYIAIAAIgIAYg");
	this.shape_668.setTransform(232.1,10.55);

	this.shape_669 = new cjs.Shape();
	this.shape_669.graphics.f("#FFFFFF").s().p("AgUAhIAAgJQAIACAIAAQALAAAFgEQAEgGABgMQgKADgKAAQgMAAgFgFQgFgEAAgKQAAgMAHgFQAGgFAMAAQAPAAAGAHQAFAIAAATQAAATgHAIQgHAIgQAAQgIAAgIgCgAgMgXQgDADAAAHQAAAHACADQAEADAJAAQAHAAAKgDQgBgNgEgFQgDgFgJAAQgIAAgEADg");
	this.shape_669.setTransform(227.45,7);

	this.shape_670 = new cjs.Shape();
	this.shape_670.graphics.f("#FFFFFF").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_670.setTransform(220.325,8);

	this.shape_671 = new cjs.Shape();
	this.shape_671.graphics.f("#FFFFFF").s().p("AgYAhIAAgIQAKACALAAQAKAAAFgDQAEgCAAgGQAAgHgEgDQgEgCgIAAIgQAAIAAgIIAQAAQAIAAADgCQADgDAAgGQAAgGgDgDQgEgCgJgBQgLAAgKACIAAgHQAKgCALAAQAOAAAGAEQAGAFAAAJQAAAOgLACQAMACAAAOQAAAKgHAFQgGAEgPAAQgMAAgJgCg");
	this.shape_671.setTransform(215.725,7);

	this.shape_672 = new cjs.Shape();
	this.shape_672.graphics.f("#FFFFFF").s().p("AgHAMIAHgYIAIAAIgIAYg");
	this.shape_672.setTransform(211.05,10.55);

	this.shape_673 = new cjs.Shape();
	this.shape_673.graphics.f("#FFFFFF").s().p("AgTAfQgHgFAAgKQAAgOANgCQgLgCAAgOQAAgJAGgFQAGgEAMAAQAOAAAGAEQAGAFAAAJQAAAOgLACQAMACAAAOQAAAKgGAFQgHAEgOAAQgNAAgGgEgAgMAGQgEADAAAGQAAAGADADQAEACAJAAQAKAAAEgCQAEgDAAgGQAAgGgFgDQgDgCgKAAQgIAAgEACgAgMgXQgDACAAAHQAAAGAEACQADACAIAAQAJAAAEgCQADgCAAgGQAAgHgDgCQgEgDgJAAQgIAAgEADg");
	this.shape_673.setTransform(206.425,7);

	this.shape_674 = new cjs.Shape();
	this.shape_674.graphics.f("#FFFFFF").s().p("AgEAYIAAgKIAJAAIAAAKgAgEgMIAAgKIAJAAIAAAKg");
	this.shape_674.setTransform(199.3,8);

	this.shape_675 = new cjs.Shape();
	this.shape_675.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAQAAIAAAHIgQAAIAAAWQAAAGABABQADACAGAAIAGAAIAAAIIgHAAQgKAAgEgDg");
	this.shape_675.setTransform(195.7,7.5);

	this.shape_676 = new cjs.Shape();
	this.shape_676.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_676.setTransform(192.225,7.95);

	this.shape_677 = new cjs.Shape();
	this.shape_677.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAGgGAMAAQAMAAAFAFQAHAGgBALIAAAFIgmAAQAAAHADAEQAFACAJAAIATgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgDgDQgEgDgHAAQgIAAgDADQgDADgBAHIAdAAIAAAAg");
	this.shape_677.setTransform(187.3,8);

	this.shape_678 = new cjs.Shape();
	this.shape_678.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_678.setTransform(183.075,7.05);

	this.shape_679 = new cjs.Shape();
	this.shape_679.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_679.setTransform(178.625,7.925);

	this.shape_680 = new cjs.Shape();
	this.shape_680.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_680.setTransform(174.125,7.05);

	this.shape_681 = new cjs.Shape();
	this.shape_681.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAXQAJgFAIAAQAXAAAAAZQAAAZgXAAQgIAAgKgFgAgPgDIAAAZQAIAEAHAAQAIAAAEgEQAEgDAAgJQAAgJgEgEQgEgDgIAAQgHAAgIADg");
	this.shape_681.setTransform(169.825,7.05);

	this.shape_682 = new cjs.Shape();
	this.shape_682.graphics.f("#FFFFFF").s().p("AAiAYIAAgdQAAgKgMAAQgJAAgJAFIABAEIAAAeIgIAAIAAgdQAAgKgMAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQALAAAEAGQAMgGAKAAQAKAAAFAFQAFAEAAAIIAAAeg");
	this.shape_682.setTransform(161.475,7.925);

	this.shape_683 = new cjs.Shape();
	this.shape_683.graphics.f("#FFFFFF").s().p("AgTATQgGgGAAgNQAAgMAGgGQAHgGAMAAQANAAAGAGQAHAGAAAMQAAANgHAGQgGAGgNAAQgMAAgHgGgAgMgMQgEAEAAAIQAAAJAEAEQAEAEAIgBQAJABAEgEQAEgEAAgJQAAgIgEgEQgEgDgJAAQgIAAgEADg");
	this.shape_683.setTransform(153.325,8);

	this.shape_684 = new cjs.Shape();
	this.shape_684.graphics.f("#FFFFFF").s().p("AAMAiIgagZIAAAZIgJAAIAAhDIAJAAIAAAnIAYgSIANAAIgbATIAcAbg");
	this.shape_684.setTransform(147.525,6.975);

	this.shape_685 = new cjs.Shape();
	this.shape_685.graphics.f("#FFFFFF").s().p("AAQAiIAAgeQAAgJgNAAQgIAAgKAEIAAAjIgJAAIAAhDIAJAAIAAAYQAKgFAJAAQAKAAAGAFQAFAFAAAGIAAAgg");
	this.shape_685.setTransform(138.625,6.975);

	this.shape_686 = new cjs.Shape();
	this.shape_686.graphics.f("#FFFFFF").s().p("AgPATQgGgFAAgOQAAgNAGgFQAGgGANAAQAIAAAJADIAAAIQgJgCgIAAQgJAAgDADQgEAEAAAIQAAAJAEAEQADAEAJgBIASgBIAAAIQgJACgJAAQgNAAgGgGg");
	this.shape_686.setTransform(132.725,8);

	this.shape_687 = new cjs.Shape();
	this.shape_687.graphics.f("#FFFFFF").s().p("AgSATQgGgEAAgIIAAgeIAJAAIAAAdQABAKANAAQAHAAAKgFIAAgiIAJAAIAAAuIgGAAIgCgEQgLAFgJAAQgKAAgFgFg");
	this.shape_687.setTransform(126.75,8.075);

	this.shape_688 = new cjs.Shape();
	this.shape_688.graphics.f("#FFFFFF").s().p("AgXAJQABgIAEgCQAEgDAJAAIAUAAIAAgDQAAgFgDgCQgDgCgJAAIgTACIAAgIQAJgCAKAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAAAgQgAgLAEQgCACgBAEQABAEACACQADACAFAAQAKAAAIgEIAAgLIgSAAQgGAAgCABg");
	this.shape_688.setTransform(120.35,8);

	this.shape_689 = new cjs.Shape();
	this.shape_689.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_689.setTransform(115.825,7.95);

	this.shape_690 = new cjs.Shape();
	this.shape_690.graphics.f("#FFFFFF").s().p("AgQAeIgCADIgGAAIAAhCIAJAAIAAAXQAJgFAIAAQAXAAAAAZQAAAZgXAAQgIAAgKgFgAgPgDIAAAZQAIAEAHAAQAIAAAEgEQAEgDAAgJQAAgJgEgEQgEgDgIAAQgHAAgIADg");
	this.shape_690.setTransform(110.775,7.05);

	this.shape_691 = new cjs.Shape();
	this.shape_691.graphics.f("#FFFFFF").s().p("AgMAYIAAguIAHAAIABAEQAIgFAJAAIAAAJQgJAAgHADIAAAjg");
	this.shape_691.setTransform(105.925,7.95);

	this.shape_692 = new cjs.Shape();
	this.shape_692.graphics.f("#FFFFFF").s().p("AgRATQgHgFABgOQgBgMAHgGQAFgGANAAQAMAAAFAFQAHAGgBALIAAAFIgmAAQAAAHADAEQAFACAJAAIATgBIAAAIQgJACgLAAQgOAAgFgGgAAPgDQAAgHgDgDQgEgDgHAAQgIAAgDADQgDADgBAHIAdAAIAAAAg");
	this.shape_692.setTransform(101,8);

	this.shape_693 = new cjs.Shape();
	this.shape_693.graphics.f("#FFFFFF").s().p("AgHAiIgahDIAKAAIAXA6IACAAIAWg6IAKAAIgaBDg");
	this.shape_693.setTransform(94.4,6.975);

	this.shape_694 = new cjs.Shape();
	this.shape_694.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_694.setTransform(86.7,9.85);

	this.shape_695 = new cjs.Shape();
	this.shape_695.graphics.f("#FFFFFF").s().p("AARAiIAAgPIgqAAIAAgHIAZgtIAJAAIgXArIAfAAIAAgOIAJAAIAAAmg");
	this.shape_695.setTransform(81.875,6.975);

	this.shape_696 = new cjs.Shape();
	this.shape_696.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_696.setTransform(75.975,6.925);

	this.shape_697 = new cjs.Shape();
	this.shape_697.graphics.f("#FFFFFF").s().p("AgUAaQgGgHAAgTQAAgSAGgIQAGgIAOAAQAOAAAHAIQAGAIAAASQAAATgGAHQgHAJgOAAQgOAAgGgJgAgNgTQgEAFAAAOQAAAOAEAHQAEAFAJAAQAKAAADgFQAEgHABgOQgBgOgEgFQgDgGgKgBQgJABgEAGg");
	this.shape_697.setTransform(69.85,7);

	this.shape_698 = new cjs.Shape();
	this.shape_698.graphics.f("#FFFFFF").s().p("AgYAiIAAgMQAAgGADgEQACgDAHgEIASgKIAHgFQACgCAAgEQAAgFgEgCQgDgCgKAAQgJAAgLACIAAgIQALgCAKAAQANAAAGAEQAGAEAAAJQAAAHgDAEQgDADgIAEIgSALIgFAEQgCABAAAEIAAAEIAoAAIAAAIg");
	this.shape_698.setTransform(63.725,6.925);

	this.shape_699 = new cjs.Shape();
	this.shape_699.graphics.f("#FFFFFF").s().p("AgEAhIAAguIAIAAIAAAugAgEgYIAAgIIAJAAIAAAIg");
	this.shape_699.setTransform(56.925,7.05);

	this.shape_700 = new cjs.Shape();
	this.shape_700.graphics.f("#FFFFFF").s().p("AgXAJQABgIAEgCQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTACIAAgIQAKgCAJAAQANAAAGAEQAEAEAAAIIAAAgIgFAAIgCgEQgJAFgKAAQgUAAAAgQgAgLAEQgCACgBAEQABAEACACQACACAGAAQAKAAAIgEIAAgLIgSAAQgGAAgCABg");
	this.shape_700.setTransform(52.5,8);

	this.shape_701 = new cjs.Shape();
	this.shape_701.graphics.f("#FFFFFF").s().p("AAaAiIAAg2IgUAnIgLAAIgUgnIAAA2IgKAAIAAhDIAOAAIAVAqIABAAIAVgqIAOAAIAABDg");
	this.shape_701.setTransform(45.025,6.975);

	this.shape_702 = new cjs.Shape();
	this.shape_702.graphics.f("#FFFFFF").s().p("AgEAYIAAgKIAJAAIAAAKgAgEgMIAAgKIAJAAIAAAKg");
	this.shape_702.setTransform(36.5,8);

	this.shape_703 = new cjs.Shape();
	this.shape_703.graphics.f("#FFFFFF").s().p("AgYAKQAAgZAXAAQAHAAAKAFIAAgXIAJAAIAABCIgGAAIgBgDQgLAFgIAAQgXAAAAgZgAgLgDQgEAEAAAJQAAAJAEADQAEAFAIAAQAHAAAIgFIAAgZQgIgDgHAAQgIAAgEADg");
	this.shape_703.setTransform(31.6,7.05);

	this.shape_704 = new cjs.Shape();
	this.shape_704.graphics.f("#FFFFFF").s().p("AAQAYIAAgdQAAgKgNAAQgJAAgJAFIAAAiIgJAAIAAguIAHAAIABAEQALgFAJAAQAKAAAGAFQAFAEAAAIIAAAeg");
	this.shape_704.setTransform(25.325,7.925);

	this.shape_705 = new cjs.Shape();
	this.shape_705.graphics.f("#FFFFFF").s().p("AgXAJQAAgIAFgCQAEgDAJAAIAUAAIAAgDQAAgFgEgCQgCgCgJAAIgTACIAAgIQAKgCAJAAQANAAAFAEQAFAEABAIIAAAgIgGAAIgCgEQgJAFgKAAQgTAAgBgQgAgLAEQgDACAAAEQAAAEADACQACACAHAAQAJAAAIgEIAAgLIgSAAQgGAAgCABg");
	this.shape_705.setTransform(18.95,8);

	this.shape_706 = new cjs.Shape();
	this.shape_706.graphics.f("#FFFFFF").s().p("AgFAaQgEgEAAgJIAAgXIgGAAIAAgGIAGgBIAAgLIAJAAIAAALIAPAAIAAAHIgPAAIAAAWQAAAGACABQABACAHAAIAGAAIAAAIIgIAAQgJAAgEgDg");
	this.shape_706.setTransform(13.95,7.5);

	this.shape_707 = new cjs.Shape();
	this.shape_707.graphics.f("#FFFFFF").s().p("AgaAgIAAgKQANADANAAQAKAAAEgBQAEgDAAgFQAAgGgDgDQgEgCgLgBQgPgCgGgDQgFgEgBgKQABgKAGgEQAHgFAOAAQALAAAMADIAAAJQgNgDgKAAQgKAAgEACQgDACgBAFQAAAGADACIAOAEQARABAFADQAFAFAAAKQAAAKgGAGQgHAEgOAAQgNAAgNgDg");
	this.shape_707.setTransform(8.6,7);

	this.shape_708 = new cjs.Shape();
	this.shape_708.graphics.f("#FFFFFF").s().p("AAAAFIgGAMIgGgEIAJgLIgOgDIADgGIAMAFIgBgOIAHAAIgBAOIAMgFIADAGIgOADIAJALIgGAEg");
	this.shape_708.setTransform(3.25,5.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_708},{t:this.shape_707},{t:this.shape_706},{t:this.shape_705},{t:this.shape_704},{t:this.shape_703},{t:this.shape_702},{t:this.shape_701},{t:this.shape_700},{t:this.shape_699},{t:this.shape_698},{t:this.shape_697},{t:this.shape_696},{t:this.shape_695},{t:this.shape_694},{t:this.shape_693},{t:this.shape_692},{t:this.shape_691},{t:this.shape_690},{t:this.shape_689},{t:this.shape_688},{t:this.shape_687},{t:this.shape_686},{t:this.shape_685},{t:this.shape_684},{t:this.shape_683},{t:this.shape_682},{t:this.shape_681},{t:this.shape_680},{t:this.shape_679},{t:this.shape_678},{t:this.shape_677},{t:this.shape_676},{t:this.shape_675},{t:this.shape_674},{t:this.shape_673},{t:this.shape_672},{t:this.shape_671},{t:this.shape_670},{t:this.shape_669},{t:this.shape_668},{t:this.shape_667},{t:this.shape_666},{t:this.shape_665},{t:this.shape_664},{t:this.shape_663},{t:this.shape_662},{t:this.shape_661},{t:this.shape_660},{t:this.shape_659},{t:this.shape_658},{t:this.shape_657},{t:this.shape_656},{t:this.shape_655},{t:this.shape_654},{t:this.shape_653},{t:this.shape_652},{t:this.shape_651},{t:this.shape_650},{t:this.shape_649},{t:this.shape_648},{t:this.shape_647},{t:this.shape_646},{t:this.shape_645},{t:this.shape_644},{t:this.shape_643},{t:this.shape_642},{t:this.shape_641},{t:this.shape_640},{t:this.shape_639},{t:this.shape_638},{t:this.shape_637},{t:this.shape_636},{t:this.shape_635},{t:this.shape_634},{t:this.shape_633},{t:this.shape_632},{t:this.shape_631},{t:this.shape_630},{t:this.shape_629},{t:this.shape_628},{t:this.shape_627},{t:this.shape_626},{t:this.shape_625},{t:this.shape_624},{t:this.shape_623},{t:this.shape_622},{t:this.shape_621},{t:this.shape_620},{t:this.shape_619},{t:this.shape_618},{t:this.shape_617},{t:this.shape_616},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613},{t:this.shape_612},{t:this.shape_611},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605},{t:this.shape_604},{t:this.shape_603},{t:this.shape_602},{t:this.shape_601},{t:this.shape_600},{t:this.shape_599},{t:this.shape_598},{t:this.shape_597},{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.legal, new cjs.Rectangle(0,0,288.2,188.2), null);


(lib.img3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.instance = new lib.img3();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3_1, new cjs.Rectangle(0,0,300,225), null);


(lib.img2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.instance = new lib.img2();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2_1, new cjs.Rectangle(0,0,298,250), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// _
	this.instance = new lib.img1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_1, new cjs.Rectangle(0,0,290.5,211), null);


(lib.hit2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Aj5BQIAAifIHzAAIAACfg");
	this.shape.setTransform(39.9979,8,1.5999,1);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,80,16);


(lib.ctaTxt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAYAvIgtg9IAAA9IgSAAIAAhdIAPAAIAtA+IAAg+IATAAIAABdg");
	this.shape.setTransform(144.3,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAvIgXgiIgKAAIAAAiIgSAAIAAhdIAkAAQAJAAAHAEQAHADAEAIQAEAGAAAIQAAAJgEAHQgEAGgIADIgFADIAbAkgAgSgBIAQAAQAGgBAEgDQAEgEAAgHQAAgHgEgEQgEgEgGABIgQAAg");
	this.shape_1.setTransform(135.025,10.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIA/AAIAAARIgtAAIAAAVIAnAAIAAAPIgnAAIAAAXIAtAAIAAARg");
	this.shape_2.setTransform(126.25,10.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAVAvIAAgnIgqAAIAAAnIgSAAIAAhdIASAAIAAAmIAqAAIAAgmIATAAIAABdg");
	this.shape_3.setTransform(116.65,10.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAtQgJgEgGgHQgHgGgEgJQgDgJAAgKQAAgJADgJQAEgJAHgGQAGgHAJgEQAJgDAJAAQANAAALAFQAKAFAGAJIgOALQgEgGgHgDQgGgDgIAAQgIAAgHADQgHAFgEAHQgDAHAAAHQAAAIADAIQAEAHAHADQAHAFAHAAQAJAAAGgEQAHgDAEgGIAOALQgGAJgLAFQgKAFgNABQgJAAgJgEg");
	this.shape_4.setTransform(106.725,10.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_5.setTransform(99.55,10.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgSAuQgIgCgIgHIAIgNQAGADAGADQAHACAHABQAIgBAEgCQAEgCAAgGQAAgEgDgDQgCgDgHgCIgNgFQgHgDgFgCQgGgEgCgFQgDgEAAgIQAAgIAFgGQAEgGAHgEQAIgCAIAAIAMAAIAKADIAKAGIgJAOQgEgDgGgCQgGgCgHAAQgFAAgEACQgEADAAAFQAAAEADADQADACAFACIANAFQAIACAFADQAGADADAFQACAGAAAHQAAANgJAIQgJAGgRABQgKAAgIgDg");
	this.shape_6.setTransform(93.325,10.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIAvIAAhMIgeAAIAAgRIBNAAIAAARIgeAAIAABMg");
	this.shape_7.setTransform(81.875,10.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSAtQgJgEgHgHQgHgGgDgJQgEgJAAgKQAAgJAEgJQADgIAHgIQAHgGAJgEQAIgDAKAAQAKAAAJADQAJAEAHAHQAGAHAEAIQAEAJAAAJQAAAKgEAJQgEAJgGAGQgHAHgJAEQgJAEgKAAQgKAAgIgEgAgPgaQgGAFgEAHQgEAHAAAHQAAAIAEAHQAEAHAGAEQAHAFAIAAQAJAAAHgFQAGgDAEgHQAEgIAAgIQAAgHgEgHQgEgHgGgEQgHgEgJAAQgIAAgHADg");
	this.shape_8.setTransform(72.175,10.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgiAvIAAhdIAjAAQAJAAAGADQAHAEADAFQADAGAAAHQAAAGgDAFQgDAFgGADQAJACAFAFQAEAGAAAIQAAAKgEAGQgFAGgHADQgIADgIAAgAgQAhIARAAQAEgBAEgBQADgBACgDQACgDAAgFQAAgFgCgDQgCgDgEgBQgDgCgFABIgQAAgAgQgIIAPAAIAGgBQACgBABgCQADgDAAgEQAAgFgDgDQgBgCgDgBIgFgBIgPAAg");
	this.shape_9.setTransform(62.55,10.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIA+AAIAAARIgsAAIAAAVIAoAAIAAAPIgoAAIAAAXIAtAAIAAARg");
	this.shape_10.setTransform(53.95,10.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPAtQgIgEgHgHQgHgGgDgJQgEgJAAgKQAAgJAEgJQADgJAHgGQAHgHAIgEQAKgDAKAAQAMAAAKAEQALAGAGAJIgOAKQgEgGgHgDQgGgCgIAAQgJAAgGADQgIAFgDAHQgEAHAAAHQAAAIAEAIQADAHAIADQAHAFAIAAQAIAAAHgDIAHgEIAAgPIgWAAIAAgMIAoAAIAAAiQgGAIgLAFQgKAFgNAAQgKAAgKgEg");
	this.shape_11.setTransform(44.25,10.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAYAvIgtg9IAAA9IgSAAIAAhdIAPAAIAuA+IAAg+IASAAIAABdg");
	this.shape_12.setTransform(33.9,10.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAbAvIgJgXIglAAIgIAXIgTAAIAjhdIAXAAIAjBdgAAOAIIgOglIgNAlIAbAAg");
	this.shape_13.setTransform(23.75,10.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaTxt, new cjs.Rectangle(0,0,168.4,20.8), null);


(lib.ctaBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AiiCyIgGAAIgGAAIs0AAQhJAAg1g1Qg0g0AAhJQAAhJA0g0QA1g0BJAAIM0AAIAGAAIAGAAISFAAQBJAAA0A0QA1A0AABJQAABJg1A0Qg0A1hJAAg");
	this.shape.setTransform(117.275,17.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaBg, new cjs.Rectangle(0,0,234.6,35.6), null);


(lib.txt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3a
	this.txt3a = new lib.txt3a();
	this.txt3a.name = "txt3a";
	this.txt3a.setTransform(92.2,21.2,1,1,0,0,0,92.2,21.2);

	this.timeline.addTween(cjs.Tween.get(this.txt3a).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(0,0,192.1,41.8), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1a
	this.txt1a = new lib.txt1a();
	this.txt1a.name = "txt1a";
	this.txt1a.setTransform(84.8,9.2,1,1,0,0,0,84.8,9.2);

	this.timeline.addTween(cjs.Tween.get(this.txt1a).wait(1));

	// txt1b
	this.txt1b = new lib.txt1b();
	this.txt1b.name = "txt1b";
	this.txt1b.setTransform(84.25,25,1,1,0,0,0,84.4,9.2);

	this.timeline.addTween(cjs.Tween.get(this.txt1b).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-0.1,0,169.7,39), null);


(lib.detailsMc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// legal
	this.legal = new lib.legal();
	this.legal.name = "legal";
	this.legal.setTransform(7.5,7.5);

	this.timeline.addTween(cjs.Tween.get(this.legal).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(90.2,311.2,1,1,0,0,0,-59.8,186.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.detailsMc, new cjs.Rectangle(0,0,970,250), null);


(lib.details = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.hit = new lib.hit2();
	this.hit.name = "hit";
	this.hit.setTransform(0.1,0,0.7947,1.0585,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit2(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgPAQIAAgGQAIACAHAAIAIgBQAAAAAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAIgIgBQgJgBgDgCQgDgBAAgGQAAgFAEgCQADgDAIAAQAHAAAIACIAAAFIgPgBIgHABQAAAAAAAAQgBAAAAABQAAAAAAABQgBAAAAABQAAAAABABQAAAAAAABQAAAAAAABQABAAAAAAIAHACQAKABADABQADACAAAGQAAAFgDACQgFADgIAAQgIAAgHgCg");
	this.shape.setTransform(57.75,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgCAYIAAghIAFAAIAAAhgAgCgRIAAgGIAFAAIAAAGg");
	this.shape_1.setTransform(54.825,10.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgNAOQgDgEAAgKQAAgIADgFQAFgEAJAAQAIAAAEAEQAFAEAAAIIAAADIgcAAQAAAGADACQADACAGAAIANgBIAAAFQgGACgHAAQgKAAgFgEgAALgCQgBgFgCgCQgCgCgGAAQgEAAgDACQgCACgBAFIAVAAIAAAAg");
	this.shape_2.setTransform(51.85,10.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAKARIgKgcIgJAcIgKAAIgKghIAGAAIAJAcIAKgcIAJAAIAKAcIAIgcIAHAAIgKAhg");
	this.shape_3.setTransform(46.475,10.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AALARIAAgUQAAgHgJAAQgGAAgHADIAAAYIgFAAIAAggIAEAAIABACQAHgDAHAAQAHAAAEADQADADAAAGIAAAVg");
	this.shape_4.setTransform(40.95,10.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgCAYIAAghIAFAAIAAAhgAgCgRIAAgGIAFAAIAAAGg");
	this.shape_5.setTransform(37.725,10.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AALAYIAAgWQAAgFgJgBQgFAAgHAEIAAAYIgGAAIAAgvIAGAAIAAAQQAHgCAFAAQAIgBAEAEQADADABAFIAAAWg");
	this.shape_6.setTransform(34.5,10.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgPAQIAAgGQAIACAHAAIAIgBQAAAAAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAIgIgBQgJgBgDgCQgDgBAAgGQAAgFAEgCQADgDAIAAQAHAAAIACIAAAFIgPgBIgHABQAAAAAAAAQgBAAAAABQAAAAAAABQAAAAgBABQABAAAAABQAAAAAAABQAAAAAAABQABAAAAAAIAHACQAKABADABQADACAAAGQAAAFgEACQgEADgIAAQgIAAgHgCg");
	this.shape_7.setTransform(30.2,10.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAGAVQgGAAgDgCQgDgDAAgGIAAgQIgEAAIAAgFIAEgBIAAgIIAGAAIAAAIIALAAIAAAGIgLAAIAAAPQAAAEABABQACABAEAAIAEAAIAAAGIgFAAg");
	this.shape_8.setTransform(26.7,10.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AALAYIAAgWQAAgFgJgBQgFAAgHAEIAAAYIgHAAIAAgvIAHAAIAAAQQAHgCAFAAQAIgBAEAEQADADABAFIAAAWg");
	this.shape_9.setTransform(23,10.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgKAOQgFgFAAgJQAAgJAFgEQAEgEAJAAIAMACIAAAFIgMgBQgGAAgDADQgCACAAAGQAAAGACADQADADAGAAIANgBIAAAFQgGACgHAAQgJAAgEgEg");
	this.shape_10.setTransform(18.775,10.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgMAOQgEgEgBgKQABgIAEgFQAEgEAIAAQAJAAAEAEQAFAEgBAIIAAADIgbAAQAAAGADACQADACAGAAIANgBIAAAFQgGACgHAAQgKAAgEgEgAALgCQAAgFgDgCQgCgCgGAAQgFAAgCACQgCACgBAFIAVAAIAAAAg");
	this.shape_11.setTransform(14.75,10.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAMAYIgJgPIgBAAIgPAAIAAAPIgGAAIAAgvIAVAAQAKAAAEAEQAFADAAAJQAAAHgDADQgCADgGACIAKAQgAgNACIAPAAQAGAAADgBQACgCABgGQgBgFgCgDQgDgCgGAAIgPAAg");
	this.shape_12.setTransform(10.15,10.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAAAEIgFAIIgEgDIAHgHIgKgCIACgEIAJADIgBgKIAEAAIgBAKIAKgDIACAEIgKACIAGAHIgEADg");
	this.shape_13.setTransform(6.075,9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.details, new cjs.Rectangle(0,0,63.6,17), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As9DKIAAmTIZ7AAIAAGTg");
	mask.setTransform(83,20.2);

	// txt
	this.ctaTxt = new lib.ctaTxt();
	this.ctaTxt.name = "ctaTxt";
	this.ctaTxt.setTransform(83.05,20.2,1,1,0,0,0,84.2,10.4);

	var maskedShapeInstanceList = [this.ctaTxt];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaTxt).wait(1));

	// bg
	this.ctaBg = new lib.ctaBg();
	this.ctaBg.name = "ctaBg";
	this.ctaBg.setTransform(0,20.2,0.7077,1.1348,0,0,0,0,17.8);

	this.timeline.addTween(cjs.Tween.get(this.ctaBg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,166,40.4), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var title = this.title;
		var img1 = this.img1;
		var img2 = this.img2;
		var img3 = this.img3;
		var img4 = this.img4;
		
		var txt1 = this.txt1;
			var txt1a = txt1.txt1a;
			var txt1b = txt1.txt1b;
		var txt2 = this.txt2;
		var txt3 = this.txt3;
			var txt3a = txt3.txt3a;
			//var txt3b = txt3.txt3b;
		var txt4 = this.txt4;
			
		var offer = this.offer;
		var cta = this.cta;
			var ctaTxt= cta.ctaTxt;
			var ctaBg= cta.ctaBg;
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		//LEGAL START
		var details = this.details;
		var detailsMc = this.detailsMc;
		var detailsStart = detailsMc.y;
		detailsMc.alpha = 0;
		var detailsState = false;
		
		var legal = detailsMc.legal;
		var timePerFrame = 6;
		var totalFrame = 1;
		var legalSprite = TweenMax.to(legal, (timePerFrame*totalFrame), {y:"-="+(h*totalFrame-h), ease: SteppedEase.config(totalFrame-1),yoyo: false, repeat: -1, paused:true} );
		
		function onDetailsHover(eventObj) { //console.log(eventObj);
			if (!detailsState) {       
				TweenLite.to(detailsMc, .5, {alpha:1, ease:Power2.easeOut});
				legalSprite.restart();
				tl.pause();
				detailsState = true; 
		
			} else {
				if(eventObj.type!="mouseover") {
					legalSprite.pause();
					TweenLite.to(detailsMc, .5, {alpha:0, ease:Power2.easeInOut,onComplete:function()
						{2
							detailsState = false; //console.log(detailsState);
						}
					});
					tl.play();
				}
			}
		}
		
		function addListeners(){
			details.hit.addEventListener("mouseover", onDetailsHover);
			details.hit.addEventListener("mouseout", onDetailsHover);
			//detailsMc.addEventListener("click", onDetailsHover);
		}
		
		
		addListeners();
		detailsMc.cache(0, 0, detailsMc.nominalBounds.width, detailsMc.nominalBounds.height, 2);
		
		//LEGAL END
		
		var toMask = [
			title, offer,
			txt1a, txt1b,
			txt2,
			txt3a, /*txt3b,*/
			img2, img3, img4,
		];
		
		function makeTxtsMask(){
		
		 for (var i = 0; i < toMask.length; i++) {
			 
			var txtMask = new createjs.Shape();
			txtMask.graphics.beginStroke("1px solid #ccc").drawRect(0, 0, (toMask[i].nominalBounds.width * toMask[i].scaleX), (toMask[i].nominalBounds.height * toMask[i].scaleY));
		
				toMask[i].mask = txtMask;
				toMask[i].mask.regX = toMask[i].regX * toMask[i].scaleX;
				toMask[i].mask.regY = toMask[i].regY * toMask[i].scaleY;
				toMask[i].mask.x = toMask[i].x;
				toMask[i].mask.y = toMask[i].y;
			 
				//toMask[i].parent.addChild(txtMask); // Also made visible
			}
		}
		makeTxtsMask();
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf, options) {
			if (window.takeAutoShot !== undefined) {
				window.takeAutoShot(tf, options);
			}
		}
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat:0, repeatDelay:0, 
			defaults: {ease: Power2.easeOut, duration: 1}});
		
		tl
			.add("frame1")
			.from([title.mask], {x:"-="+(title.nominalBounds.width), duration:.7, ease: Power1.easeOut}, "frame1+=.5")
			.from([txt1a.mask, txt1b.mask], { y:"+="+(txt1a.nominalBounds.height), duration:.4, ease: Power2.easeOut }, "frame1+=1" )
			.add(autoShot)
			
			.add("frame2","frame1+=5")
			.to([txt1], {alpha: 0, duration:.25, ease: Power2.easeOut}, "frame2" )
			.from([img2.mask], {x:"-="+(img2.nominalBounds.width), duration:.4, ease: Power2.easeOut }, "frame2+=.2")
			.from([txt2.mask], { y:"+="+(txt2.nominalBounds.height), duration:.4 , ease: Power2.easeOut}, "frame2+=.2" )
			.add(autoShot)
		
			.add("frame3", "frame2+=2.5")
			.to([txt2], {alpha: 0, duration:.25, ease: Power2.easeOut}, "frame3" )
			.from([img3.mask], {x:"-="+(img3.nominalBounds.width), duration:.4, ease: Power2.easeOut }, "frame3+=.2")
			.from([txt3a.mask, /*txt3b.mask*/], { y:"+="+(txt3a.nominalBounds.height), duration:.4, ease: Power2.easeOut }, "frame3+=.2" )
			.add(autoShot)
		
			.add("frame4", "frame3+=2.5")
			.to([txt3], {alpha: 0, duration:.25, ease: Power2.easeOut}, "frame4" )
			.from([img4.mask], {x:"-="+(img4.nominalBounds.width), duration:.4, ease: Power2.easeOut }, "frame4+=.2")
			.from([offer, txt4], {y:"+="+30, alpha: 0, duration:.5, ease: Power2.easeOut}, "frame4+=.5")
			//.to([img2, img3], .1, { alpha: 0 }, "frame4+=.4")
			.add(autoShot)
		
			.add("frame5", "frame4+=2.5")
			.to(offer, { duration: .3, scaleY: 0, ease: Power2.easeOut }, "frame5")
			.from([ctaTxt], .5, {x:"-="+(cta.nominalBounds.width), ease: Power2.easeOut}, "frame5+=.3")
			.from([ctaBg], .5, {scaleX:0, ease: Power2.easeOut}, "frame5+=.3")
			.add(autoShot, "frame5+=2.5")
			.call(autoShot, [true, ["modify", [
				{name: "legal", elements: details}, 
				{name: "hide", elements: [details]}]]],"+=0")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// detailcMc
	this.detailsMc = new lib.detailsMc();
	this.detailsMc.name = "detailsMc";

	this.timeline.addTween(cjs.Tween.get(this.detailsMc).wait(1));

	// detailsBtn
	this.details = new lib.details();
	this.details.name = "details";
	this.details.setTransform(234.55,232.55,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.details).wait(1));

	// logo
	this.instance = new lib.logosvg("synched",0);
	this.instance.setTransform(214.55,26.15,0.1191,0.1184,0,0,0,640.5,141);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// title
	this.title = new lib.title();
	this.title.name = "title";
	this.title.setTransform(90.2,179.8,1,1,0,0,0,85.2,16.6);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(84.3,218.65,1,1,0,0,0,78.1,22.5);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// offer
	this.offer = new lib.offer();
	this.offer.name = "offer";
	this.offer.setTransform(28.5,210.85,1,1,0,0,0,20.9,20);

	this.timeline.addTween(cjs.Tween.get(this.offer).wait(1));

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(237.6,218,1,1,0,0,0,50.1,26);

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	// txt3
	this.txt3 = new lib.txt3();
	this.txt3.name = "txt3";
	this.txt3.setTransform(56.7,202,1,1,0,0,0,52.8,11.6);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(62.4,201.6,1,1,0,0,0,59.4,11.6);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(88.85,206.7,1,1,0,0,0,84.8,16.4);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// frame
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDgA2fFKMAs/AAAIAA3vMgs/AAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// img4
	this.img4 = new lib.img1_1();
	this.img4.name = "img4";
	this.img4.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// img3
	this.img3 = new lib.img3_1();
	this.img3.name = "img3";
	this.img3.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// img2
	this.img2 = new lib.img2_1();
	this.img2.name = "img2";
	this.img2.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(154.75,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(150,125,150,125);
// library properties:
lib.properties = {
	id: 'B2061C9C367D447692F04741500D2D84',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"img1.jpg", id:"img1"},
		{src:"img2.jpg", id:"img2"},
		{src:"img3.jpg", id:"img3"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B2061C9C367D447692F04741500D2D84'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;