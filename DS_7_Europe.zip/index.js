(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.img2 = function() {
	this.initialize(img.img2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,600);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgnBHQgRgLgJgSQgJgTAAgVQAAgmAVgWQAVgXAgABQAWAAASAKQARAKAJATQAJATAAAWQAAAYgJAUQgKASgSAKQgRAJgVAAQgVAAgSgKgAglgvQgQAPAAAiQAAAdAQAQQAPARAWAAQAYAAAPgRQAPgQAAgfQAAgSgGgOQgHgPgMgHQgNgJgQABQgVAAgQAPg");
	this.shape.setTransform(144.725,67.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKBPIg9idIAWAAIAqByIAHAZIAIgZIArhyIAVAAIg9Cdg");
	this.shape_1.setTransform(128.8,67.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJBPIAAidIATAAIAACdg");
	this.shape_2.setTransform(118.5,67.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgJBPIAAiKIg0AAIAAgTIB8AAIAAATIg0AAIAACKg");
	this.shape_3.setTransform(108.75,67.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgKBPIAAidIAVAAIAACdg");
	this.shape_4.setTransform(99,67.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgjBJQgOgIgGgPQgGgOAAgZIAAhaIAVAAIAABaQAAAVAEAJQAEAKAJAFQAJAGAOAAQAWAAAJgLQAKgKAAgeIAAhaIAVAAIAABaQAAAXgFAOQgGAOgOAKQgOAIgXAAQgVAAgOgHg");
	this.shape_5.setTransform(87.975,67.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgJBPIAAiKIg1AAIAAgTIB9AAIAAATIg1AAIAACKg");
	this.shape_6.setTransform(73.4,67.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAoBPIhRh7IAAB7IgUAAIAAidIAVAAIBSB7IAAh7IAUAAIAACdg");
	this.shape_7.setTransform(58.7,67.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgKBPIAAidIAVAAIAACdg");
	this.shape_8.setTransform(47.8,67.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BPIAAgUIBPhjIARgTIhXAAIAAgTIBwAAIAAATIhYBsIgJALIBjAAIAAATg");
	this.shape_9.setTransform(133.125,40.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgnBHQgRgLgJgSQgJgTAAgVQAAgmAVgWQAVgXAgABQAWgBASALQARAKAJATQAJATAAAWQAAAYgJAUQgKASgSAKQgRAJgVAAQgVAAgSgKgAglgvQgQAPAAAiQAAAdAQAQQAPARAWAAQAYAAAPgRQAPgQAAgfQAAgSgGgOQgHgPgMgHQgNgJgQABQgVAAgQAPg");
	this.shape_10.setTransform(117.925,40.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgKBPIg9idIAWAAIAqByIAHAZIAIgZIArhyIAVAAIg9Cdg");
	this.shape_11.setTransform(102,40.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag6BPIAAidIBxAAIAAATIhcAAIAAAwIBWAAIAAASIhWAAIAAA1IBgAAIAAATg");
	this.shape_12.setTransform(81.575,40.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhABPIAAidIA2AAQASAAAJADQAOADAKAIQAMAKAGARQAGAQAAAVQAAARgEAOQgEAOgHAJQgGAJgIAFQgIAFgLADQgLADgNAAgAgrA8IAiAAQAOAAAJgDQAIgDAGgFQAHgHAFgNQADgMABgRQAAgZgJgNQgHgNgMgFQgIgDgSAAIghAAg");
	this.shape_13.setTransform(66.3,40.575);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag6BPIAAidIBxAAIAAATIhcAAIAAAwIBWAAIAAASIhWAAIAAA1IBgAAIAAATg");
	this.shape_14.setTransform(160.275,14.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJBPIAAiKIg0AAIAAgTIB8AAIAAATIg0AAIAACKg");
	this.shape_15.setTransform(146,14.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AApBPIhSh7IAAB7IgUAAIAAidIAVAAIBSB7IAAh7IAUAAIAACdg");
	this.shape_16.setTransform(131.3,14.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag6BPIAAidIBxAAIAAATIhcAAIAAAwIBWAAIAAASIhWAAIAAA1IBgAAIAAATg");
	this.shape_17.setTransform(116.375,14.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgJBPIAAiKIg0AAIAAgTIB8AAIAAATIg1AAIAACKg");
	this.shape_18.setTransform(102.1,14.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgeBLQgPgGgIgMQgIgNAAgQIATgCQACAMAFAIQAFAHAKAFQALAFAMAAQANAAAIgEQAKgDAFgGQADgHAAgHQAAgHgDgGQgFgFgKgEQgGgDgVgFQgVgFgJgEQgMgGgFgIQgGgJAAgLQAAgMAHgKQAHgLANgFQANgFAQAAQAQAAAOAFQANAGAHALQAIALAAAOIgUABQgCgPgJgHQgJgIgSAAQgSAAgJAHQgJAHABAKQAAAIAFAGQAGAFAZAGQAaAGAJAEQAOAFAGAKQAHAKAAAMQgBANgGALQgIALgNAGQgOAGgRAAQgUAAgOgGg");
	this.shape_19.setTransform(87.95,14.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgJBPIAAidIATAAIAACdg");
	this.shape_20.setTransform(77.7,14.025);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgeBLQgPgGgIgMQgIgNgBgQIAUgCQACAMAEAIQAFAHAMAFQAKAFANAAQALAAAKgEQAJgDAEgGQAFgHAAgHQAAgHgFgGQgEgFgKgEQgGgDgVgFQgVgFgKgEQgKgGgGgIQgFgJAAgLQAAgMAGgKQAHgLANgFQANgFAQAAQARAAANAFQANAGAIALQAGALABAOIgUABQgCgPgJgHQgJgIgSAAQgSAAgJAHQgJAHAAAKQAAAIAHAGQAFAFAZAGQAaAGAJAEQANAFAHAKQAGAKAAAMQABANgIALQgGALgOAGQgNAGgRAAQgVAAgOgGg");
	this.shape_21.setTransform(67.2,14.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgeBLQgPgGgIgMQgIgNgBgQIAUgCQABAMAFAIQAGAHAKAFQALAFANAAQALAAAJgEQAJgDAGgGQADgHAAgHQAAgHgDgGQgFgFgKgEQgGgDgVgFQgWgFgIgEQgLgGgGgIQgFgJgBgLQABgMAGgKQAHgLANgFQANgFAQAAQAQAAAOAFQANAGAIALQAHALAAAOIgUABQgBgPgKgHQgJgIgSAAQgSAAgJAHQgJAHAAAKQABAIAGAGQAFAFAZAGQAZAGAKAEQAOAFAGAKQAHAKgBAMQAAANgGALQgIALgNAGQgOAGgQAAQgVAAgOgGg");
	this.shape_22.setTransform(52.55,14.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAyBPIgSgwIhBAAIgRAwIgXAAIA9idIAVAAIBBCdgAAZAOIgQgrQgIgTgCgNQgDAPgGAPIgRAtIA0AAg");
	this.shape_23.setTransform(37.975,14.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(0,0,198,81.7), null);


(lib.txt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA3BPIAAiDIgtCDIgSAAIguiFIAACFIgUAAIAAidIAfAAIAlBvIAHAXIAJgZIAlhtIAcAAIAACdg");
	this.shape.setTransform(177.7,14.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag6BPIAAidIBxAAIAAATIhcAAIAAAwIBWAAIAAASIhWAAIAAA1IBgAAIAAATg");
	this.shape_1.setTransform(161.525,14.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKBPIAAiKIgzAAIAAgTIB8AAIAAATIg0AAIAACKg");
	this.shape_2.setTransform(147.25,14.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeBLQgPgGgIgMQgIgNgBgQIAUgCQABAMAFAIQAGAHAKAFQALAFANAAQALAAAJgEQAJgDAGgGQADgHAAgHQAAgHgDgGQgFgFgKgEQgGgDgVgFQgWgFgIgEQgLgGgGgIQgFgJgBgLQABgMAGgKQAHgLANgFQANgFAQAAQAQAAAOAFQANAGAIALQAHALAAAOIgUABQgBgPgKgHQgJgIgSAAQgSAAgJAHQgJAHAAAKQABAIAGAGQAFAFAZAGQAZAGAKAEQAOAFAGAKQAHAKgBAMQAAANgGALQgIALgNAGQgOAGgQAAQgVAAgOgGg");
	this.shape_3.setTransform(133.1,14.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgKBPIAAhDIg9haIAZAAIAfAwIAPAaIARgbIAfgvIAYAAIg/BaIAABDg");
	this.shape_4.setTransform(118.475,14.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeBLQgPgGgIgMQgIgNAAgQIATgCQABAMAGAIQAEAHAMAFQAKAFAMAAQAMAAAKgEQAIgDAFgGQAEgHABgHQgBgHgEgGQgEgFgKgEQgGgDgVgFQgVgFgJgEQgMgGgFgIQgGgJABgLQgBgMAHgKQAHgLANgFQANgFAQAAQARAAANAFQANAGAHALQAIALAAAOIgUABQgCgPgJgHQgJgIgSAAQgSAAgJAHQgIAHAAAKQAAAIAFAGQAHAFAYAGQAaAGAJAEQANAFAHAKQAGAKABAMQAAANgHALQgIALgNAGQgNAGgSAAQgUAAgOgGg");
	this.shape_5.setTransform(103.8,14.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgeBLQgPgGgIgMQgIgNgBgQIAUgCQACAMAEAIQAGAHALAFQAKAFANAAQAMAAAJgEQAJgDAFgGQAEgHAAgHQAAgHgEgGQgFgFgKgEQgGgDgVgFQgVgFgKgEQgKgGgGgIQgFgJAAgLQAAgMAGgKQAHgLANgFQANgFAQAAQAQAAAOAFQANAGAIALQAGALABAOIgUABQgCgPgJgHQgJgIgSAAQgSAAgJAHQgJAHAAAKQAAAIAHAGQAFAFAZAGQAaAGAJAEQAOAFAGAKQAGAKAAAMQABANgIALQgGALgOAGQgNAGgRAAQgVAAgOgGg");
	this.shape_6.setTransform(83.05,14.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgKBPIAAidIAVAAIAACdg");
	this.shape_7.setTransform(72.8,14.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AArBPIgVghIgPgWQgGgHgDgDQgFgDgFgBIgLgBIgZAAIAABGIgUAAIAAidIBEAAQAVAAALAFQALAEAHAKQAGALAAANQAAARgKALQgLALgXADIANAIQAJAIAIANIAbArgAgwgIIAtAAQANAAAJgDQAIgDAEgHQAEgGAAgIQAAgLgIgHQgIgHgSAAIgxAAg");
	this.shape_8.setTransform(62.525,14.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgKBPIAAidIAVAAIAACdg");
	this.shape_9.setTransform(50.85,14.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgeBLQgPgGgIgMQgIgNgBgQIAUgCQACAMAFAIQAEAHAMAFQAKAFAMAAQAMAAAKgEQAIgDAFgGQAFgHAAgHQAAgHgFgGQgEgFgKgEQgGgDgVgFQgVgFgKgEQgLgGgFgIQgGgJABgLQAAgMAGgKQAHgLANgFQANgFAQAAQARAAANAFQANAGAIALQAGALABAOIgUABQgCgPgJgHQgJgIgSAAQgSAAgJAHQgIAHAAAKQgBAIAHAGQAFAFAZAGQAaAGAJAEQANAFAHAKQAGAKABAMQAAANgIALQgGALgOAGQgOAGgQAAQgVAAgOgGg");
	this.shape_10.setTransform(34.25,14.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhABPIAAidIA2AAQASAAAJADQAOADAJAIQANAKAGARQAGAQAAAVQAAARgEAOQgEAOgHAJQgGAJgIAFQgIAFgLADQgLADgNAAgAgrA8IAhAAQAPAAAJgDQAIgDAGgFQAIgHAEgNQADgMAAgRQAAgZgIgNQgHgNgMgFQgJgDgRAAIghAAg");
	this.shape_11.setTransform(19.35,14.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(0,0,198,28.6), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYAtQgLgHgGgMQgGgLAAgOQAAgYANgOQAOgOAUAAQAOAAALAHQALAHAGALQAGAMAAAOQAAAQgGAMQgGAMgMAGQgLAGgNAAQgNAAgLgHgAgXgeQgKAKAAAWQAAASAJAKQAKALAOAAQAPAAAKgLQAJgKAAgUQAAgLgEgJQgEgJgIgFQgIgFgKAAQgNAAgKAJg");
	this.shape.setTransform(174.325,27.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgFAyIAAhYIghAAIAAgLIBOAAIAAALIgiAAIAABYg");
	this.shape_1.setTransform(164.6,27.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAaAyIgzhOIAABOIgNAAIAAhjIANAAIA0BNIAAhNIAMAAIAABjg");
	this.shape_2.setTransform(155.2,27.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgkAyIAAhjIBHAAIAAALIg6AAIAAAfIA2AAIAAALIg2AAIAAAiIA8AAIAAAMg");
	this.shape_3.setTransform(145.75,27.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgGAyIAAhjIANAAIAABjg");
	this.shape_4.setTransform(139.025,27.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAjAyIAAhTIgdBTIgLAAIgdhVIAABVIgNAAIAAhjIAUAAIAYBGIAEAOIAFgQIAYhEIASAAIAABjg");
	this.shape_5.setTransform(131.225,27.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAgAyIgMgfIgpAAIgLAfIgOAAIAnhjIANAAIApBjgAAQAJIgLgbIgGgUIgFATIgLAcIAhAAg");
	this.shape_6.setTransform(120.775,27.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAaAyIgzhOIAABOIgOAAIAAhjIAPAAIAzBNIAAhNIAMAAIAABjg");
	this.shape_7.setTransform(111,27.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgGAyIAAhjIANAAIAABjg");
	this.shape_8.setTransform(104.125,27.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AghAyIAAhjIBDAAIAAALIg2AAIAAAfIAvAAIAAAMIgvAAIAAAtg");
	this.shape_9.setTransform(98.125,27.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgkAyIAAhjIBHAAIAAALIg6AAIAAAfIA3AAIAAALIg3AAIAAAiIA8AAIAAAMg");
	this.shape_10.setTransform(89.15,27.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAbAyIgNgVIgJgNIgGgIIgGgCIgIAAIgPAAIAAAsIgNAAIAAhjIArAAQAOAAAHACQAHADAEAHQAEAHAAAIQAAALgHAHQgHAHgOACIAIAEQAFAGAGAIIARAbgAgegFIAdAAQAIAAAFgCQAFgBADgFQACgEAAgFQAAgHgFgFQgFgEgLAAIgfAAg");
	this.shape_11.setTransform(79.725,27.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgeAyIAAhjIANAAIAABXIAwAAIAAAMg");
	this.shape_12.setTransform(66.775,27.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAgAyIgMgfIgpAAIgLAfIgOAAIAnhjIANAAIApBjgAAQAJIgLgbIgGgUIgFATIgLAcIAhAAg");
	this.shape_13.setTransform(57.975,27.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AglAyIAAhjIBIAAIAAALIg6AAIAAAgIA3AAIAAAKIg3AAIAAAiIA9AAIAAAMg");
	this.shape_14.setTransform(143.45,9.65);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgUArQgGgHAAgPIALgCQABAMAEAEQADAEAHAAQAFAAADgCQAEgCABgEQABgEAAgJIAAhEIAOAAIAABDQAAANgEAHQgDAHgGADQgHAEgIAAQgMAAgIgIg");
	this.shape_15.setTransform(134.75,9.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAgAyIgMgeIgpAAIgLAeIgOAAIAnhjIANAAIApBjgAAQAJIgLgbIgGgVIgFATIgLAdIAhAAg");
	this.shape_16.setTransform(126.975,9.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgGAyIAAhjIANAAIAABjg");
	this.shape_17.setTransform(120.425,9.65);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgGAyIgnhjIAOAAIAaBHIAFARIAFgRIAchHIANAAIgnBjg");
	this.shape_18.setTransform(113.8,9.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAaAyIgzhNIAABNIgOAAIAAhjIAPAAIAzBOIAAhOIAMAAIAABjg");
	this.shape_19.setTransform(100.2,9.65);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgWAuQgJgFgEgJQgDgJAAgQIAAg5IANAAIAAA5QAAANACAGQACAGAGAEQAHADAIAAQANAAAHgHQAGgGAAgTIAAg5IAOAAIAAA5QAAAPgEAJQgEAJgIAFQgKAGgOAAQgNAAgJgFg");
	this.shape_20.setTransform(90.15,9.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(0,0,233,37.2), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgcBKQABgfAMggQAMggATgZIhAAAIAAgbIBhAAIAAAVQgMAMgNAWQgMAWgHAZQgFAZAAAUg");
	this.shape.setTransform(163.175,13.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgqBBQgPgNgDgaIAdgDQADAPAIAHQAIAHANAAQAPAAAHgGQAIgGAAgIQAAgGgDgDQgEgEgHgDIgYgHQgYgGgKgHQgOgNAAgSQAAgLAHgKQAGgKANgFQAMgGARAAQAbAAAPANQAOAMABAVIgfABQgCgLgGgFQgGgGgMAAQgNAAgIAGQgFADAAAGQAAAGAFADQAGAFAVAFQAWAGALAFQAKAGAGAJQAGAJAAAOQAAANgHAMQgHALgNAFQgOAGgTAAQgcAAgPgNg");
	this.shape_1.setTransform(144.425,13.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag+BLIAAiVIA3AAQATAAAKADQANAEAJAKQAJAKAGAOQAEAOAAAVQAAASgEAOQgGAQgKAKQgJAIgNAEQgKADgPAAgAgfAyIAWAAQAMAAAFgCQAIgBAFgFQAEgEADgKQAEgKAAgSQAAgQgEgKQgDgJgFgFQgGgFgIgCQgGgCgSAAIgNAAg");
	this.shape_2.setTransform(130.2,13.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag0A5QgUgUAAgkQAAgWAHgQQAFgLAJgJQAJgJAKgFQAOgGASAAQAhAAAUAVQAUAVAAAjQAAAlgUAUQgUAVghAAQghAAgTgVgAgdgmQgMANAAAZQAAAaAMANQAMANARAAQASAAAMgNQAMgNAAgaQAAgZgMgNQgLgNgTAAQgSAAgLANg");
	this.shape_3.setTransform(108.5,13.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgQBLIg1iVIAhAAIAlBuIAkhuIAhAAIg2CVg");
	this.shape_4.setTransform(93.3,13.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag4BLIAAiVIBuAAIAAAZIhQAAIAAAiIBLAAIAAAYIhLAAIAAApIBTAAIAAAZg");
	this.shape_5.setTransform(79.55,13.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgeBIQgLgFgHgJQgGgHgCgJQgDgNAAgZIAAhQIAfAAIAABRQAAATABAGQACAKAHAFQAHAGAMgBQANAAAGgEQAHgGABgIIABgZIAAhTIAfAAIAABPQAAAbgDALQgCALgHAHQgGAJgMAEQgLAEgRAAQgUAAgMgEg");
	this.shape_6.setTransform(64.65,13.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAdBLIg7hhIAABhIgdAAIAAiVIAeAAIA8BjIAAhjIAdAAIAACVg");
	this.shape_7.setTransform(49.525,13.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(0,0,211,27.5), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjgAFIAAgJIHBAAIAAAJg");
	this.shape.setTransform(22.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line1, new cjs.Rectangle(0,0,45,1), null);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AnVAFIAAgJIOrAAIAAAJg");
	this.shape.setTransform(47,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1,94,1);


(lib.Interpoler18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FAFAFA","#F8F8F8","#EBEBEB","#878787"],[0.02,0.063,0.471,0.961],0,-158.2,0,158.2).s().p("Ao84tIAgAZQEeDyDWDgQGvHBB7FOQA7CkAACPQAACQg7CkQh7FOmvHBQjWDgkeDyIggAZg");
	this.shape.setTransform(-9.2759,-10.4337,0.0561,0.0561);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#A8A8A7","#1D1D1C","#1D1D1C"],[0,0.212,0.808],-4.1,-45.9,3.8,44.8).s().p("ApzH5QgCgCCwieIBQhKQCQiICYjcQBMhvAvhVQA+h4AagcQAtgwBZgJQCugQCFgCQAZAAALAEQAMAFAEAMQAGATgmAbQh3BUkQDZQmOE7idB6IhTBAIiMBqQgrAigIAAIgCAAg");
	this.shape_1.setTransform(-5.0532,-7.6345,0.0553,0.0553);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#706F6F","#818180","#AAAAAA","#E5E5E5","#FFFFFF","#F1F1F1","#CDCDCD","#8D8D8D","#5F5F5E"],[0.039,0.106,0.239,0.424,0.506,0.565,0.686,0.859,0.961],0,-168.5,0,168.6).s().p("AwWYtIAggZIABAAQDbiVCziRQETjcDPjWQG/nMAAlwQAAlxm/nMQjRjYkRjaQi5iUjWiSIgggZIAAhmIfrYrQBCAzAAA2QAAA4hCAyI/rYrg");
	this.shape_2.setTransform(-6.9287,-10.5532,0.0553,0.0553);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#A8A8A7","#1D1D1C","#1D1D1C"],[0,0.212,0.808],4.1,44.8,-3.8,-46).s().p("AHxGdIiFhwIopm4Qj+jIiLhiQgmgaAGgUQADgMAMgFQAMgEAZAAQCFACCuAQQBYAJAtAwQAbAcA+B4IB7DEQCXDcCRCIQAiAgBcBcQBrBrgDADIAAAAQgJAAhuhcg");
	this.shape_3.setTransform(2.4249,-7.8033,0.0546,0.0546);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1D1D1C").s().p("EAAAAnvQAAgcABgtQADgyAEgSQAFgYANgZQAOgaASgRQG/mxBcheQFalgBrkOQA5iRAAiEQAAifg5itQh0lgmQnVQjWj8kWkGQgggdgLgoQgOAxg3ApMggKAZCMAAAg13MAgKAZEQA2AoAPAxQAOgxA2goMAgKgZDIgBBAQAAAagCAjQgDAugEAWQgFAYgNAZQgOAZgSATQndHSg+BAQlaFihsESQg5CUAACEQAACdA5CvQB0FfGRHWQDWD7EVEHQAxAvAAA0QAAAmgaAkQgSAZgdAWMggJAZDgAKhiAQEpF6BiEoQA6CyAACgQAACHg7CUQhrERleFkQhSBUnHG5QgnAmgKA6QgDAPgCAuIgCBCIAAAaIfs4sQAYgRAQgWQAaghAAgiQAAgsgrgqIhsheI8Q1/QEwEqDZEVgEgg9AMjIfs4rQBBgyAAg4QAAg3hBgzI/s4rgAeoK2QkukpjWkTQkll2hgklQg7ivAAiiQAAiIA7iWQBskUFelnQBIhKHRnHQAngmAKg7QAHgpAAhIIAAgaI/tYsQgsAhgQApQgEAMgBAQQAAATAFAPQAMAfAaAYQAPAOBXBKIcLV7IAAAAg");
	this.shape_4.setTransform(-1.4443,-5.8627,0.0546,0.0546);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(0,0,0,0)","rgba(247,247,247,0)","#F7F7F7","#ECEBEC","#DCDBDB","#C7C7C6","#ABAAAB","#888888","#5D5D5D","#242424","#1D1D1C"],[0,0.682,0.682,0.729,0.773,0.812,0.851,0.882,0.914,0.945,0.961],0,155.7,0,-155.6).s().p("AhmRDQGunBB7lOQA8ikAAiQQAAiPg8ikQh7lOmunBQjXjgkdjyQEyDvDsDjQHSHBCFFOQBACiAACRQAACShACiQiFFOnSHBQjsDjkyDvQEdjyDXjgg");
	this.shape_5.setTransform(-9.6338,-10.7468,0.0542,0.0542);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#1D1D1C","#343433","#676766","#909090","#B1B0B0","#CACACA","#DEDEDE","#EDEDED","#F7F7F7","#FDFDFD","#FFFFFF","#FEFEFE","#F7F7F7","rgba(247,247,247,0)","rgba(0,0,0,0)"],[0.039,0.051,0.082,0.118,0.157,0.196,0.239,0.286,0.337,0.4,0.506,0.62,0.682,0.682,1],0,155.7,0,-155.6).s().p("AhmRDQGunBB7lOQA8ikAAiQQAAiPg8ikQh7lOmunBQjXjgkdjyQEyDvDsDjQHSHBCFFOQBACiAACRQAACShACiQiFFOnSHBQjsDjkyDvQEdjyDXjgg");
	this.shape_6.setTransform(-9.6338,-10.7468,0.0542,0.0542);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("Ah5RDQHSnBCFlOQBAiiAAiSQAAiRhAiiQiFlOnSnBQjsjjkyjvQDWCRC5CVQEPDaDRDXQHAHNAAFwQAAFxnAHMQjPDVkRDdQhuBYhrBOQhMA3hqBJQEyjvDsjjg");
	this.shape_7.setTransform(-9.1641,-10.6863,0.0546,0.0546);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AqBXxQDoi0E7k3QG8m4Brj6QBBiYAAh7QAAidg1iaQh3lTmdnMQjXjwkKjtQB+BjDhDRQC0CjDpEUQDEDmBlC2QB/DoAADEQAAC2h7DGQhoCnjJDBQhzBuk+ELQlDEOhnBHg");
	this.shape_8.setTransform(2.3652,-1.3872,0.0546,0.0546);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(0,0,0,0)","rgba(233,233,233,0)","#E9E9E9","#D8D8D8","#C0C0C0","#A1A1A1","#7A7A79","#494848","#1D1D1C"],[0,0.694,0.694,0.745,0.792,0.843,0.886,0.933,0.961],0,152.2,0,-152.2).s().p("Ao0XeQHHm5BThUQFclkBskQQA7iUAAiHQAAifg7iyQhhkokpl7QjYkVkwkqQEKDuDXDvQGdHMB3FTQA1CbAACcQAAB7hBCYQhrD7m8G3Qk7E3joC0QALgOAGgGg");
	this.shape_9.setTransform(1.8255,-1.5143,0.0542,0.0542);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#706F6F","#7C7C7C","#9E9E9D","#BABABA","#D0D0D0","#E2E2E2","#EFEFEF","#F8F8F8","#FEFEFE","#FFFFFF","#FDFDFD","#F6F6F6","#E9E9E9","rgba(233,233,233,0)","rgba(0,0,0,0)"],[0.039,0.051,0.078,0.11,0.145,0.184,0.227,0.278,0.349,0.506,0.58,0.639,0.694,0.694,1],0,152.2,0,-152.2).s().p("Ao0XeQHHm5BThUQFclkBskQQA7iUAAiHQAAifg7iyQhhkokpl7QjYkVkwkqQEKDuDXDvQGdHMB3FTQA1CbAACcQAAB7hBCYQhrD7m8G3Qk7E3joC0QALgOAGgGg");
	this.shape_10.setTransform(1.8255,-1.5143,0.0542,0.0542);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(0,0,0,0)","rgba(248,248,248,0)","#F8F8F8","#EEEEEE","#DFDFDF","#CCCCCC","#B4B4B4","#9D9D9C"],[0,0.722,0.722,0.784,0.835,0.886,0.929,0.961],0,152.3,0,-152.2).s().p("AgEQZQmWnFh2lRQg2ibAAicQABh7BAiaQBrj9G+m8QE4k4Dri4QgKAOgIAHQnRHHhJBKQlcFnhtETQg6CXAACHQAAChA6CwQBhEkEjF2QDWEUEsEoQkFjqjXjwg");
	this.shape_11.setTransform(6.4241,-10.4593,0.0542,0.0542);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#1D1D1C","#515150","#7B7B7A","#9E9E9D","#BABABA","#D0D0D0","#E2E2E2","#EFEFEF","#F8F8F8","#FEFEFE","#FFFFFF","#FDFDFD","#F8F8F8","rgba(248,248,248,0)","rgba(0,0,0,0)"],[0.039,0.063,0.086,0.114,0.141,0.173,0.208,0.251,0.298,0.361,0.506,0.643,0.722,0.722,1],0,152.3,0,-152.2).s().p("AgEQZQmWnFh2lRQg2ibAAicQABh7BAiaQBrj9G+m8QE4k4Dri4QgKAOgIAHQnRHHhJBKQlcFnhtETQg6CXAACHQAAChA6CwQBhEkEjF2QDWEUEsEoQkFjqjXjwg");
	this.shape_12.setTransform(6.4241,-10.4593,0.0542,0.0542);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D1D1C").s().p("AF7V0QhAg4h6hxQi0iljokTQjFjmhki2Qh/joAAjDQAAi3B7jIQBoiqDKjCQBxhuFAkOQFCkRBnhIIgBADQjrC3k4E4Qm9G8hrD9QhBCaAAB7QAACcA2CbQB2FTGYHHQDYDwEEDoQhHg3hVhKg");
	this.shape_13.setTransform(6.3357,-10.3983,0.0546,0.0546);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#E2E1E1","#DEDEDE","#D3D3D3","#C6C6C6","#C9C9C9","#F0F0F0","#FFFFFF","#FBFBFB","#EFEFEF","#DBDBDB","#BEBEBE","#969695","#616160","#1D1D1C"],[0.039,0.106,0.188,0.251,0.263,0.424,0.506,0.549,0.604,0.671,0.737,0.812,0.89,0.961],0,-163.1,0,163.2).s().p("AuFDjQhXhJgPgOQgagZgMgeQgFgPAAgTQABgRAEgLQAQgpAsghIfs4sIAAAaQAABJgHApQgKA7gnAmQnRHHhIBKQleFnhrETQg7CXAACGQAACiA7CwQBfElElF3QDWETEuEpg");
	this.shape_14.setTransform(4.3373,-10.9811,0.0546,0.0546);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#A8A8A7","#1D1D1C","#1D1D1C"],[0,0.212,0.808],-4.1,-45.8,3.8,44.7).s().p("Ap5H5QgDgDA+g5QBbhUBDhGQEBkPCIkmQA0hzAigiQAtgvBbgJQEJgYB1gBQAZgBALAFQAMAEAEAMQAFAUgmAbQiKBij+DIQhJA5ngF+QkQDNgPAAIgBAAg");
	this.shape_15.setTransform(6.1789,1.848,0.0546,0.0546);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#838382","#848383","#C9C9C9","#F0F0F0","#FFFFFF","#FCFCFC","#F1F1F1","#E0DFDF","#C6C6C6","#A3A3A3","#9D9D9C"],[0.043,0.043,0.271,0.427,0.506,0.576,0.659,0.749,0.847,0.945,0.961],0,-163.6,0,163.7).s().p("AwVYtIAEhVIACgPQALg5AmgkQHHm5BShUQFelkBqkRQA7iUABiGQAAigg7iyQhhkokpl7QjZkVkwkqIcPWAIBsBeQArAqAAAsQAAAigaAgQgQAWgYARI/rYsg");
	this.shape_16.setTransform(4.3634,-0.7689,0.0546,0.0546);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("EBLNAG+QhMhMAAieICYAAQABBaAlApQAmAsBWAAQBSAAAlgkQAigiAAhIQAAhLgcgoQgcgnhGgVIhcgcQh8gmg1hBQg4hEAAh8QAAh6BHhHQBMhMCKAAQCZAABKBFQBKBHAACWIiYAAQgChSgggjQgiglhOAAQhEAAghAfQghAeAABAQAABHAeAjQAdAhBMAYIBXAbQB+AmAzBFQA0BGAACGQAACGhPBKQhQBLiUAAQihAAhNhNgATiG0QhXhWAAiaIAAmCQAAicBXhYQBXhYCaAAQCbAABXBYQBWBYAACcIAAGCQAACahWBWQhXBXibAAQiaAAhXhXgAVRlPQgtAwAABbIAAGJQAABbAtAwQAtAwBVAAQBWAAAtgwQAtgwAAhbIAAmJQAAhbgtgwQgtgwhWAAQhVAAgtAwgAq+G0QhXhWAAiaIAAmCQAAicBXhYQBWhYCbAAQCaAABXBYQBXBYAACcIAAGCQAACahXBWQhXBXiaAAQibAAhWhXgApQlPQgtAwAABbIAAGJQAABbAtAwQAuAwBVAAQBVAAAtgwQAtgwAAhbIAAmJQAAhbgtgwQgtgwhVAAQhVAAguAwgEgkgAG5QhPhSAAiaIAArJICZAAIAALUQAABZApApQAmAmBQAAQBQAAAmgmQAogoAAhaIAArUICZAAIAALJQAACahPBSQhPBSiZAAQiZAAhQhSgEhFwAG+QhMhMAAieICYAAQABBaAlApQAmAsBWAAQBRAAAlgkQAigiAAhIQAAhLgcgoQgcgnhFgVIhcgcQh8gmg1hBQg4hEAAh8QAAh6BHhHQBLhMCKAAQCaAABJBFQBLBHAACWIiZAAQgChSgggjQghglhPAAQhEAAggAfQghAeAABAQAABHAeAjQAdAhBLAYIBXAbQB+AmAzBFQA0BGAACGQAACGhPBKQhQBLiTAAQiiAAhMhNgEA/OAH8IAAv4IH+AAIAACMIllAAIAAEgIE9AAIAACIIk9AAIAAE6IF1AAIAACKgEA0TAH8IAAv4ICZAAIAANuIFZAAIAACKgEAthAH8IAAv4ICZAAIAAP4gEAgYAH8IAAv4IE8AAQB/AABDBEQBDBDAACAQAABVgbA7QgeA/g7AbQBHAWAkA+QAjA9AABgQAACHhHBIQhHBHiHAAgEAiwAF4ICjAAQBBAAAigmQAigmAAhLQAAhRghgsQghgsg/AAIinAAgEAiwgBLICgAAQA5AAAegnQAegmAAhIQAAhIghgoQgggng6AAIiaAAgAL+H8IAAsEIi5HqIiDAAIi6nrIAAMFIiRAAIAAv4IC7AAIDVJAIDUpAICzAAIAAP4gA1FH8IAAtuIj5AAIAAiKIKMAAIAACKIj6AAIAANugEgrTAH8IhBkXIkeAAIhBEXIiWAAID5v4IDfAAID8P4gEgszABfIhvnaIhxHaIDgAAgEhTtAH8IAAv4IEiAAQCbAABXBXQBXBWAACaIAAFvQAACYhXBVQhXBVibAAgEhRXAF0ICKAAQBWAAAugwQAugwAAhbIAAlxQAAhbgugwQgugwhWAAIiKAAg");
	this.shape_17.setTransform(-0.1226,17.0293,0.0572,0.0572);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.7,-20.1,61.2,40.1);


(lib.img2Guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Guide, new cjs.Rectangle(0,0,600,600), null);


(lib.img2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5_copy_copy
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","#000000"],[0.549,0.922],4.7,106,4.7,-100.7).s().p("Eg+zAQKMAAAggTMB9nAAAMAAAAgTg");
	this.shape.setTransform(198,103.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_5_copy
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0)","#000000"],[0.306,0.961],-7.7,-142.5,-7.7,99.5).s().p("Eg+zAPtIAA/ZMB9nAAAIAAfZg");
	this.shape_1.setTransform(198,499.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_1
	this.instance = new lib.img2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2_1, new cjs.Rectangle(-204,0,804,600), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_1, new cjs.Rectangle(0,0,300,600), null);


(lib.Interpoler62copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-47.9,0,48,0).s().p("AnfNUINC6xIB8AAIuIa7g");
	this.shape.setTransform(-195.3915,-358.7566,1.6719,1.6719);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-7.6,0,7.6,0).s().p("AA5GFIiEsJIAqAWIBtLxIgSACg");
	this.shape_1.setTransform(-420.3821,-86.4524,1.6719,1.6719);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-5.2,0,5.2,0).s().p("AAKCsIg9ljIA1AXIAyFYg");
	this.shape_2.setTransform(-437.1843,-194.7889,1.6719,1.6719);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-12.2,0,12.3,0).s().p("ABkDTIjemnIAoAKIDNGfg");
	this.shape_3.setTransform(-448.3021,-56.5261,1.6719,1.6719);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-6.7,0,6.7,0).s().p("AAcBdIhei1IAtgEIBYC5g");
	this.shape_4.setTransform(-489.806,-138.4473,1.6719,1.6719);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-7.6,0,7.6,0).s().p("AhLgsIAJgcICOCRIgfAAg");
	this.shape_5.setTransform(-468.6152,-33.5381,1.6719,1.6719);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-3.4,0,3.4,0).s().p("AghgLIAGgiIA9A+IgHAeg");
	this.shape_6.setTransform(-494.6126,-57.9054,1.6719,1.6719);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-15.8,0,15.9,0).s().p("AidiCIAZgkIEiEqIgLAjg");
	this.shape_7.setTransform(-533.7342,-96.0656,1.6719,1.6719);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-3.3,0,3.4,0).s().p("AgggJIAWgLIArAWIgCATg");
	this.shape_8.setTransform(-456.4106,9.0944,1.6719,1.6719);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-6.4,0,6.5,0).s().p("AhAgRIAegRIBjAzIgWASg");
	this.shape_9.setTransform(-507.9039,-17.739,1.6719,1.6719);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiZgMIAsgTIEBArIAGATg");
	this.shape_10.setTransform(-479.6913,23.347,1.6719,1.6719);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhQACICVgWIAMARIiOAYg");
	this.shape_11.setTransform(-468.1972,47.6725,1.6719,1.6719);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag7ASIBngyIAQAMIhnA1g");
	this.shape_12.setTransform(-459.1274,66.8571,1.6719,1.6719);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-7.3,0,7.4).s().p("AiBAcIDOhlIA2AQIj7CDg");
	this.shape_13.setTransform(-591.0371,136.1557,1.6719,1.6719);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgxAZIBQhOIATAHIhhBkg");
	this.shape_14.setTransform(-447.1318,84.9968,1.6719,1.6719);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-39.8,0,39.9).s().p("AmNFNILprWIAWgBQAUgCAHgCIsEMdg");
	this.shape_15.setTransform(-571.6436,211.8074,1.6719,1.6719);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-66.7,0,66.7).s().p("AlnKbIK701IAVAAIqQU1g");
	this.shape_16.setTransform(-484.874,198.5161,1.6719,1.6719);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-43.1,0,43.2).s().p("AA/moIAUgHIhyMWIgzBJg");
	this.shape_17.setTransform(-421.9703,164.1594,1.6719,1.6719);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-4.6,0,4.7,0).s().p("AgujhIAQgMIBNHCIgaAZg");
	this.shape_18.setTransform(-385.7746,131.4745,1.6719,1.6719);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-10.9,0,11,0).s().p("AApCfIiVkvIAeghIC7Fjg");
	this.shape_19.setTransform(-286.4661,258.3686,1.6719,1.6719);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-14.8,0,14.8,0).s().p("AiTj+IAMgRIEbIcIgkADg");
	this.shape_20.setTransform(-351.794,131.5163,1.6719,1.6719);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-12.7,0,12.7,0).s().p("Ah+h0IBOgLICvCpIgPBWg");
	this.shape_21.setTransform(-143.8147,300.0815,1.6719,1.6719);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-17.4,0,17.5,0).s().p("Aith6IAAg4IFbFRIg2AUg");
	this.shape_22.setTransform(-227.4076,207.3769,1.6719,1.6719);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-22,0,22.1,0).s().p("AjcjMIAHgTIGxGnIgVAYg");
	this.shape_23.setTransform(-324.9607,113.2512,1.6719,1.6719);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-252.4,0,252.4,0).s().p("EgnbgUSIAAgUMBNxAmPIBGC/g");
	this.shape_24.setTransform(71.0611,282.2344,1.6719,1.6719);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-227.4,0,227.5,0).s().p("EgjcgF0IgGgTMBGGAKmIA/Bpg");
	this.shape_25.setTransform(34.4892,110.6598,1.6719,1.6719);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-234,0,234.1,0).s().p("EgkkAGDMBJJgMWIhBBtMhH8AK6g");
	this.shape_26.setTransform(45.1473,-36.8818,1.6719,1.6719);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-176,0,176.1,0).s().p("A7gOUMA3BgczIgtB2Mg2DAbJg");
	this.shape_27.setTransform(-57.4213,-141.6238,1.6719,1.6719);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-71.1,0,71.1,0).s().p("ArGLZIV+3GIAPByI04Vpg");
	this.shape_28.setTransform(0.1743,-374.8064,1.6719,1.6719);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-39.1,0,39.2,0).s().p("AmGF2ILrsEIAjBBIrvLcg");
	this.shape_29.setTransform(-191.3791,-172.7204,1.6719,1.6719);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AkwEmIJEpRIAdAYIpNI/g");
	this.shape_30.setTransform(-311.2096,-51.3852,1.6719,1.6719);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAEgnIAngPIg0BlIghAHg");
	this.shape_31.setTransform(-348.0323,-64.0077,1.6719,1.6719);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgwBKIBDiJIAegKIhMCTg");
	this.shape_32.setTransform(-368.1365,-24.4264,1.6719,1.6719);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgDgmIATgFIgNBMIgSALg");
	this.shape_33.setTransform(-391.1663,-17.0285,1.6719,1.6719);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-3,0,3,0).s().p("AgdhyIAwAmIALCiIglAdg");
	this.shape_34.setTransform(-418.1668,-188.0179,1.6719,1.6719);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-11.1,0,11.1,0).s().p("ABTGUIjBrsIAkg+IC5Mtg");
	this.shape_35.setTransform(-447.1736,-160.5158,1.6719,1.6719);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-8,0,8.1,0).s().p("AhQiFIAYgnICJFYIgcABg");
	this.shape_36.setTransform(-462.1368,-115.2084,1.6719,1.6719);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-3.9,0,4,0).s().p("AgngfIAag2IA1CEIgbAog");
	this.shape_37.setTransform(-483.8709,-165.9911,1.6719,1.6719);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-4.7,0,4.8,0).s().p("AgugoIAWgUIBHB3IgdACg");
	this.shape_38.setTransform(-474.0488,-85.1567,1.6719,1.6719);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-8,0,8.1,0).s().p("AhPhoIAtgFIBzC/IgYAcg");
	this.shape_39.setTransform(-505.9395,-133.2227,1.6719,1.6719);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-4.5,0,4.5,0).s().p("AALAkIg3g+IAegJIA7BHg");
	this.shape_40.setTransform(-489.4717,-68.4799,1.6719,1.6719);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-14.5,0,14.6,0).s().p("AiRicIA3gDIDsEcIgLAjg");
	this.shape_41.setTransform(-527.3811,-108.521,1.6719,1.6719);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-13.9,0,13.9,0).s().p("ABKBrIjPirIgFg5IEVDzg");
	this.shape_42.setTransform(-539.5857,-86.0345,1.6719,1.6719);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-12.4,0,12.4).s().p("Ai1BEIFBi/IArAOIltDpg");
	this.shape_43.setTransform(-581.5493,150.6591,1.6719,1.6719);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-30.1,0,30.2).s().p("AlRDlIJ7oRIAoAHIqhJSg");
	this.shape_44.setTransform(-579.2505,193.5841,1.6719,1.6719);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-42.3,0,42.3).s().p("Al+GcILZtCIAjACIq2NLg");
	this.shape_45.setTransform(-555.5937,217.0319,1.6719,1.6719);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-50.1,0,50.2).s().p("AEzn1IASAWIowO4IhZAdg");
	this.shape_46.setTransform(-523.7448,233.0818,1.6719,1.6719);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-46.2,0,46.2).s().p("AjNHAIGFuNIAWATIlkOIg");
	this.shape_47.setTransform(-484.874,236.3419,1.6719,1.6719);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-32.7,0,32.8).s().p("ABHlGIAXAPIh5IoIhCBWg");
	this.shape_48.setTransform(-446.2123,220.6682,1.6719,1.6719);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-14.7,0,14.8).s().p("AABiTIAZAMIgPECIgkAYg");
	this.shape_49.setTransform(-413.9454,194.2946,1.6719,1.6719);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-10.1,0,10.1).s().p("AgUhkIAaAHIAPCiIgbAgg");
	this.shape_50.setTransform(-389.5362,187.022,1.6719,1.6719);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-7,0,7.1,0).s().p("AAPB5IhVjTIAdgnIBwECg");
	this.shape_51.setTransform(-304.6058,265.5994,1.6719,1.6719);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-4.1,0,4.2,0).s().p("AgohIIAbgBIA2B9IgYAWg");
	this.shape_52.setTransform(-345.4409,173.5218,1.6719,1.6719);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-9.4,0,9.5,0).s().p("AhdiTIA3AKICFDQIgMBOg");
	this.shape_53.setTransform(-275.2228,248.3793,1.6719,1.6719);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-4.7,0,4.8,0).s().p("AgJAqIgmg/IATgmIBMB3g");
	this.shape_54.setTransform(-296.7062,204.3258,1.6719,1.6719);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-4.4,0,4.4,0).s().p("Agrg1IAbgFIA8BdIgUAZg");
	this.shape_55.setTransform(-326.2146,161.2754,1.6719,1.6719);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-15.1,0,15.1,0).s().p("AiWh2IA/gUIDuENIhYAIg");
	this.shape_56.setTransform(-164.7965,311.7428,1.6719,1.6719);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-7.1,0,7.1,0).s().p("AhGhFIAlgJIBoB1IgSAog");
	this.shape_57.setTransform(-276.226,185.9771,1.6719,1.6719);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-6.3,0,6.4,0).s().p("Ag/gzIAagKIBlBxIggAKg");
	this.shape_58.setTransform(-305.7343,149.1126,1.6719,1.6719);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-51.5,0,51.6,0).s().p("AoDm3IAYgOIPvM9IgKBOg");
	this.shape_59.setTransform(-215.0777,199.5192,1.6719,1.6719);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-132.3,0.1,132.4,0.1).s().p("A0rsEIAWgSMApAAYUIiAAZg");
	this.shape_60.setTransform(-67.4107,238.6825,1.6719,1.6719);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-241.8,0,241.8,0).s().p("EglxgPKIASgUMBLRAeQIiZAtg");
	this.shape_61.setTransform(125.4801,253.3113,1.6719,1.6719);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-272.1,0,272.2,0).s().p("EgqhgKYIAQgYMBTSATKIBhCXg");
	this.shape_62.setTransform(183.0757,182.508,1.6719,1.6719);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-258.8,0,258.9,0).s().p("EgocgC9IAMgZMBP7AFQQgCABAZAuIAbAug");
	this.shape_63.setTransform(164.6017,82.4472,1.6719,1.6719);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-638.1,-502.8,1276.2,1005.7);


(lib.Interpoler60copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-142.4,0,142.5,0).s().p("A2ICEMAsZgEiIgtBsMgr0ADRg");
	this.shape.setTransform(-184.1348,-90.24,1.6719,1.6719);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-259.5,0,259.6,0).s().p("EgogAJ5MBPngUNIBdBeMhRHATLg");
	this.shape_1.setTransform(8.8814,-194.8566,1.6719,1.6719);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-206.2,0,206.2,0).s().p("EggNANzMBAbgcBIhACbMg/aAaCg");
	this.shape_2.setTransform(-86.5818,-256.59,1.6719,1.6719);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-333.9,0,333.9,0).s().p("Eg0KAgqMBoVhBvIgJCwMhoGA/bg");
	this.shape_3.setTransform(117.1343,-477.1919,1.6719,1.6719);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-150.2,0,150.3,0).s().p("A3dTEMAucgmIIAgB4MgtLAkRg");
	this.shape_4.setTransform(33.3323,-556.1037,1.6719,1.6719);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-13.7,0,13.8,0).s().p("AiJAZICjiOIBwAJIkPDig");
	this.shape_5.setTransform(-239.0136,-318.7832,1.6719,1.6719);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-23.6,0,23.7,0).s().p("AjsC4IHZmjIgRBgInCF3g");
	this.shape_6.setTransform(-339.6178,-241.2507,1.6719,1.6719);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AifBsIEQjxIAvAKIk1EBg");
	this.shape_7.setTransform(-426.9725,-162.6733,1.6719,1.6719);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-28.4,0,28.4,0).s().p("AkbDxIHRo1IBmAiIoaJng");
	this.shape_8.setTransform(-241.396,-418.1335,1.6719,1.6719);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-33.7,0,33.8,0).s().p("AlMFLIJUrWIBJAVIqiMCg");
	this.shape_9.setTransform(-361.2266,-277.4047,1.6719,1.6719);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ah8CMID5kvIAAA6IjrENg");
	this.shape_10.setTransform(-447.9125,-182.7356,1.6719,1.6719);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-66.3,0,66.4,0).s().p("AqXP8MATtggxIBCBjMgUUAgIg");
	this.shape_11.setTransform(-299.3678,-470.6716,1.6719,1.6719);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-10,0,10.1,0).s().p("AhkBxICnkdIAiAnIjAEyg");
	this.shape_12.setTransform(-432.4896,-252.7447,1.6719,1.6719);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-36.3,0,36.4,0).s().p("AEes4IBOBQIqaYTIg9AOg");
	this.shape_13.setTransform(-393.9533,-446.2625,1.6719,1.6719);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgOgXIANgIIAQA0IgLALg");
	this.shape_14.setTransform(-563.3544,-87.0634,1.6719,1.6719);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-18.5,0,18.5,0).s().p("AClIhIldwHIAdg+IFURHIgTACg");
	this.shape_15.setTransform(-602.6013,-205.7655,1.6719,1.6719);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWgQIAJgOIAkAzIgLAKg");
	this.shape_16.setTransform(-570.836,-81.1283,1.6719,1.6719);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-14.2,0,14.3,0).s().p("ABzC8IkBlZIAQggIENF7g");
	this.shape_17.setTransform(-619.1528,-147.3758,1.6719,1.6719);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-10.4,0,10.5,0).s().p("Ahoh7IAlgWICsDzIgIAwg");
	this.shape_18.setTransform(-671.3566,-214.5845,1.6719,1.6719);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ah0hEIAIgUIDhCnIgKAKg");
	this.shape_19.setTransform(-592.1522,-85.6424,1.6719,1.6719);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-7,0,7.1,0).s().p("AhFglIAagPIBxBUIgMAVg");
	this.shape_20.setTransform(-642.0572,-119.4975,1.6719,1.6719);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-8.2,0,8.3,0).s().p("AhSgUIAGguICfB2IgqAPg");
	this.shape_21.setTransform(-709.0988,-171.2416,1.6719,1.6719);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhJgKIgOgYICvA6IgLALg");
	this.shape_22.setTransform(-592.8628,-71.0972,1.6719,1.6719);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AjcgMIGrAFIAOAOImoAGg");
	this.shape_23.setTransform(-623.834,-56.8028,1.6719,1.6719);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AiLAfIEMhSIALALIkTBdg");
	this.shape_24.setTransform(-602.8103,-40.7947,1.6719,1.6719);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ah7BNIDtinIAKAKIjoCsg");
	this.shape_25.setTransform(-594.5346,-28.1722,1.6719,1.6719);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-19.1,0,19.2).s().p("AjnB3IG1k1IAqANInuFwg");
	this.shape_26.setTransform(-730.206,73.7277,1.6719,1.6719);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AiYCzIEomOIAJAKIkwGug");
	this.shape_27.setTransform(-594.4092,-1.1716,1.6719,1.6719);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-44.9,0,44.9).s().p("AlLGIIJxtIIAmAAIp3OBg");
	this.shape_28.setTransform(-691.7951,134.0818,1.6719,1.6719);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-73,0,73).s().p("ADyrZIAKALIm2WGIhCAig");
	this.shape_29.setTransform(-605.0673,90.0283,1.6719,1.6719);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],0,-42.4,0,42.5).s().p("AgHmZIAPgPIAKM9IgjAUg");
	this.shape_30.setTransform(-555.5803,46.7271,1.6719,1.6719);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-11.9,0,12,0).s().p("ABRE+IjHqCIALgLIDiKfg");
	this.shape_31.setTransform(-528.3708,24.4078,1.6719,1.6719);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-16.2,0.1,16.2,0.1).s().p("ABACXIjhk+IBXAVIDsE6g");
	this.shape_32.setTransform(-351.8224,222.8576,1.6719,1.6719);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-7.3,0,7.3,0).s().p("AhIhEIAPgpICCCvIgTAsg");
	this.shape_33.setTransform(-438.7173,104.6989,1.6719,1.6719);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-24.3,0,24.4,0).s().p("Ajzk5IALgJIHcJ/IglAGg");
	this.shape_34.setTransform(-501.4956,16.6755,1.6719,1.6719);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-365.9,0,365.9,0).s().p("Eg5KgoqIAKgKMByLBQNIjpBcg");
	this.shape_35.setTransform(75.0034,394.3904,1.6719,1.6719);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-389.5,0,389.5,0).s().p("Eg82gTyIALgLMB5iAlfIipCcg");
	this.shape_36.setTransform(120.4362,165.2202,1.6719,1.6719);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-269.9,0,270,0).s().p("Egp8AAJIgPgOMBTBgApIBWBdg");
	this.shape_37.setTransform(-71.7859,-55.8832,1.6719,1.6719);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-149.9,0,150,0).s().p("A3aHqMAu2gPdIgFBGMgumAOhg");
	this.shape_38.setTransform(-279.8906,-146.6234,1.6719,1.6719);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-49.8,0,49.8,0).s().p("AnNE8IO/rTIAABvIvjLAg");
	this.shape_39.setTransform(-242.0648,-285.346,1.6719,1.6719);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AoDFgIOpq6IBegPIv+LTg");
	this.shape_40.setTransform(-449.7934,-129.5287,1.6719,1.6719);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-26.4,0,26.4,0).s().p("AkHEpIHLqQIBEBQIncJ/g");
	this.shape_41.setTransform(-264.4259,-456.0847,1.6719,1.6719);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-23.2,0,23.3,0).s().p("AjnEgIGvpoIAhBMImyJFg");
	this.shape_42.setTransform(-364.2359,-319.5773,1.6719,1.6719);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-10.2,0,10.3,0).s().p("AhmBpIC0j+IAYArIi9EAg");
	this.shape_43.setTransform(-427.4322,-230.1746,1.6719,1.6719);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AjuFBIHMqLIASAgInUJ1g");
	this.shape_44.setTransform(-501.2448,-129.7794,1.6719,1.6719);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgtBrIBDjZIAYgIIhQDtg");
	this.shape_45.setTransform(-539.4886,-100.2711,1.6719,1.6719);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#FFFFFF","#A8C1DF","#1D1D1C"],[0,1,1],-1.3,0,1.3,0).s().p("AgMiLIAZgPIgDEjIgSASg");
	this.shape_46.setTransform(-554.4518,-143.2379,1.6719,1.6719);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgHgaIAPgHIAAA0IgPAPg");
	this.shape_47.setTransform(-553.3651,-94.9212,1.6719,1.6719);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AiAgDICEh9IB9CEIiEB9g");
	this.shape_48.setTransform(-555.0369,-56.2176,1.6719,1.6719);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-771.6,-831.2,1543.3000000000002,1662.5);


(lib.Interpoler15copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Egz9AAAMAz9gz9MAz+Az9Mgz+Az+g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-332.5,-332.5,665.1,665.1);


(lib.ctaBtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYA9QgMgEgHgKQgHgLAAgNIAQgCQABAKAEAHQAEAGAJAEQAJADAKAAQAKAAAHgCQAIgEADgFQAEgFAAgFQAAgGgEgFQgDgEgIgDIgWgHQgSgEgHgDQgJgFgFgHQgEgHAAgJQAAgKAFgIQAGgJAKgEQALgEANgBQANABALAEQALAFAGAIQAGAKABALIgRABQgBgMgIgGQgHgHgPABQgPAAgHAFQgHAGAAAIQAAAHAFAEQAFAEAUAFQAVAFAHADQAMAFAFAIQAFAHAAALQAAAKgFAKQgGAJgLAEQgLAGgOgBQgRABgLgGg");
	this.shape.setTransform(183.325,24.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AApBBIgPgoIg1AAIgOAoIgTAAIAyiBIASAAIA1CBgAAUAMIgNgjIgIgbQgCAMgFANIgOAlIAqAAg");
	this.shape_1.setTransform(171.4,24.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgIBBIAAhxIgqAAIAAgQIBlAAIAAAQIgrAAIAABxg");
	this.shape_2.setTransform(159.975,24.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAkBBIgSgbIgMgSIgHgIIgIgEIgKgBIgUAAIAAA6IgRAAIAAiBIA5AAQARAAAJAEQAJAEAFAIQAFAJAAALQAAAOgIAJQgJAJgTACQAHADADAEQAIAGAHALIAWAjgAgngGIAlAAQALgBAGgCQAHgCADgFQAEgGAAgGQAAgJgHgGQgGgGgPAAIgoAAg");
	this.shape_3.setTransform(148.575,24.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgvBBIAAiBIBcAAIAAAQIhLAAIAAAoIBGAAIAAANIhGAAIAAAsIBOAAIAAAQg");
	this.shape_4.setTransform(135.725,24.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBBIAAiBIBVAAIAAAQIhEAAIAAAoIA7AAIAAAOIg7AAIAAA7g");
	this.shape_5.setTransform(124.375,24.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfA6QgPgJgHgPQgIgPAAgRQAAgfASgTQARgRAagBQASAAAOAJQAPAIAHAQQAIAPAAATQAAATgIAQQgIAPgPAIQgOAHgRAAQgRAAgOgIgAgegnQgNANAAAcQAAAYANANQAMANASAAQATAAANgNQAMgOAAgZQAAgPgFgLQgGgMgKgGQgKgHgNAAQgRAAgNAMg");
	this.shape_6.setTransform(111.575,24.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAkBBIgSgbIgMgSIgHgIIgIgEIgKgBIgUAAIAAA6IgRAAIAAiBIA5AAQARAAAJAEQAJAEAFAIQAFAJAAALQAAAOgIAJQgJAJgTACQAHADADAEQAIAGAHALIAWAjgAgngGIAlAAQALgBAGgCQAHgCADgFQAEgGAAgGQAAgJgHgGQgGgGgPAAIgoAAg");
	this.shape_7.setTransform(93.675,24.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgvBBIAAiBIBcAAIAAAQIhLAAIAAAoIBGAAIAAANIhGAAIAAAsIBOAAIAAAQg");
	this.shape_8.setTransform(80.825,24.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIBBIgyiBIASAAIAiBeIAGAUIAHgUIAjheIARAAIgzCBg");
	this.shape_9.setTransform(68.575,24.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(0.1,2,1).p("Azrj5MAnXAAAIAAHzMgnXAAAg");
	this.shape_10.setTransform(126,25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AzrD6IAAnzMAnXAAAIAAHzg");
	this.shape_11.setTransform(126,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaBtn, new cjs.Rectangle(-1,-1,254,52), null);


(lib.frameMc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// line6
	this.line6 = new lib.line();
	this.line6.name = "line6";
	this.line6.setTransform(260,555,1.3829,1,180);

	this.timeline.addTween(cjs.Tween.get(this.line6).wait(1));

	// line5
	this.line5 = new lib.line();
	this.line5.name = "line5";
	this.line5.setTransform(0,556,1.3829,1);

	this.timeline.addTween(cjs.Tween.get(this.line5).wait(1));

	// line4
	this.line4 = new lib.line();
	this.line4.name = "line4";
	this.line4.setTransform(259,0,5.9148,1,90);

	this.timeline.addTween(cjs.Tween.get(this.line4).wait(1));

	// line3
	this.line3 = new lib.line();
	this.line3.name = "line3";
	this.line3.setTransform(0,0,5.9148,1,90);

	this.timeline.addTween(cjs.Tween.get(this.line3).wait(1));

	// line2
	this.line2 = new lib.line();
	this.line2.name = "line2";
	this.line2.setTransform(189,1,0.7447,1);

	this.timeline.addTween(cjs.Tween.get(this.line2).wait(1));

	// line1
	this.line1 = new lib.line();
	this.line1.name = "line1";
	this.line1.setTransform(70,0,0.7447,1,180);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,260,556);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ctaBtn();
	this.instance.setTransform(126,25,1,1,0,0,0,126,25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,252.1,50.1), null);


(lib.allEurope = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// euro1
	this.euro1 = new lib.Interpoler60copy();
	this.euro1.name = "euro1";
	this.euro1.setTransform(55.35,184.9,0.2245,0.2245,-0.0545,0,0,-549.1,-47.8);

	this.timeline.addTween(cjs.Tween.get(this.euro1).wait(1));

	// euro2
	this.euro2 = new lib.Interpoler62copy();
	this.euro2.name = "euro2";
	this.euro2.setTransform(55.25,184.9,0.2175,0.2175,0,0,0,-408.4,67.1);

	this.timeline.addTween(cjs.Tween.get(this.euro2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.allEurope, new cjs.Rectangle(5.3,8.8,346.7,373.5), null);


(lib.europa = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// euroSquare
	this.euroSquare = new lib.Interpoler15copy();
	this.euroSquare.name = "euroSquare";
	this.euroSquare.setTransform(124.25,519.65,0.0107,0.0107,0,0,0,0,-23.4);
	this.euroSquare.alpha = 0.3008;

	this.timeline.addTween(cjs.Tween.get(this.euroSquare).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ASbWRQgPhKiljNQiljOg9gqIgrgNQrjAAibgIQibgIhoBrIiwCzIpEn+InMFyMAAAgrRMAzPAAUMAAAA0fIm4CCQgGkAgPhKg");
	mask.setTransform(148.025,469.45);

	// allEurope
	this.allEurope = new lib.allEurope();
	this.allEurope.name = "allEurope";
	this.allEurope.setTransform(124.25,519.65,1,1,0,0,0,54.3,182.9);

	var maskedShapeInstanceList = [this.allEurope];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.allEurope).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.europa, new cjs.Rectangle(75.3,345.6,236.7,299.4), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var img1 = this.img1;
		var img2 = this.img2;
		var logo = this.logo;
		var img2Guide = this.img2Guide;
		
		
		var txt1 = this.txt1;
		var txt2 = this.txt2;
		var txt3 = this.txt3;
		var txt4 = this.txt4;
		
		var lineTxt = this.lineTxt;
		
		var frame = this.frame;
		var line1 = frame.line1;
		var line2 = frame.line2;
		var line3 = frame.line3;
		var line4 = frame.line4;
		var line5 = frame.line5;
		var line6 = frame.line6;
		
		var ctaBtn = this.cta;
		
		var europa = this.europa;
		var euro1 = europa.allEurope.euro1;
		var euro2 = europa.allEurope.euro2;
		var allEurope = europa.allEurope;
		var euroSquare = europa.euroSquare;
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		//Timelines
		this.tl = tl = new TimelineMax(); //główny timeline
		this.tlLine = tlLine = new TimelineMax(); //timeline dla ramki
		this.tlLine2 = tlLine2 = new TimelineMax({paused:true, repeat:0, repeatDelay:0}); //timeline dla cofniecia ramki
		this.bgcTl = bgcTl = new TimelineMax({paused:true, repeat:0, repeatDelay:0}); //timeline dla drugiego zdjęcia
		this.euroTl = euroTl = new TimelineMax({paused:true, repeat:0, repeatDelay:0}); //timeline dla europy
		
		//MASK - START 
		var toMask = [euro1];
		
		function makeMask(){
		
			for (var i = 0; i < toMask.length; i++) {
			 
				var toMaskVar = toMask[i]; 
				var areaMask = new createjs.Shape();
				//MASKA CZWOROKĄT
				//areaMask.graphics.beginStroke("1px solid #ccc").drawRect(0, 0, (toMaskVar.nominalBounds.width * toMaskVar.scaleX), (toMaskVar.nominalBounds.height * toMaskVar.scaleY));
				
				//MASKA KÓŁKO
				 areaMask.graphics.beginStroke("1px solid #ffffff").arc((toMaskVar.nominalBounds.width * toMaskVar.scaleX)/2, (toMaskVar.nominalBounds.height * toMaskVar.scaleY)/2, toMaskVar.nominalBounds.width * toMaskVar.scaleX, 0, 2 * Math.PI);
					toMaskVar.mask = areaMask;
					toMaskVar.mask.regX = toMaskVar.regX * toMaskVar.scaleX;
					toMaskVar.mask.regY = toMaskVar.regY * toMaskVar.scaleY;
					toMaskVar.mask.x = toMask[i].x + toMaskVar.nominalBounds.x * toMaskVar.scaleX;
					toMaskVar.mask.y = toMask[i].y + toMaskVar.nominalBounds.y * toMaskVar.scaleY;
					
					toMaskVar.parent.addChild(areaMask); // Also made visible
			}
			
		}
		makeMask();
		//MASK - START END
		
		
		euroTl
			.add("europe")
			.from([allEurope], 4, {rotation:"17"}, "europe")
			.from([euroSquare], 2, {scaleX:2, scaleY:2, alpha:0, ease: Back.easeOut.config(1)}, "europe+=.3")
			.from(euro1, 2, {scaleX:1.1, scaleY:1.1, alpha: 0, ease: Power2.easeOut}, "europe+=.6")
			.to(euro1.mask, 3, {scaleX:1.1, scaleY:1.1, alpha: 0}, "europe+=.7")
			.from(euro2, 2, {scaleX:1.1, scaleY:1.1, alpha: 0, ease: Power2.easeOut}, "europe+=1")
		
		
		tlLine
			.add("frame1")
			.from([line1, line2], 1, {scaleX: 0, ease: Power2.easeIn}, "frame1")
			.from([line3, line4], 1, {scaleX: 0, ease: Power0.easeNone})
			.from([line5, line6], 1, {scaleX: 0, ease: Power2.easeOut})
		
		tlLine2
			.add("frame1")
			.to([line5, line6], 1, {scaleX: 0, ease: Power2.easeOut})
			.to([line3, line4], 1, {scaleX: 5.26, ease: Power0.easeNone})
			
		bgcTl
			.add("frame1")
			.to([img2], 10, {x:img2Guide.x, y:img2Guide.y, scaleX:img2Guide.scaleX, scaleY:img2Guide.scaleY, ease: Linear.easeNone}, "frame2");
		
		tl
			.set(img2Guide, {visible: false})
			.set(euro1.mask, {scaleX:0, scaleY:0})
		
			.add("frame1")
			.from([img1, logo], 1.5, {alpha:0, ease: Power2.easeOut}, "frame1")
			.add(function(){euroTl.play(0)}, "frame1+=1")
			.from(txt1, .7, {y:"-=5", alpha:0}, "frame1+=1.2")
			.from(lineTxt, .7, {scaleX:0, ease: Power2.easeOut})
			.from(txt2, .5, {y:"+=5", alpha:0})
			
			.add("frame2", "+=2.5")
			.add(function(){bgcTl.play(0)})
			.from(img2, 1, {alpha:0, ease: Power2.easeOut}, "frame2")
			.from(txt3, 2, {alpha:0, ease: Power2.easeOut}, "frame2+=1")
			.to(txt3, .85, {alpha:0, ease: Power2.easeOut})
			.from(txt4, 2, {alpha:0, ease: Power2.easeOut}, "frame2+=4")
			.to(txt4, .85, {alpha:0, ease: Power2.easeOut})
			
			.add("frame3")
			.set([allEurope, euroSquare], {visible: false})
			.to(logo, .5, {alpha:0, ease: Power2.easeOut}, "frame3")
			.to(txt1, .5, {y:"-=5", alpha:0}, "frame3")
			.to(txt2, .5, {y:"-=5", alpha:0}, "frame3")
			.to(lineTxt, .5, {scaleX:0}, "frame3")
			.to(img2, 1, {alpha:0, ease: Power2.easeOut}, "frame3+=1")
			
			.to(logo, 1.2, {alpha:1, ease: Power2.easeOut}, "frame3+=2")
			.add(function(){tlLine2.play(0)})
			.to(txt1, .7, {y:"+=5", alpha:1})
			.to(lineTxt, .7, {scaleX:1, ease: Power2.easeOut})
			.to(txt2, .5, {y:"+=5", alpha:1})
			
		
			.from(ctaBtn, 1, {alpha:0})
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logo = new lib.Interpoler18();
	this.logo.name = "logo";
	this.logo.setTransform(150.15,54.75,1.4353,1.4347,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// frame
	this.frame = new lib.frameMc();
	this.frame.name = "frame";
	this.frame.setTransform(20,22);

	this.timeline.addTween(cjs.Tween.get(this.frame).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(150,553,1,1,0,0,0,126,25);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt3
	this.txt3 = new lib.txt3();
	this.txt3.name = "txt3";
	this.txt3.setTransform(150.1,521.1,0.8582,0.8582,0,0,0,99.1,14.4);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(149.55,522.15,0.8384,0.8384,0,0,0,99,40.8);

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	// img2Guide
	this.img2Guide = new lib.img2Guide();
	this.img2Guide.name = "img2Guide";
	this.img2Guide.setTransform(155.9,300,1,1,0,0,0,300,300);

	this.timeline.addTween(cjs.Tween.get(this.img2Guide).wait(1));

	// img2
	this.img2 = new lib.img2_1();
	this.img2.name = "img2";
	this.img2.setTransform(266.05,300,1,1,0,0,0,300,300);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// lineTxt
	this.lineTxt = new lib.line1();
	this.lineTxt.name = "lineTxt";
	this.lineTxt.setTransform(150,156.5,1,1,0,0,0,22.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.lineTxt).wait(1));

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(150,182.85,1,1,0,0,0,116.5,18.6);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(150,132.5,1,1,0,0,0,105.5,13.7);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// europa
	this.europa = new lib.europa();
	this.europa.name = "europa";
	this.europa.setTransform(123.8,211,1,1,0,0,0,123.8,519.9);

	this.timeline.addTween(cjs.Tween.get(this.europa).wait(1));

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-87.9,285.1,654,314.9);
// library properties:
lib.properties = {
	id: '7F803018D0A0AB41BA7D75344414CF7A',
	width: 300,
	height: 600,
	fps: 30,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"img1.jpg", id:"img1"},
		{src:"img2.jpg", id:"img2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['7F803018D0A0AB41BA7D75344414CF7A'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;