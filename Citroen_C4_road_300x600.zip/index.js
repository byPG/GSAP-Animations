(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg = function() {
	this.initialize(img.bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,300);


(lib.ec41 = function() {
	this.initialize(img.ec41);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,292);


(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,400);


(lib.img2 = function() {
	this.initialize(img.img2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,400);


(lib.road = function() {
	this.initialize(img.road);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,540);


(lib.roadcolor = function() {
	this.initialize(img.roadcolor);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,540);


(lib.tri = function() {
	this.initialize(img.tri);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,540);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bXcMAAAgu3MAu3AAAMAAAAu3g");
	this.shape.setTransform(150,150);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,300,300), null);


(lib.txt5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bold
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA2A41").s().p("AAAAHIgOAcIgMgJIAVgXIgfgFIAFgOIAdANIgFgfIAPAAIgFAfIAegNIAEAOIgfAFIAVAXIgMAJg");
	this.shape.setTransform(234.4,10.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA2A41").s().p("AgJA2QgIgIABgOIAAgxIgSAAIAAgQIASAAIAAgbIARAAIAAAbIAfAAIAAAQIgfAAIAAApQgBAMADAFQADAFAHAAIAIgBIAIgDIAGAPQgGACgGABIgNABQgNABgGgIg");
	this.shape_1.setTransform(226.65,14.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BA2A41").s().p("AgYAwIAAhdIAPAAIACAJIAIgGQAFgDAFAAQAHgCAHAAIgCASIgMABQgFABgFACIgHAIIAABBg");
	this.shape_2.setTransform(220.55,15.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA2A41").s().p("AgYArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGANAAQANAAAMAGQAKAHAHALQAGALAAANQAAAOgGALQgHALgKAHQgMAGgNAAQgNAAgLgGgAgPgbQgGAEgEAHQgEAHgBAJQABAJAEAIQAEAHAGAEQAIAFAHAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_3.setTransform(211.35,15.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BA2A41").s().p("AgSBEIAAhOIgPAAIAAgQIAPAAIAAgGQAAgQAIgJQAJgJAQAAIALABIAIABIgFAQIgGgBIgHgBQgJAAgEAEQgDAEAAALIAAAFIAaAAIAAAQIgaAAIAABOg");
	this.shape_4.setTransform(203.275,13.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BA2A41").s().p("AA1AwIAAg4QAAgNgEgFQgFgFgLAAQgIAAgHADQgFADgFAFIABALIAAA5IgRAAIAAg4QAAgNgEgFQgFgFgLAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIADAJQAGgFAHgDQAGgDAKAAQAKAAAIAEQAGACADAGQAGgFAIgDQAIgEAMAAQAKAAAIAEQAHADAFAHQAEAJAAAPIAAA5g");
	this.shape_5.setTransform(191.525,15.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BA2A41").s().p("AgYArQgLgHgGgLQgHgLABgOQgBgNAHgLQAGgLALgHQALgGANAAQANAAAMAGQAKAHAHALQAHALgBANQABAOgHALQgHALgKAHQgMAGgNAAQgNAAgLgGgAgPgbQgGAEgEAHQgEAHAAAJQAAAJAEAIQAEAHAGAEQAIAFAHAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_6.setTransform(177.7,15.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BA2A41").s().p("AgSA8QgMgFgJgJQgJgJgFgMQgFgMAAgNQAAgMAFgMQAFgNAJgIQAJgKAMgEQAMgFANgBQAQAAAOAHQANAHAJAMIgOAKQgHgIgKgFQgJgFgMAAQgNAAgLAHQgKAGgGALQgGALABAMQgBANAGAKQAGALAKAHQALAGANAAQAMABAJgGQAKgEAHgJIAOALQgJAMgNAGQgOAIgQAAQgNAAgMgGg");
	this.shape_7.setTransform(166,13.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BA2A41").s().p("AgWA9QgLgHgFgLQgGgKAAgOQAAgOAGgKQAGgLALgHQALgGANgBQAIAAAGACQAGACAEADIAAgsIASAAIAACFIgOAAIgDgJQgFAEgHADQgHADgJABQgMgBgKgGgAgMgJQgGAEgEAHQgEAHAAAKQAAAJAEAHQADAIAGAEQAIAEAHAAQAHAAAHgCQAGgDAFgGIAAgsQgEgFgGgCQgGgDgHABQgIAAgIAEg");
	this.shape_8.setTransform(148.95,13.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_9.setTransform(138.675,15.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BA2A41").s().p("AgUArQgKgHgHgLQgGgLgBgOQABgNAGgLQAHgLAKgHQAKgGAMAAQARAAAKAHQALAHAEALIgPAIQgDgIgHgEQgGgFgLAAQgHAAgGAFQgHAEgDAHQgFAHAAAJQAAAJAFAIQAEAHAGAEQAHAFAIAAQAKAAAGgFQAHgEAFgGIAMAJQgGAJgKAHQgKAGgQAAQgMAAgKgGg");
	this.shape_10.setTransform(128.85,15.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BA2A41").s().p("AAXAwIAAg4QAAgNgEgFQgFgFgMAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIACAJQAGgFAIgDQAHgDAJAAQAKAAAIAEQAIADAFAHQAEAJAAAPIAAA5g");
	this.shape_11.setTransform(118.575,15.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BA2A41").s().p("AgeArQgIgIAAgLQAAgIADgFQACgGAIgDQAGgDANgCIAbgGIAAgGQAAgKgFgDQgFgEgKAAQgKAAgEACQgFACgCAHIgPgGQADgLAKgFQAKgFAOAAQAMAAAIAEQAIADAEAHQAFAHAAAKIAABAIgPAAIgCgJQgIAGgIACQgGADgJAAQgMAAgJgGgAgEAJQgKADgDADQgDACAAAHQAAAEAEAEQADACAIAAQAGAAAHgDQAGgDAHgFIAAgUg");
	this.shape_12.setTransform(108.1,15.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BA2A41").s().p("AgIAvIglhdIAUAAIAaBHIAbhHIASAAIglBdg");
	this.shape_13.setTransform(99.025,15.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BA2A41").s().p("AgXA9QgJgHgGgLQgGgKAAgOQAAgOAGgKQAHgLALgHQAKgGANgBQAIAAAGACQAGACAEADIAAgsIASAAIAACFIgPAAIgCgJQgFAEgHADQgHADgJABQgMgBgLgGgAgLgJQgHAEgFAHQgDAHAAAKQAAAJADAHQAEAIAGAEQAIAEAHAAQAHAAAHgCQAGgDAFgGIAAgsQgDgFgHgCQgGgDgIABQgHAAgHAEg");
	this.shape_14.setTransform(88.6,13.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BA2A41").s().p("AAqBAIgPglIg2AAIgOAlIgTAAIAyh/IAUAAIAzB/gAAVALIgVg3IgVA3IAqAAg");
	this.shape_15.setTransform(77.125,13.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BA2A41").s().p("AgTAtQgLgDgFgFIAIgNQAGAFAHACQAJACAHABQAIAAAFgEQAEgDAAgFQAAgEgCgDQgDgEgIgDIgNgEQgLgDgHgGQgGgGgBgLQAAgIAFgGQADgFAIgDQAHgEAKAAQAJAAAJADQAIADAHAFIgKANQgFgFgGgBQgHgDgGAAQgHAAgDAEQgEADAAAEQAAAEADADQADAEAHACIANAEQANAEAFAGQAHAGgBAMQABALgKAIQgIAHgRAAQgMAAgJgEg");
	this.shape_16.setTransform(62.05,15.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_17.setTransform(52.875,15.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BA2A41").s().p("AgQBDQgIgCgHgFQgFgGgEgHIAPgIQACAFADADQAEADAFACQAGACAGAAQAMAAAHgHQAHgGAAgMIAAgKQgFAEgHADQgHACgIAAQgMAAgLgGQgKgHgFgLQgGgKAAgOQAAgOAGgLQAGgLALgGQAKgHANAAQAHAAAHADQAIACAEAEIACgHIAPAAIAABhQAAALgFAJQgFAJgKAGQgJAFgOAAQgJAAgJgDgAgMgwQgHAEgEAHQgDAHAAAKQAAAJADAIQAEAGAGAFQAIAEAHAAQAHAAAHgDQAGgCAFgFIAAgrQgEgGgHgDQgGgDgHAAQgIAAgHAFg");
	this.shape_18.setTransform(41.95,17.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BA2A41").s().p("AgVA/QgLgHgGgLQgHgKAAgOQAAgOAHgKQAGgLALgHQALgGAMgBQAUABAMALQAMANAAAUIAAAHIhIAAQABAHACAGQAEAHAIAFQAHAEAIAAQALAAAGgEQAHgEAEgGIANAJQgGAJgLAGQgKAHgPAAQgNgBgLgGgAAbAJQgBgJgFgEQgHgIgLABQgIAAgHAEQgHAEgEAHIgCAFIA0AAIAAAAgAgIgmIgageIAVAAIAWAeg");
	this.shape_19.setTransform(31.675,13.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BA2A41").s().p("AgIBDIAAhdIARAAIAABdgAgHguQgEgDAAgFQAAgGAEgCQADgEAEAAQAFAAADAEQAEACAAAGQAAAFgEADQgDADgFAAQgEAAgDgDg");
	this.shape_20.setTransform(24.325,13.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BA2A41").s().p("AgWA+QgLgEgLgJIAKgNQAIAGAIAEQAJADAJAAQAMAAAHgEQAHgFAAgKQAAgHgEgFQgFgEgLgEIgRgHQgJgDgHgDQgGgFgEgHQgDgGAAgJQAAgLAFgIQAGgIAJgDQAJgEALgBIAPACIAMAEQAGACAGAFIgJANQgGgEgHgCQgHgDgKAAQgIAAgHAEQgGAFAAAIQAAAIAFAFQAEAEAJACIASAHQAJADAHAEQAHAEADAHQAEAHAAAKQAAARgMAKQgLAJgVAAQgNAAgKgEg");
	this.shape_21.setTransform(16.925,13.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt5, new cjs.Rectangle(-11,0,272,26.8), null);


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA2A41").s().p("AAAAHIgOAcIgNgJIAWgXIgfgFIAFgOIAdANIgFgfIAPAAIgFAfIAegNIAEAOIgfAFIAVAXIgMAJg");
	this.shape.setTransform(255.2,10.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA2A41").s().p("AgJA2QgIgIAAgOIAAgxIgRAAIAAgQIARAAIAAgbIASAAIAAAbIAfAAIAAAQIgfAAIAAApQAAAMACAFQADAFAHAAIAIgBIAIgDIAGAPQgGACgGABIgNABQgNABgGgIg");
	this.shape_1.setTransform(247.45,14.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BA2A41").s().p("AgYAwIAAhdIAPAAIACAJIAIgGQAFgDAFAAQAGgCAIAAIgCASIgMABQgGABgEACIgHAIIAABBg");
	this.shape_2.setTransform(241.35,15.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA2A41").s().p("AgYArQgLgHgGgLQgHgLABgOQgBgNAHgLQAGgLALgHQALgGANAAQANAAAMAGQAKAHAHALQAHALgBANQABAOgHALQgHALgKAHQgMAGgNAAQgNAAgLgGgAgPgbQgGAEgFAHQgDAHAAAJQAAAJADAIQAFAHAGAEQAIAFAHAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_3.setTransform(232.15,15.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BA2A41").s().p("AgSBEIAAhOIgPAAIAAgQIAPAAIAAgGQAAgQAIgJQAJgJAQAAIALABIAIABIgFAQIgGgBIgHgBQgJAAgEAEQgDAEAAALIAAAFIAaAAIAAAQIgaAAIAABOg");
	this.shape_4.setTransform(224.075,13.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BA2A41").s().p("AA1AwIAAg4QAAgNgEgFQgFgFgLAAQgIAAgHADQgFADgFAFIABALIAAA5IgRAAIAAg4QAAgNgEgFQgFgFgLAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIADAJQAGgFAHgDQAGgDAKAAQAKAAAIAEQAGACADAGQAGgFAIgDQAIgEAMAAQAKAAAIAEQAHADAFAHQAEAJAAAPIAAA5g");
	this.shape_5.setTransform(212.325,15.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BA2A41").s().p("AgYArQgKgHgHgLQgHgLABgOQgBgNAHgLQAHgLAKgHQAMgGAMAAQAOAAALAGQALAHAGALQAHALgBANQABAOgHALQgGALgLAHQgLAGgOAAQgMAAgMgGgAgPgbQgHAEgEAHQgDAHAAAJQAAAJADAIQAEAHAHAEQAIAFAHAAQAJAAAHgFQAHgDADgIQAEgIAAgJQAAgIgEgIQgDgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_6.setTransform(198.5,15.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BA2A41").s().p("AgSA8QgMgFgJgJQgJgJgFgMQgFgMAAgNQAAgMAFgMQAFgNAJgIQAJgKAMgEQAMgFANgBQAQAAAOAHQANAHAJAMIgPAKQgFgIgLgFQgJgFgMAAQgNAAgLAHQgKAGgGALQgGALABAMQgBANAGAKQAGALAKAHQALAGANAAQAMABAJgGQALgEAFgJIAPALQgJAMgNAGQgOAIgQAAQgNAAgMgGg");
	this.shape_7.setTransform(186.8,13.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BA2A41").s().p("AgXA9QgKgHgFgLQgGgKAAgOQAAgOAGgKQAGgLALgHQALgGANgBQAIAAAGACQAGACAEADIAAgsIASAAIAACFIgOAAIgDgJQgFAEgHADQgHADgJABQgMgBgLgGgAgMgJQgGAEgFAHQgDAHAAAKQAAAJADAHQAEAIAGAEQAIAEAHAAQAHAAAHgCQAGgDAFgGIAAgsQgEgFgGgCQgGgDgIABQgHAAgIAEg");
	this.shape_8.setTransform(169.75,13.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_9.setTransform(159.475,15.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BA2A41").s().p("AgUArQgKgHgHgLQgHgLAAgOQAAgNAHgLQAHgLAKgHQALgGAMAAQAQAAAKAHQALAHAEALIgOAIQgFgIgGgEQgGgFgKAAQgIAAgGAFQgHAEgDAHQgFAHAAAJQAAAJAFAIQAEAHAGAEQAHAFAIAAQAKAAAHgFQAGgEAFgGIAMAJQgGAJgKAHQgKAGgPAAQgMAAgLgGg");
	this.shape_10.setTransform(149.65,15.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BA2A41").s().p("AAXAwIAAg4QAAgNgEgFQgFgFgMAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIACAJQAGgFAIgDQAHgDAJAAQAKAAAIAEQAIADAFAHQAEAJAAAPIAAA5g");
	this.shape_11.setTransform(139.375,15.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BA2A41").s().p("AgeArQgIgIAAgLQAAgIADgFQACgGAIgDQAGgDANgCIAbgGIAAgGQAAgKgFgDQgEgEgLAAQgKAAgEACQgEACgDAHIgPgGQACgLALgFQAKgFAOAAQAMAAAIAEQAIADAFAHQAEAHAAAKIAABAIgPAAIgCgJQgIAGgIACQgGADgJAAQgMAAgJgGgAgEAJQgKADgDADQgDACAAAHQAAAEAEAEQADACAHAAQAHAAAHgDQAHgDAGgFIAAgUg");
	this.shape_12.setTransform(128.9,15.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BA2A41").s().p("AgIAvIglhdIAUAAIAaBHIAbhHIASAAIglBdg");
	this.shape_13.setTransform(119.825,15.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BA2A41").s().p("AgXA9QgJgHgGgLQgGgKAAgOQAAgOAGgKQAHgLALgHQAKgGANgBQAIAAAGACQAGACAEADIAAgsIASAAIAACFIgPAAIgCgJQgFAEgHADQgHADgJABQgMgBgLgGgAgLgJQgHAEgFAHQgDAHAAAKQAAAJADAHQAEAIAHAEQAGAEAIAAQAHAAAHgCQAGgDAFgGIAAgsQgEgFgGgCQgGgDgIABQgHAAgHAEg");
	this.shape_14.setTransform(109.4,13.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BA2A41").s().p("AAqBAIgPglIg2AAIgOAlIgTAAIAyh/IAUAAIAzB/gAAVALIgVg3IgVA3IAqAAg");
	this.shape_15.setTransform(97.925,13.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BA2A41").s().p("AAXAwIAAg4QAAgNgEgFQgFgFgMAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIACAJQAGgFAIgDQAHgDAJAAQAKAAAIAEQAIADAFAHQAEAJAAAPIAAA5g");
	this.shape_16.setTransform(81.725,15.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BA2A41").s().p("AgXArQgMgHgGgLQgHgLAAgOQAAgNAHgLQAGgLAMgHQALgGAMAAQAOAAAKAGQALAHAHALQAGALAAANQAAAOgGALQgHALgLAHQgKAGgOAAQgMAAgLgGgAgPgbQgHAEgDAHQgFAHAAAJQAAAJAFAIQADAHAHAEQAIAFAHAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_17.setTransform(70.85,15.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BA2A41").s().p("AgIBDIAAhdIARAAIAABdgAgHguQgEgDAAgFQAAgGAEgCQADgEAEAAQAFAAADAEQAEACAAAGQAAAFgEADQgDADgFAAQgEAAgDgDg");
	this.shape_18.setTransform(63.225,13.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BA2A41").s().p("AgUAtQgJgDgGgFIAIgNQAGAFAHACQAJACAHABQAJAAAEgEQAEgDABgFQAAgEgDgDQgDgEgIgDIgNgEQgLgDgGgGQgIgGAAgLQAAgIAFgGQAEgFAHgDQAIgEAJAAQAKAAAIADQAJADAFAFIgKANQgEgFgGgBQgHgDgFAAQgIAAgEAEQgDADAAAEQAAAEADADQADAEAHACIANAEQAMAEAGAGQAHAGAAAMQgBALgIAIQgJAHgRAAQgLAAgLgEg");
	this.shape_19.setTransform(56.9,15.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BA2A41").s().p("AAXAwIAAg4QAAgNgEgFQgFgFgMAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIACAJQAGgFAIgDQAHgDAJAAQAKAAAIAEQAIADAFAHQAEAJAAAPIAAA5g");
	this.shape_20.setTransform(47.625,15.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_21.setTransform(37.025,15.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BA2A41").s().p("AgsBFIAAiHIAOAAIACAJQAGgFAHgDQAHgDAIAAQANAAAKAGQAKAHAGALQAGALAAAOQAAAOgGAKQgHALgKAHQgLAGgMAAQgHAAgJgDQgFgCgEgDIAAAwgAgPgxQgGACgFAGIAAAqQAEAGAGACQAGAEAIAAQAIAAAHgFQAGgDAEgHQAEgIAAgJQAAgJgEgIQgDgHgHgEQgGgFgJAAQgHAAgGADg");
	this.shape_22.setTransform(26.8,17.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BA2A41").s().p("AgUAtQgJgDgGgFIAIgNQAGAFAHACQAJACAHABQAJAAAEgEQAEgDABgFQAAgEgDgDQgDgEgIgDIgNgEQgLgDgGgGQgIgGAAgLQAAgIAFgGQAEgFAHgDQAIgEAJAAQAKAAAIADQAJADAFAFIgKANQgEgFgGgBQgHgDgFAAQgIAAgEAEQgDADAAAEQAAAEADADQADAEAHACIANAEQAMAEAGAGQAHAGAAAMQgBALgIAIQgJAHgRAAQgLAAgLgEg");
	this.shape_23.setTransform(16.85,15.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BA2A41").s().p("AgXAsQgIgCgEgJQgFgIAAgPIAAg5IASAAIAAA4QAAANAFAFQAFAFAMAAQAGAAAGgEQAFgCAFgHIAAhCIASAAIAABdIgOAAIgDgJIgMAIQgHADgJAAQgKAAgIgEg");
	this.shape_24.setTransform(7.5,15.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BA2A41").s().p("AgWA+QgLgEgLgJIAKgNQAIAGAIAEQAJADAJAAQAMAAAHgEQAHgFAAgKQAAgHgEgFQgFgEgLgEIgRgHQgJgDgHgDQgGgFgEgHQgDgGAAgJQAAgLAFgIQAGgIAJgDQAJgEALgBIAPACIAMAEQAGACAGAFIgJANQgGgEgHgCQgHgDgKAAQgIAAgHAEQgGAFAAAIQAAAIAFAFQAEAEAJACIASAHQAJADAHAEQAHAEADAHQAEAHAAAKQAAARgMAKQgLAJgVAAQgNAAgKgEg");
	this.shape_25.setTransform(-2.875,13.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(-12,0,275,26.8), null);


(lib.txt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA2A41").s().p("AAAAHIgOAcIgNgJIAWgXIgfgFIAFgOIAdANIgFgfIAPAAIgFAfIAegNIAEAOIgfAFIAVAXIgMAJg");
	this.shape.setTransform(194,30.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_1.setTransform(184.875,35.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BA2A41").s().p("AgYAwIAAhdIAPAAIACAJIAIgGQAFgDAFAAQAHgCAHAAIgCASIgMABQgGABgEACIgHAIIAABBg");
	this.shape_2.setTransform(177.25,35.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA2A41").s().p("AgQBBQgHgEgFgEIgCAJIgOAAIAAiFIASAAIAAAuQAEgDAIgDQAGgCAJgBQAMABAKAGQAKAHAGALQAGAKAAAOQAAAOgGAKQgHALgKAHQgLAGgMAAQgHABgIgDgAgPgLQgHADgEAFIAAArQAEAFAHADQAGADAHAAQAIAAAGgEQAHgEAEgIQAEgHAAgJQAAgJgEgIQgEgGgGgFQgHgEgIAAQgHAAgGACg");
	this.shape_3.setTransform(168.4,33.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BA2A41").s().p("AA1AwIAAg4QAAgNgEgFQgFgFgLAAQgIAAgHADQgFADgFAFIABALIAAA5IgRAAIAAg4QAAgNgEgFQgFgFgLAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIADAJQAGgFAHgDQAGgDAKAAQAKAAAIAEQAGACADAGQAGgFAIgDQAIgEAMAAQAKAAAIAEQAHADAFAHQAEAJAAAPIAAA5g");
	this.shape_4.setTransform(154.375,35.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_5.setTransform(140.825,35.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BA2A41").s().p("AgJA2QgIgIAAgOIAAgxIgRAAIAAgQIARAAIAAgbIARAAIAAAbIAgAAIAAAQIggAAIAAApQABAMACAFQADAFAHAAIAIgBIAIgDIAGAPQgGACgGABIgNABQgNABgGgIg");
	this.shape_6.setTransform(131.9,33.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BA2A41").s().p("AgsBFIAAiHIAOAAIACAJQAGgFAHgDQAHgDAIAAQANAAAKAGQAKAHAGALQAGALAAAOQAAAOgGAKQgHALgKAHQgLAGgMAAQgHAAgJgDQgFgCgEgDIAAAwgAgPgxQgGACgFAGIAAAqQAEAGAHACQAGAEAHAAQAIAAAHgFQAGgDAEgHQAEgIAAgJQAAgJgEgIQgDgHgHgEQgGgFgJAAQgHAAgGADg");
	this.shape_7.setTransform(123.2,37.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_8.setTransform(112.225,35.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BA2A41").s().p("AgUAtQgKgDgGgFIAJgNQAFAFAJACQAHACAIABQAIAAAFgEQAFgDAAgFQgBgEgDgDQgCgEgIgCIgNgFQgLgDgGgGQgIgGABgLQAAgIADgFQAFgGAHgDQAIgEAJAAQAJAAAJADQAJADAFAFIgKANQgEgFgGgBQgGgDgHAAQgHAAgEAEQgDADAAAEQAAAEADADQADAEAHACIANAEQAMAEAHAGQAFAGAAAMQAAALgJAIQgIAHgRAAQgLAAgLgEg");
	this.shape_9.setTransform(102.95,35.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BA2A41").s().p("AgWA9QgKgEgGgJQgGgJAAgLQAAgLAGgIQAGgJAJgDQgGgDgEgIQgEgIAAgJQAAgKAFgIQAFgHAIgEQAJgEAKgBQALABAJAEQAJAEAEAHQAFAIABAKQAAAJgFAIQgEAIgGADQAJADAHAJQAFAIAAALQAAALgFAJQgHAJgKAEQgKAEgNAAQgMAAgKgEgAgNAGQgGAEgDAEQgEAGAAAHQAAALAHAHQAJAFAKAAQAMAAAIgFQAHgHAAgLQAAgHgEgGQgDgEgGgEQgGgDgIAAQgHAAgGADgAgNgsQgGAFAAAJQAAAJAGAGQAFAEAIAAQAJAAAGgEQAFgGAAgJQAAgJgFgFQgGgFgJgBQgIABgFAFg");
	this.shape_10.setTransform(89,33.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BA2A41").s().p("AAGBAIAAhrIgdAMIAAgSIAggOIAPAAIAAB/g");
	this.shape_11.setTransform(79.525,33.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BA2A41").s().p("AgXAsQgIgCgEgJQgFgIAAgPIAAg5IASAAIAAA4QAAANAFAFQAFAFAMAAQAGAAAGgEQAFgCAFgHIAAhCIASAAIAABdIgOAAIgDgJIgMAIQgHADgJAAQgKAAgIgEg");
	this.shape_12.setTransform(66.9,35.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BA2A41").s().p("AgeArQgIgIAAgLQAAgIADgFQACgGAIgDQAGgDANgCIAbgGIAAgGQAAgKgFgDQgFgEgKAAQgKAAgEACQgFACgCAHIgQgGQAEgLAKgFQALgFANAAQAMAAAIAEQAIADAEAHQAFAHAAAKIAABAIgPAAIgCgJQgIAGgIACQgGADgJAAQgMAAgJgGgAgEAJQgKADgDADQgDACAAAHQAAAEAEAEQADACAIAAQAGAAAHgDQAGgDAHgFIAAgUg");
	this.shape_13.setTransform(56.7,35.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BA2A41").s().p("AgWA9QgIgEgGgHQgFgIgCgJIARgDQABAIAHAFQAHAFALAAQAIAAAGgDQAGgDADgGQADgGABgIQAAgHgEgGQgCgGgGgDQgGgDgJAAQgHAAgIADQgGACgFAIIgOgFIAMhFIBAAAIAAARIg0AAIgGAiQAFgDAGgCQAGgBAGAAQAMAAAIADQAIAEAGAGQAFAGACAHQACAHABAIQgBANgGAKQgFAJgLAGQgKAFgMAAQgMAAgKgEg");
	this.shape_14.setTransform(209.55,13.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BA2A41").s().p("AAGBAIAAhrIgdAMIAAgSIAggOIAPAAIAAB/g");
	this.shape_15.setTransform(200.225,13.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BA2A41").s().p("AgXAsQgIgCgEgJQgFgIAAgPIAAg5IASAAIAAA4QAAANAFAFQAFAFAMAAQAGAAAGgEQAFgCAFgHIAAhCIASAAIAABdIgOAAIgCgJIgNAIQgHADgJAAQgKAAgIgEg");
	this.shape_16.setTransform(187.6,15.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BA2A41").s().p("AgWA9QgKgHgGgLQgGgKAAgOQAAgOAGgKQAHgLALgHQALgGAMgBQAIAAAGACQAGACAEADIAAgsIASAAIAACFIgOAAIgDgJQgFAEgHADQgHADgJABQgMgBgKgGgAgLgJQgIAEgDAHQgEAHAAAKQAAAJAEAHQADAIAHAEQAGAEAIAAQAIAAAGgCQAGgDAFgGIAAgsQgDgFgHgCQgGgDgHABQgJAAgGAEg");
	this.shape_17.setTransform(176.65,13.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BA2A41").s().p("AgTAtQgLgDgFgFIAIgNQAGAFAHACQAJACAHABQAIAAAFgEQAEgDAAgFQAAgEgCgDQgDgEgIgDIgNgEQgLgDgHgGQgGgGgBgLQAAgIAFgGQADgFAIgDQAHgEAKAAQAJAAAJADQAIADAHAFIgKANQgFgFgGgBQgHgDgGAAQgHAAgDAEQgEADAAAEQAAAEADADQADAEAHACIANAEQANAEAFAGQAHAGAAAMQAAALgKAIQgIAHgRAAQgMAAgJgEg");
	this.shape_18.setTransform(162.85,15.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_19.setTransform(153.675,15.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BA2A41").s().p("AgJA2QgIgIABgOIAAgxIgSAAIAAgQIASAAIAAgbIARAAIAAAbIAfAAIAAAQIgfAAIAAApQgBAMADAFQADAFAHAAIAIgBIAIgDIAGAPQgGACgGABIgMABQgOABgGgIg");
	this.shape_20.setTransform(144.75,14.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BA2A41").s().p("AgYAwIAAhdIAPAAIACAJIAIgGQAFgDAFAAQAHgCAHAAIgCASIgMABQgFABgFACIgHAIIAABBg");
	this.shape_21.setTransform(138.65,15.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_22.setTransform(129.725,15.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BA2A41").s().p("AgIAvIglhdIAUAAIAaBHIAbhHIASAAIglBdg");
	this.shape_23.setTransform(119.925,15.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BA2A41").s().p("AgXAsQgIgCgEgJQgFgIABgPIAAg5IASAAIAAA4QgBANAFAFQAEAFAMAAQAHAAAGgEQAFgCAGgHIAAhCIASAAIAABdIgPAAIgCgJIgNAIQgHADgIAAQgLAAgIgEg");
	this.shape_24.setTransform(109.95,15.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BA2A41").s().p("AgXArQgLgHgHgLQgGgLAAgOQAAgNAGgLQAHgLALgHQAKgGANAAQANAAALAGQALAHAHALQAGALABANQgBAOgGALQgHALgLAHQgLAGgNAAQgNAAgKgGgAgOgbQgHAEgFAHQgEAHAAAJQAAAJAEAIQAFAHAHAEQAGAFAIAAQAJAAAHgFQAHgDADgIQAFgIAAgJQAAgIgFgIQgDgHgHgEQgHgFgJAAQgIAAgGAFg");
	this.shape_25.setTransform(99.35,15.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BA2A41").s().p("AgUAtQgJgDgGgFIAIgNQAGAFAHACQAJACAHABQAJAAAEgEQAEgDABgFQAAgEgDgDQgDgEgIgDIgNgEQgLgDgGgGQgIgGAAgLQAAgIAFgGQAEgFAHgDQAIgEAJAAQAKAAAIADQAJADAFAFIgKANQgEgFgGgBQgHgDgFAAQgIAAgEAEQgDADAAAEQAAAEADADQADAEAHACIANAEQAMAEAGAGQAHAGAAAMQgBALgIAIQgJAHgRAAQgLAAgLgEg");
	this.shape_26.setTransform(85.25,15.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_27.setTransform(76.075,15.35);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#BA2A41").s().p("AgKA2QgGgIAAgOIAAgxIgSAAIAAgQIASAAIAAgbIARAAIAAAbIAfAAIAAAQIgfAAIAAApQAAAMACAFQADAFAHAAIAIgBIAJgDIAFAPQgGACgGABIgMABQgNABgIgIg");
	this.shape_28.setTransform(67.15,14.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#BA2A41").s().p("AgYAwIAAhdIAPAAIACAJIAIgGQAFgDAFAAQAHgCAHAAIgCASIgMABQgGABgDACIgIAIIAABBg");
	this.shape_29.setTransform(61.05,15.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#BA2A41").s().p("AgXArQgLgHgHgLQgGgLgBgOQABgNAGgLQAHgLALgHQALgGAMAAQAOAAAKAGQALAHAHALQAGALABANQgBAOgGALQgHALgLAHQgKAGgOAAQgMAAgLgGgAgOgbQgIAEgDAHQgFAHAAAJQAAAJAFAIQADAHAIAEQAGAFAIAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgIAAgGAFg");
	this.shape_30.setTransform(51.85,15.35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#BA2A41").s().p("AgqBAIAAh/IAtAAQATAAAKALQALALAAARQAAASgLAJQgKALgTAAIgbAAIAAAygAgYgBIAZAAQAHAAAFgCQAFgDADgFQADgFgBgIQABgHgDgFQgDgGgFgCQgFgDgHAAIgZAAg");
	this.shape_31.setTransform(41.5,13.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(-14,0,278,46.6), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA2A41").s().p("AgXAwIAAhdIAOAAIACAJIAIgGQAFgDAFAAQAGgCAHAAIgBASIgMABQgGABgDACIgIAIIAABBg");
	this.shape.setTransform(129.35,15.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA2A41").s().p("AgVArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGAMAAQAUAAAMAMQAMAMAAAWIAAAGIhIAAQABAHACAGQAEAHAIAEQAHAFAIAAQALAAAGgFQAHgEAEgGIANAJQgGAJgLAHQgKAGgPAAQgNAAgLgGgAAbgKQgBgJgFgGQgHgHgLAAQgIAAgHAFQgHAEgEAHIgCAGIA0AAIAAAAg");
	this.shape_1.setTransform(120.425,15.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BA2A41").s().p("AgKA2QgGgIgBgOIAAgxIgRAAIAAgQIARAAIAAgbIARAAIAAAbIAgAAIAAAQIggAAIAAApQAAAMADAFQADAFAHAAIAIgBIAJgDIAFAPQgGACgGABIgMABQgNABgIgIg");
	this.shape_2.setTransform(111.5,14.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA2A41").s().p("AgXAwIAAhdIANAAIADAJIAIgGQAFgDAGAAQAFgCAHAAIgBASIgMABQgFABgEACIgHAIIAABBg");
	this.shape_3.setTransform(105.4,15.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BA2A41").s().p("AgXArQgLgHgHgLQgGgLgBgOQABgNAGgLQAHgLALgHQAKgGANAAQANAAALAGQALAHAHALQAGALABANQgBAOgGALQgHALgLAHQgLAGgNAAQgNAAgKgGgAgOgbQgHAEgFAHQgEAHABAJQgBAJAEAIQAFAHAHAEQAGAFAIAAQAJAAAHgFQAHgDADgIQAFgIAAgJQAAgIgFgIQgDgHgHgEQgHgFgJAAQgIAAgGAFg");
	this.shape_4.setTransform(96.2,15.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BA2A41").s().p("AgsBFIAAiHIAOAAIADAJQAFgFAHgDQAHgDAJAAQAMAAAKAGQAKAHAGALQAGALAAAOQAAAOgHAKQgGALgKAHQgLAGgLAAQgJAAgHgDQgFgCgFgDIAAAwgAgPgxQgGACgFAGIAAAqQAEAGAHACQAFAEAIAAQAIAAAGgFQAHgDAEgHQAEgIAAgJQAAgJgEgIQgDgHgHgEQgHgFgIAAQgHAAgGADg");
	this.shape_5.setTransform(85.7,17.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BA2A41").s().p("AgTAtQgKgDgHgFIAJgNQAFAFAJACQAHACAIABQAJAAAEgEQAFgDgBgFQAAgEgCgDQgDgEgIgDIgNgEQgLgDgHgGQgGgGAAgLQAAgIAEgGQADgFAIgDQAHgEAKAAQAJAAAJADQAIADAHAFIgKANQgFgFgGgBQgGgDgHAAQgHAAgDAEQgEADAAAEQAAAEADADQADAEAHACIANAEQAMAEAHAGQAFAGAAAMQABALgKAIQgIAHgRAAQgLAAgKgEg");
	this.shape_6.setTransform(75.75,15.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BA2A41").s().p("AAXAwIAAg4QAAgNgEgFQgFgFgMAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIACAJQAGgFAIgDQAHgDAJAAQAKAAAIAEQAIADAFAHQAEAJAAAPIAAA5g");
	this.shape_7.setTransform(66.475,15.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BA2A41").s().p("AgeArQgIgIAAgLQAAgIADgFQACgGAIgDQAGgDANgCIAbgGIAAgGQAAgKgFgDQgEgEgLAAQgKAAgEACQgEACgDAHIgPgGQACgLALgFQAKgFAOAAQAMAAAIAEQAIADAFAHQAEAHAAAKIAABAIgPAAIgCgJQgIAGgIACQgGADgJAAQgMAAgJgGgAgEAJQgKADgDADQgDACAAAHQAAAEAEAEQADACAHAAQAHAAAHgDQAHgDAGgFIAAgUg");
	this.shape_8.setTransform(56,15.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BA2A41").s().p("AgYAwIAAhdIAPAAIACAJIAIgGQAFgDAFAAQAHgCAHAAIgCASIgMABQgFABgFACIgHAIIAABBg");
	this.shape_9.setTransform(49.1,15.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BA2A41").s().p("AgJA2QgIgIAAgOIAAgxIgRAAIAAgQIARAAIAAgbIARAAIAAAbIAgAAIAAAQIggAAIAAApQABAMACAFQADAFAHAAIAIgBIAIgDIAGAPQgGACgGABIgNABQgMABgHgIg");
	this.shape_10.setTransform(41.55,14.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BA2A41").s().p("AgUAtQgKgDgGgFIAJgNQAFAFAJACQAHACAIABQAIAAAFgEQAFgDAAgFQAAgEgEgDQgCgEgIgDIgNgEQgLgDgGgGQgIgGABgLQAAgIADgGQAFgFAHgDQAIgEAJAAQAJAAAJADQAJADAFAFIgKANQgEgFgGgBQgGgDgGAAQgIAAgEAEQgDADAAAEQAAAEADADQADAEAHACIANAEQAMAEAHAGQAFAGABAMQgBALgIAIQgJAHgRAAQgMAAgKgEg");
	this.shape_11.setTransform(29.25,15.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BA2A41").s().p("AgXAsQgIgCgEgJQgEgIgBgPIAAg5IASAAIAAA4QABANAEAFQAFAFALAAQAHAAAGgEQAGgCAEgHIAAhCIASAAIAABdIgOAAIgDgJIgMAIQgHADgIAAQgLAAgIgEg");
	this.shape_12.setTransform(19.9,15.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BA2A41").s().p("AgYArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGANAAQANAAAMAGQAKAHAHALQAGALAAANQAAAOgGALQgHALgKAHQgMAGgNAAQgNAAgLgGgAgPgbQgGAEgEAHQgEAHgBAJQABAJAEAIQAEAHAGAEQAIAFAHAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_13.setTransform(9.3,15.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BA2A41").s().p("AgIAvIglhdIAUAAIAaBHIAbhHIASAAIglBdg");
	this.shape_14.setTransform(-0.775,15.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BA2A41").s().p("AgeArQgIgIAAgLQAAgIADgFQADgGAHgDQAGgDAMgCIAcgGIAAgGQAAgKgFgDQgEgEgLAAQgKAAgEACQgFACgBAHIgQgGQACgLALgFQALgFAMAAQAMAAAJAEQAIADAFAHQAEAHAAAKIAABAIgOAAIgDgJQgIAGgHACQgHADgJAAQgNAAgIgGgAgEAJQgJADgEADQgDACAAAHQAAAEAEAEQAEACAGAAQAHAAAHgDQAHgDAGgFIAAgUg");
	this.shape_15.setTransform(-15,15.35);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BA2A41").s().p("AgIAvIglhdIAUAAIAaBHIAbhHIASAAIglBdg");
	this.shape_16.setTransform(-24.075,15.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BA2A41").s().p("AgJA2QgIgIABgOIAAgxIgSAAIAAgQIASAAIAAgbIARAAIAAAbIAfAAIAAAQIgfAAIAAApQgBAMADAFQADAFAHAAIAIgBIAIgDIAGAPQgGACgGABIgNABQgNABgGgIg");
	this.shape_17.setTransform(-37.05,14.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BA2A41").s().p("AgYAwIAAhdIAPAAIACAJIAIgGQAFgDAFAAQAGgCAIAAIgCASIgMABQgFABgFACIgHAIIAABBg");
	this.shape_18.setTransform(-43.15,15.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BA2A41").s().p("AgYArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQALgGANAAQANAAAMAGQAKAHAHALQAGALAAANQAAAOgGALQgHALgKAHQgMAGgNAAQgNAAgLgGgAgPgbQgGAEgEAHQgEAHgBAJQABAJAEAIQAEAHAGAEQAIAFAHAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_19.setTransform(-52.35,15.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BA2A41").s().p("AgSBEIAAhOIgPAAIAAgQIAPAAIAAgGQAAgQAIgJQAJgJAQAAIALABIAIABIgFAQIgGgBIgHgBQgJAAgEAEQgDAEAAALIAAAFIAaAAIAAAQIgaAAIAABOg");
	this.shape_20.setTransform(-60.425,13.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BA2A41").s().p("AAXAwIAAg4QAAgNgEgFQgFgFgMAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIACAJQAGgFAIgDQAHgDAJAAQAKAAAIAEQAIADAFAHQAEAJAAAPIAAA5g");
	this.shape_21.setTransform(-69.225,15.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BA2A41").s().p("AgXArQgLgHgHgLQgGgLgBgOQABgNAGgLQAHgLALgHQALgGAMAAQANAAALAGQALAHAHALQAGALABANQgBAOgGALQgHALgLAHQgLAGgNAAQgMAAgLgGgAgOgbQgIAEgDAHQgFAHAAAJQAAAJAFAIQADAHAIAEQAGAFAIAAQAJAAAHgFQAHgDADgIQAFgIAAgJQAAgIgFgIQgDgHgHgEQgHgFgJAAQgIAAgGAFg");
	this.shape_22.setTransform(-80.1,15.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BA2A41").s().p("AgUArQgKgHgHgLQgHgLAAgOQAAgNAHgLQAHgLAKgHQALgGAMAAQAQAAAKAHQALAHAEALIgOAIQgFgIgGgEQgGgFgKAAQgIAAgGAFQgHAEgDAHQgFAHAAAJQAAAJAFAIQAEAHAGAEQAHAFAIAAQAKAAAHgFQAGgEAFgGIAMAJQgGAJgKAHQgKAGgPAAQgMAAgLgGg");
	this.shape_23.setTransform(-90.2,15.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BA2A41").s().p("AAXAwIAAg4QAAgNgEgFQgFgFgMAAQgIAAgFAEQgGACgFAHIAABCIgSAAIAAhdIAOAAIACAJQAGgFAIgDQAHgDAJAAQAKAAAIAEQAIADAFAHQAEAJAAAPIAAA5g");
	this.shape_24.setTransform(-105.025,15.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BA2A41").s().p("AgYArQgLgHgGgLQgHgLAAgOQAAgNAHgLQAGgLALgHQAMgGAMAAQAOAAAKAGQALAHAHALQAGALAAANQAAAOgGALQgHALgLAHQgKAGgOAAQgMAAgMgGgAgPgbQgHAEgDAHQgFAHAAAJQAAAJAFAIQADAHAHAEQAIAFAHAAQAJAAAHgFQAHgDAEgIQADgIAAgJQAAgIgDgIQgEgHgHgEQgHgFgJAAQgHAAgIAFg");
	this.shape_25.setTransform(-115.9,15.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BA2A41").s().p("AgWA+QgLgEgLgJIAKgNQAIAGAIAEQAJADAJAAQAMAAAHgEQAHgFAAgKQAAgHgEgFQgFgEgLgEIgRgHQgJgDgHgDQgGgFgEgHQgDgGAAgJQAAgLAFgIQAGgIAJgDQAJgEALgBIAPACIAMAEQAGACAGAFIgJANQgGgEgHgCQgHgDgKAAQgIAAgHAEQgGAFAAAIQAAAIAFAFQAEAEAJACIASAHQAJADAHAEQAHAEADAHQAEAHAAAKQAAARgMAKQgLAJgVAAQgNAAgKgEg");
	this.shape_26.setTransform(-126.525,13.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(-139,0,278,26.8), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// C4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAYBUIAAgaIhXAAIAAggIBBhtIAuAAIg/BoIAnAAIAAgfIAoAAIAABeg");
	this.shape.setTransform(8.575,290.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgbBQQgQgGgMgMQgMgMgGgQQgHgQAAgSQAAgRAHgQQAGgQAMgMQAMgMAQgHQAQgGASAAQAYAAATAKQAUAKALAQIgiAZQgGgJgLgFQgJgGgNAAQgNAAgKAGQgKAHgFAKQgHALABALQAAAMAFALQAFAKALAHQAKAGANAAQANAAAJgGQALgFAGgJIAhAYQgLARgTAKQgTAKgYAAQgSAAgQgHg");
	this.shape_1.setTransform(-7.15,290.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-137.5,272.9,275,34), null);


(lib.triangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A2fAEUAarggGgAGgAGMAtDAAxMAAAA73UAAAAAEgxJABxUgxJABxAAAAADUgABAABAarggGg");
	mask.setTransform(590.6999,196.65);

	// Layer_1
	this.instance = new lib.tri();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.triangle, new cjs.Rectangle(276.2,0,623.8,402.4), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiKD1QhTgxghhdQgghZAaheQAWhRBCg3QA+gzBUgRQBTgRBOAWQBTAXA1A+QADADgEAEIhLBGQgGAGgHgGQgtgsg8gLQg4gLgzAVQg0AWgcAvQgfAzAHBCQAKBkBaAmQBUAkBZgqQADgCAAgEIABiYQAAgFAFAAIBuAAQAFAAAAAFIAADbQAAAFgFADQhbA8hqAHIgZABQhfAAhPgwg");
	this.shape.setTransform(53.2038,1005.32);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ED1C24").s().p("EhSyAJOIAAybMCcSAAAQAGAAADAEIJJJIQACACgCADIpNJKgEhK4gEZQhVASg+AzQhCA3gWBQQgaBeAgBaQAiBcBSAyQBZA1BvgHQBqgHBbg7QAFgEAAgFIAAjcQAAgEgFAAIhuAAQgFAAAAAEIgBCaQAAAEgDABQhZArhVglQhagmgJhjQgHhDAegzQAcgvA0gVQA0gVA4AKQA8AMAuAsQAGAFAGgFIBMhHQADgDgDgEQg1g9hTgYQgsgMguAAQgjAAgkAHg");
	this.shape_1.setTransform(529.9,1004.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjREZQgEAAAAgEIAAoqQgBgDAFAAIGjAAQABAAABAAQABAAAAABQAAAAABABQAAAAAAABIAABkQAAAEgEAAIkfAAQgBAAAAAAQgBABAAAAQgBABAAAAQAAABAAABIAACJQgBAEAEAAID8AAQAEAAAAAEIAABjQAAAEgEAAIj8AAQgBAAAAAAQgBAAAAABQgBAAAAABQAAAAAAABIAADEQAAADgEAAg");
	this.shape_2.setTransform(56.1159,867.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F37021").s().p("EhJfAJOIAAybMCJsAAAQAGAAAEAEIJIJIQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAIAAAAIpGJGQgFAEgFAAgEhEEgERIAAIpQABAEADAAIB9ABQAEAAAAgEIAAjDQgBgDAEAAID9AAQAEAAAAgEIAAhkQAAgDgEAAIj9AAQgDAAAAgEIAAiKQgBgDAEAAIEgAAQAEAAAAgEIAAhkQAAgBAAgBQAAAAgBgBQAAAAgBAAQgBAAgBgBImkAAQgBABgBAAQAAAAgBAAQAAABAAAAQgBABAAABg");
	this.shape_3.setTransform(470.4,867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjbEUIAAonQAAgFAFAAIGhAAQAFAAAAAFIACBdQAAAJgIAAIAAAAIkaAAQgGAAAAAGIAABpQAAAHAGAAID4AAQAFAAAAAFIAABeQAAAFgFAAIj4AAQgGAAAAAGIAAByQAAAHAHAAIEkAAQAFAAAAAFQAEAqgEAmQgBAEACAEQACADgBAEQgBAFgGAAImrAAQgFAAAAgFg");
	this.shape_4.setTransform(55.4813,729.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FDB913").s().p("EhAWAJOIAAybMB3cAAAQAEAAACACIJJJKQAEADgEADIpHJGQgDADgEAAgEg7IgEPIABInQAAAFAFAAIGsAAQAFAAACgFQAAgEgBgDQgCgEABgEQAEgmgEgqQAAgFgGAAIkkAAQgIAAAAgHIAAhyQAAgGAGAAID5AAQAFAAAAgFIAAheQAAgFgFAAIj5AAQgGAAAAgHIAAhpQAAgGAGAAIEbAAQAEAAACgCQADgDAAgEIgDhdQAAgFgFAAImiAAQgFAAAAAFg");
	this.shape_5.setTransform(411.9125,728.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFF200").s().p("AgQCqIiBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIABlOQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAABAAICAABQBDAAAwAuQAwAuAABBIAAAYQgBBBgvAuQgwAuhDAAIgBAAg");
	this.shape_6.setTransform(55.45,591.4253);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AkaEXIgCosQAAgEAFAAIERgBQB3AABWBPQBUBPABBxIAAAAIAAAUQABBwhVBQQhUBQh4ABIkRABQgFAAAAgEgAiTinIgBFOQAAAAAAABQAAAAABABQAAAAAAAAQABAAAAAAICBAAQBDABAxguQAvguABhBIAAgYQAAhBgwguQgwgvhDAAIiAAAQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAABg");
	this.shape_7.setTransform(55.5501,591.4748);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFF200").s().p("Eg3IAJOIAAybUAygAABAyggABQAPAAJBJNIABACIgBACIpHJGQgEAEgGAAgEgujgEVIkSABQgEAAAAAEIACIsQAAAEAEAAIERgBQB5gBBUhQQBVhQAAhwIAAgUQgBhxhVhPQhVhPh3AAIgBAAg");
	this.shape_8.setTransform(352.925,590.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAUEkQibgIhQhxQgsg+gHhQQgIhPAghGQAghFBBgtQA+grBNgLQBMgLBIAYQBLAYAyA6QAEAEgEAEIhOBIQgEADgEgEQhDhHhfAKQhgALgnBaQgeBGAUA+QASA6A2AhQA0AhA+gHQBEgHA1g1QAEgEAEADIBNBIQAEADgDAFQhVBiiNAAIgVAAg");
	this.shape_9.setTransform(54.3279,453.3777);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BFD730").s().p("Egt/AJOIAAybMBSsAAAQAGAAAEAEIJHJHQAEADgEAFIAAAAIpGJEQgEAEgGAAgEglmgEcQhOALg9ArQhCAtggBFQgfBGAHBPQAIBQAsA+QBQBxCbAIQCcAIBbhqQADgFgEgDIhNhIQgEgDgDAEQg1A1hEAHQg/AHg1ghQg1ghgTg6QgUg+AfhGQAnhaBhgLQBfgKBDBHQAEAEAEgDIBNhIQAEgEgEgEQgyg6hLgYQgxgQgzAAQgYAAgYADg");
	this.shape_10.setTransform(294.3875,452.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AiaDnQgFAAAAgFIAAg8QAAgFADgDIC6iwQAdgcAAgkQAAgpgrgMQhAgRgyA4QgEAEgFgDIhHguQgFgCAEgEQBsh2CSAxQBEAWATA+QATA8gkA9QgVAhgxAtIhLBHQgFAGAHAAICvAAQAFAAAAAFIAABNQAAAFgFAAg");
	this.shape_11.setTransform(665.7984,304.1186);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#50B848").s().p("ABRCKIlIgCQgFAAAAgFIABkHQAAgFAFAAIFIACQBHAAAyAlQAyAkAAAzIAAAaQgBAzgyAkQgyAkhFAAIgCAAg");
	this.shape_12.setTransform(96.975,279.0003);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#50B848").s().p("AhsBmQgugqAAg7QAAg7AtgrQAtgqBAAAQA/AAAuAqQAtAqABA7QAAA7gtArQguAqhAAAIAAAAQg/AAgtgqg");
	this.shape_13.setTransform(413.7747,258.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AFLEuQgFAAAAgFIgBlCQAAg5ghghQgdgfgsgCQgsgDgjAaQgnAcgKAzQgFAWAAAjIAAEdQAAAGgFAAIikAAQgGAAABgGIgBlGQAAhghRgSQhIgQgsAuQgnArgBBJQgCCkAACDQAAAFgFAAIiiAAQgFAAAAgFIAApGQAAgFAFAAICbAAQAFAAAAAFIAAAyQAAAGAEgEQBUhGBsACQB0ACA/BXQADAEAEgDQA5g5BPgWQBLgUBIASQBJATAtA3QAyA9ACBcQADCZgDDRQAAAFgEAAg");
	this.shape_14.setTransform(865.3942,260.3207);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ai1GDQhAgSgwgjQgGgDAEgGIBBh1QAAgBABgBQAAgBABAAQAAAAABAAQABAAAAABIABAAQAuAgBAASQBFAUA6gGQCVgNgJieQAAgFgEADQg9AzhPALQhKALhIgaQhKgagxg4Qg0g8gMhPQgMhTAchJQAahEA6gvQA4guBKgOQBNgPBOAYQA3AQAoArQAGAGAAgJIAAg2QAAgFAFAAICdAAQAFAAAAAEQACFogCCGQgCDXikBIQhIAghZAAQhTAAhjgcgAABkNQg/AAgtAqQguArABA7QAAA8AtAqQAuApA/AAQBAAAAtgqQAtgqAAg8QAAg7gugqQgtgqg/AAIgBAAg");
	this.shape_15.setTransform(413.6052,271.5941);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#50B848").s().p("AgFD2QhkgDhEhKQhEhKAChkQADhmBIhGQBIhGBiACQBkACBFBKQBEBKgDBlQgDBmhIBGQhGBEhfAAIgFAAg");
	this.shape_16.setTransform(612.45,251.9015);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#50B848").s().p("AAAByQg1AAgmgiQgnghAAgvQABgvAmghQAmghA1AAQA2AAAnAiQAmAhAAAuQgBAwgmAhQgmAhg1AAIgBAAg");
	this.shape_17.setTransform(339.875,236.8504);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#50B848").s().p("AjcCDQgBAAgBAAQAAAAgBgBQAAAAgBgBQAAgBAAAAIAAj/QAAAAAAgBQABgBAAAAQABgBAAAAQABAAABAAIEVAAQBFAAAyAkQAxAiAAAyIAAAVQAAAygxAiQgxAkhGAAg");
	this.shape_18.setTransform(94.225,233.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgJGCQAAAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAApsQAAgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBAAIiVAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAgBAAgBIAAiKQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAAAAAIFIAAQADgBABAEIAAL9QAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_19.setTransform(281.5,251.865);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgIGCQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAApsQAAgBAAgBQgBAAAAAAQgBgBAAAAQgBAAgBAAIiUAAQgBAAgBAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIgBiKQAAgBAAgBQABAAAAgBQAAAAABAAQABAAAAAAIFIAAQABAAABAAQAAAAABAAQAAABABAAQAAABAAABIAAL9QAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_20.setTransform(238.225,251.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AkLE7Qikh5AJjPQAIi8CPhuQCLhrC8AWQCnAUBlByQBbBpAHCPQAHCPhSBuQhaB5ikAfQgzAKgwAAQiPAAh2hWgAikixQhIBGgDBmQgCBkBEBKQBEBKBkADQBiACBIhGQBJhGAChmQADhlhEhKQhFhKhjgCIgGAAQhfAAhGBEg");
	this.shape_21.setTransform(612.4005,251.9241);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgwGFQieghhah9Qhah/AWigQAZiyCRhfQCKhaC0AZQCTATBfBsQAFAHgGAFIAAAAQg5AzgzAxQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAgBAAQhnhih6AMQhkAKg7BJQg2BCAABbQAABaA1BDQA7BKBlAMQB/APBdhkQAEgEAEADIBtBlQAEADgDAEQhLBXh0AhQg8AQg+AAQgzAAg0gLg");
	this.shape_22.setTransform(526.3202,251.9136);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AkeFeQgFgCADgFIBAh+QADgEADACQB5BBBuguQB1gxAEiNQAAgBAAgBQAAAAgBAAQAAgBgBAAQAAABgBAAQg7AohMALQhLAMhFgVQhIgVgsgzQgxg3gFhTQgFhcAxhEQArg8BQgeQBLgcBUAGQBWAHBEAoQBjA5AlB5QAgBngQB/QgRCQhWBZQhXBaiQAQQgeAEgdAAQhtAAhigygAhojmQgmAhgBAvQAAAvAnAiQAmAhA2ABQA1AAAmgiQAmghABgvQAAgvgmgiQgnghg1AAIgCAAQg0AAgmAhg");
	this.shape_23.setTransform(341.1933,251.912);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AB0GZIgCgCIi1jhQAAgBgBAAQAAgBgBAAQAAAAgBABQAAAAgBAAIAAAAIhOBOQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAABAAIAACQQAAABgBABQAAAAAAABQgBAAAAABQgBAAgBAAIioAAQgBAAgBAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIAAsqQAAAAAAgBQAAgBAAAAQABAAAAgBQABAAABAAICoAAQABAAAAAAQABABAAAAQABAAAAABQAAABAAAAIABG9QAAABAAABQAAAAABABQAAAAABABQAAAAABAAIADgBIDujhIACgBIDJAAQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABIgBACIjuDzQgBAAAAABQAAABAAAAQAAABAAAAQAAAAABABIEHFPQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABIgCABg");
	this.shape_24.setTransform(775.5444,249.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("An9IxQgFAAAAgFIAAxXQAAgFAFAAIIsgBQChAABtA8QCHBKAHCVQAHCgiQBeQgEADAFACQDNBUgODRQgKCoiaBGQhtAwi/ABIlGABIjpgBgAj9BeIgCEIQAAAFAFAAIFIACQBHAAAzgkQAygkAAgzIABgbQAAgzgygkQgyglhHAAIlIgCQgFAAAAAFgAj+lnIAAD/QAAABAAABQABAAAAABQAAAAABABQABAAABAAIEVAAQBFAAAygjQAxgkAAgxIAAgWQAAgygxgjQgxgjhGAAIkVAAQgBAAgBAAQgBAAAAABQAAAAgBABQAAAAAAABg");
	this.shape_25.setTransform(97.2417,256.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Aj/IHQgBAAgBgBQAAAAgBAAQAAgBAAAAQAAgBAAgBIAAAAIFowHQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAICXAAQABAAABABQAAAAAAAAQABABAAAAQAAABAAABIAAABIloQFQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAg");
	this.shape_26.setTransform(714.275,249.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#50B848").s().p("EhStAScMAAAgk3MCTGAAAQAFAAACADISNSXQACACgCACIyMSVQgDAEgGAAgAVkFaQArALAAApQAAAlgeAcIi7CxQgDADAAAFIAAA8QAAAFAFAAIFNAAQAFAAAAgFIAAhOQAAgFgFAAIivAAQgJAAAGgGIBLhGQAyguAUgiQAlg9gTg8QgUg9hDgXQiTgwhtB2QgDADAEADIBHAtQAFAEAFgFQAmgqAvAAQAPAAAPAEgA1sFrIAAABIhBB1QgEAGAGADQAwAjBAASQDLA7CNg/QCkhIACjXQACiHgClnQAAgEgFAAIidAAQgFAAAAAFIAAA2QAAAJgGgGQgogrg3gQQhPgYhNAPQhKAOg4AuQg6AvgaBEQgcBJAMBSQAMBQA0A8QAxA4BKAaQBIAaBLgLQBPgLA9gzQAEgDAAAFQAJCeiVANQg7AGhFgUQhAgSguggIgCAAQgBAAAAAAQAAAAgBAAQAAAAAAABQgBAAAAAAgEhLfgIsQgFAAAAAFIAARXQAAAFAFAAQC7ABF1gBQC/gBBtgxQCahFAKioQAOjRjNhVQgFgCAEgCQCQhfgHigQgHiViHhKQhtg7ihAAgAefpEIlpQHQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABIABAAICXAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAAAIFpwGQABgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAIiYgBQgBAAAAAAQgBABAAAAQgBAAAAAAQAAABAAAAgAIulfQiPBugIC7QgJDQCkB4QCdBzDMgnQCkgfBah5QBShugHiOQgHiQhbhoQhlhzingTQgggEggAAQiVAAhzBZgAjhlxQiRBfgZCxQgWChBaB+QBaB+CeAhQB1AYBsgeQB0ggBLhXQADgEgEgEIhthkQgEgEgEAEQhdBkh+gPQhmgLg7hKQg1hDAAhaQAAhcA2hCQA7hJBlgKQB5gMBnBiQABABAAAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAzgxA5gyQAGgGgFgGQhfhsiTgUQgmgFglAAQiGAAhtBHgEgg6ACwIhBB/QgCAFAFACQB8A+CNgQQCRgRBYhaQBVhYASiQQAQh/gghnQgmh5hig6QhEgohWgGQhWgHhLAdQhPAdgsA9QgwBDAFBdQAEBSAxA5QAsAyBJAVQBEAUBMgLQBMgLA8gpQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAABQgFCNh1AxQhvAvh4hBIgDgBQAAAAgBAAQAAAAAAABQgBAAAAAAQgBABAAAAgEA36gBpQAtACAdAfQAgAiABA4IABFCQAAAFAFAAICkAAQAFAAAAgFQADjQgEiaQgChbgxg9Qgtg3hKgTQhHgThMAVQhOAVg6A5QgDAEgDgEQhBhXhzgCQhtgDhTBGQgFAFAAgHIAAgxQAAgFgFAAIibAAQgFAAAAAFIAAJFQAAAFAFAAICiAAQAFAAAAgFQAAiDADijQABhKAngqQArgvBJARQBRASAABfIABFHQgBAFAGAAICkAAQAGAAAAgFIAAkdQAAgkAEgVQALgzAmgcQAggYAoAAIAHAAgEAlZAB2IAAAAIC2DiIACABIDOAAQABAAABAAQAAAAABgBQAAAAAAgBQAAAAAAgBIAAgCIkHlPQAAAAgBgBQAAAAAAAAQAAgBAAgBQABAAAAgBIDujyQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBgBgBIgCAAIjJAAIgCAAIjvDiQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBIgBgCIgBm+QAAgBAAgBQAAAAAAgBQgBAAAAAAQgBAAgBAAIioAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAABAAABIAAMqQAAABAAAAQAAABABAAQAAABABAAQAAAAABAAICoAAQABAAABAAQABAAAAgBQAAAAABgBQAAAAAAgBIAAiQQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIBOhNIACgBIACABgEgpWgGnIAACKQAAABABABQAAAAAAABQABAAAAABQABAAAAAAICVAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAABIAAJsQAAABABAAQAAABAAAAQAAABABAAQABAAAAAAICuAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAr9QAAgBAAgBQAAAAgBgBQAAAAgBAAQAAAAgBAAIlJAAQAAAAgBAAQAAAAgBAAQAAABAAAAQgBABAAABgEgwHgGnIABCKQAAABAAABQAAAAABABQAAAAABABQAAAAABAAICUAAQABAAABAAQABAAAAABQAAAAABAAQAAABAAABIAAJsQAAABAAAAQAAABABAAQAAABABAAQAAAAABAAICtAAQABAAABAAQABAAAAgBQAAAAABgBQAAAAAAgBIAAr9QAAgBAAgBQgBAAAAgBQAAAAgBAAQgBAAgBAAIlJAAQAAAAgBAAQAAAAgBAAQAAABAAAAQgBABAAABg");
	this.shape_27.setTransform(529.4125,255.975);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#00A651").s().p("AhNBlQgHAAACgGIBQjBQACgFACAFIBQDCQADAFgGAAg");
	this.shape_28.setTransform(53.8132,55.3125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("ACyEZQgBAAgBgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgwhzQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAIj6AAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAABIgxB1QAAAAAAAAQgBABAAAAQAAAAgBAAQAAABgBAAIiCgBIgCgBIgBgDIAAgBID4orQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAIB+AAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAAAID5IrQAAABAAABQAAAAAAABQAAAAgBABQAAAAgBABIgBABgAgDiKIhQDAQgCAGAHAAICcAAQAGABgDgGIhQjBQAAgBgBgBQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAABgBAAQAAABAAABg");
	this.shape_29.setTransform(53.9417,59.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#00A651").s().p("EggTAJOIAAybMA3dAAAIJIJJQACACAAADQAAADgCADIpDJBQgFAGgHAAgA18ClQABAAAAAAQABAAAAAAQABABAAAAQAAAAAAABIAwBzQAAABAAAAQAAABABAAQAAAAABAAQAAABABAAICGABQABAAAAgBQABAAAAAAQABgBAAAAQAAgBAAgBIAAgCIj5orQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIh/AAQAAAAgBABQAAAAgBAAQAAAAAAABQgBAAAAAAIj4IrQAAABAAAAQAAABAAABQAAAAABAAQABABAAAAIABABICCABQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAAAIAxh1QAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAg");
	this.shape_30.setTransform(206.825,59);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#F68E92").ss(2,0,0,4).p("ACLCcQhZAqhUgkQhagmgKhkQgHhCAfgzQAcgvA0gWQAzgVA4ALQA8ALAtAsQAHAGAGgGIBLhGQAEgEgDgDQg1g+hTgXQhOgWhTARQhUARg+AzQhCA3gWBRQgaBeAgBZQAhBdBTAxQBZA2BugHQBqgHBbg8QAFgDAAgFIAAjbQAAgFgFAAIhuAAQgFAAAAAFIgBCYQAAAEgDACg");
	this.shape_31.setTransform(53.2038,1005.32);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#F9B890").ss(2,0,0,4).p("AhQipQgBgEAEAAIEfAAQAEAAAAgEIAAhkQAAgDgEAAImjAAQgEAAAAADIAAIqQAAAEAEAAIB9AAQAEAAAAgDIAAjEQgBgDAEAAID8AAQAEAAAAgEIAAhjQAAgEgEAAIj8AAQgDAAAAgEg");
	this.shape_32.setTransform(56.125,867.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FEDC89").ss(2,0,0,4).p("ADaEFQAEgmgEgqQAAgFgFAAIkkAAQgHAAAAgHIAAhyQAAgGAGAAID4AAQAFAAAAgFIAAheQAAgFgFAAIj4AAQgGAAAAgHIAAhpQAAgGAGAAIEaAAQADAAADgCQACgDAAgEIgChdQAAgFgFAAImhAAQgFAAAAAFIAAInQAAAFAFAAIGrAAQAGAAABgFQABgEgCgDQgCgEABgEg");
	this.shape_33.setTransform(55.4813,729.375);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiSinIgBFOQAAADACAAICBAAQBDAAAxguQAwguAAhBIAAgYQAAhBgwguQgwguhDAAIiBgBQgBAAgBACg");
	this.shape_34.setTransform(55.45,591.4253);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FFF980").ss(2,0,0,4).p("AkckVIACIsQAAAEAEAAIESgBQB3gBBVhQQBVhQgBhwIAAgUQAAhxhWhPQhVhPh3AAIkSABQgEAAAAAEg");
	this.shape_35.setTransform(55.5501,591.4748);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#DFEB98").ss(2,0,0,4).p("AjXCrQBQBxCbAIQCcAIBbhqQADgFgEgDIhNhIQgEgDgEAEQg1A1hEAHQg+AHg0ghQg2ghgSg6QgUg+AehGQAnhaBggLQBfgKBDBHQAEAEAEgDIBOhIQAEgEgEgEQgyg6hLgYQhIgYhMALQhNALg+ArQhBAtggBFQggBGAIBPQAHBQAsA+g");
	this.shape_36.setTransform(54.3279,453.3777);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACbAAQgBg7gtgqQgugrg/ABQhAAAgtAqQgtArAAA6QAAA8AuAqQAtAqA/AAQBAAAAugrQAtgqAAg7g");
	this.shape_37.setTransform(413.7747,258.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AgGD2QBjACBIhGQBIhGADhmQAChlhEhKQhEhKhkgCQhigChIBGQhJBGgCBmQgDBkBFBKQBEBKBjADg");
	this.shape_38.setTransform(612.45,251.9015);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACDAAQAAgugmghQgngig2AAQg1AAgmAhQgmAhgBAvQAAAvAnAhQAmAiA1AAQA2AAAmghQAmghABgwg");
	this.shape_39.setTransform(339.875,236.8996);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Aj7iEIgBEHQAAAFAFAAIFIACQBHAAAygkQAygkABgzIAAgaQAAgzgygkQgyglhHAAIlIgCQgFAAAAAFg");
	this.shape_40.setTransform(96.975,279.0003);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Ajgh/IAAD/QAAADAEAAIEVAAQBFAAAygjQAxgjAAgyIAAgUQAAgygxgjQgxgkhGAAIkVAAQgEAAAAADg");
	this.shape_41.setTransform(94.225,233.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AAACKQACgDBJhEQAxgtAVghQAkg9gTg8QgTg+hEgWQiSgxhsB2QgEAEAFACIBHAuQAFADAEgEQAyg4BAARQArAMAAApQAAAkgdAcIi6CwQgDADAAAFIAAA8QAAAFAFAAIFLAAQAFAAAAgFIAAhNQAAgFgFAAIivAAQgHAAAFgGg");
	this.shape_42.setTransform(665.7984,304.1186);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AlPjrIAAgyQAAgFgFAAIibAAQgFAAAAAFIAAJGQAAAFAFAAICiAAQAFAAAAgFQAAiDACikQABhJAngrQAsguBIAQQBRASAABgQABBsAADaQgBAGAGAAICkAAQAFAAAAgGQAAiOAAiPQAAgjAFgWQAKgzAngcQAjgaAsADQAsACAdAfQAhAhAAA5IABFCQAAAFAFAAIClAAQAEAAAAgFQADjRgDiZQgChcgyg9Qgtg3hJgTQhIgShLAUQhPAWg5A5QgEADgDgEQg/hXh0gCQhsgChUBGQgEAEAAgGg");
	this.shape_43.setTransform(865.3942,260.3207);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACYBjQAJCeiVANQg6AGhFgUQhAgSguggQgDgBgCACIAAABIhBB1QgEAGAGADQAwAjBAASQDKA7CNg/QCkhIACjXQACiGgCloQAAgEgFAAIidAAQgFAAAAAFIAAA2QAAAJgGgGQgogrg3gQQhOgYhNAPQhKAOg4AuQg6AvgaBEQgcBJAMBTQAMBPA0A8QAxA4BKAaQBIAaBKgLQBPgLA9gzQAEgDAAAFg");
	this.shape_44.setTransform(413.6052,271.5941);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AgPjwQADAAAAADIAAJsQAAADAEAAICsAAQAEAAAAgDIAAr9QAAgDgEAAIlHAAQgEAAAAADIAACKQAAAEAEAAg");
	this.shape_45.setTransform(281.5,251.875);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AgPjwQAEAAAAADIAAJsQAAADADAAICsAAQAEAAAAgDIAAr9QAAgDgEAAIlIAAQgDAAAAADIABCKQAAAEADAAg");
	this.shape_46.setTransform(238.225,251.875);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AmmgNQgJDPCkB5QCdBzDLgnQCkgfBah5QBShugHiPQgHiPhbhpQhlhyingUQi8gWiLBrQiPBugIC8g");
	this.shape_47.setTransform(612.4005,251.9241);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AD/ibQABABABgBQAzgxA5gzQAGgGgFgGQhfhsiTgTQi0gZiKBaQiRBfgZCyQgWCgBaB/QBaB9CeAhQB1AZBsgeQB0ghBLhXQADgEgEgDIhthlQgEgDgEAEQhdBkh/gPQhlgMg7hKQg1hDAAhaQAAhbA2hCQA7hJBkgKQB6gMBnBig");
	this.shape_48.setTransform(526.3202,251.9136);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACGAsQgECNh1AxQhuAuh5hBQgDgCgDAEIhAB+QgDAFAFACQB8A/COgRQCQgQBXhaQBWhZARiQQAQh/gghnQglh5hjg5QhEgohWgHQhUgGhLAcQhQAegrA8QgxBEAFBcQAFBTAxA3QAsAzBIAVQBFAVBLgMQBMgLA7goQADgCAAAEg");
	this.shape_49.setTransform(341.1933,251.912);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AiPArQgDACgCgCIgBgDIgBm9QAAgDgDAAIioAAQgDAAAAADIAAMqQAAAEADAAICoAAQAEAAAAgEIAAiQQgBgBABgBIBOhOQACgBACABIAAABIC1DhIACACIDOAAQADAAAAgEIAAgBIkHlPQgCgCACgCIDujzQACgBgCgDQgBgBgBAAIjJAAQAAAAgCABg");
	this.shape_50.setTransform(775.525,249.625);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AFCgYQCQhegHigQgHiViHhKQhtg8ihAAIosABQgFAAAAAFIAARXQAAAFAFAAQC7ABF0gBQC/gBBtgwQCahGAKioQAOjRjNhUQgFgCAEgDg");
	this.shape_51.setTransform(97.2417,256.325);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ABpoGQgCAAgBACIloQHQgBADADABIABAAICXAAQACgBABgBIFowGQABgEgDgBg");
	this.shape_52.setTransform(714.275,249.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#80D3A8").ss(2,0,0,4).p("AhNBlICcAAQAGAAgDgFIhQjCQgCgFgCAFIhQDBQgCAGAHAAg");
	this.shape_53.setTransform(53.8132,55.3125);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#80D3A8").ss(2,0,0,4).p("Ak6EUQgBADADABIABABICCABQADAAAAgDIAxh0QABgCACAAID6AAQADAAAAACIAwB0QAAACADAAICGABQADAAAAgEIAAgBIj5osQAAgCgDAAIh+AAQgCAAgBACg");
	this.shape_54.setTransform(53.9375,59.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AiKD1QhTgxghhdQgghZAaheQAWhRBCg3QA+gzBUgRQBTgRBOAWQBTAXA1A+QADADgEAEIhLBGQgGAGgHgGQgtgsg8gLQg4gLgzAVQg0AWgcAvQgfAzAHBCQAKBkBaAmQBUAkBZgqQADgCAAgEIABiYQAAgFAFAAIBuAAQAFAAAAAFIAADbQAAAFgFADQhbA8hqAHIgZABQhfAAhPgwg");
	this.shape_55.setTransform(53.2038,1005.32);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#ED1C24").s().p("EhSyAJOIAAybMCcSAAAQAGAAADAEIJJJIQACACgCADIpNJKgEhK4gEZQhVASg+AzQhCA3gWBQQgaBeAgBaQAiBcBSAyQBZA1BvgHQBqgHBbg7QAFgEAAgFIAAjcQAAgEgFAAIhuAAQgFAAAAAEIgBCaQAAAEgDABQhZArhVglQhagmgJhjQgHhDAegzQAcgvA0gVQA0gVA4AKQA8AMAuAsQAGAFAGgFIBMhHQADgDgDgEQg1g9hTgYQgsgMguAAQgjAAgkAHg");
	this.shape_56.setTransform(529.9,1004.975);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AjREZQgEAAAAgEIAAoqQgBgDAFAAIGjAAQABAAABAAQABAAAAABQAAAAABABQAAAAAAABIAABkQAAAEgEAAIkfAAQgBAAAAAAQgBABAAAAQgBABAAAAQAAABAAABIAACJQgBAEAEAAID8AAQAEAAAAAEIAABjQAAAEgEAAIj8AAQgBAAAAAAQgBAAAAABQgBAAAAABQAAAAAAABIAADEQAAADgEAAg");
	this.shape_57.setTransform(56.1159,867.375);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#F37021").s().p("EhJfAJOIAAybMCJsAAAQAGAAAEAEIJIJIQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAIAAAAIpGJGQgFAEgFAAgEhEEgERIAAIpQABAEADAAIB9ABQAEAAAAgEIAAjDQgBgDAEAAID9AAQAEAAAAgEIAAhkQAAgDgEAAIj9AAQgDAAAAgEIAAiKQgBgDAEAAIEgAAQAEAAAAgEIAAhkQAAgBAAgBQAAAAgBgBQAAAAgBAAQgBAAgBgBImkAAQgBABgBAAQAAAAgBAAQAAABAAAAQgBABAAABg");
	this.shape_58.setTransform(470.4,867);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AjbEUIAAonQAAgFAFAAIGhAAQAFAAAAAFIACBdQAAAJgIAAIAAAAIkaAAQgGAAAAAGIAABpQAAAHAGAAID4AAQAFAAAAAFIAABeQAAAFgFAAIj4AAQgGAAAAAGIAAByQAAAHAHAAIEkAAQAFAAAAAFQAEAqgEAmQgBAEACAEQACADgBAEQgBAFgGAAImrAAQgFAAAAgFg");
	this.shape_59.setTransform(55.4813,729.375);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FDB913").s().p("EhAWAJOIAAybMB3cAAAQAEAAACACIJJJKQAEADgEADIpHJGQgDADgEAAgEg7IgEPIABInQAAAFAFAAIGsAAQAFAAACgFQAAgEgBgDQgCgEABgEQAEgmgEgqQAAgFgGAAIkkAAQgIAAAAgHIAAhyQAAgGAGAAID5AAQAFAAAAgFIAAheQAAgFgFAAIj5AAQgGAAAAgHIAAhpQAAgGAGAAIEbAAQAEAAACgCQADgDAAgEIgDhdQAAgFgFAAImiAAQgFAAAAAFg");
	this.shape_60.setTransform(411.9125,728.975);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFF200").s().p("AgQCqIiBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIABlOQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAABAAICAABQBDAAAwAuQAwAuAABBIAAAYQgBBBgvAuQgwAuhDAAIgBAAg");
	this.shape_61.setTransform(55.45,591.4253);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AkaEXIgCosQAAgEAFAAIERgBQB3AABWBPQBUBPABBxIAAAAIAAAUQABBwhVBQQhUBQh4ABIkRABQgFAAAAgEgAiTinIgBFOQAAAAAAABQAAAAABABQAAAAAAAAQABAAAAAAICBAAQBDABAxguQAvguABhBIAAgYQAAhBgwguQgwgvhDAAIiAAAQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAABg");
	this.shape_62.setTransform(55.5501,591.4748);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFF200").s().p("Eg3IAJOIAAybUAygAABAyggABQAPAAJBJNIABACIgBACIpHJGQgEAEgGAAgEgujgEVIkSABQgEAAAAAEIACIsQAAAEAEAAIERgBQB5gBBUhQQBVhQAAhwIAAgUQgBhxhVhPQhVhPh3AAIgBAAg");
	this.shape_63.setTransform(352.925,590.975);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AAUEkQibgIhQhxQgsg+gHhQQgIhPAghGQAghFBBgtQA+grBNgLQBMgLBIAYQBLAYAyA6QAEAEgEAEIhOBIQgEADgEgEQhDhHhfAKQhgALgnBaQgeBGAUA+QASA6A2AhQA0AhA+gHQBEgHA1g1QAEgEAEADIBNBIQAEADgDAFQhVBiiNAAIgVAAg");
	this.shape_64.setTransform(54.3279,453.3777);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#BFD730").s().p("Egt/AJOIAAybMBSsAAAQAGAAAEAEIJHJHQAEADgEAFIAAAAIpGJEQgEAEgGAAgEglmgEcQhOALg9ArQhCAtggBFQgfBGAHBPQAIBQAsA+QBQBxCbAIQCcAIBbhqQADgFgEgDIhNhIQgEgDgDAEQg1A1hEAHQg/AHg1ghQg1ghgTg6QgUg+AfhGQAnhaBhgLQBfgKBDBHQAEAEAEgDIBNhIQAEgEgEgEQgyg6hLgYQgxgQgzAAQgYAAgYADg");
	this.shape_65.setTransform(294.3875,452.975);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AiaDnQgFAAAAgFIAAg8QAAgFADgDIC6iwQAdgcAAgkQAAgpgrgMQhAgRgyA4QgEAEgFgDIhHguQgFgCAEgEQBsh2CSAxQBEAWATA+QATA8gkA9QgVAhgxAtIhLBHQgFAGAHAAICvAAQAFAAAAAFIAABNQAAAFgFAAg");
	this.shape_66.setTransform(665.7984,304.1186);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#50B848").s().p("ABRCKIlIgCQgFAAAAgFIABkHQAAgFAFAAIFIACQBHAAAyAlQAyAkAAAzIAAAaQgBAzgyAkQgyAkhFAAIgCAAg");
	this.shape_67.setTransform(96.975,279.0003);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#50B848").s().p("AhsBmQgugqAAg7QAAg7AtgrQAtgqBAAAQA/AAAuAqQAtAqABA7QAAA7gtArQguAqhAAAIAAAAQg/AAgtgqg");
	this.shape_68.setTransform(413.7747,258.95);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AFLEuQgFAAAAgFIgBlCQAAg5ghghQgdgfgsgCQgsgDgjAaQgnAcgKAzQgFAWAAAjIAAEdQAAAGgFAAIikAAQgGAAABgGIgBlGQAAhghRgSQhIgQgsAuQgnArgBBJQgCCkAACDQAAAFgFAAIiiAAQgFAAAAgFIAApGQAAgFAFAAICbAAQAFAAAAAFIAAAyQAAAGAEgEQBUhGBsACQB0ACA/BXQADAEAEgDQA5g5BPgWQBLgUBIASQBJATAtA3QAyA9ACBcQADCZgDDRQAAAFgEAAg");
	this.shape_69.setTransform(865.3942,260.3207);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Ai1GDQhAgSgwgjQgGgDAEgGIBBh1QAAgBABgBQAAgBABAAQAAAAABAAQABAAAAABIABAAQAuAgBAASQBFAUA6gGQCVgNgJieQAAgFgEADQg9AzhPALQhKALhIgaQhKgagxg4Qg0g8gMhPQgMhTAchJQAahEA6gvQA4guBKgOQBNgPBOAYQA3AQAoArQAGAGAAgJIAAg2QAAgFAFAAICdAAQAFAAAAAEQACFogCCGQgCDXikBIQhIAghZAAQhTAAhjgcgAABkNQg/AAgtAqQguArABA7QAAA8AtAqQAuApA/AAQBAAAAtgqQAtgqAAg8QAAg7gugqQgtgqg/AAIgBAAg");
	this.shape_70.setTransform(413.6052,271.5941);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#50B848").s().p("AgFD2QhkgDhEhKQhEhKAChkQADhmBIhGQBIhGBiACQBkACBFBKQBEBKgDBlQgDBmhIBGQhGBEhfAAIgFAAg");
	this.shape_71.setTransform(612.45,251.9015);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#50B848").s().p("AAAByQg1AAgmgiQgnghAAgvQABgvAmghQAmghA1AAQA2AAAnAiQAmAhAAAuQgBAwgmAhQgmAhg1AAIgBAAg");
	this.shape_72.setTransform(339.875,236.8504);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#50B848").s().p("AjcCDQgBAAgBAAQAAAAgBgBQAAAAgBgBQAAgBAAAAIAAj/QAAAAAAgBQABgBAAAAQABgBAAAAQABAAABAAIEVAAQBFAAAyAkQAxAiAAAyIAAAVQAAAygxAiQgxAkhGAAg");
	this.shape_73.setTransform(94.225,233.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgJGCQAAAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAApsQAAgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBAAIiVAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAgBAAgBIAAiKQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAAAAAIFIAAQADgBABAEIAAL9QAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_74.setTransform(281.5,251.865);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgIGCQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAApsQAAgBAAgBQgBAAAAAAQgBgBAAAAQgBAAgBAAIiUAAQgBAAgBAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIgBiKQAAgBAAgBQABAAAAgBQAAAAABAAQABAAAAAAIFIAAQABAAABAAQAAAAABAAQAAABABAAQAAABAAABIAAL9QAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_75.setTransform(238.225,251.875);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AkLE7Qikh5AJjPQAIi8CPhuQCLhrC8AWQCnAUBlByQBbBpAHCPQAHCPhSBuQhaB5ikAfQgzAKgwAAQiPAAh2hWgAikixQhIBGgDBmQgCBkBEBKQBEBKBkADQBiACBIhGQBJhGAChmQADhlhEhKQhFhKhjgCIgGAAQhfAAhGBEg");
	this.shape_76.setTransform(612.4005,251.9241);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgwGFQieghhah9Qhah/AWigQAZiyCRhfQCKhaC0AZQCTATBfBsQAFAHgGAFIAAAAQg5AzgzAxQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAgBAAQhnhih6AMQhkAKg7BJQg2BCAABbQAABaA1BDQA7BKBlAMQB/APBdhkQAEgEAEADIBtBlQAEADgDAEQhLBXh0AhQg8AQg+AAQgzAAg0gLg");
	this.shape_77.setTransform(526.3202,251.9136);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AkeFeQgFgCADgFIBAh+QADgEADACQB5BBBuguQB1gxAEiNQAAgBAAgBQAAAAgBAAQAAgBgBAAQAAABgBAAQg7AohMALQhLAMhFgVQhIgVgsgzQgxg3gFhTQgFhcAxhEQArg8BQgeQBLgcBUAGQBWAHBEAoQBjA5AlB5QAgBngQB/QgRCQhWBZQhXBaiQAQQgeAEgdAAQhtAAhigygAhojmQgmAhgBAvQAAAvAnAiQAmAhA2ABQA1AAAmgiQAmghABgvQAAgvgmgiQgnghg1AAIgCAAQg0AAgmAhg");
	this.shape_78.setTransform(341.1933,251.912);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AB0GZIgCgCIi1jhQAAgBgBAAQAAgBgBAAQAAAAgBABQAAAAgBAAIAAAAIhOBOQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAABAAIAACQQAAABgBABQAAAAAAABQgBAAAAABQgBAAgBAAIioAAQgBAAgBAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIAAsqQAAAAAAgBQAAgBAAAAQABAAAAgBQABAAABAAICoAAQABAAAAAAQABABAAAAQABAAAAABQAAABAAAAIABG9QAAABAAABQAAAAABABQAAAAABABQAAAAABAAIADgBIDujhIACgBIDJAAQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABIgBACIjuDzQgBAAAAABQAAABAAAAQAAABAAAAQAAAAABABIEHFPQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABIgCABg");
	this.shape_79.setTransform(775.5444,249.625);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("An9IxQgFAAAAgFIAAxXQAAgFAFAAIIsgBQChAABtA8QCHBKAHCVQAHCgiQBeQgEADAFACQDNBUgODRQgKCoiaBGQhtAwi/ABIlGABIjpgBgAj9BeIgCEIQAAAFAFAAIFIACQBHAAAzgkQAygkAAgzIABgbQAAgzgygkQgyglhHAAIlIgCQgFAAAAAFgAj+lnIAAD/QAAABAAABQABAAAAABQAAAAABABQABAAABAAIEVAAQBFAAAygjQAxgkAAgxIAAgWQAAgygxgjQgxgjhGAAIkVAAQgBAAgBAAQgBAAAAABQAAAAgBABQAAAAAAABg");
	this.shape_80.setTransform(97.2417,256.325);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("Aj/IHQgBAAgBgBQAAAAgBAAQAAgBAAAAQAAgBAAgBIAAAAIFowHQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAICXAAQABAAABABQAAAAAAAAQABABAAAAQAAABAAABIAAABIloQFQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAg");
	this.shape_81.setTransform(714.275,249.6);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#50B848").s().p("EhStAScMAAAgk3MCTGAAAQAFAAACADISNSXQACACgCACIyMSVQgDAEgGAAgAVkFaQArALAAApQAAAlgeAcIi7CxQgDADAAAFIAAA8QAAAFAFAAIFNAAQAFAAAAgFIAAhOQAAgFgFAAIivAAQgJAAAGgGIBLhGQAyguAUgiQAlg9gTg8QgUg9hDgXQiTgwhtB2QgDADAEADIBHAtQAFAEAFgFQAmgqAvAAQAPAAAPAEgA1sFrIAAABIhBB1QgEAGAGADQAwAjBAASQDLA7CNg/QCkhIACjXQACiHgClnQAAgEgFAAIidAAQgFAAAAAFIAAA2QAAAJgGgGQgogrg3gQQhPgYhNAPQhKAOg4AuQg6AvgaBEQgcBJAMBSQAMBQA0A8QAxA4BKAaQBIAaBLgLQBPgLA9gzQAEgDAAAFQAJCeiVANQg7AGhFgUQhAgSguggIgCAAQgBAAAAAAQAAAAgBAAQAAAAAAABQgBAAAAAAgEhLfgIsQgFAAAAAFIAARXQAAAFAFAAQC7ABF1gBQC/gBBtgxQCahFAKioQAOjRjNhVQgFgCAEgCQCQhfgHigQgHiViHhKQhtg7ihAAgAefpEIlpQHQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABIABAAICXAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAAAIFpwGQABgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAIiYgBQgBAAAAAAQgBABAAAAQgBAAAAAAQAAABAAAAgAIulfQiPBugIC7QgJDQCkB4QCdBzDMgnQCkgfBah5QBShugHiOQgHiQhbhoQhlhzingTQgggEggAAQiVAAhzBZgAjhlxQiRBfgZCxQgWChBaB+QBaB+CeAhQB1AYBsgeQB0ggBLhXQADgEgEgEIhthkQgEgEgEAEQhdBkh+gPQhmgLg7hKQg1hDAAhaQAAhcA2hCQA7hJBlgKQB5gMBnBiQABABAAAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAzgxA5gyQAGgGgFgGQhfhsiTgUQgmgFglAAQiGAAhtBHgEgg6ACwIhBB/QgCAFAFACQB8A+CNgQQCRgRBYhaQBVhYASiQQAQh/gghnQgmh5hig6QhEgohWgGQhWgHhLAdQhPAdgsA9QgwBDAFBdQAEBSAxA5QAsAyBJAVQBEAUBMgLQBMgLA8gpQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAABQgFCNh1AxQhvAvh4hBIgDgBQAAAAgBAAQAAAAAAABQgBAAAAAAQgBABAAAAgEA36gBpQAtACAdAfQAgAiABA4IABFCQAAAFAFAAICkAAQAFAAAAgFQADjQgEiaQgChbgxg9Qgtg3hKgTQhHgThMAVQhOAVg6A5QgDAEgDgEQhBhXhzgCQhtgDhTBGQgFAFAAgHIAAgxQAAgFgFAAIibAAQgFAAAAAFIAAJFQAAAFAFAAICiAAQAFAAAAgFQAAiDADijQABhKAngqQArgvBJARQBRASAABfIABFHQgBAFAGAAICkAAQAGAAAAgFIAAkdQAAgkAEgVQALgzAmgcQAggYAoAAIAHAAgEAlZAB2IAAAAIC2DiIACABIDOAAQABAAABAAQAAAAABgBQAAAAAAgBQAAAAAAgBIAAgCIkHlPQAAAAgBgBQAAAAAAAAQAAgBAAgBQABAAAAgBIDujyQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBgBgBIgCAAIjJAAIgCAAIjvDiQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBIgBgCIgBm+QAAgBAAgBQAAAAAAgBQgBAAAAAAQgBAAgBAAIioAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAABAAABIAAMqQAAABAAAAQAAABABAAQAAABABAAQAAAAABAAICoAAQABAAABAAQABAAAAgBQAAAAABgBQAAAAAAgBIAAiQQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIBOhNIACgBIACABgEgpWgGnIAACKQAAABABABQAAAAAAABQABAAAAABQABAAAAAAICVAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAABIAAJsQAAABABAAQAAABAAAAQAAABABAAQABAAAAAAICuAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAr9QAAgBAAgBQAAAAgBgBQAAAAgBAAQAAAAgBAAIlJAAQAAAAgBAAQAAAAgBAAQAAABAAAAQgBABAAABgEgwHgGnIABCKQAAABAAABQAAAAABABQAAAAABABQAAAAABAAICUAAQABAAABAAQABAAAAABQAAAAABAAQAAABAAABIAAJsQAAABAAAAQAAABABAAQAAABABAAQAAAAABAAICtAAQABAAABAAQABAAAAgBQAAAAABgBQAAAAAAgBIAAr9QAAgBAAgBQgBAAAAgBQAAAAgBAAQgBAAgBAAIlJAAQAAAAgBAAQAAAAgBAAQAAABAAAAQgBABAAABg");
	this.shape_82.setTransform(529.4125,255.975);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#00A651").s().p("AhNBlQgHAAACgGIBQjBQACgFACAFIBQDCQADAFgGAAg");
	this.shape_83.setTransform(53.8132,55.3125);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("ACyEZQgBAAgBgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgwhzQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAIj6AAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAABIgxB1QAAAAAAAAQgBABAAAAQAAAAgBAAQAAABgBAAIiCgBIgCgBIgBgDIAAgBID4orQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAIB+AAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAAAID5IrQAAABAAABQAAAAAAABQAAAAgBABQAAAAgBABIgBABgAgDiKIhQDAQgCAGAHAAICcAAQAGABgDgGIhQjBQAAgBgBgBQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAABgBAAQAAABAAABg");
	this.shape_84.setTransform(53.9417,59.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#00A651").s().p("EggTAJOIAAybMA3dAAAIJIJJQACACAAADQAAADgCADIpDJBQgFAGgHAAgA18ClQABAAAAAAQABAAAAAAQABABAAAAQAAAAAAABIAwBzQAAABAAAAQAAABABAAQAAAAABAAQAAABABAAICGABQABAAAAgBQABAAAAAAQABgBAAAAQAAgBAAgBIAAgCIj5orQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIh/AAQAAAAgBABQAAAAgBAAQAAAAAAABQgBAAAAAAIj4IrQAAABAAAAQAAABAAABQAAAAABAAQABABAAAAIABABICCABQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAAAIAxh1QAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAg");
	this.shape_85.setTransform(206.825,59);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#F68E92").ss(2,0,0,4).p("ACLCcQhZAqhUgkQhagmgKhkQgHhCAfgzQAcgvA0gWQAzgVA4ALQA8ALAtAsQAHAGAGgGIBLhGQAEgEgDgDQg1g+hTgXQhOgWhTARQhUARg+AzQhCA3gWBRQgaBeAgBZQAhBdBTAxQBZA2BugHQBqgHBbg8QAFgDAAgFIAAjbQAAgFgFAAIhuAAQgFAAAAAFIgBCYQAAAEgDACg");
	this.shape_86.setTransform(53.2038,1005.32);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#F9B890").ss(2,0,0,4).p("AhQipQgBgEAEAAIEfAAQAEAAAAgEIAAhkQAAgDgEAAImjAAQgEAAAAADIAAIqQAAAEAEAAIB9AAQAEAAAAgDIAAjEQgBgDAEAAID8AAQAEAAAAgEIAAhjQAAgEgEAAIj8AAQgDAAAAgEg");
	this.shape_87.setTransform(56.125,867.375);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#FEDC89").ss(2,0,0,4).p("ADaEFQAEgmgEgqQAAgFgFAAIkkAAQgHAAAAgHIAAhyQAAgGAGAAID4AAQAFAAAAgFIAAheQAAgFgFAAIj4AAQgGAAAAgHIAAhpQAAgGAGAAIEaAAQADAAADgCQACgDAAgEIgChdQAAgFgFAAImhAAQgFAAAAAFIAAInQAAAFAFAAIGrAAQAGAAABgFQABgEgCgDQgCgEABgEg");
	this.shape_88.setTransform(55.4813,729.375);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#FFF980").ss(2,0,0,4).p("AiSinIgBFOQAAADACAAICBAAQBDAAAxguQAwguAAhBIAAgYQAAhBgwguQgwguhDAAIiBgBQgBAAgBACg");
	this.shape_89.setTransform(55.45,591.4253);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#FFF980").ss(2,0,0,4).p("AkckVIACIsQAAAEAEAAIESgBQB3gBBVhQQBVhQgBhwIAAgUQAAhxhWhPQhVhPh3AAIkSABQgEAAAAAEg");
	this.shape_90.setTransform(55.5501,591.4748);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#DFEB98").ss(2,0,0,4).p("AjXCrQBQBxCbAIQCcAIBbhqQADgFgEgDIhNhIQgEgDgEAEQg1A1hEAHQg+AHg0ghQg2ghgSg6QgUg+AehGQAnhaBggLQBfgKBDBHQAEAEAEgDIBOhIQAEgEgEgEQgyg6hLgYQhIgYhMALQhNALg+ArQhBAtggBFQggBGAIBPQAHBQAsA+g");
	this.shape_91.setTransform(54.3279,453.3777);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACbAAQgBg7gtgqQgugrg/ABQhAAAgtAqQgtArAAA6QAAA8AuAqQAtAqA/AAQBAAAAugrQAtgqAAg7g");
	this.shape_92.setTransform(413.7747,258.95);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AgGD2QBjACBIhGQBIhGADhmQAChlhEhKQhEhKhkgCQhigChIBGQhJBGgCBmQgDBkBFBKQBEBKBjADg");
	this.shape_93.setTransform(612.45,251.9015);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACDAAQAAgugmghQgngig2AAQg1AAgmAhQgmAhgBAvQAAAvAnAhQAmAiA1AAQA2AAAmghQAmghABgwg");
	this.shape_94.setTransform(339.875,236.8996);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Aj7iEIgBEHQAAAFAFAAIFIACQBHAAAygkQAygkABgzIAAgaQAAgzgygkQgyglhHAAIlIgCQgFAAAAAFg");
	this.shape_95.setTransform(96.975,279.0003);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("Ajgh/IAAD/QAAADAEAAIEVAAQBFAAAygjQAxgjAAgyIAAgUQAAgygxgjQgxgkhGAAIkVAAQgEAAAAADg");
	this.shape_96.setTransform(94.225,233.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AAACKQACgDBJhEQAxgtAVghQAkg9gTg8QgTg+hEgWQiSgxhsB2QgEAEAFACIBHAuQAFADAEgEQAyg4BAARQArAMAAApQAAAkgdAcIi6CwQgDADAAAFIAAA8QAAAFAFAAIFLAAQAFAAAAgFIAAhNQAAgFgFAAIivAAQgHAAAFgGg");
	this.shape_97.setTransform(665.7984,304.1186);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AlPjrIAAgyQAAgFgFAAIibAAQgFAAAAAFIAAJGQAAAFAFAAICiAAQAFAAAAgFQAAiDACikQABhJAngrQAsguBIAQQBRASAABgQABBsAADaQgBAGAGAAICkAAQAFAAAAgGQAAiOAAiPQAAgjAFgWQAKgzAngcQAjgaAsADQAsACAdAfQAhAhAAA5IABFCQAAAFAFAAIClAAQAEAAAAgFQADjRgDiZQgChcgyg9Qgtg3hJgTQhIgShLAUQhPAWg5A5QgEADgDgEQg/hXh0gCQhsgChUBGQgEAEAAgGg");
	this.shape_98.setTransform(865.3942,260.3207);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACYBjQAJCeiVANQg6AGhFgUQhAgSguggQgDgBgCACIAAABIhBB1QgEAGAGADQAwAjBAASQDKA7CNg/QCkhIACjXQACiGgCloQAAgEgFAAIidAAQgFAAAAAFIAAA2QAAAJgGgGQgogrg3gQQhOgYhNAPQhKAOg4AuQg6AvgaBEQgcBJAMBTQAMBPA0A8QAxA4BKAaQBIAaBKgLQBPgLA9gzQAEgDAAAFg");
	this.shape_99.setTransform(413.6052,271.5941);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AgPjwQADAAAAADIAAJsQAAADAEAAICsAAQAEAAAAgDIAAr9QAAgDgEAAIlHAAQgEAAAAADIAACKQAAAEAEAAg");
	this.shape_100.setTransform(281.5,251.875);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AgPjwQAEAAAAADIAAJsQAAADADAAICsAAQAEAAAAgDIAAr9QAAgDgEAAIlIAAQgDAAAAADIABCKQAAAEADAAg");
	this.shape_101.setTransform(238.225,251.875);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AmmgNQgJDPCkB5QCdBzDLgnQCkgfBah5QBShugHiPQgHiPhbhpQhlhyingUQi8gWiLBrQiPBugIC8g");
	this.shape_102.setTransform(612.4005,251.9241);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AD/ibQABABABgBQAzgxA5gzQAGgGgFgGQhfhsiTgTQi0gZiKBaQiRBfgZCyQgWCgBaB/QBaB9CeAhQB1AZBsgeQB0ghBLhXQADgEgEgDIhthlQgEgDgEAEQhdBkh/gPQhlgMg7hKQg1hDAAhaQAAhbA2hCQA7hJBkgKQB6gMBnBig");
	this.shape_103.setTransform(526.3202,251.9136);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ACGAsQgECNh1AxQhuAuh5hBQgDgCgDAEIhAB+QgDAFAFACQB8A/COgRQCQgQBXhaQBWhZARiQQAQh/gghnQglh5hjg5QhEgohWgHQhUgGhLAcQhQAegrA8QgxBEAFBcQAFBTAxA3QAsAzBIAVQBFAVBLgMQBMgLA7goQADgCAAAEg");
	this.shape_104.setTransform(341.1933,251.912);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AiPArQgDACgCgCIgBgDIgBm9QAAgDgDAAIioAAQgDAAAAADIAAMqQAAAEADAAICoAAQAEAAAAgEIAAiQQgBgBABgBIBOhOQACgBACABIAAABIC1DhIACACIDOAAQADAAAAgEIAAgBIkHlPQgCgCACgCIDujzQACgBgCgDQgBgBgBAAIjJAAQAAAAgCABg");
	this.shape_105.setTransform(775.525,249.625);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("AFCgYQCQhegHigQgHiViHhKQhtg8ihAAIosABQgFAAAAAFIAARXQAAAFAFAAQC7ABF0gBQC/gBBtgwQCahGAKioQAOjRjNhUQgFgCAEgDg");
	this.shape_106.setTransform(97.2417,256.325);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#A8DCA4").ss(2,0,0,4).p("ABpoGQgCAAgBACIloQHQgBADADABIABAAICXAAQACgBABgBIFowGQABgEgDgBg");
	this.shape_107.setTransform(714.275,249.6);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#80D3A8").ss(2,0,0,4).p("AhNBlICcAAQAGAAgDgFIhQjCQgCgFgCAFIhQDBQgCAGAHAAg");
	this.shape_108.setTransform(53.8132,55.3125);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#80D3A8").ss(2,0,0,4).p("Ak6EUQgBADADABIABABICCABQADAAAAgDIAxh0QABgCACAAID6AAQADAAAAACIAwB0QAAACADAAICGABQADAAAAgEIAAgBIj5osQAAgCgDAAIh+AAQgCAAgBACg");
	this.shape_109.setTransform(53.9375,59.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,1059.8,1064), null);


(lib.subRandom3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape.setTransform(121.125,17.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_1.setTransform(117.425,17.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3E424A").s().p("AgKATQgDgCgBgDQgCgEAAgGIAAgXIAIAAIAAAXQAAAFACACQABACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgCABgEAAQgEAAgEgBg");
	this.shape_2.setTransform(113.05,17.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_3.setTransform(109.925,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_4.setTransform(108.075,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEABgGQgBgFADgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_5.setTransform(104.9,17.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAEAFQAFAEAAAHQAAAIgFADQgEAFgIAAIgKAAIAAAVgAgJAAIAKAAIAEgBIAEgDQABgCAAgEQAAgDgBgCQgBAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgEgBIgKAAg");
	this.shape_6.setTransform(100.55,16.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3E424A").s().p("AgHATQgFgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgIAAQgDAAgEgCg");
	this.shape_7.setTransform(96.25,17.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAFAAIABAEQADgDADgBQADgBAEAAQAEAAAEABQACACACADQACADABAHIAAAXg");
	this.shape_8.setTransform(92.35,17.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_9.setTransform(89.15,16.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAGgDAEAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_10.setTransform(85.95,17.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AATAbIAAgiIgQAiIgFAAIgQgiIAAAiIgIAAIAAg1IAGAAIAUArIAVgrIAGAAIAAA1g");
	this.shape_11.setTransform(80.275,16.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_12.setTransform(75.775,17.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(72.075,17.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_14.setTransform(67.925,17.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgMASQgEgDAAgFQAAgDACgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQABADAAAFIAAAaIgGAAIgBgEIgGAEIgGABQgFAAgEgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAFgBIAFgDIAAgIg");
	this.shape_15.setTransform(63.7,17.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_16.setTransform(60.925,16.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQADgCADgBQADgCACAAQAGAAAEADQAEADACAEQADAFAAAGQAAAFgDAEQgDAFgEACQgEADgFAAQgDAAgDgBIgEgDIAAAVgAgGgUIgEADIAAARIAEAEQACACAEAAQADAAADgDQACgBABgCQACgDABgEQAAgEgCgEQgBgCgDgCQgDgCgDAAIgGABg");
	this.shape_17.setTransform(57.85,18.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_18.setTransform(53.275,16.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3E424A").s().p("AgWAbIAAg1IATAAQAFAAAFACQAFACADAEQAEAEACAFQACAEAAAFQAAAFgCAFQgCAFgEAEQgDAEgFACQgFACgFAAgAgPAUIAMAAQADAAAEgCQADgBADgDIAEgGQABgEAAgEQAAgDgBgDQgCgEgCgDQgDgDgDgBQgEgCgDAAIgMAAg");
	this.shape_19.setTransform(48.425,16.525);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(43.225,17.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3E424A").s().p("AgJAaQgFgCgEgDIAEgGQADADAEABIAHACQAFAAADgCQADgCAAgEQAAgDgCgCQgCgCgFgCIgGgDQgEgBgDgBIgEgEQgCgDABgEQgBgFADgDQADgDADgCQAEgCAEAAIAGABIAFACIAGADIgFAFIgFgDIgHgBQgDAAgCACQgDACAAAEQAAADACACIAGADIAGACIAHADQADACACADQABACAAAFQAAAHgFAEQgFAEgIAAQgGAAgEgCg");
	this.shape_21.setTransform(38.9,16.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3E424A").s().p("AAAAdIAFgOIgSAAIgEAOIgIAAIAFgOIgIAAIAAgGIAKAAIAFgRIgJAAIAAgGIALAAIAEgOIAHAAIgEAOIATAAIAEgOIAHAAIgFAOIAIAAIAAAGIgKAAIgFARIAJAAIAAAGIgLAAIgEAOgAgLAJIASAAIAFgRIgSAAg");
	this.shape_22.setTransform(33.7,16.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3E424A").s().p("AgDAEQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAABABAAQAAAAABAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAg");
	this.shape_23.setTransform(27.8,18.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAHAAIABAEQACgDADgBQADgBADAAQAFAAADABQAEACACADQACADAAAHIAAAXg");
	this.shape_24.setTransform(24.7,17.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3E424A").s().p("AgJATQgDgCgDgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQADAAACgBIAEgEIAAgbIAIAAIAAAmIgGAAIgCgEIgFAEQgDABgCAAQgFAAgDgBg");
	this.shape_25.setTransform(20.2,17.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3E424A").s().p("AAWAUIAAgXQAAgFgBgCQgCgCgFAAIgGABIgEADIAAAFIAAAXIgHAAIAAgXQAAgFgCgCQgBgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQACABABADIAGgEQAEgBAFAAQAEAAADABQADACACADQACADAAAHIAAAXg");
	this.shape_26.setTransform(14.525,17.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3E424A").s().p("AAWAUIAAgXQAAgFgBgCQgCgCgFAAIgGABIgEADIAAAFIAAAXIgHAAIAAgXQAAgFgCgCQgBgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQACABABADIAGgEQAEgBAFAAQAEAAADABQADACACADQACADAAAHIAAAXg");
	this.shape_27.setTransform(7.525,17.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQADAAAEgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgEgCgDAAQgDAAgDACg");
	this.shape_28.setTransform(1.75,17.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_29.setTransform(-2.525,17.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQAEACABADQACADAAAHIAAAXg");
	this.shape_30.setTransform(-8.75,17.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_31.setTransform(-13.175,17.225);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQABgDAEgBQADgCADAAQAFAAADACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_32.setTransform(105,7.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_33.setTransform(101.725,7.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_34.setTransform(99.125,7.575);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAFgDAFAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgFAAgFgDgAgFgLQgEACgBADQgCADAAADQAAAEACADQABADAEACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_35.setTransform(95.3,7.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgDADgBQADgBADAAQAFAAAFADQAEACADAFQACAFAAAGQAAAFgCAFQgDAEgFACQgEAEgFAAQgDgBgDgBIgEgDIAAAVgAgGgUQgDABgBACIAAARQABADADABQADABADABQADAAADgCQACgCABgCQACgDAAgEQABgEgCgDQgCgEgCgCQgDgBgDAAIgGABg");
	this.shape_36.setTransform(90.85,8.45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3E424A").s().p("AgIATQgEgBgCgDIADgFIAGADIAGABQADAAACgBQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgDgBIgFgCQgFgCgDgBQgDgDABgFQgBgDACgCQACgDADgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADAAAEQAAAFgDAEQgEADgIAAQgDAAgFgCg");
	this.shape_37.setTransform(86.65,7.625);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgFABIgEAEIAAAbIgIAAIAAgmIAHAAIABAEQACgDADgBQADgBADAAQAFAAADABQAEACACADQACADAAAHIAAAXg");
	this.shape_38.setTransform(82.75,7.575);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAFgDQAEgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_39.setTransform(78.35,7.625);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_40.setTransform(75.425,7.575);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIADgBIADAGIgFACg");
	this.shape_41.setTransform(72.275,7.075);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQACgDADgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgEAAgEgCg");
	this.shape_42.setTransform(67.1,7.625);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_43.setTransform(63.275,7.625);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_44.setTransform(60.175,6.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#3E424A").s().p("AgPAUIAAgGIAVgaIgUAAIAAgHIAdAAIAAAGIgVAaIAWAAIAAAHg");
	this.shape_45.setTransform(55.6,7.625);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_46.setTransform(51.675,7.625);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgFABIgEAEIAAAbIgIAAIAAgmIAHAAIABAEQACgDADgBQADgBADAAQAFAAADABQADACADADQABADAAAHIAAAXg");
	this.shape_47.setTransform(47.3,7.575);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_48.setTransform(42.875,7.625);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_49.setTransform(39.625,7.575);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgDAEgBQADgBACAAQAFAAAFADQAEACACAFQADAFAAAGQAAAFgDAFQgDAEgEACQgEAEgFAAQgDgBgDgBIgFgDIAAAVgAgGgUIgFADIAAARQACADADABQADABADABQADAAADgCQACgCABgCQADgDAAgEQAAgEgCgDQgCgEgCgCQgDgBgDAAIgGABg");
	this.shape_50.setTransform(35.9,8.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#3E424A").s().p("AgFAJIAFgSIAGAAIgGASg");
	this.shape_51.setTransform(30.8,9.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgFABIgEAEIAAAbIgHAAIAAgmIAGAAIABAEQACgDADgBQADgBADAAQAFAAADABQAEACACADQACADAAAHIAAAXg");
	this.shape_52.setTransform(27.85,7.575);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_53.setTransform(23.425,7.625);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_54.setTransform(20.35,6.775);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#3E424A").s().p("AgIAZQgFgCgCgEQgDgGAAgFQAAgGADgEQACgFAFgCQAFgDAFAAIAGABIADABIAAgSIAIAAIAAA4IgGAAIgBgFIgFAEQgDABgEABQgEAAgEgEgAgEgEQgDACgBADQgCADAAAEIABAHIAEAFQADACADAAIAGgBIAEgEIAAgTQAAAAAAAAQgBgBAAAAQgBAAAAgBQgBAAAAAAIgGgBQgDAAgDABg");
	this.shape_55.setTransform(16.95,6.85);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_56.setTransform(13.9,6.775);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_57.setTransform(11.375,7.075);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQADAAAEgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgEgCgDAAQgDAAgDACg");
	this.shape_58.setTransform(7.6,7.625);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#3E424A").s().p("AgJATQgDgCgDgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQADAAACgBIAEgEIAAgbIAIAAIAAAmIgGAAIgCgEIgFAEQgDABgCAAQgFAAgDgBg");
	this.shape_59.setTransform(3.1,7.675);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#3E424A").s().p("AAMAdIAAgUIgGADIgGABQgEAAgFgEQgEgCgDgEQgCgFAAgFQAAgGACgFQADgFAFgCQAEgDAFAAIAGABQADABACADIABgEIAGAAIAAA4gAgEgUQgDACgCAEQgCADAAAEIACAHIAFAEQADACACAAIAGgBIAFgDIAAgTIgFgDIgGgBQgCAAgDABg");
	this.shape_60.setTransform(-1.55,8.45);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#3E424A").s().p("AgJATQgEgCgCgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_61.setTransform(-7.8,7.675);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#3E424A").s().p("AASAbIgHgQIgWAAIgGAQIgIAAIAVg1IAIAAIAWA1gAAJAFIgJgXIgIAXIARAAg");
	this.shape_62.setTransform(-12.65,6.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg copy
	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#DCDCDC").s().p("ArKBmIAAjKIUFAAIAABSICQAAIAAB4g");
	this.shape_63.setTransform(53.5,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_63).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom3, new cjs.Rectangle(-18,0,143,23.2), null);


(lib.subRandom2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape.setTransform(93.175,17.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_1.setTransform(89.675,17.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3E424A").s().p("AgKATQgDgCgBgDQgCgEAAgGIAAgXIAHAAIAAAXQABAFACACQABACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgCABgEAAQgEAAgEgBg");
	this.shape_2.setTransform(85.5,17.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_3.setTransform(82.575,16.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_4.setTransform(80.925,16.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAGgDAEAAQAGAAAFADQAEADADAEQADAFAAAFQAAAGgDAFQgDAEgEADQgFADgGAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgCACg");
	this.shape_5.setTransform(77.95,17.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAFAFQAEAEAAAHQAAAIgEADQgFAFgIAAIgLAAIAAAVgAgKAAIALAAIAEgBIADgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgEgBIgLAAg");
	this.shape_6.setTransform(73.8,16.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQABAAABAAQAAAAABABIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_7.setTransform(69.7,17.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAGAAIABAEQACgDADgBQADgBADAAQAFAAADABQADACADADQACADAAAHIAAAXg");
	this.shape_8.setTransform(66,17.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3E424A").s().p("AgDAcIAAgmIAHAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_9.setTransform(63,16.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEABgGQgBgFADgFQADgEAFgDQAEgDAFAAQAFAAAFADQAFADACAEQADAFAAAFQAAAGgDAFQgCAEgFADQgFADgFAAQgFAAgEgDgAgGgLQgCACgCADQgCADAAADQAAAEACADQACADACACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_10.setTransform(60,17.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AATAbIAAgiIgQAiIgFAAIgQgiIAAAiIgIAAIAAg1IAGAAIAUArIAVgrIAGAAIAAA1g");
	this.shape_11.setTransform(54.525,16.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_12.setTransform(50.225,17.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(46.725,17.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_14.setTransform(42.775,17.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgFAAgEgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_15.setTransform(38.75,17.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_16.setTransform(36.175,16.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQADgCADgBQADgCACAAQAFAAAFADQAEADACAEQADAFAAAGQAAAGgDAEQgDAEgEADQgEACgFABQgDgBgDgBIgFgCIAAAUgAgGgUQgDABgCADIAAARIAFADQACACAEgBQACAAADgCQADgBACgCQACgDAAgEQgBgEgBgDQgCgEgDgCQgCgBgDAAIgGABg");
	this.shape_17.setTransform(33.3,18.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_18.setTransform(28.925,16.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3E424A").s().p("AgWAbIAAg1IATAAQAFAAAFACQAFACADAEQAEAEACAFQACAEAAAFQAAAFgCAFQgCAFgEAEQgDAEgFACQgFACgFAAgAgPAUIAMAAQADAAAEgCQADgBADgDIAEgGQABgEAAgEQAAgDgBgDQgCgEgCgDQgDgDgDgBQgEgCgDAAIgMAAg");
	this.shape_19.setTransform(24.275,16.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(19.275,17.275);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3E424A").s().p("AgJAaQgEgCgFgDIAEgGQADADAEABIAHACQAFAAADgCQADgCAAgEQAAgDgCgCQgCgCgFgCIgGgDQgEgBgCgBIgFgEQgCgDABgEQgBgFADgDQADgDADgCQAEgCAEAAIAGABIAFACIAGADIgFAFIgFgDIgHgBQgDAAgDACQgCACAAAEQAAADABACIAHADIAGACIAHADQADACACADQABACAAAFQAAAHgFAEQgFAEgIAAQgFAAgFgCg");
	this.shape_21.setTransform(15.15,16.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3E424A").s().p("AAAAdIAFgOIgSAAIgFAOIgHAAIAFgOIgIAAIAAgGIAJAAIAGgRIgJAAIAAgGIALAAIAEgOIAHAAIgEAOIATAAIAEgOIAHAAIgEAOIAHAAIAAAGIgKAAIgFARIAJAAIAAAGIgLAAIgFAOgAgLAJIASAAIAGgRIgTAAg");
	this.shape_22.setTransform(10.15,16.575);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3E424A").s().p("AgDAEQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAg");
	this.shape_23.setTransform(72.65,9.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_24.setTransform(70.875,7.625);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_25.setTransform(67.375,7.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_26.setTransform(64.325,7.625);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3E424A").s().p("AgKATQgCgCgCgDQgCgEAAgGIAAgXIAHAAIAAAXQABAFACACQABACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgFAEQgDABgEAAQgEAAgEgBg");
	this.shape_27.setTransform(60.75,7.725);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAAAABABQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_28.setTransform(57.175,7.125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_29.setTransform(54.95,6.825);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEAAgGQAAgFADgFQADgEAFgDQAFgDAEAAQAGAAAFADQAEADADAEQADAFgBAFQABAGgDAFQgDAEgEADQgFADgGAAQgEAAgFgDgAgGgLQgCACgCADQgCADAAADQAAAEACADQACADACACQADACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgDACg");
	this.shape_30.setTransform(51.95,7.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3E424A").s().p("AgDAUIgPgnIAIAAIAKAdIAMgdIAHAAIgPAng");
	this.shape_31.setTransform(47.925,7.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAFgDAFAAQAFAAAFADQAFADACAEQADAFABAFQgBAGgDAFQgCAEgFADQgFADgFAAQgFAAgFgDgAgFgLQgEACgBADQgCADAAADQAAAEACADQABADAEACQACACADAAQAEAAACgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgCgCgEAAQgDAAgCACg");
	this.shape_32.setTransform(43.9,7.675);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_33.setTransform(39.825,7.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3E424A").s().p("AgMAaQgDgDAAgFQAAgDABgCQABgCADgCIAIgCIALgDIAAgCQAAgEgCgBQgCgBgFAAIgFAAIgDAEIgGgCQABgFAEgCQAFgCAFAAQAFAAADABQAEACABADQACADAAADIAAAbIgFAAIgCgEIgGAEIgGABQgFAAgEgDgAgBANQgEAAgBACQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABIAEABIAGgBIAFgEIAAgIgAgCgPIgKgNIAJAAIAIANg");
	this.shape_34.setTransform(34.1,6.825);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3E424A").s().p("AgPAUIAAgGIAVgaIgUAAIAAgHIAdAAIAAAGIgVAaIAWAAIAAAHg");
	this.shape_35.setTransform(29,7.675);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_36.setTransform(25.275,7.675);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCAEAAQADAAAEACIAGADIgEAFIgEgCIgFgBQgDAAgCABQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgHAAQgEAAgFgCg");
	this.shape_37.setTransform(21.55,7.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAGAAIABAEQACgDADgBQADgBADAAQAFAAADABQADACADADQACADAAAHIAAAXg");
	this.shape_38.setTransform(17.85,7.625);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_39.setTransform(13.625,7.675);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAFAFQAEAEAAAHQAAAIgEADQgFAFgIAAIgKAAIAAAVgAgJAAIAJAAIAGgBIACgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAAAAAIgGgBIgJAAg");
	this.shape_40.setTransform(9.6,6.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg copy
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#DCDCDC").s().p("AnLBmIAAh3IAAAAIAAhTILHAAIAABTIDQAAIAAB3g");
	this.shape_41.setTransform(50.65,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom2, new cjs.Rectangle(4.7,0.1,92,23.2), null);


(lib.subRandom1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape.setTransform(111.075,17.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_1.setTransform(107.575,17.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3E424A").s().p("AgKATQgCgCgCgDQgCgEAAgGIAAgXIAHAAIAAAXQAAAFADACQABACAFAAQACAAADgBIAEgEIAAgbIAIAAIAAAmIgGAAIgCgEIgEAEQgEABgDAAQgEAAgEgBg");
	this.shape_2.setTransform(103.4,17.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_3.setTransform(100.475,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_4.setTransform(98.825,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAGgDAEAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_5.setTransform(95.85,17.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAFAFQAEAEAAAHQAAAIgEADQgFAFgIAAIgLAAIAAAVgAgKAAIAKAAIAFgBIADgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgFgBIgKAAg");
	this.shape_6.setTransform(91.7,16.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3E424A").s().p("AgHATQgFgBgDgDIAEgFIAGADIAGABQADAAADgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgFgCQgEgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCAEAAQADAAAEACIAGADIgEAFIgFgCIgEgBQgDAAgCABQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQgBAFgEAEQgDADgHAAQgEAAgEgCg");
	this.shape_7.setTransform(87.6,17.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3E424A").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgFAAIgGABIgEAEIAAAbIgHAAIAAgmIAFAAIACAEQACgDADgBQADgBAEAAQAEAAAEABQACACACADQADADAAAHIAAAXg");
	this.shape_8.setTransform(83.9,17.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3E424A").s().p("AgDAcIAAgmIAHAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_9.setTransform(80.9,16.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgJASQgFgDgDgFQgDgEABgGQgBgFADgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAFQAAAGgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgGgLQgDACgBADQgCADAAADQAAAEACADQABADADACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_10.setTransform(77.9,17.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AATAbIAAgiIgQAiIgFAAIgQgiIAAAiIgIAAIAAg1IAGAAIAUArIAVgrIAGAAIAAA1g");
	this.shape_11.setTransform(72.425,16.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_12.setTransform(68.125,17.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(64.625,17.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_14.setTransform(60.675,17.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgEAAIgGABIgDADIgGgCQABgEAFgDQAEgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgFAAgEgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_15.setTransform(56.65,17.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_16.setTransform(54.075,16.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgCAEgBQADgCACAAQAFAAAFADQAEADACAEQADAFAAAGQAAAFgDAEQgDAFgEACQgEADgFAAQgDAAgDgBIgFgDIAAAVgAgGgUIgFADIAAARIAFAEQADACADAAQADAAACgDQADgBABgCQADgDAAgEQAAgEgCgEQgCgCgDgCQgCgCgDAAIgGABg");
	this.shape_17.setTransform(51.2,18.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_18.setTransform(46.825,16.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3E424A").s().p("AgWAbIAAg1IATAAQAFAAAFACQAFACADAEQAEAEACAFQACAEAAAFQAAAFgCAFQgCAFgEAEQgDAEgFACQgFACgFAAgAgPAUIAMAAQADAAAEgCQADgBADgDIAEgGQABgEAAgEQAAgDgBgDQgCgEgCgDQgDgDgDgBQgEgCgDAAIgMAAg");
	this.shape_19.setTransform(42.175,16.525);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(37.175,17.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3E424A").s().p("AgJAaQgFgCgEgDIAEgGQADADAEABIAHACQAFAAADgCQADgCAAgEQAAgDgCgCQgCgCgFgCIgGgDQgEgBgDgBIgEgEQgCgDABgEQgBgFADgDQADgDADgCQAEgCAEAAIAGABIAGACIAFADIgFAFIgFgDIgHgBQgDAAgDACQgCACAAAEQAAADACACIAGADIAGACIAHADQADACACADQABACAAAFQAAAHgFAEQgFAEgIAAQgGAAgEgCg");
	this.shape_21.setTransform(33.05,16.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3E424A").s().p("AAAAdIAFgOIgSAAIgFAOIgHAAIAFgOIgIAAIAAgGIAKAAIAFgRIgJAAIAAgGIALAAIAEgOIAHAAIgEAOIATAAIAEgOIAHAAIgEAOIAHAAIAAAGIgKAAIgFARIAJAAIAAAGIgLAAIgFAOgAgLAJIASAAIAGgRIgTAAg");
	this.shape_22.setTransform(28.05,16.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3E424A").s().p("AgCAEQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAABABAAQAAAAAAAAQABABAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAABQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAAAAAg");
	this.shape_23.setTransform(22.55,18.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAFgDAFAAQAFAAAFADQAFADACAEQADAFABAFQgBAGgDAFQgCAEgFADQgFADgFAAQgFAAgFgDgAgFgLQgEACgBADQgCADAAADQAAAEACADQABADAEACQACACADAAQAEAAACgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgCgCgEAAQgDAAgCACg");
	this.shape_24.setTransform(19.6,17.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_25.setTransform(16.575,16.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_26.setTransform(13.725,16.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3E424A").s().p("AgDAUIgPgnIAIAAIAKAdIAMgdIAHAAIgPAng");
	this.shape_27.setTransform(9.825,17.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_28.setTransform(4.225,17.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_29.setTransform(1.325,16.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3E424A").s().p("AgJATQgEgCgCgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_30.setTransform(-3.3,17.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAGgDAEAAQAGAAAFADQAEADADAEQADAFAAAFQAAAGgDAFQgDAEgEADQgFADgGAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgCACg");
	this.shape_31.setTransform(-7.55,17.225);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_32.setTransform(-13.475,17.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3E424A").s().p("AAKAcIAAgYQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAcIgIAAIAAg3IAIAAIAAAVQACgDADgBQADgCAEAAQAEAAAEACQADABABAEQACADAAAFIAAAZg");
	this.shape_33.setTransform(-17.65,16.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_34.setTransform(-21.725,17.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_35.setTransform(-24.725,17.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3E424A").s().p("AgMASQgEgDAAgFQAAgDACgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQABADAAAFIAAAaIgGAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAFgBIAFgDIAAgIg");
	this.shape_36.setTransform(-28.2,17.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3E424A").s().p("AAWAUIAAgXQAAgFgBgCQgCgCgFAAIgGABIgEADIAAAFIAAAXIgHAAIAAgXQAAgFgCgCQgBgCgFAAIgGABIgEAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQACABABADIAGgEQAEgBAFAAQAEAAADABQADACACADQACADAAAHIAAAXg");
	this.shape_37.setTransform(-33.325,17.175);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_38.setTransform(-40.45,17.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_39.setTransform(-43.025,16.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3E424A").s().p("AgPAUIAAgGIAVgaIgUAAIAAgHIAdAAIAAAGIgVAaIAWAAIAAAHg");
	this.shape_40.setTransform(60.45,7.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_41.setTransform(56.725,7.625);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_42.setTransform(53.85,6.775);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#3E424A").s().p("AgGAcQgDgBgDgCQgDgCgBgEIAGgCIACACIAEADIAEAAQAGAAACgCQADgDABgFIAAgEIgGACQgCACgEAAQgEAAgFgDQgEgDgDgFQgCgDAAgGQAAgGACgEQADgFAFgDQAEgCAEAAIAHABIAFACIABgCIAGAAIAAAnQAAAGgCADQgCAEgEACQgEADgGgBIgHgBgAgEgUIgFAFQgBADAAAEQAAAEABADQACACADACQADACACAAIAGgBIAFgDIAAgSIgFgDIgGgCQgCAAgDACg");
	this.shape_43.setTransform(50.65,8.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#3E424A").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_44.setTransform(46.575,6.775);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_45.setTransform(43.675,6.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#3E424A").s().p("AgDAcIAAgmIAGAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_46.setTransform(42.05,6.775);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#3E424A").s().p("AgDAUIgPgnIAIAAIAKAdIAMgdIAHAAIgPAng");
	this.shape_47.setTransform(39.375,7.625);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#3E424A").s().p("AgDAcIAAgmIAHAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_48.setTransform(36.7,6.775);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_49.setTransform(34.875,7.575);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#3E424A").s().p("AgSAdIAAg4IAGAAIABAEQACgDADgBQADgBADAAQAGAAAEADQAEACADAFQACAFAAAGQAAAFgCAFQgEAEgEACQgEAEgFAAQgDgBgDgBIgEgDIAAAVgAgGgUQgDABgBACIAAARQABADADABQADABADABQACAAADgCQADgCACgCQABgDAAgEQABgEgCgDQgBgEgEgCQgCgBgDAAIgGABg");
	this.shape_50.setTransform(31.35,8.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#3E424A").s().p("AgFAJIAEgSIAHAAIgGASg");
	this.shape_51.setTransform(28.35,9.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCAEAAQADAAAEACIAGADIgEAFIgEgCIgFgBQgDAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgHAAQgEAAgFgCg");
	this.shape_52.setTransform(26.05,7.625);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_53.setTransform(22.975,7.075);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_54.setTransform(20.575,7.575);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#3E424A").s().p("AgKATQgCgCgCgDQgCgEAAgGIAAgXIAHAAIAAAXQAAAFADACQABACAFAAQACAAADgBIAEgEIAAgbIAIAAIAAAmIgGAAIgCgEIgEAEQgEABgDAAQgEAAgEgBg");
	this.shape_55.setTransform(17,7.675);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEABgGQgBgFADgFQADgEAEgDQAFgDAFAAQAFAAAFADQAFADACAEQADAFAAAFQAAAGgDAFQgCAEgFADQgFADgFAAQgFAAgFgDgAgGgLQgCACgCADQgCADAAADQAAAEACADQACADACACQADACADAAQAEAAADgCQADgCABgDQACgDAAgEQAAgDgCgDQgBgDgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_56.setTransform(12.75,7.625);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#3E424A").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_57.setTransform(8.675,7.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQABgDAEgBQADgCADAAQAFAAADACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_58.setTransform(3.3,7.625);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_59.setTransform(0.225,7.075);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_60.setTransform(-3.225,7.625);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#3E424A").s().p("AgGAlIgDgBIABgHIADABIADAAQAAAAABAAQABAAAAAAQAAAAAAAAQAAgBAAAAQACgBAAgEIAAgrIAHAAIAAAsQAAAFgCAEQgEAEgFgBgAACgcQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAIABADIgBAEQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_61.setTransform(-6.7,7.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#3E424A").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_62.setTransform(-8.95,7.625);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_63.setTransform(-11.675,7.575);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#3E424A").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape_64.setTransform(-14.625,7.075);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#3E424A").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgDgDAAgFQAAgDACgCQABgDAEgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADAAAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_65.setTransform(-19.4,7.625);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#3E424A").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_66.setTransform(-23.025,7.625);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#3E424A").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_67.setTransform(-25.925,6.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#3E424A").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_68.setTransform(-29.425,7.575);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#3E424A").s().p("AgJATQgEgCgCgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQACAAADgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_69.setTransform(-33,7.675);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#3E424A").s().p("AgKASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAGgDAEAAQAGAAAFADQAEADADAEQADAFAAAFQAAAGgDAFQgDAEgEADQgFADgGAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQAEgCABgDQACgDAAgEQAAgDgCgDQgBgDgEgCQgDgCgDAAQgDAAgCACg");
	this.shape_70.setTransform(-37.25,7.625);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#3E424A").s().p("AgRAbIAAg1IASAAQAIAAAEAFQAFAEAAAHQAAAIgFADQgEAFgIAAIgLAAIAAAVgAgKAAIALAAIAEgBIADgDQACgCAAgEQAAgDgCgCQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgEgBIgLAAg");
	this.shape_71.setTransform(-41.4,6.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg copy
	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#DCDCDC").s().p("AspBmIAAjKIRyAAIAABSIHhAAIAAB4g");
	this.shape_72.setTransform(34.05,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_72).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom1, new cjs.Rectangle(-46.9,0,162,23.2), null);


(lib.sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgHAQQgEgCgDgFQgCgEAAgFQAAgEACgEQADgEAEgDQAEgCAEAAQAHAAAEAFQAFAEAAAIIAAABIgaAAIACAGQABACACABQADACADAAQADAAADgCIADgDIAGADIgGAGQgEACgGAAQgEAAgEgCgAAKgDQgBgEgBgCQgDgCgEAAQgCAAgDABIgEAFIAAACIASAAIAAAAg");
	this.shape.setTransform(72.2,6.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgIASIAAgiIAFAAIABADIACgCIAEgBIAFgBIgBAHIgEAAIgEACIgCACIAAAYg");
	this.shape_1.setTransform(69.55,6.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgGAZIAAgcIgGAAIAAgGIAGAAIAAgDQAAgFADgEQADgDAFAAIAFAAIACABIgBAGIgCgBIgDAAQgDAAgCACQgBABAAAEIAAACIAKAAIAAAGIgKAAIAAAcg");
	this.shape_2.setTransform(67.35,6.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAZIAAgcIgGAAIAAgGIAGAAIAAgDQAAgFADgEQADgDAFAAIAFAAIADABIgCAGIgDgBIgCAAQgEAAgBACQgBABAAAEIAAACIAKAAIAAAGIgKAAIAAAcg");
	this.shape_3.setTransform(65.25,6.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgIAQQgEgCgCgFQgDgEAAgFQAAgEADgEQACgEAEgDQAEgCAEAAQAFAAAEACQAEADACAEQADAEAAAEQAAAGgDADQgCAFgEACQgEACgFAAQgEAAgEgCgAgFgKIgEAFIgBAFIABAHIAEADQADACACAAQADAAADgCIAEgDIABgHIgBgFIgEgFQgDgBgDAAQgCAAgDABg");
	this.shape_4.setTransform(62.1,6.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEAIIADgPIAGAAIgFAPg");
	this.shape_5.setTransform(59.625,4.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgCAYIAAgvIAFAAIAAAvg");
	this.shape_6.setTransform(58.325,6.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgHAQQgEgCgDgFQgCgEAAgFQAAgEACgEQADgEAEgDQAEgCAEAAQAHAAAEAFQAFAEAAAIIAAABIgaAAIACAGQAAACADABQADACADAAQAEAAACgCIADgDIAGADIgHAGQgDACgGAAQgEAAgEgCgAAKgDQgBgEgBgCQgDgCgEAAQgDAAgCABIgEAFIAAACIASAAIAAAAg");
	this.shape_7.setTransform(54.3,6.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgHAXQgEgDgCgEQgDgEAAgFQAAgFADgDQACgEAEgDQAEgCAEAAIAFABIAEABIAAgQIAHAAIAAAwIgGAAIgBgDQgBACgDABIgGABQgEAAgDgCgAgEgDIgDAEQgCACAAAEIABAGIAEAEQADACACAAIAFgBIAEgDIAAgQQAAAAgBgBQAAAAAAAAQgBgBgBAAQAAAAgBAAIgFgBIgFABg");
	this.shape_8.setTransform(50.425,6.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgHARQgEgBgBgCIACgFIAGACIAEACIAGgCQAAAAAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgCIgEgCIgEgDQgEAAgDgCQgCgCAAgFIABgEQABgCAEgCQADgBACAAIAHABIAFADIgEAFIgDgCIgFgBIgDABQgBAAAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABIADACIAFABQAEABACACQACADABADQgBAFgDADQgDACgHAAIgHgBg");
	this.shape_9.setTransform(45.7,6.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgCAYIAAgvIAFAAIAAAvg");
	this.shape_10.setTransform(43.575,6.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgCAZIAAgiIAGAAIAAAigAgCgQIgBgDQAAgBAAAAQAAgBAAAAQAAAAAAgBQABAAAAAAIACgCQABAAAAAAQAAAAABABQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAABIgCADQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCgBg");
	this.shape_11.setTransform(42.1,6.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKAQQgDgDAAgEIABgFIADgDIAHgBIAKgCIAAgCQAAgFgCgBQgCgBgEAAIgEABQgBAAAAAAQAAABgBAAQAAAAAAABQAAAAgBABIgFgCQABgEAEgCQADgCAFAAQAEAAADABQADABACADQABADAAADIAAAXIgFAAIgBgDIgGADIgFABQgEAAgDgCgAgBAEIgFACIgBADQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIAEACIAEgCIAFgDIAAgHg");
	this.shape_12.setTransform(39.625,6.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgDAUQgCgDAAgFIAAgSIgHAAIAAgFIAHAAIAAgLIAFAAIAAALIAMAAIAAAFIgMAAIAAAPIABAGQAAABABAAQAAAAABAAQAAABABAAQAAAAABAAIADAAIADgBIACAFIgEABIgFABQgEAAgDgDg");
	this.shape_13.setTransform(36.775,6.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgHAXQgEgCgCgEQgDgEAAgFQAAgGADgCQACgEAEgDQADgCAFAAQAHgBAFAFQAEAEAAAIIAAACIgaAAIACAFQABACACACQADABADAAQADAAACgBIAFgEIAEAEIgFAFQgEADgGAAQgEAAgEgDgAAKADQgBgDgCgBQgCgDgEAAQgCAAgDACIgEADIgBACIATAAIAAAAgAgDgNIAIgMIAIAAIgKAMg");
	this.shape_14.setTransform(33.75,6.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgHAXQgEgDgCgEQgDgEAAgFQAAgFADgDQACgEAEgDQAEgCAEAAIAFABIAEABIAAgQIAHAAIAAAwIgGAAIgBgDQgBACgDABIgGABQgEAAgDgCgAgEgDQgCACgBACQgCACAAAEIABAGIAEAEQADACACAAIAFgBIAEgDIAAgQQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAAAgBAAIgFgBIgFABg");
	this.shape_15.setTransform(29.875,6.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgIASIAAgiIAFAAIABADIADgCIADgBIAFgBIAAAHIgFAAIgDACIgDACIAAAYg");
	this.shape_16.setTransform(25.75,6.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgCAZIAAgiIAFAAIAAAigAgCgQIgCgDQAAgBABAAQAAgBAAAAQAAAAAAgBQABAAAAAAIACgCQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQAAAAAAABIgBADQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAIgCgBg");
	this.shape_17.setTransform(23.7,6.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgIAQQgEgCgCgFQgDgEAAgFQAAgEADgEQACgEAEgDQAEgCAEAAQAFAAAEACQAEADACAEQADAEAAAEQAAAGgDADQgCAFgEACQgEACgFAAQgEAAgEgCgAgFgKIgEAFIgBAFIABAHIAEADQACACADAAQADAAADgCIAEgDIABgHIgBgFIgEgFQgDgBgDAAQgDAAgCABg");
	this.shape_18.setTransform(21.05,6.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgDAXIgRgtIAHAAIANAmIAOgmIAHAAIgRAtg");
	this.shape_19.setTransform(17.025,6.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAAADIgFAKIgEgEIAIgIIgMgBIACgFIALAEIgCgLIAFAAIgCAMIALgFIACAFIgMABIAIAJIgFADg");
	this.shape_20.setTransform(12.025,5.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub3, new cjs.Rectangle(8.5,0,77.5,12.4), null);


(lib.sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAHAAIABAEQACgDADgBQADgBADAAQAFAAADABQAEACACADQABADAAAHIAAAXg");
	this.shape.setTransform(48.75,7.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAFgDAFAAQAFAAAFADQAFADACAEQADAFABAFQgBAGgDAFQgCAEgFADQgFADgFAAQgFAAgFgDgAgFgLQgEACgBADQgCADAAADQAAAEACADQABADAEACQACACADAAQAEAAADgCQACgCACgDQACgDAAgEQAAgDgCgDQgCgDgCgCQgDgCgEAAQgDAAgCACg");
	this.shape_1.setTransform(44.35,7.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgDAcIAAgmIAHAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_2.setTransform(41.3,6.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQACgDADgBQADgCADAAQAEAAAEACIAGADIgEAFIgEgCIgGgBQgCAAgCABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgEAAgEgCg");
	this.shape_3.setTransform(38.75,7.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_4.setTransform(36.125,7.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_5.setTransform(32.575,7.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgDAUIgPgnIAIAAIAKAdIAMgdIAHAAIgPAng");
	this.shape_6.setTransform(28.625,7.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAAEABQADACABADQACADAAAHIAAAXg");
	this.shape_7.setTransform(22.85,7.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAGgDAEAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_8.setTransform(18.45,7.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_9.setTransform(15.375,6.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_10.setTransform(12.475,7.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQABgDAEgBQADgCADAAQAFAAADACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_11.setTransform(8.7,7.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAAADIgGAMIgFgEIAKgKIgOgBIADgGIALAFIgBgNIAFAAIgCANIANgFIACAGIgOABIAJAKIgFAEg");
	this.shape_12.setTransform(3.75,5.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub2, new cjs.Rectangle(0,0,71.4,13.6), null);


(lib.sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQABABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEAAIADgBIADAGIgFACg");
	this.shape.setTransform(85.725,7.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAADABQAEACABADQACADAAAHIAAAXg");
	this.shape_1.setTransform(82.15,7.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgMASQgDgDgBgFQABgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQACADAAAFIAAAaIgHAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_2.setTransform(77.9,7.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgSAdIAAg4IAGAAIABAEQADgDADgBQADgBACAAQAGAAAEADQAEACACAFQADAFAAAGQAAAFgDAFQgDAEgEACQgEAEgFAAQgDgBgDgBIgEgDIAAAVgAgGgUIgEADIAAARQACADACABQACABAEABQADAAADgCQACgCABgCQACgDABgEQAAgEgCgDQgBgEgDgCQgDgBgDAAIgGABg");
	this.shape_3.setTransform(74.05,8.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgDAcIAAgmIAGAAIAAAmgAgDgTQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_4.setTransform(70.85,6.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgIASQgEgDgDgFQgDgEAAgGQAAgFADgFQADgEAEgDQAFgDAEAAQAHAAAEADQAFADACAFIgHADQgBgDgDgCQgDgCgEAAQgDAAgCACQgDACgCADQgBADAAADQAAAEABADQACADADACQADACACAAQAFAAADgCIAEgFIAGAEQgDAEgEADQgFADgGAAQgEAAgFgDg");
	this.shape_5.setTransform(68.075,7.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgDAcIAAgmIAGAAIAAAmgAgCgTQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_6.setTransform(65.2,6.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAFAaQgFAAgDgDQgDgEAAgGIAAgUIgIAAIAAgGIAIAAIAAgMIAGAAIAAAMIANAAIAAAGIgNAAIAAARIABAHQAAABABAAQAAABABAAQAAAAABAAQABAAAAAAIAEAAIADgBIADAGIgFACg");
	this.shape_7.setTransform(62.825,7.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_8.setTransform(60.375,7.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgMASQgEgDAAgFQAAgDACgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgFAAIgFABIgDADIgGgCQABgEAEgDQAFgCAFAAQAFAAADACQAEABACADQABADAAAFIAAAaIgGAAIgBgEIgGAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAFABIAFgBIAFgDIAAgIg");
	this.shape_9.setTransform(56.85,7.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgSAdIAAg4IAGAAIABAEQACgDAEgBQADgBACAAQAFAAAFADQAEACACAFQADAFAAAGQAAAFgDAFQgDAEgEACQgEAEgFAAQgDgBgDgBIgFgDIAAAVgAgGgUIgFADIAAARQACADADABQADABADABQADAAACgCQADgCABgCQADgDAAgEQAAgEgCgDQgCgEgDgCQgCgBgDAAIgGABg");
	this.shape_10.setTransform(53,8.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgJATQgDgCgDgDQgBgEAAgGIAAgXIAIAAIAAAXQAAAFABACQACACAFAAQADAAACgBIAFgEIAAgbIAHAAIAAAmIgGAAIgBgEIgGAEQgDABgCAAQgFAAgDgBg");
	this.shape_11.setTransform(46.75,7.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgMASQgDgDAAgFQAAgDABgCQABgDADgBIAIgCIALgCIAAgDQAAgEgCgBQgCgCgEAAIgGABIgCADIgHgCQABgEAFgDQAEgCAFAAQAFAAAEACQADABABADQADADAAAFIAAAaIgHAAIAAgEIgHAEIgGABQgGAAgDgDgAgBAEQgEABgCABQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAIAFABIAEgBIAGgDIAAgIg");
	this.shape_12.setTransform(42.6,7.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_13.setTransform(38.775,7.625);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgIATQgEgBgCgDIADgFIAGADIAGABQADAAACgBQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgDgBIgGgCQgEgCgDgBQgDgDABgFQgBgDACgCQACgDADgBQADgCADAAQAFAAADACIAGADIgEAFIgFgCIgFgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQADADgBAEQAAAFgDAEQgEADgIAAQgDAAgFgCg");
	this.shape_14.setTransform(35,7.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgIAaQgFgCgDgFQgCgFAAgGQAAgFACgEQADgFAFgCQAEgDAFAAQAIAAAFAFQAFAFAAAIIAAADIgeAAIACAFQACAEADABQADACADAAQAEAAADgCQADgBABgDIAGAEQgDAEgEACQgEADgHAAQgEAAgFgDgAALAEQAAgEgCgBQgDgDgFAAQgDAAgDABIgEAEIgBADIAVAAIAAAAgAgDgPIAJgNIAJAAIgLANg");
	this.shape_15.setTransform(31.325,6.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgJAUIAAgmIAGAAIABAEIADgDIAEgCIAFAAIAAAHIgFABIgEABIgDADIAAAbg");
	this.shape_16.setTransform(28.225,7.575);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAKAUIAAgXQAAgFgCgCQgCgCgGAAIgEABIgFAEIAAAbIgIAAIAAgmIAGAAIABAEQADgDADgBQADgBAEAAQAEAAAEABQADACABADQACADAAAHIAAAXg");
	this.shape_17.setTransform(22.85,7.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgKASQgEgDgDgFQgCgEgBgGQABgFACgFQADgEAEgDQAGgDAEAAQAFAAAGADQAEADACAEQAEAFAAAFQAAAGgEAFQgCAEgEADQgGADgFAAQgEAAgGgDgAgFgLQgDACgCADQgCADAAADQAAAEACADQACADADACQACACADAAQADAAADgCQADgCACgDQACgDAAgEQAAgDgCgDQgCgDgDgCQgDgCgDAAQgDAAgCACg");
	this.shape_18.setTransform(18.45,7.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_19.setTransform(15.375,6.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgIASQgFgDgDgFQgCgEAAgGQAAgFACgFQADgEAFgDQAEgDAFAAQAIAAAFAFQAFAFAAAKIAAACIgeAAIACAFQACADADACQADACADAAQAEAAADgCQADgCABgCIAGADQgDAEgEADQgEADgHAAQgEAAgFgDgAALgEQAAgEgCgCQgDgDgFAAQgDAAgDACIgEAFIgBACIAVAAIAAAAg");
	this.shape_20.setTransform(12.475,7.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgIATQgEgBgDgDIAEgFIAGADIAGABQAEAAACgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgBgDQgBgBgEgBIgEgCQgFgCgDgBQgCgDAAgFQAAgDABgCQABgDAEgBQADgCADAAQAFAAADACIAGADIgEAFIgEgCIgGgBQgDAAgBABQAAABgBAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIAEADIAFABIAIAEQACADABAEQAAAFgFAEQgDADgIAAQgDAAgFgCg");
	this.shape_21.setTransform(8.7,7.625);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAAADIgGAMIgFgEIAKgKIgOgBIADgGIALAFIgBgNIAFAAIgCANIANgFIACAGIgOABIAJAKIgFAEg");
	this.shape_22.setTransform(3.75,5.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub1, new cjs.Rectangle(0,0,98.3,13.6), null);


(lib.roadcolor_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhIMAIVUAAAAAEAi1gIDMAizgICQEGg2hYhRQgagYg7gbQg0gUACgBQAJgEvGkXQjuhiBfg8QAvgfBggKUAAEgACAsggF9UAr+gF5AAlgAGIigA9UAAIgADg+tAMCQkeAzB1AuQA8AYB1AQQAAADOyDVIOxDVQDEA9hhBgQgeAdg5AgQgyAZAAABUAAAAADgl7ARbUgl7ARbAAAAADMggjAAVg");
	mask.setTransform(457.55,353.825);

	// Layer_1
	this.instance = new lib.roadcolor();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roadcolor_1, new cjs.Rectangle(0,159,900,381), null);


(lib.road_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhIMAIVUAAAAAEAi1gIDMAizgICQEGg2hYhRQgagYg7gbQg0gUACgBQAJgEvGkXQjuhiBfg8QAvgfBggKUAAEgACAsggF9UAr+gF5AAlgAGIigA9UAAIgADg+tAMCQkeAzB1AuQA8AYB1AQQAAADOyDVIOxDVQDEA9hhBgQgeAdg5AgQgyAZAAABUAAAAADgl7ARbUgl7ARbAAAAADMggjAAVg");
	mask.setTransform(457.55,353.825);

	// Layer_1
	this.instance = new lib.road();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.road_1, new cjs.Rectangle(0,159,900,381), null);


(lib.offer2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// layer_1 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgFADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape.setTransform(53.1,123.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_1.setTransform(48.925,123.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_2.setTransform(46.15,122.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIACAFIACgDIAGgCIAFgBIAAAJIgGAAIgFACIgCADIAAAfg");
	this.shape_3.setTransform(44.15,123.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_4.setTransform(40.175,124.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQAEgFAFgDQAEgDAGAAQAJAAAGAFQAGAGgBALIAAACIghAAIACAGQABADAEACQADACAEAAQAFAAADgCIAFgEIAGAEQgDAEgEADQgFADgIAAQgFAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgEADgBADIgBADIAYAAIAAAAg");
	this.shape_5.setTransform(35.15,123.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIACAFIACgDIAGgCIAGgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_6.setTransform(31.75,123.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgEgFAAgHQAAgGAEgFQADgFAEgDQAGgDAFAAQAJAAAGAFQAFAGAAALIAAACIghAAIACAGQABADAEACQAEACADAAQAFAAADgCIAFgEIAGAEQgDAEgFADQgFADgGAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgEADgBADIgCADIAZAAIAAAAg");
	this.shape_7.setTransform(25.75,123.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgDAFAAIAHABIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDACQgEABgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_8.setTransform(20.775,122.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIACAFIAGgEQADgCADAAQAGAAADACQAEABACAEQACAEAAAHIAAAbg");
	this.shape_9.setTransform(14.1,123.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgKAUQgGgDgDgFQgDgFAAgHQAAgGADgFQADgFAGgDQAEgDAGAAQAGAAAFADQAGADADAFQADAFAAAGQAAAHgDAFQgDAFgGADQgFADgGAAQgGAAgEgDgAgHgNQgDADgBADQgCADAAAEQAAAEACAEQABADADACQAEACADAAQAEAAADgBQADgCADgEQACgEAAgEQAAgDgCgEQgDgDgDgCQgDgDgEAAQgDAAgEACg");
	this.shape_10.setTransform(9.15,123.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_11.setTransform(5.7,122.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_12.setTransform(3.075,122.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_13.setTransform(0.5,122.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgDAFAAIAHABIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDACQgEABgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_14.setTransform(-3.075,122.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgFAAQgDAAgDABQgDACgCADIAAAfIgIAAIAAgsIAGAAIACAFIAFgEQAEgCADAAQAFAAAEACQAEABADAEQABAEAAAHIAAAbg");
	this.shape_15.setTransform(-7.8,123.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgKAUQgGgDgDgFQgDgFAAgHQAAgGADgFQADgFAGgDQAFgDAFAAQAGAAAFADQAFADAEAFQADAFAAAGQAAAHgDAFQgEAFgFADQgEADgHAAQgFAAgFgDgAgHgNQgDADgCADQgCADAAAEQAAAEACAEQACADADACQADACAEAAQAEAAAEgBQACgCACgEQACgEAAgEQAAgDgCgEQgCgDgCgCQgEgDgEAAQgEAAgDACg");
	this.shape_16.setTransform(-12.75,123.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgDgFAAgHQAAgGADgFQADgFAFgDQAFgDAFAAQAIAAAEADQAFADADAGIgHADIgFgGQgDgCgFAAQgDAAgDACIgFAGQgCADAAAEQAAAEADAEQABADADACQAEACADAAQAFAAADgCQADgCACgDIAGAFQgDAEgFADQgFADgHAAQgFAAgFgDg");
	this.shape_17.setTransform(-17.35,123.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_18.setTransform(-23.425,123.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQACAEAAAHIAAAbg");
	this.shape_19.setTransform(-27.65,123.325);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgOAUQgDgDAAgGQgBgDACgDIAFgEIAJgCIAMgDIAAgDQAAgEgCgCQgDgCgFAAIgGABQgCABAAADIgIgCQABgGAFgCQAFgCAFAAQAGAAAEABQAEACADADQABAEAAAFIAAAdIgHAAIgBgEQgDADgEABQgDABgEAAQgFAAgFgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_20.setTransform(-32.45,123.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgKAdQgFgCgFgEIAEgGIAIAEQAEACAEAAQAGAAADgCQADgCAAgFQAAgDgCgCQgCgDgFgCIgIgCIgHgDQgDgCgCgDQgCgDAAgFQAAgFADgEQADgDAEgDQAEgBAFAAIAHAAIAGADIAGADIgFAHQgDgDgDgBQgDgBgFgBQgDAAgDACQgDACAAAFQAAAEACACQACABAEACIAIADIAIADIAFAFQABADAAAFQAAAIgFAFQgGAEgJAAQgGAAgFgCg");
	this.shape_21.setTransform(-36.825,122.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgDAdQAAAAgBgBQAAAAAAAAQAAgBAAgBQAAAAgBgBQABAAAAgBQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQAAAAAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBgAgCAOIgCgsIAIAAIgBAsg");
	this.shape_22.setTransform(59.95,111.825);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_23.setTransform(55.075,112.575);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQADAEAAAHIAAAbg");
	this.shape_24.setTransform(50.85,112.525);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgGABQgCABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACACADQABAEAAAFIAAAdIgHAAIgBgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_25.setTransform(46.05,112.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAMAeIAAgKIggAAIAAgGIAZgrIAJAAIgYApIAWAAIAAgMIAJAAIAAAeg");
	this.shape_26.setTransform(39.65,111.775);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_27.setTransform(33.825,111.975);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_28.setTransform(29.8,112.525);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgFABQgDABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACABADQACAEAAAFIAAAdIgGAAIgCgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQABABAEAAIAGgBIAGgEIAAgJg");
	this.shape_29.setTransform(25,112.575);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgDAFAAIAHABIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDABQgEACgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_30.setTransform(20.375,111.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgBgCgHAAQgCAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQACAEABAHIAAAbg");
	this.shape_31.setTransform(15.65,112.525);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgFADQgEADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_32.setTransform(10.8,112.575);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_33.setTransform(6.175,113.525);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgKAdQgFgCgFgEIAEgGIAIAEQAEACAEAAQAGAAADgCQADgCAAgFQAAgDgCgCQgCgDgFgCIgIgCIgHgDQgDgCgCgDQgCgDAAgFQAAgFADgEQADgDAEgDQAEgBAFAAIAHAAIAGADIAGADIgFAHQgDgDgDgBQgDgBgFgBQgDAAgDACQgDACAAAFQAAAEACACQACABAEACIAIADIAIADIAFAFQABADAAAFQAAAIgFAFQgGAEgJAAQgGAAgFgCg");
	this.shape_34.setTransform(-0.825,111.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgTAeIAAg7IAnAAIAAAIIgeAAIAAARIAaAAIAAAHIgaAAIAAATIAeAAIAAAIg");
	this.shape_35.setTransform(-5.325,111.775);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgDAeIAAgzIgUAAIAAgIIAvAAIAAAIIgUAAIAAAzg");
	this.shape_36.setTransform(-10.45,111.775);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AALAeIgQgXIgHAAIAAAXIgIAAIAAg7IAUAAQAFAAAEACQAFADACAEQACAEAAAFQAAAFgCAFQgCADgFACIgFACIASAYgAgMAAIALAAQAFAAACgDQADgCAAgGQAAgFgDgDQgCgDgFAAIgLAAg");
	this.shape_37.setTransform(-15.15,111.775);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgTAeIAAg7IAnAAIAAAIIgeAAIAAARIAaAAIAAAHIgaAAIAAATIAeAAIAAAIg");
	this.shape_38.setTransform(-20.225,111.775);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgSAeIAAg7IAlAAIAAAIIgdAAIAAASIAaAAIAAAHIgaAAIAAAag");
	this.shape_39.setTransform(-24.975,111.775);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgSAeIAAg7IAlAAIAAAIIgdAAIAAASIAaAAIAAAHIgaAAIAAAag");
	this.shape_40.setTransform(-29.675,111.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgLAdQgGgDgEgEQgEgFgDgFQgCgGAAgGQAAgFACgHQADgFAEgEQAEgFAGgCQAFgCAGAAQAGAAAHACQAFACAEAFQAFAEABAGQADAFAAAGQAAAHgDAFQgBAFgFAFQgEAEgFADQgHACgGAAQgGAAgFgCgAgLgSQgEADgDAEQgDAFAAAGQAAAFADAGQADAFAEADQAFAEAGgBQAGAAAGgCQAFgEACgFQADgFAAgGQAAgFgDgFQgCgFgFgDQgGgEgGAAQgGAAgFAEg");
	this.shape_41.setTransform(-35.75,111.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQAEgFAEgDQAFgDAGAAQAJAAAGAFQAGAGAAALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgGADgHAAQgFAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_42.setTransform(41.1,101.775);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgDgFAAgHQAAgGADgFQADgFAFgDQAFgDAFAAQAIAAAEADQAFADADAGIgHADIgFgGQgDgCgFAAQgDAAgDACIgFAGQgCADAAAEQAAAEADAEQABADADACQAEACADAAQAFAAADgCQADgCACgDIAGAFQgDAEgFADQgFADgHAAQgFAAgFgDg");
	this.shape_43.setTransform(36.65,101.775);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQADAEAAAHIAAAbg");
	this.shape_44.setTransform(31.95,101.725);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgGABQgCABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACABADQACAEAAAFIAAAdIgHAAIgBgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_45.setTransform(27.15,101.775);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_46.setTransform(23.475,101.175);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_47.setTransform(20.025,101.775);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_48.setTransform(17.25,100.825);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_49.setTransform(14.475,101.775);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_50.setTransform(10.825,101.775);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AAUAeIgHgRIgZAAIgHARIgJAAIAYg7IAJAAIAYA7gAAKAFIgKgZIgJAZIATAAg");
	this.shape_51.setTransform(6.075,100.975);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgRAdQgFgCgCgEQgDgDAAgGQAAgEACgDIAGgGIAEgBIgFgGQgDgEAAgGQAAgDACgEQACgDAEgCQAEgCAGAAQAFAAADABQADADACADQACADAAAEQAAAFgCADQgCADgEACIgFADIANANIABgDQACgEABgGIAHAAQgBAKgEAHIAAABIAMAMIgKAAIgHgGIgEAEQgGADgHAAQgGAAgFgCgAgLAEIgGAFQgCACAAADQAAAEABACIAFACQADACAEAAQAEAAACgCIAGgDIgQgQgAgLgXIgDADIgBAFQAAADADADIAEAFIAEgCQADgCABgCQADgCAAgEQAAgDgDgDQgBgCgEAAIgGABg");
	this.shape_52.setTransform(-1.575,101);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQAEgFAFgDQAEgDAGAAQAJAAAGAFQAGAGgBALIAAACIghAAIACAGQABADAEACQADACAEAAQAFAAADgCIAFgEIAGAEQgDAEgEADQgGADgHAAQgFAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgEADgBADIgBADIAYAAIAAAAg");
	this.shape_53.setTransform(-8.95,101.775);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgDAgIAAgsIAIAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_54.setTransform(-12.25,100.825);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgEAZQgDgDAAgHIAAgXIgJAAIAAgHIAJAAIAAgNIAHAAIAAANIAPAAIAAAHIgPAAIAAATIABAIQACACADAAIAEAAIAEgBIADAHIgGACIgGAAQgGAAgDgEg");
	this.shape_55.setTransform(-14.875,101.175);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgDgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAHgEQADgCAEAAQAEAAAFACQADABACAEQADAEAAAHIAAAbg");
	this.shape_56.setTransform(-18.9,101.725);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgNAUQgFgDAAgGQABgDABgDIAFgEIAJgCIAMgDIAAgDQAAgEgDgCQgBgCgGAAIgGABQgCABgBADIgHgCQABgGAFgCQAFgCAFAAQAHAAADABQAFACABADQACAEAAAFIAAAdIgHAAIgBgEQgEADgDABQgDABgDAAQgHAAgDgDgAgBAFIgHACQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_57.setTransform(-23.7,101.775);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIACAFIACgDIAGgCIAGgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_58.setTransform(-26.75,101.725);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgOAUQgDgDAAgGQgBgDACgDIAEgEIAJgCIANgDIAAgDQAAgEgCgCQgCgCgFAAIgHABQgBABgBADIgIgCQABgGAFgCQAFgCAGAAQAFAAAEABQAFACACADQACAEAAAFIAAAdIgIAAIgBgEQgDADgEABQgDABgEAAQgFAAgFgDgAgBAFIgGACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQACABADAAIAGgBIAGgEIAAgJg");
	this.shape_59.setTransform(-30.75,101.775);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgJAdQgFgDgFgEQgEgFgCgFQgDgGAAgGQAAgGADgFQACgGAEgEQAFgFAFgCQAGgCAGAAQAIAAAGADQAHADAEAGIgHAFQgDgEgEgDQgFgCgGAAQgGAAgFAEQgFADgDAEQgDAGAAAFQAAAGADAFQADAFAFAEQAFACAGAAQAGABAFgDIAGgFIAAgKIgRAAIAAgGIAaAAIAAAUQgFAFgGAEQgHADgIAAQgGAAgGgCg");
	this.shape_60.setTransform(-35.975,101);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AAZAXIAAgaQAAgGgCgDQgCgCgFAAQgFAAgCABIgFAEIAAAFIAAAbIgIAAIAAgaQAAgGgCgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQADgCAFAAQAFAAADACQADABABADIAHgEQAEgCAGAAQAEAAAEACQADABACAEQACAEABAHIAAAbg");
	this.shape_61.setTransform(48.9,90.925);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AAIAgIgSgVIAAAVIgIAAIAAg+IAIAAIAAAiIARgQIAKAAIgTAUIAVAYg");
	this.shape_62.setTransform(43.225,90.05);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgLAbQgFgEgCgGQgDgIAAgJQAAgIADgHQACgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQADAHAAAIQAAAJgDAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGABAKQgBALAEAGQAEAGAFgBQAHABADgGQAEgGAAgLQAAgKgEgGQgDgGgHAAQgFAAgEAGg");
	this.shape_63.setTransform(36.15,90.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgLAbQgFgEgDgGQgCgIAAgJQAAgIACgHQADgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHABAIQgBAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGABAKQgBALAEAGQAEAGAFgBQAHABADgGQADgGABgLQgBgKgDgGQgDgGgHAAQgFAAgEAGg");
	this.shape_64.setTransform(30.85,90.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgLAbQgFgEgDgGQgCgIAAgJQAAgIACgHQADgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHABAIQgBAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgDAGAAAKQAAALADAGQAEAGAFgBQAGABAEgGQADgGABgLQgBgKgDgGQgEgGgGAAQgFAAgEAGg");
	this.shape_65.setTransform(25.55,90.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgLAbQgFgEgCgGQgEgIAAgJQAAgIAEgHQACgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHAAAIQAAAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgEAGAAAKQAAALAEAGQAEAGAFgBQAHABADgGQAEgGgBgLQABgKgEgGQgDgGgHAAQgFAAgEAGg");
	this.shape_66.setTransform(18.3,90.2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AANAeIAAgKIghAAIAAgGIAZgrIAJAAIgYApIAXAAIAAgMIAIAAIAAAeg");
	this.shape_67.setTransform(13.2,90.175);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgPAnIAWhNIAJAAIgXBNg");
	this.shape_68.setTransform(9.425,90.825);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_69.setTransform(6.225,90.975);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_70.setTransform(3.45,90.025);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgKAUQgGgDgDgFQgDgFAAgHQAAgGADgFQADgFAGgDQAEgDAGAAQAGAAAFADQAGADADAFQADAFAAAGQAAAHgDAFQgDAFgGADQgFADgGAAQgGAAgEgDgAgHgNQgDADgBADQgCADgBAEQABAEACAEQABADADACQADACAEAAQAEAAAEgBQACgCACgEQADgEAAgEQAAgDgDgEQgCgDgCgCQgEgDgEAAQgEAAgDACg");
	this.shape_71.setTransform(0.05,90.975);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AAZAXIAAgaQAAgGgCgDQgCgCgFAAQgFAAgDABIgEAEIAAAFIAAAbIgHAAIAAgaQgBgGgCgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQACABABADIAHgEQAEgCAFAAQAFAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_72.setTransform(-6.25,90.925);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgKAdQgFgCgDgFQgCgEAAgFQAAgFACgEQADgEAEgBQgDgCgBgDQgCgEAAgEQAAgFACgEQACgDAFgCQAEgCAEAAQAFAAAEACQAEACADADQACAEAAAFQAAAEgCAEQgCADgDACQAFABACAEQADAEAAAFQAAAFgDAEQgCAFgFACQgFACgGAAQgFAAgFgCgAgGADQgDACgBACQgCACAAADQAAAGAEADQADADAFAAQAFAAAEgDQAEgDAAgGQAAgDgCgCIgFgEQgCgCgEABQgDgBgDACgAgGgVQgDADAAAEQAAAEADADQADADADgBQAEABADgDQACgDAAgEQAAgEgCgDQgDgCgEAAQgDAAgDACg");
	this.shape_73.setTransform(-14.525,90.2);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AANAeIAAgKIghAAIAAgGIAZgrIAJAAIgYApIAXAAIAAgMIAIAAIAAAeg");
	this.shape_74.setTransform(-19.45,90.175);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgZAeIAAg7IAVAAQAGAAAFACQAGADAEAEQAEAEADAFQACAGAAAFQAAAGgCAGQgDAFgEAEQgEAFgGACQgFACgGAAgAgRAWIANAAQAEAAAEgBIAHgFIAEgHQACgEAAgFQAAgDgCgEIgEgHQgDgEgEgBQgEgCgEAAIgNAAg");
	this.shape_75.setTransform(-26.475,90.175);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgSAeIAAg7IAIAAIAAAzIAdAAIAAAIg");
	this.shape_76.setTransform(-31.825,90.175);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgSAeIAAg7IAIAAIAAAzIAdAAIAAAIg");
	this.shape_77.setTransform(-36.475,90.175);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgFAdQgFgDgEgEQgFgFgCgFIAAgBIgHAAIAAgIIAGAAIAAgDIAAgDIgGAAIAAgHIAHAAIAAgBQACgGAFgEQAEgFAFgCQAFgCAFAAQAIAAAFADQAGADAFAGIgHAFQgDgEgEgDQgFgCgFAAQgFAAgEAEQgEADgDAEIgBABIAZAAIgBAHIgZAAIAAADIAAADIAYAAIgCAIIgVAAIABAAQADAFAEAEQAEACAFAAQAFABAFgDQAEgDADgDIAHAFQgFAFgGAEQgFADgIAAQgFAAgFgCg");
	this.shape_78.setTransform(86.75,79.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgLAbQgFgEgDgGQgCgIAAgJQAAgIACgHQADgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHABAIQgBAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgDAGAAAKQAAALADAGQAEAGAFgBQAGABAEgGQADgGABgLQgBgKgDgGQgEgGgGAAQgFAAgEAGg");
	this.shape_79.setTransform(79.1,79.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgLAbQgFgEgDgGQgDgIAAgJQAAgIADgHQADgIAFgDQAFgEAGAAQAHAAAFAEQAFADADAIQACAHAAAIQAAAJgCAIQgDAGgFAEQgFAEgHAAQgGAAgFgEgAgJgQQgDAGgBAKQABALADAGQAEAGAFgBQAGABAEgGQADgGABgLQgBgKgDgGQgEgGgGAAQgFAAgEAGg");
	this.shape_80.setTransform(73.8,79.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgJAdQgFgCgDgDQgCgEgBgEIAIgCQAAAEAEACQADADAFAAQADAAAEgCQADgBABgDQABgDAAgDQAAgEgBgDQgCgDgCgBQgDgBgEAAQgDAAgEABQgDABgCAEIgGgCIAFghIAeAAIAAAIIgYAAIgCAQIAEgCIAFgBQAGAAAEACQAEACACADIAEAFIABAIQAAAGgDAEQgDAFgFACQgFADgFAAQgGAAgDgCg");
	this.shape_81.setTransform(68.8,79.425);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgKAdQgFgCgCgDQgCgEgBgEIAIgCQABAEACACQAEADAFAAQAGAAADgDQADgDABgFQgBgGgDgDQgDgDgGAAIgGAAIAAgEIAMgSIgXAAIAAgIIAiAAIAAAGIgNASQAGABAEADQAEACACAEIABAIQgBAFgCAFQgCAEgFACQgFADgGAAQgGAAgEgCg");
	this.shape_82.setTransform(62.1,79.425);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgEgFAAgHQAAgGAEgFQACgFAGgDQAFgDAFAAQAKAAAFAFQAFAGAAALIAAACIghAAIACAGQABADAEACQAEACADAAQAFAAADgCIAFgEIAGAEQgCAEgGADQgFADgGAAQgGAAgFgDgAANgEQAAgFgDgCQgDgEgGAAQgDAAgDACQgEADgBADIgCADIAZAAIAAAAg");
	this.shape_83.setTransform(55.55,80.175);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgKAdQgFgDgCgFQgDgFAAgHQAAgHADgEQADgFAFgEQAFgDAFAAIAHABIAFACIAAgUIAIAAIAAA+IgGAAIgCgEQgCACgDABQgEACgEAAQgFAAgFgDgAgFgEQgDADgCACQgCADAAAFQAAAEACADQACAEADACQADACADAAIAHgBIAFgEIAAgVQgCgCgDgBIgGgBQgEAAgDACg");
	this.shape_84.setTransform(50.575,79.3);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIACAFIACgDIAGgCIAGgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_85.setTransform(45.25,80.125);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgCgFAAgHQAAgGACgFQADgFAFgDQAFgDAGAAQAKAAAFAFQAGAGAAALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgEADQgGADgHAAQgFAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgBADIAYAAIAAAAg");
	this.shape_86.setTransform(41.2,80.175);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgLAgIAIgUIgSgrIAKAAIALAhIANghIAJAAIgYA/g");
	this.shape_87.setTransform(36.725,81.175);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgLAUQgFgDgDgFQgDgFAAgHQAAgGADgFQADgFAFgDQAGgDAFAAQAGAAAFADQAFADAEAFQADAFAAAGQAAAHgDAFQgEAFgFADQgEADgHAAQgFAAgGgDgAgGgNQgEADgCADQgCADAAAEQAAAEACAEQACADAEACQADACADAAQAEAAAEgBQADgCABgEQACgEAAgEQAAgDgCgEQgBgDgDgCQgEgDgEAAQgDAAgDACg");
	this.shape_88.setTransform(32.15,80.175);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgDAgIAAg+IAHAAIAAA+g");
	this.shape_89.setTransform(28.725,79.25);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIABAFIAEgDIAEgCIAHgBIgBAJIgGAAIgEACIgDADIAAAfg");
	this.shape_90.setTransform(24.75,80.125);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgJAUQgGgDgDgFQgDgFAAgHQAAgGADgFQAEgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQACADADACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgFADQgEADgHAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgDADgCADIgCADIAZAAIAAAAg");
	this.shape_91.setTransform(20.7,80.175);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgDAgIAAgsIAHAAIAAAsgAgDgVQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_92.setTransform(17.4,79.225);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AAZAXIAAgaQAAgGgCgDQgCgCgFAAQgFAAgDABIgEAEIAAAFIAAAbIgHAAIAAgaQgBgGgCgDQgCgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQACABABADIAHgEQAEgCAFAAQAFAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_93.setTransform(12.65,80.125);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgJAUQgFgDgDgFQgEgFAAgHQAAgGAEgFQADgFAEgDQAGgDAFAAQAJAAAGAFQAFAGABALIAAACIgiAAIACAGQABADAEACQAEACADAAQAFAAADgCIAFgEIAHAEQgEAEgFADQgFADgGAAQgGAAgFgDgAANgEQgBgFgCgCQgDgEgGAAQgDAAgDACQgEADgBADIgCADIAZAAIAAAAg");
	this.shape_94.setTransform(6.4,80.175);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgKAXIAAgsIAGAAIABAFIAEgDIAEgCIAGgBIAAAJIgGAAIgEACIgDADIAAAfg");
	this.shape_95.setTransform(3,80.125);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_96.setTransform(-0.975,81.125);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AALAXIAAgaQAAgGgCgDQgDgCgFAAQgDAAgDABQgDACgCADIAAAfIgJAAIAAgsIAHAAIABAFIAGgEQAEgCAEAAQAFAAAEACQADABADAEQACAEAAAHIAAAbg");
	this.shape_97.setTransform(-8,80.125);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgKAVQgEgBgCgEQgCgEAAgHIAAgbIAIAAIAAAaQAAAGACADQADACAFAAQADAAACgBIAFgFIAAgfIAJAAIAAAsIgHAAIgBgFIgGAEQgDACgEAAQgFAAgDgCg");
	this.shape_98.setTransform(-12.925,80.225);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgJAWQgEgCgDgDIAEgGIAGAEIAHABQAEAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgCgEgBIgGgCQgFgCgDgCQgEgDAAgFQAAgEACgCQACgDAEgCQADgBAEAAQAFAAAEABQAEABADADIgFAGIgFgDIgGgBQgDAAgCACQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABIAFACIAGACQAFACADACQADADAAAGQAAAFgEAEQgEADgIAAQgFAAgFgBg");
	this.shape_99.setTransform(-19.075,80.175);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgJAeQgGgDgDgFQgCgFAAgHQAAgHACgEQAEgFAEgEQAFgDAGAAQAJABAGAFQAGAGAAAJIAAAEIgiAAIACAFQACAEADACQAEACADAAQAFAAADgCIAFgEIAHADQgEAFgEADQgGADgHAAQgFAAgFgDgAANAFQgBgFgCgCQgDgDgGAAQgDAAgDACQgDACgCADIgBADIAYAAIAAAAgAgDgRIgNgPIAKAAIAKAPg");
	this.shape_100.setTransform(-23.25,79.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgLAXIAAgsIAHAAIABAFIADgDIAFgCIAHgBIgBAJIgGAAIgFACIgCADIAAAfg");
	this.shape_101.setTransform(-26.65,80.125);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgUAhIAAhAIAGAAIACAFQACgDADgBQAEgCADAAQAGAAAFADQAFADACAGQADAFAAAHQAAAGgDAEQgDAGgFADQgFADgFAAQgEAAgDgCIgFgCIAAAXgAgHgXQgDABgCADIAAAUIAFAEIAHABQADAAADgCQADgCACgCQACgEAAgEQAAgFgCgDQgCgEgDgCQgDgCgDAAQgEAAgDABg");
	this.shape_102.setTransform(-30.625,81.125);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AAUAeIgHgRIgZAAIgHARIgJAAIAYg7IAJAAIAYA7gAAKAFIgKgZIgJAZIATAAg");
	this.shape_103.setTransform(-36.225,79.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.offer2, new cjs.Rectangle(-41.3,71.9,183.5,58), null);


(lib.offer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA2A41").s().p("AABALIgPAYIgMgJIAQgWIgagHIAFgOIAZAJIAAgaIANAAIAAAaIAZgJIAFAOIgaAHIAQAWIgLAJg");
	this.shape.setTransform(-75.75,-17.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2 copy 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA2A41").s().p("AgQAmQgIgDgFgFIAHgKQAFADAHACQAGADAFAAQAIAAAEgDQADgCAAgFQAAgDgCgDQgCgDgHgCIgLgDQgIgDgGgEQgFgGgBgJQAAgGAEgFQADgFAGgCQAHgDAHAAQAIAAAHACQAHADAEAEIgIAKIgJgFIgKgBQgFAAgEACQgCADAAADQgBAEADACQADADAFACIALADQAKAEAFAEQAFAGAAAIQAAAKgHAGQgHAGgPAAQgIAAgJgCg");
	this.shape_1.setTransform(-71.4,17.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BA2A41").s().p("AgHA3IAAhMIAOAAIAABMgAgGglQgDgEAAgDQAAgFADgCQADgDADAAQAEAAADADQADACAAAFQAAADgDAEQgDADgEAAQgDAAgDgDg");
	this.shape_2.setTransform(-76.075,16.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA2A41").s().p("AgTAjQgJgFgGgJQgFgJAAgMQAAgKAFgJQAGgJAJgGQAJgFAKAAQALAAAJAFQAJAFAFAKQAGAJAAAKQAAAMgGAJQgFAJgJAFQgJAFgLAAQgKAAgJgFgAgMgWQgGADgDAGQgDAGAAAHQAAAIADAGQADAGAGAEQAGADAGAAQAHAAAGgDQAGgEADgGQADgGAAgIQAAgGgDgHQgDgGgGgDQgGgEgHAAQgGAAgGAEg");
	this.shape_3.setTransform(-81.925,17.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BA2A41").s().p("AAsAnIAAguQAAgKgEgEQgDgEgKAAQgHAAgFACQgEADgEAEIABAIIAAAvIgOAAIAAguQAAgKgEgEQgDgEgKAAQgGAAgFACQgEADgEAFIAAA2IgPAAIAAhLIAMAAIACAHQAFgEAFgDQAGgCAIAAQAIAAAGACQAFACADAGQAFgFAGgDQAHgCAJAAQAJAAAGACQAGADAEAHQADAGAAAMIAAAvg");
	this.shape_4.setTransform(-92.775,17.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BA2A41").s().p("AgbBEIAoiHIAPAAIgoCHg");
	this.shape_5.setTransform(-102.15,17.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer_2 copy
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BA2A41").s().p("AgTBcQgSgHgMgOQgNgOgHgSIgBgEIgVAAIAAgXIAQAAIgBgMIABgKIgQAAIAAgXIAVAAIABgFQAHgSANgOQAMgNASgIQARgIATAAQAXAAAUALQATAKANASIgXAQQgIgNgNgHQgOgIgRAAQgTAAgOALQgOAKgJAQIAAACIBQAAIgDAXIhUAAIgBAKIABAMIBQAAIgEAXIhFAAIAAABQAJARAOAKQAOAKATAAQARAAAOgIQANgIAIgMIAXAQQgNASgTAKQgUALgXAAQgTAAgRgIg");
	this.shape_6.setTransform(-90.45,-6.075);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	// Layer_2
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BA2A41").s().p("AhECnIBOhuIgSABQghAAgbgNQgagOgPgZQgPgXgBgjQABggAPgZQAOgaAcgQQAdgPAmAAQAoAAAcAPQAcAPAPAaQAOAaAAAgQAAASgHAXQgHAWgVAdIhaB/gAgtheQgQAQAAAaQAAAaAQARQAQAOAdAAQAeAAAQgOQAQgRAAgaQAAgagQgQQgQgQgegBQgdABgQAQg");
	this.shape_7.setTransform(-115.6,4.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BA2A41").s().p("AA6CkIAAg1IixAAIAAgvICFjjIBGAAIiBDZIBnAAIAAhDIA+AAIAACxg");
	this.shape_8.setTransform(-143.55,4.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BA2A41").s().p("AhtCnIAAgwIB8h/IARgTQAHgKADgIQADgJAAgJQAAgUgLgMQgLgMgXAAQgZgBgMAMQgLAMgCAVIg+gKQAFgcANgVQANgVAXgMQAXgLAjAAQAhAAAYAMQAYANANAVQANAWAAAcQAAAPgDAOQgDAPgKAPQgKAPgSARIhVBbICHAAIAAA3g");
	this.shape_9.setTransform(-169.625,4.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]}).wait(1));

	// text
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3E424A").s().p("AgQAiQgJgGgFgJQgFgIAAgLQAAgKAFgJQAFgIAJgGQAIgFAKABQAPAAAKAJQAJAJAAASIAAAEIg5AAQABAGACAEQAEAGAFADQAGAEAGAAQAIAAAGgEQAFgDADgFIAKAHQgEAIgJAFQgIAEgLAAQgKAAgJgEgAAWgIQgBgHgFgEQgEgGgKAAQgGAAgFADQgGAEgDAFIgCAFIAqAAIAAAAg");
	this.shape_10.setTransform(-113.85,-21.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3E424A").s().p("AgRAwQgJgFgEgJQgFgIABgLQAAgLAEgIQAFgJAJgFQAJgFAJAAIALABIAIAEIAAgiIAPAAIAABoIgMAAIgCgHQgEADgGADQgFACgHAAQgKAAgHgFgAgJgHQgFAEgDAEQgEAGAAAIQAAAHAEAGQACAGAGADQAEADAHAAQAFAAAFgCQAFgCAEgEIAAgjQgDgEgFgCQgEgBgGAAQgGAAgGADg");
	this.shape_11.setTransform(-122.65,-22.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3E424A").s().p("AgSAmIAAhKIALAAIACAIIAGgFIAIgDIAKgBIgBAOIgJABQgFABgDACIgFAFIAAA0g");
	this.shape_12.setTransform(-132.675,-21.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3E424A").s().p("AgGA1IAAhJIANAAIAABJgAgGgkQgDgDAAgEQAAgEADgCQADgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDADgEAAQgDAAgDgDg");
	this.shape_13.setTransform(-137.55,-22.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3E424A").s().p("AgHAqQgGgGAAgLIAAgnIgNAAIAAgMIANAAIAAgWIAOAAIAAAWIAZAAIAAAMIgZAAIAAAhQAAAJABAEQACAEAHAAIAGgBIAGgCIAFALQgFADgFABIgJABQgLAAgFgHg");
	this.shape_14.setTransform(-142.45,-22.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E424A").s().p("AgSAmIAAhKIALAAIACAIIAGgFIAIgDIAKgBIgBAOIgJABQgFABgDACIgFAFIAAA0g");
	this.shape_15.setTransform(-147.475,-21.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E424A").s().p("AgXAiQgHgGAAgKQAAgFADgEQACgEAFgEQAGgBAJgCIAWgGIAAgEQAAgHgEgEQgEgCgIAAQgIAAgDABQgDACgCAFIgNgEQADgJAIgEQAIgEAKABQAKAAAGACQAHADADAFQAEAGAAAIIAAAyIgMAAIgCgHQgGAEgGACQgFACgHAAQgKAAgGgEgAgDAIQgHABgDACQgDADAAAEQAAAFAEACQADACAFAAQAFAAAFgCQAGgDAFgEIAAgPg");
	this.shape_16.setTransform(-154.625,-21.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3E424A").s().p("AgjA2IAAhqIALAAIADAHQADgEAHgCQAFgCAGAAQAKAAAIAEQAIAGAFAIQAEAJAAALQAAALgEAIQgGAJgIAFQgIAFgKAAQgFAAgGgDQgFgBgDgDIAAAmgAgMgnQgFACgDAEIAAAiQADAEAFADQAFACAGAAQAGAAAFgDQAFgEADgEQADgGAAgIQAAgHgDgGQgCgGgGgDQgFgEgGAAQgGAAgFACg");
	this.shape_17.setTransform(-162.3,-19.625);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3E424A").s().p("AAhBDIgMgdIgqAAIgLAdIgPAAIAnhjIAQAAIAoBjgAARAaIgRgsIgRAsIAiAAgAgGgqIgVgYIARAAIARAYg");
	this.shape_18.setTransform(-175.9,-24.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.offer, new cjs.Rectangle(-184.8,-33.7,463.2,100.7), null);


(lib.logo_black = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhTD2QgmgUgeglQgdglgRgwQgRgyAAg2QAAg1ARgyQARgwAdglQAeglAmgUQApgVAqAAQAsAAAoAVQAnAUAdAlQAeAlAQAwQARAyAAA1QAAA2gRAyQgQAwgeAlQgdAlgnAUQgoAVgsAAQgqAAgpgVgAiaCLIAAABQAbAwApAbQApAbAtAAQAuAAApgbQApgbAbgwIABgBIichzgACwBdIAAgBQAEgOADgPIACgNIi5iIIi3CIIgBAAIACANQADAPAFAOIAAABICuiCgAC+gIIAAAAQgBgvgPgrQgPgqgbghQgbghgigRQgigSglAAQgkAAgiASQgiARgaAhQgbAhgPAqQgPArgCAvIAAAAIC9iMg");
	this.shape.setTransform(221.55,27.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgXBaQgsgBgbgZQgbgZAAgnIAAAAQAAgRAHgRQAGgQANgMQANgNATgHQASgGAWgBIAAAAIAkgBIBIAAIAlAAIAAAjIhqgBIgYABIgLAAIgBAAIgBAAQgaABgQAPQgPAQAAAXQgBAZARAPQAPAOAbABIAiABIBsAAIAAAiIg7ABQhEAAgSgBg");
	this.shape_1.setTransform(18.55,29.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AibBFQgcAAgVgUQgUgUAAgcQAAgcAUgUQAUgVAdAAIE4AAQAcAAAVAVQATAUABAcQgBAcgTAUQgVAUgcAAg");
	this.shape_2.setTransform(143.8933,16.7732,0.19,0.1902);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("ApGHfIAAu9ISNAAIAAC1Iu3AAIAADPINCAAIAACtItCAAIAADXIO3AAIAAC1g");
	this.shape_3.setTransform(149.1089,29.4491,0.19,0.1902);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AjAHzQjsgFiRiKQiRiJAAjaIAAgBQAAhmAlhZQAkhbBFhCQBHhGBigmQBhgmB1gEIADAAIAzgCQBBgCBGAAQBdAABoAEQDsAKCRCJQCRCKAADVIAAABQAABmglBaQgkBZhFBDQhHBGhiAmQhhAnh1ADIgDAAQhKAEhwAAQhuAAhXgEgAmWjhQhUBUAACLQAACMBVBUQBVBUCSAEIADAAQBdAEBcAAQBtAAAugEIAIAAQCRgGBUhUQBUhUABiKIAAgBQAAiMhVhTQhVhTiVgHIgJAAQhUgEg5AAQhEAAhEACIg2ACIgEAAIgFAAQiRAHhUBUg");
	this.shape_4.setTransform(119.0933,29.4491,0.19,0.1902);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AqpHfIAAu9IPCAAQCmAABdBOQBdBNAACJQAACYhWA/QhYBCjbAFIhqAAIIkF3Ik3AAIqRnbIAAg3IIbAAQBdADAmgoQAcgeAAg8QAAg5ghgcQghgdhAgBIrtAAIAAMIg");
	this.shape_5.setTransform(88.4364,29.4491,0.19,0.1902);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AibBFQgcAAgVgUQgUgUgBgcQABgcAUgUQAUgVAdAAIE5AAQAcAAATAVQAUAUAAAcQAAAbgUAVQgTAUgcAAg");
	this.shape_6.setTransform(154.2675,16.7732,0.19,0.1902);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AGnHfIAAncQAAihhYhJQhQhCigAAIoFAAIAAMIIjVAAIAAu9IMNAAQD1ABCBCDQB0B3AADMIAAH2g");
	this.shape_7.setTransform(177.9513,29.4491,0.19,0.1902);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhqHfIAAu9IDVAAIAAO9g");
	this.shape_8.setTransform(39.449,29.3778,0.19,0.1902);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgUBbIAAiTIhmAAIAAgiID1AAIAAAiIhnAAIAACTg");
	this.shape_9.setTransform(58.5,29.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_black, new cjs.Rectangle(6.4,0.5,236.7,53.4), null);


(lib.img2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img2();
	this.instance.setTransform(-5,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2_1, new cjs.Rectangle(-5,-31,300,400), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();
	this.instance.setTransform(3,-30);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_1, new cjs.Rectangle(3,-30,300,400), null);


(lib.hero = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ec41();
	this.instance.setTransform(0,0,0.98,0.98);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.hero, new cjs.Rectangle(0,0,326.4,286.2), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIA+AAIAAARIgsAAIAAAVIAoAAIAAAPIgoAAIAAAXIAtAAIAAARg");
	this.shape.setTransform(181.3,21.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAvIgXgiIgKAAIAAAiIgSAAIAAhdIAkAAQAJAAAHAEQAHADAEAIQAEAGAAAIQAAAJgEAHQgEAGgIADIgFADIAbAkgAgSgCIAQAAQAGAAAEgDQAEgEAAgHQAAgHgEgEQgEgEgGABIgQAAg");
	this.shape_1.setTransform(172.825,21.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLAvIghhdIATAAIAZBKIAahKIATAAIghBdg");
	this.shape_2.setTransform(163.15,21.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVArQgJgFgEgJQgEgJAAgNIAAg2IASAAIAAA2QAAAIACAFQADAFAEADQAFACAGAAQAHAAAFgCQAEgDADgFQACgFAAgIIAAg2IASAAIAAA2QAAANgEAJQgEAJgJAFQgJAFgNAAQgMAAgJgFg");
	this.shape_3.setTransform(153.475,21.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAtQgJgEgHgHQgHgGgDgJQgEgJAAgKQAAgJAEgJQADgIAHgIQAHgGAJgEQAIgDAKAAQAKAAAJADQAJAEAHAHQAGAHAEAIQAEAJAAAJQAAAKgEAJQgEAJgGAGQgHAHgJAEQgJAEgKAAQgKAAgIgEgAgPgaQgGAFgEAHQgEAHAAAHQAAAIAEAHQAEAHAGAEQAHAFAIAAQAJAAAHgFQAGgDAEgIQAEgHAAgIQAAgHgEgHQgEgHgGgEQgHgEgJAAQgIAAgHADg");
	this.shape_4.setTransform(143.025,21.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOAtQgJgEgGgHQgHgGgEgJQgDgJAAgKQAAgJADgJQAEgJAHgGQAGgHAJgEQAJgDAJAAQANAAALAFQAKAFAGAJIgOALQgEgGgHgDQgGgDgIAAQgIAAgHADQgHAFgEAHQgDAHAAAHQAAAIADAHQAEAIAHADQAHAFAHAAQAJAAAGgEQAHgDAEgGIAOALQgGAJgLAFQgKAFgNABQgJAAgJgEg");
	this.shape_5.setTransform(132.775,21.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfA/IAAhdIA+AAIAAARIgsAAIAAAUIAoAAIAAAQIgoAAIAAAXIAtAAIAAARgAgIgmIAPgYIAVAAIgVAYg");
	this.shape_6.setTransform(123.85,19.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpAvIAAhdIAkAAQAJAAAJAEQAJAEAGAGQAHAHAEAIQADAIAAAJQAAAJgDAJQgEAJgGAHQgHAGgJADQgJAEgJAAgAgXAfIASAAQAFAAAGgDQAFgCAEgEQAEgFACgFQACgGAAgGQAAgFgCgFQgCgFgEgFQgEgEgFgDQgGgCgFAAIgSAAg");
	this.shape_7.setTransform(114.575,21.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIA+AAIAAARIgsAAIAAAVIAoAAIAAAPIgoAAIAAAXIAtAAIAAARg");
	this.shape_8.setTransform(102,21.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgNAvIgHgBIAFgQIAEABIADAAQAGAAACgCQACgDAAgGIAAhDIATAAIAABEQAAAMgHAIQgHAHgMAAg");
	this.shape_9.setTransform(94.4,21.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7A99AC").s().p("AmZCyQhJAAg1g1Qg0gzAAhKQAAhIA0g1QA1g0BJAAIMzAAQBJAAA0A0QA1A1AABIQAABKg1AzQg0A1hJAAg");
	this.shape_10.setTransform(140.275,20.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(50,2.9,180.6,36.6), null);


(lib.subRandom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// subRandom3
	this.subRandom3 = new lib.subRandom3();
	this.subRandom3.name = "subRandom3";
	this.subRandom3.setTransform(79.1,16.4,1,1,0,0,0,61.1,16.9);

	this.timeline.addTween(cjs.Tween.get(this.subRandom3).wait(1));

	// subRandom2
	this.subRandom2 = new lib.subRandom2();
	this.subRandom2.name = "subRandom2";
	this.subRandom2.setTransform(42.95,12.05,1,1,0,0,0,47.6,12.6);

	this.timeline.addTween(cjs.Tween.get(this.subRandom2).wait(1));

	// subRandom1
	this.subRandom1 = new lib.subRandom1();
	this.subRandom1.name = "subRandom1";
	this.subRandom1.setTransform(103.05,16.4,1,1,0,0,0,56.1,16.9);

	this.timeline.addTween(cjs.Tween.get(this.subRandom1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.subRandom, new cjs.Rectangle(0,-0.5,162,23.2), null);


(lib.roadMc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhGTAeuMAAAg9bMCMnAAAMAAAA9bg");
	mask.setTransform(450,196.575);

	// roadcolor
	this.roadcolor = new lib.roadcolor_1();
	this.roadcolor.name = "roadcolor";
	this.roadcolor.setTransform(0,-159);

	var maskedShapeInstanceList = [this.roadcolor];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.roadcolor).wait(1));

	// triangle
	this.triangle = new lib.triangle();
	this.triangle.name = "triangle";
	this.triangle.setTransform(270.65,242.8,1.1451,1.1451,0,0,0,276.1,402.3);

	this.timeline.addTween(cjs.Tween.get(this.triangle).wait(1));

	// msk (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhGTAeuMAAAg9bMCMnAAAMAAAA9bg");
	mask_1.setTransform(450,196.575);

	// road
	this.road = new lib.road_1();
	this.road.name = "road";
	this.road.setTransform(0,-159);

	var maskedShapeInstanceList = [this.road];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.road).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roadMc, new cjs.Rectangle(-45.5,-228.3,1036.7,628.8), null);


(lib.note = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.instance = new lib.Symbol1();
	this.instance.setTransform(0.1,0,1,1,0,0,0,529.9,532);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.note, new cjs.Rectangle(-530,-532,1060,1064), null);


(lib.logo_Citroen_horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzMETIAAolMAmZAAAIAAIlg");
	mask.setTransform(126.475,27.4);

	// black_left
	this.logo_black = new lib.logo_black();
	this.logo_black.name = "logo_black";
	this.logo_black.setTransform(122.2,26.7,1,1,0,0,0,121.2,26.7);

	var maskedShapeInstanceList = [this.logo_black];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.logo_black).wait(1));

	// white_left
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhTD2QgmgUgeglQgdglgRgwQgRgyAAg2QAAg1ARgyQARgwAdglQAeglAmgUQApgVAqAAQAsAAAoAVQAnAUAdAlQAeAlAQAwQARAyAAA1QAAA2gRAyQgQAwgeAlQgdAlgnAUQgoAVgsAAQgqAAgpgVgAiaCLIAAABQAbAwApAbQApAbAtAAQAuAAApgbQApgbAbgwIABgBIichzgACwBdIAAgBQAEgOADgPIACgNIi5iIIi3CIIgBAAIACANQADAPAFAOIAAABICuiCgAC+gIIAAAAQgBgvgPgrQgPgqgbghQgbghgigRQgigSglAAQgkAAgiASQgiARgaAhQgbAhgPAqQgPArgCAvIAAAAIC9iMg");
	this.shape.setTransform(222.8,27.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXBaQgsgBgbgZQgbgZAAgnIAAAAQAAgRAHgRQAGgQANgMQANgNATgHQASgGAWgBIAAAAIAkgBIBIAAIAlAAIAAAjIhqgBIgYABIgLAAIgBAAIgBAAQgaABgQAPQgPAQAAAXQgBAZARAPQAPAOAbABIAiABIBsAAIAAAiIg7ABQhEAAgSgBg");
	this.shape_1.setTransform(19.9,29.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibBFQgcAAgVgUQgUgUAAgcQAAgcAUgUQAUgVAdAAIE4AAQAcAAAVAVQATAUABAcQgBAcgTAUQgVAUgcAAg");
	this.shape_2.setTransform(145.1933,17.2232,0.19,0.1902);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ApGHfIAAu9ISNAAIAAC1Iu3AAIAADPINCAAIAACtItCAAIAADXIO3AAIAAC1g");
	this.shape_3.setTransform(150.4589,29.5991,0.19,0.1902);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjAHzQjsgFiRiKQiRiJAAjaIAAgBQAAhmAlhZQAkhbBFhCQBHhGBigmQBhgmB1gEIADAAIAzgCQBBgCBGAAQBdAABoAEQDsAKCRCJQCRCKAADVIAAABQAABmglBaQgkBZhFBDQhHBGhiAmQhhAnh1ADIgDAAQhKAEhwAAQhuAAhXgEgAmWjhQhUBUAACLQAACMBVBUQBVBUCSAEIADAAQBdAEBcAAQBtAAAugEIAIAAQCRgGBUhUQBUhUABiKIAAgBQAAiMhVhTQhVhTiVgHIgJAAQhUgEg5AAQhEAAhEACIg2ACIgEAAIgFAAQiRAHhUBUg");
	this.shape_4.setTransform(120.4433,29.5991,0.19,0.1902);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AiABbIAAi1IC1AAQAfAAATAOQARAPAAAbQAAAcgQALQgRANgqABIgUAAIBpBIIg8AAIh8hbIAAgKIBmAAQASABAHgHQAFgHAAgLQAAgLgGgFQgHgGgMAAIiNAAIAACTg");
	this.shape_5.setTransform(89.8,29.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AibBFQgcAAgVgUQgUgUgBgcQABgcAUgUQAUgVAdAAIE5AAQAcAAATAVQAUAUAAAcQAAAbgUAVQgTAUgcAAg");
	this.shape_6.setTransform(155.5675,17.2232,0.19,0.1902);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AGnHfIAAncQAAihhYhJQhQhCigAAIoFAAIAAMIIjVAAIAAu9IMNAAQD1ABCBCDQB0B3AADMIAAH2g");
	this.shape_7.setTransform(179.3013,29.5991,0.19,0.1902);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhqHfIAAu9IDVAAIAAO9g");
	this.shape_8.setTransform(40.799,29.5278,0.19,0.1902);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgUBbIAAiTIhmAAIAAgiID1AAIAAAiIhnAAIAACTg");
	this.shape_9.setTransform(59.85,29.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_Citroen_horizontal, new cjs.Rectangle(7.4,0.5,236.9,53.5), null);


(lib.groupBox = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// hero
	this.hero = new lib.hero();
	this.hero.name = "hero";
	this.hero.setTransform(26,-2);

	this.timeline.addTween(cjs.Tween.get(this.hero).wait(1));

	// roadMc
	this.roadMc = new lib.roadMc();
	this.roadMc.name = "roadMc";
	this.roadMc.setTransform(-279.7,-49.1);

	this.timeline.addTween(cjs.Tween.get(this.roadMc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.groupBox, new cjs.Rectangle(-325.2,-277.4,1036.7,628.8), null);


(lib.aniBoxbg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// groupBox
	this.groupBox = new lib.groupBox();
	this.groupBox.name = "groupBox";
	this.groupBox.setTransform(30.1,64.1,0.7783,0.7783,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.groupBox).wait(1));

	// bg
	this.instance = new lib.bg();
	this.instance.setTransform(-355,-237,2.0402,2.0402);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aniBoxbg, new cjs.Rectangle(-355,-237,1020.1,612.1), null);


(lib.aniBox = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// aniBoxbg_guide
	this.aniBoxbgGuide = new lib.aniBoxbg();
	this.aniBoxbgGuide.name = "aniBoxbgGuide";
	this.aniBoxbgGuide.setTransform(24,-155,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.aniBoxbgGuide).wait(1));

	// aniBoxbg
	this.aniBoxbg = new lib.aniBoxbg();
	this.aniBoxbg.name = "aniBoxbg";
	this.aniBoxbg.setTransform(0,-49.2);

	this.timeline.addTween(cjs.Tween.get(this.aniBoxbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aniBox, new cjs.Rectangle(-355,-344.6,1020.1,670.5), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var aniBox = this.aniBox;
		var aniBoxbg = aniBox.aniBoxbg;
		var aniBoxbgGuide = aniBox.aniBoxbgGuide;
		var aniBoxbgGuide2 = aniBox.aniBoxbgGuide2;
		var groupBox = aniBox.aniBoxbg.groupBox;
		var roadMc = groupBox.roadMc;
		var triangle = roadMc.triangle;
		
		var img1 = this.img1;
		var img2 = this.img2;
		var nota = this.nota;
		
		var hero = aniBox.aniBoxbg.groupBox.hero;
		var white = this.white;
		var white2 = this.white2;
		
		var txt1 = this.txt1;
		var txt1Guide = this.txt1Guide;
		var txt2 = this.txt2;
		var txt3 = this.txt3;
		var txt3 = this.txt3;
		var txt4 = this.txt4;
		var txt5 = this.txt5;
		
		var offer= this.offer;
		var offer2= this.offer2;
		
		var sub1= this.sub1;
		var sub2= this.sub2;
		var sub3= this.sub3;
		
		var cta = this.cta;
		
		var logo= this.logo;
		var logo_black = logo.logo_black;
		
		var r = 0;
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf);
			}
		}
		
		
		var subRandom = this.subRandom;
		subRandom.visible = false;
		var toRandom = [subRandom.subRandom1, subRandom.subRandom2, subRandom.subRandom3];
		function randomSub() {
			
			var r = Math.floor(Math.random() * toRandom.length) + 1;
			for (var i = 0; i < toRandom.length; i++) {
				if(r-1==i) {
					toRandom[i].visible = true;
				} else { 
					toRandom[i].visible = false;
				}
			}
			
			console.log(r + " / " + toRandom.length + " - " + toRandom[r-1]);
			//TweenMax.set([cta] ,{x: ctaGuide.x, y: ctaGuide.y});
			//TweenMax.set([sub2] ,{x: sub2Guide.x, y: sub2Guide.y});
			TweenMax.set([subRandom] ,{visible: true});
			
		}
		
		
		
		this.tl = tl = new TimelineMax({onStart:getTime, repeat: 1, repeatDelay:2, onRepeat:randomSub, onComplete:autoShot, onCompleteParams:[true]});
		this.tlBg = tlBg = new TimelineMax({paused: true, repeat:0, repeatDelay: 0});
		
		
		
		tl
			.set([aniBoxbgGuide,txt1Guide], {visible: false})
		
		
			
			.add("frame1", "+=0")
			.from([logo], .5, {alpha: 0 }, "frame1")
			.add(function(){tlBg.play(0);}, "frame1")
			.add(autoShot)
		
			.add("frame2", "frame1+=2")
			.to([aniBoxbg], .5, {x: aniBoxbgGuide.x, y: aniBoxbgGuide.y, scaleX: aniBoxbgGuide.scaleX, scaleY: aniBoxbgGuide.scaleY , ease: Sine.easeInOut}, "frame2")
			.from([white], .5, {y:h, ease: Power1.easeOut}, "frame2")
			.from(nota, .5, {y: "+=20", alpha: 0, ease: Power1.easeOut}, "frame2")
			.from([txt1, txt2], .5, {y: "+=40", alpha: 0,  ease: Power2.easeOut}, "frame2+=.5")
			.add(autoShot)
			
			.add("frame2a", "frame2+=2")
			.to([txt2], .5, {y: "+=20", alpha: 0,  ease: Power2.easeOut}, "frame2a")
			.from([txt3, sub1], .5, {y: "+=10", alpha: 0,  ease: Power2.easeOut}, "frame2a")
			.add(autoShot)
		
			.add("frame3", "frame2a+=2.5")
			.to([txt3, sub1, nota], .5, {y: "+=20", alpha: 0,  ease: Power2.easeOut}, "frame3")
			.to([aniBoxbg], .5, {y:"+="+30 , ease: Sine.easeInOut}, "frame3")
			.to(white, .5, {y:"+="+30, ease: Power1.easeOut}, "frame3")
			.to([txt2, sub1], .5, {x: "-="+w, alpha: 0,  ease: Power2.easeOut}, "frame3")
			.from([img1], .5, {x: "-="+w, alpha: 0, scaleX: 1.75, scaleY: 1.75, ease: Power2.easeOut}, "frame3")
			.to([img1], 1, {x: "-="+10, scaleX: .95, scaleY: .95,ease: Power2.easeOut}, "frame3+=.5")
			.from([white2], .5, {y:"-="+50, ease: Power1.easeOut}, "frame3")
			.from([logo_black.mask], .5, {y:"-="+logo_black.nominalBounds.height, ease: Power2.easeOut}, "frame3")
			.from([txt4, sub2], .5, {x: "-="+w, alpha: 0,  ease: Power2.easeOut}, "frame3")
			.add(autoShot)
		
			
			.add("frame4", "frame3+=2.5")
			.to([txt4], .5, {alpha: 0,  ease: Power2.easeOut}, "frame4")
			.from([txt5], .5, {x: "-="+w, alpha: 0,  ease: Power2.easeOut}, "frame4")
			.from([img2], .5, {x: "-="+w, alpha: 0, ease: Power2.easeOut}, "frame4")
			.to([img2], 1, {x: "-="+10, scaleX: .95, scaleY: .95, ease: Power2.easeOut}, "frame4+=.5")
			.add(autoShot)
		
			.add("frame5", "frame4+=2.5")
			.to([aniBoxbg, white, txt1], .5, {y:"-="+30 , ease: Power2.easeOut}, "frame5")
			.to([img2, img1], .3, {x:"+="+w, ease: Power2.easeOut}, "frame5")
			.to([white2, logo_black.mask], .5, {y:"-="+70, ease: Power2.easeOut}, "frame5")
			.to([sub2, txt5], .5, {alpha: 0,  ease: Power2.easeOut}, "frame5")
			.from([offer, offer2, sub3], .5, {y: "+="+10, alpha: 0,  ease: Power2.easeOut}, "frame5")
			.add(autoShot)
		
			.add("frame6", "frame5+=2.5")
			.to([offer, offer2], .5, {x:"+="+(w/2),  ease: Power2.easeOut}, "frame6")
			.to([sub3], .5, {x:"+="+210,  ease: Power2.easeOut}, "frame6+=.5")
			.to([sub2], .5, {alpha: 0,  ease: Power2.easeOut}, "frame6+=.5")
			.from([cta], .5, {scaleY:0, ease: Power2.easeOut}, "frame6+=.5")
			.from([subRandom], .5, {y: "+="+(h/3), alpha: 0, ease: Power1.easeOut}, "frame6+=.5")
			
		
			
			
			//tlBg.timeScale(0.3);
			tlBg
			.add("frame1","+=.5")
			//.set(roadMc.road.mask, {y:"-=304", x:"+=900"}, "frame1")
			.from([roadMc.road.mask], 1.4 ,{x:"+=900", ease:Power1.easeOut}, "frame1")
			.from([roadMc.road.mask], 1.8 ,{y:"-=304", ease:Power1.easeOut}, "frame1+=.5")
			.from([triangle], 1 ,{alpha:0, x:"+=300", y:"-=250", ease:Power1.easeOut}, "frame1+=1.1")
			.from([hero], 1 ,{alpha:0, x:"+=50", y:"-=20", ease:Power1.easeOut}, "frame1+=1")
			.from([roadMc.roadcolor.mask], .9 ,{x:"+=900", y:"-=500", ease:Power1.easeOut}, "frame1+=1.5")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logo = new lib.logo_Citroen_horizontal();
	this.logo.name = "logo";
	this.logo.setTransform(15.05,18.75,0.6,0.6,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(85.35,458.45,1.1627,1.1599,0,0,0,140.2,3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// subRandom
	this.subRandom = new lib.subRandom();
	this.subRandom.name = "subRandom";
	this.subRandom.setTransform(70.7,582.7,1,1,0,0,0,57.6,18.4);

	this.timeline.addTween(cjs.Tween.get(this.subRandom).wait(1));

	// sub3
	this.sub3 = new lib.sub3();
	this.sub3.name = "sub3";
	this.sub3.setTransform(144.45,580.4,1,1,0,0,0,141,6.8);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.sub2();
	this.sub2.name = "sub2";
	this.sub2.setTransform(48.1,579.2,1,1,0,0,0,35.7,6.8);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(47.8,579.2,1,1,0,0,0,35.7,6.8);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	// offer2
	this.offer2 = new lib.offer2();
	this.offer2.name = "offer2";
	this.offer2.setTransform(240,478.55,1,1,0,0,0,50.7,100.4);

	this.timeline.addTween(cjs.Tween.get(this.offer2).wait(1));

	// offer
	this.offer = new lib.offer();
	this.offer.name = "offer";
	this.offer.setTransform(75,480.05,1.0553,1.0547,0,0,0,-125.7,1.9);

	this.timeline.addTween(cjs.Tween.get(this.offer).wait(1));

	// nota
	this.nota = new lib.note();
	this.nota.name = "nota";
	this.nota.setTransform(53,333,0.0729,0.0727,0,0,0,5.5,4.8);

	this.timeline.addTween(cjs.Tween.get(this.nota).wait(1));

	// txt5
	this.txt5 = new lib.txt5();
	this.txt5.name = "txt5";
	this.txt5.setTransform(25,468.8);

	this.timeline.addTween(cjs.Tween.get(this.txt5).wait(1));

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(24.5,467.8);

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	// txt3
	this.txt3 = new lib.txt3();
	this.txt3.name = "txt3";
	this.txt3.setTransform(25,469.1);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(150,468.8);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(150,160.5);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// white2
	this.white2 = new lib.white();
	this.white2.name = "white2";
	this.white2.setTransform(300,64,1,1,180);

	this.timeline.addTween(cjs.Tween.get(this.white2).wait(1));

	// white
	this.white = new lib.white();
	this.white.name = "white";
	this.white.setTransform(0,375);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgV3AtUMAAAhanMArvAAAMAAABang");
	mask.setTransform(150,300);

	// img2
	this.img2 = new lib.img2_1();
	this.img2.name = "img2";
	this.img2.setTransform(161.05,221.15,1.11,1.11,0,0,0,145.1,169.6);

	var maskedShapeInstanceList = [this.img2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(159.05,115.5,1.11,1.11,0,0,0,150.1,62.8);

	var maskedShapeInstanceList = [this.img1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	// aniBox
	this.aniBox = new lib.aniBox();
	this.aniBox.name = "aniBox";
	this.aniBox.setTransform(140.05,293,1,1,0,0,0,155,19.7);

	var maskedShapeInstanceList = [this.aniBox];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.aniBox).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(130.5,64,174.8,611);
// library properties:
lib.properties = {
	id: '1C1E05274011C24EBDE45892271DAE73',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"bg.jpg", id:"bg"},
		{src:"ec41.png", id:"ec41"},
		{src:"img1.jpg", id:"img1"},
		{src:"img2.jpg", id:"img2"},
		{src:"road.jpg", id:"road"},
		{src:"roadcolor.jpg", id:"roadcolor"},
		{src:"tri.jpg", id:"tri"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1C1E05274011C24EBDE45892271DAE73'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;