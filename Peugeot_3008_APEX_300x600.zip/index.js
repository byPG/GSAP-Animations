(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bitmap1 = function() {
	this.initialize(img.bitmap1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,393,404);


(lib.icon = function() {
	this.initialize(img.icon);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,31,37);


(lib.img1300x600 = function() {
	this.initialize(img.img1300x600);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.img2300x600 = function() {
	this.initialize(img.img2300x600);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.img3300x600 = function() {
	this.initialize(img.img3300x600);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUA9IAAgPIAHAAQAKAAAEgEQAEgEAAgKIAAhYIARAAIAABZQgBARgGAHQgIAIgSAAg");
	this.shape.setTransform(232.8,76.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBXAAIAAAQIhGAAIAAAkIBBAAIAAAPIhBAAIAAAlIBGAAIAAAPg");
	this.shape_1.setTransform(224.75,76.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAgA8IhEhgIAABgIgRAAIAAh3IAVAAIBFBhIAAhhIARAAIAAB3g");
	this.shape_2.setTransform(211.475,76.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgvA4IAAgRQAWAHAXAAQATAAAIgEQAHgEAAgKQAAgKgGgFQgGgDgVgDQgcgDgJgHQgKgHAAgSQAAgSALgHQANgJAaABQATAAAWAEIAAARQgXgGgSABQgTAAgIADQgGAEAAAKQAAAJAGAEQAGADATADQAdADAKAHQAKAHAAAUQAAASgMAIQgMAJgbAAQgYAAgVgHg");
	this.shape_3.setTransform(198.25,76.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AArA8IgNgiIg7AAIgNAiIgRAAIAuh3IAaAAIAvB3gAAXALIgVg4IgDAAIgWA4IAuAAg");
	this.shape_4.setTransform(185.5,76.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeA8IAAgvIgSAJIAAgSIASgHIAAg4IAQAAIAAAwIAegOIAAARIgeANIAAAoIA/AAIAAAPg");
	this.shape_5.setTransform(173.575,76.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAfA8IgehoIgCAAIgdBoIgeAAIghh3IASAAIAcBoIADAAIAehoIAdAAIAdBoIADAAIAdhoIASAAIgiB3g");
	this.shape_6.setTransform(158.75,76.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgHA8IAAgvIgyhIIAUAAIAlA5IAmg5IAUAAIgyBIIAAAvg");
	this.shape_7.setTransform(138.25,76.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIA8IAAhnIgtAAIAAgQIBrAAIAAAQIguAAIAABng");
	this.shape_8.setTransform(126.35,76.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AArA8IgNgiIg7AAIgNAiIgRAAIAuh3IAaAAIAvB3gAAXALIgVg4IgDAAIgWA4IAuAAg");
	this.shape_9.setTransform(113.95,76.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgeA8IAAgvIgSAJIAAgSIASgHIAAg4IAQAAIAAAwIAegOIAAARIgeANIAAAoIA/AAIAAAPg");
	this.shape_10.setTransform(102.025,76.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgyA8IAAh3IA3AAQAZAAAKAJQALAKAAAXQAAAWgLAJQgKAKgZAAIgnAAIAAAkgAgiAIIAmAAQARAAAGgFQAHgFAAgPQAAgPgHgGQgGgFgRAAIgmAAg");
	this.shape_11.setTransform(91.375,76.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAeA8IgdhoIgBAAIgeBoIgeAAIghh3IARAAIAeBoIADAAIAchoIAeAAIAdBoIADAAIAdhoIASAAIghB3g");
	this.shape_12.setTransform(74.55,76.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAPA4QgIgFAAgOQAAgOAIgGQAGgGAOAAQAPAAAHAGQAHAGAAAOQAAAOgHAFQgHAHgPAAQgOAAgGgHgAAZAZQgDADAAAJQAAAIADADQADAEAHAAQAJAAACgEQAEgEAAgHQAAgJgEgDQgCgDgJAAQgHAAgDADgAgyA8IBVh4IAQAAIhVB4gAg4gQQgHgGAAgOQAAgOAHgGQAHgFAOAAQAPAAAHAFQAGAGAAAOQAAAOgGAGQgHAGgPAAQgOAAgHgGgAgtgwQgDAEAAAIQAAAIADAEQADADAHAAQAIAAADgDQAEgEAAgIQAAgIgEgEQgDgDgIAAQgHAAgDADg");
	this.shape_13.setTransform(53.25,76.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgkAvQgLgOAAghQAAggALgPQALgOAZAAQAaAAALAOQALAPAAAgQAAAhgLAOQgLAPgaABQgZgBgLgPgAgYgkQgHAKAAAaQAAAaAHALQAHAKARAAQARAAAIgKQAHgLAAgaQAAgagHgKQgIgKgRAAQgRAAgHAKg");
	this.shape_14.setTransform(40.925,76.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAuA8IAAhhIgkBHIgTAAIglhHIAABhIgQAAIAAh3IAYAAIAmBLIABAAIAlhLIAZAAIAAB3g");
	this.shape_15.setTransform(171.4,36.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAeA8IgWgmIgDAAIgnAAIAAAmIgQAAIAAh3IA3AAQAZAAAKAJQALAJAAAXQAAARgGAIQgGAKgOADIAZAogAgiAGIAmAAQARAAAGgFQAHgEAAgPQAAgPgHgFQgGgFgRAAIgmAAg");
	this.shape_16.setTransform(157.075,36.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgHA8IAAh3IAPAAIAAB3g");
	this.shape_17.setTransform(147.675,36.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgqA8IAAh3IBVAAIAAAQIhFAAIAAAmIBAAAIAAAPIhAAAIAAAyg");
	this.shape_18.setTransform(140.025,36.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AArA8IgOgiIg6AAIgNAiIgSAAIAvh3IAbAAIAvB3gAAYALIgXg4IgCAAIgWA4IAvAAg");
	this.shape_19.setTransform(123,36.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgnA8IAAh3IARAAIAABoIA+AAIAAAPg");
	this.shape_20.setTransform(111.95,36.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag1A8IAAh3IAxAAQAeAAAOAOQAPAPAAAeQAAAggPAOQgOAOgeAAgAglAtIAhAAQAWAAAKgLQAJgKAAgYQAAgXgJgKQgKgKgWAAIghAAg");
	this.shape_21.setTransform(99.75,36.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_22.setTransform(272.25,20.475);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgvA4IAAgRQAXAHAWAAQATAAAIgEQAHgEAAgKQAAgLgGgDQgGgEgUgDQgdgEgJgFQgKgHAAgTQAAgRAMgIQAMgJAaAAQATAAAWAGIAAAQQgXgFgSAAQgTAAgIADQgGAEAAAKQAAAJAGADQAGAEATADQAdAEAKAFQAKAIAAATQAAATgMAIQgMAIgbABQgXAAgWgHg");
	this.shape_23.setTransform(263.3,15.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBXAAIAAAQIhHAAIAAAkIBCAAIAAAPIhCAAIAAAlIBHAAIAAAPg");
	this.shape_24.setTransform(251.45,15.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgHA8IAAh3IAPAAIAAB3g");
	this.shape_25.setTransform(242.775,15.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAuA8IAAhhIgkBHIgTAAIglhHIAABhIgQAAIAAh3IAYAAIAmBLIABAAIAlhLIAZAAIAAB3g");
	this.shape_26.setTransform(232.15,15.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgcBHIAqiNIAPAAIgqCNg");
	this.shape_27.setTransform(221,16.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgtAvQgOgOAAghQAAggAOgPQAOgPAfAAQAfAAAOAPQAPAPAAAgQAAAhgPAOQgOAPgfABQgfgBgOgPgAgggjQgKAKAAAZQAAAZAKALQAKAKAWAAQAYAAAJgKQAKgLAAgZQAAgZgKgKQgJgLgYAAQgWAAgKALg");
	this.shape_28.setTransform(210.85,15.35);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgIA8IAAhnIgtAAIAAgQIBrAAIAAAQIguAAIAABng");
	this.shape_29.setTransform(197.9,15.325);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgHA8IAAhnIguAAIAAgQIBrAAIAAAQIgtAAIAABng");
	this.shape_30.setTransform(186.05,15.325);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBXAAIAAAQIhGAAIAAAkIBAAAIAAAPIhAAAIAAAlIBGAAIAAAPg");
	this.shape_31.setTransform(174.55,15.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAgA8IhEhgIAABgIgRAAIAAh3IAVAAIBFBhIAAhhIARAAIAAB3g");
	this.shape_32.setTransform(161.275,15.325);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgqBIIAAgyIgQAHIAAgcIAQgHIAAhBIAjAAIAAAwIAcgNIAAAdIgcAMIAAAlIBCAAIAAAeg");
	this.shape_33.setTransform(143.175,14.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AhCBIIAAgeIBThTIhPAAIAAgeIB9AAIAAAeIhSBTIBWAAIAAAeg");
	this.shape_34.setTransform(129.85,14.125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgvA5QgOgSAAgnQAAgmAOgSQAPgSAgAAQAhAAAOASQAPASAAAmQAAAngPASQgOASghAAQggAAgPgSgAgUgjQgGAJAAAaQAAAaAGALQAFAJAPAAQAQAAAFgJQAGgLAAgaQAAgagGgJQgFgKgQAAQgPAAgFAKg");
	this.shape_35.setTransform(110.325,14.15);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgvA5QgOgSAAgnQAAgmAOgSQAPgSAgAAQAhAAAOASQAPASAAAmQAAAngPASQgOASghAAQggAAgPgSgAgUgjQgGAJAAAaQAAAaAGALQAFAJAPAAQAQAAAFgJQAGgLAAgaQAAgagGgJQgFgKgQAAQgPAAgFAKg");
	this.shape_36.setTransform(96.825,14.15);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgwBGIAAgdQAUAEARABQAUAAAIgHQAIgFABgUQgRAGgSABQgbAAgMgMQgMgKAAgYQAAgxA7AAQAiAAAOASQAOARAAAnQAAApgRARQgQARgmAAQgVAAgRgFgAgTgqQgGAFAAAKQAAAMAFAEQAFAEAOAAQAMAAAOgFQAAgUgGgHQgGgIgOAAQgNAAgFAFg");
	this.shape_37.setTransform(83.275,14.15);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAKBIIAAhuIgoAUIgOgaIA3gbIAiAAIAACPg");
	this.shape_38.setTransform(70.125,14.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Ag2A8IAAh3IAyAAQAeAAAOAOQAOAPAAAeQAAAggOAOQgOAOgeAAgAglAtIAhAAQAWAAAJgLQAKgKAAgYQAAgXgKgKQgJgKgWAAIghAAg");
	this.shape_39.setTransform(54.35,15.325);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgtAvQgOgOAAghQAAggAOgPQAOgPAfAAQAfAAAOAPQAPAPAAAgQAAAhgPAOQgOAPgfABQgfgBgOgPgAgggjQgKAKAAAZQAAAZAKALQAKAKAWAAQAYAAAJgKQAKgLAAgZQAAgZgKgKQgJgLgYAAQgWAAgKALg");
	this.shape_40.setTransform(40.1,15.35);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("Ag0BIIAAgPIBOhZIhJAAIAAgQIBfAAIAAAQIhOBZIBSAAIAAAPgAgFg6IAAgNIAPAAIAAANg");
	this.shape_41.setTransform(22.75,14.15);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgoAzQgMgLAAgaIAAhLIARAAIAABLQAAARAIAHQAIAHATAAQAUAAAIgHQAJgHAAgRIAAhLIAQAAIAABLQAAAagNALQgMALgcAAQgbAAgNgLg");
	this.shape_42.setTransform(10.1,15.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgVA9IAAgPIAIAAQALAAADgEQADgEABgKIAAhYIARAAIAABZQAAARgHAHQgIAIgTAAg");
	this.shape_43.setTransform(-0.55,15.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(-11.9,0,295.9,88.9), null);


(lib.txt3a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAZA4Ig3g3IAAA3IgQAAIAAhvIAQAAIAAAwIA3gwIAUAAIg7A1IA9A6g");
	this.shape.setTransform(140.75,30.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgnAsQgNgOABgeQgBgeANgOQANgNAbAAQAWgBANAJQAMAJAFASIgRAAQgDgLgJgFQgJgFgOAAQgTABgJAJQgJAKABAXQgBAXAJALQAJAKATAAQAcAAAHgVIARAAQgFASgMAJQgNAIgWABQgbAAgNgPg");
	this.shape_1.setTransform(128.45,30.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAoA4IgMggIg2AAIgNAgIgQAAIArhvIAZAAIArBvgAAWAJIgUg0IgDAAIgUA0IArAAg");
	this.shape_2.setTransform(116.15,30.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguA4IAAhvIA1AAQATAAAJAGQAJAHAAAQQAAAWgRAEQAUADAAAXQAAARgKAHQgJAGgWAAgAgeAqIAkAAQAOAAAFgFQAGgDAAgKQAAgKgGgEQgFgDgMAAIgmAAgAgegHIAlAAQALAAAFgDQAFgEAAgKQAAgKgFgDQgFgDgMAAIgkAAg");
	this.shape_3.setTransform(104.425,30.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgHA4IAAhgIgqAAIAAgPIBkAAIAAAPIgrAAIAABgg");
	this.shape_4.setTransform(92.6,30.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgsA0IAAgPQAVAGAVAAQASAAAHgDQAHgFAAgJQAAgKgGgDQgFgEgTgCQgbgDgJgGQgJgGAAgSQAAgRALgGQALgIAZAAQASAAAUAEIAAAQQgVgGgRAAQgSAAgHAFQgGACAAAJQAAAKAGADQAFADATADQAbADAJAFQAJAIAAASQAAARgMAIQgLAHgZABQgWgBgUgGg");
	this.shape_5.setTransform(81.375,30.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAoA4IgMggIg3AAIgMAgIgQAAIArhvIAZAAIArBvgAAWAJIgUg0IgDAAIgUA0IArAAg");
	this.shape_6.setTransform(69.45,30.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgnA4IAAhvIBPAAIAAAPIhAAAIAAAkIA7AAIAAANIg7AAIAAAvg");
	this.shape_7.setTransform(58.675,30.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AglAvQgLgLAAgYIAAhEIAPAAIAABEQAAARAHAGQAIAHASAAQASAAAIgHQAIgGAAgRIAAhEIAQAAIAABEQAAAYgMALQgLAKgbAAQgaAAgLgKg");
	this.shape_8.setTransform(42.45,30.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgvA4IAAhvIAzAAQAYAAAKAJQAKAJAAAUQAAAVgKAJQgKAJgYAAIgjAAIAAAigAgfAIIAjAAQAPAAAGgGQAHgEAAgOQAAgPgHgFQgGgEgPAAIgjAAg");
	this.shape_9.setTransform(30.675,30.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgHA4IAAgsIguhDIASAAIAjA1IAjg1IATAAIgvBDIAAAsg");
	this.shape_10.setTransform(18.675,30.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgHA4IAAhgIgqAAIAAgPIBkAAIAAAPIgrAAIAABgg");
	this.shape_11.setTransform(7.55,30.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNA4IgrhvIARAAIAmBhIADAAIAmhhIARAAIgsBvg");
	this.shape_12.setTransform(152.05,11.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AglAvQgMgLAAgYIAAhEIAQAAIAABEQAAARAIAGQAHAHASAAQASAAAIgHQAIgGAAgRIAAhEIAPAAIAABEQAAAYgLALQgMAKgaAAQgaAAgLgKg");
	this.shape_13.setTransform(139.6,11.575);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgsA1IAAgQQAVAGAVAAQASAAAHgEQAHgDAAgKQAAgKgGgEQgFgDgTgDQgbgDgJgFQgJgGAAgSQAAgQALgIQALgHAZgBQASAAAUAGIAAAPQgVgFgRAAQgSAAgHADQgGAEAAAJQAAAIAGAEQAFADATADQAbADAJAGQAJAGAAATQAAARgMAHQgLAJgZgBQgWAAgUgFg");
	this.shape_14.setTransform(127.525,11.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgHA4IAAgsIguhDIASAAIAjA1IAjg1IATAAIgvBDIAAAsg");
	this.shape_15.setTransform(111.875,11.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAdA4IgchhIgBAAIgcBhIgcAAIgfhvIARAAIAbBhIADAAIAahhIAcAAIAbBhIADAAIAbhhIARAAIgfBvg");
	this.shape_16.setTransform(96.975,11.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgqAtQgNgPAAgeQAAgdANgOQANgOAdgBQAdABANAOQAOAOAAAdQAAAegOAPQgNAOgdgBQgdABgNgOgAgeggQgJAJAAAXQAAAYAJAJQAJALAVAAQAWAAAJgLQAJgJAAgYQAAgXgJgJQgJgLgWABQgVgBgJALg");
	this.shape_17.setTransform(81.1,11.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgyA4IAAhvIAuAAQAcAAANANQAOANAAAdQAAAdgOAOQgNANgcAAgAgiApIAeAAQAVAAAJgJQAJgJAAgXQAAgVgJgKQgJgKgVAAIgeAAg");
	this.shape_18.setTransform(68.475,11.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgHA4IAAgsIguhDIASAAIAjA1IAjg1IATAAIgvBDIAAAsg");
	this.shape_19.setTransform(56.175,11.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAcA4IgVgkIgDAAIgjAAIAAAkIgQAAIAAhvIAzAAQAYAAAKAIQAKAJAAAVQAAAQgGAHQgGAKgMADIAWAlgAgfAFIAjAAQAPABAGgFQAHgEAAgOQAAgNgHgGQgGgEgPgBIgjAAg");
	this.shape_20.setTransform(44.775,11.45);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AguA4IAAhvIA1AAQATAAAJAGQAJAHAAAQQAAAWgRAEQAUADAAAXQAAARgKAGQgJAHgWAAgAgeApIAkAAQAOAAAFgDQAGgEAAgKQAAgKgGgEQgFgEgMAAIgmAAgAgegHIAlAAQALAAAFgEQAFgDAAgKQAAgJgFgFQgFgDgMAAIgkAAg");
	this.shape_21.setTransform(32.675,11.45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgHA4IAAgsIguhDIASAAIAjA1IAjg1IATAAIgvBDIAAAsg");
	this.shape_22.setTransform(20.775,11.45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAiA4IAAgyIhDAAIAAAyIgPAAIAAhvIAPAAIAAAwIBDAAIAAgwIAQAAIAABvg");
	this.shape_23.setTransform(8.6,11.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3a, new cjs.Rectangle(0,0,168,41.7), null);


(lib.txt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag9BYQgVgNAAgdQAAglAigJQgfgLAAgkQABgbATgNQATgMAoAAQApAAATAMQAUANAAAbQAAAkgeALQAhAJAAAlQAAAdgVANQgTAMgrAAQgpAAgUgMgAgbAUQgIAGAAANQAAANAIAFQAIAFATAAQAUAAAIgFQAIgFAAgNQAAgNgIgGQgIgFgUAAQgTAAgIAFgAgZg4QgHAFAAAMQAAAMAHAFQAHAFASAAQATAAAHgFQAIgFAAgMQAAgMgIgFQgHgFgTAAQgSAAgHAFg");
	this.shape.setTransform(174.3,12.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag+BMQgUgYAAg0QAAgzAUgYQATgYArAAQArAAAUAYQAUAYAAAzQAAA0gUAYQgUAYgrAAQgrAAgTgYgAgbgwQgIANAAAjQAAAkAIANQAHANAUAAQAVAAAHgNQAIgNAAgkQAAgjgIgNQgHgNgVAAQgUAAgHANg");
	this.shape_1.setTransform(156.325,12.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BMQgUgYAAg0QAAgzAUgYQATgYArAAQArAAAUAYQAUAYAAAzQAAA0gUAYQgUAYgrAAQgrAAgTgYgAgbgwQgIANAAAjQAAAkAIANQAHANAUAAQAVAAAHgNQAIgNAAgkQAAgjgIgNQgHgNgVAAQgUAAgHANg");
	this.shape_2.setTransform(138.325,12.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhMBeIAAgmQAhAGAdAAQAaAAAKgFQAJgEAAgNQAAgNgHgFQgHgFgSAAIg1AAIAAgkIA1AAQAQAAAGgEQAHgFAAgNQAAgMgIgEQgIgEgYAAQgcAAgiAGIAAgmQAegGAiAAQAsAAAUALQAUAMAAAdQAAAkgeALQAhAJAAAlQAAAegVAMQgVAMgvAAQgiAAgegGg");
	this.shape_3.setTransform(120.475,12.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgXBgIAAhKIhQh1IA1AAIAzBLIAzhLIA0AAIhRB1IAABKg");
	this.shape_4.setTransform(93.45,12.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAjBgIghiYIgDAAIghCYIhPAAIgvi/IAyAAIAkCYIAEAAIAfiYIBPAAIAfCYIAEAAIAkiYIAyAAIgvC/g");
	this.shape_5.setTransform(65.975,12.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhPBMQgYgYAAg0QAAgzAYgYQAYgYA3AAQA4AAAZAYQAXAYAAAzQAAA0gXAYQgZAYg4AAQg3AAgYgYgAgsgsQgMANAAAfQAAAgAMANQANAOAfAAQAhAAAMgOQAMgNAAggQAAgfgMgNQgMgOghAAQgfAAgNAOg");
	this.shape_6.setTransform(37.575,12.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAmBgIhYh/IAAB/IgvAAIAAi/IA6AAIBaCCIAAiCIAvAAIAAC/g");
	this.shape_7.setTransform(13.975,12.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(0,-6,193.2,36.3), null);


(lib.txt2_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag1BQQgQgMAAgZQAAgkAggHQgdgIAAgjQAAgZAQgLQAQgMAiAAQAjAAAQAMQAQALAAAZQAAAjgdAIQAgAHAAAkQAAAZgQAMQgRAMglAAQgkAAgRgMgAgiAQQgKAHAAARQAAAPAJAHQALAHAYAAQAaAAAKgHQAKgHAAgPQAAgRgLgHQgKgGgZAAQgYAAgKAGgAggg9QgJAHAAAPQAAAQAJAGQAKAGAWAAQAYAAAJgGQAKgGAAgQQAAgPgJgHQgKgHgYAAQgXAAgJAHg");
	this.shape.setTransform(58.525,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag1BGQgRgVAAgxQAAgvARgWQAQgWAlAAQAmAAAQAWQARAWAAAvQAAAxgRAVQgQAWgmAAQglAAgQgWgAgjg1QgLAQAAAlQAAAmALAQQAKAPAZAAQAZAAALgPQALgQAAgmQAAglgLgQQgLgPgZAAQgZAAgKAPg");
	this.shape_1.setTransform(42.4,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag2BGQgQgVAAgxQAAgvAQgWQARgWAlAAQAlAAARAWQARAWAAAvQAAAxgRAVQgRAWglAAQglAAgRgWgAgjg1QgLAQABAlQgBAmALAQQAKAPAZAAQAaAAAKgPQAKgQAAgmQAAglgKgQQgKgPgaAAQgZAAgKAPg");
	this.shape_2.setTransform(26.25,16.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhBBWIAAgUQAcAGAcAAQAcAAAMgIQAKgGAAgRQAAgSgKgHQgJgGgWAAIgsAAIAAgVIAsAAQAVAAAIgGQAJgGAAgSQAAgQgJgHQgKgHgaAAQgcAAgaAGIAAgUQAZgGAeAAQAkAAARALQAPALAAAaQAAAjgcAIQAgAGAAAlQAAAagRALQgSAMgnAAQggAAgZgGg");
	this.shape_3.setTransform(10.175,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2_6, new cjs.Rectangle(0,0,94.4,33.6), null);


(lib.txt2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCBGQgVgWAAgwQAAgvAVgWQAVgWAtAAQAuAAAVAWQAVAWAAAvQAAAwgVAWQgVAWguAAQgtAAgVgWgAgwg0QgOAQAAAkQAAAlAOAQQAPAPAhAAQAiAAAPgPQAOgQAAglQAAgkgOgQQgPgPgiAAQghAAgPAPg");
	this.shape.setTransform(120.6,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABGQgVgWAAgwQAAgvAVgWQAUgWAtAAQAkAAAUAOQAUANAHAdIgaAAQgFgRgPgIQgNgHgYAAQghAAgOAPQgOAQAAAkQAAAlAOAQQAPAPAiAAQAeAAAOgKQAOgLAAgZIAAgFIg9AAIAAgWIBWAAIAAAcQAABFhTAAQguAAgVgWg");
	this.shape_1.setTransform(100.175,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag/BYIAAivIB/AAIAAAXIhnAAIAAA1IBgAAIAAAWIhgAAIAAA2IBnAAIAAAXg");
	this.shape_2.setTransform(81.85,16.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAtBYIgriZIgDAAIgrCZIgsAAIgxivIAaAAIArCZIAEAAIAqiZIAtAAIAqCZIAFAAIAqiZIAaAAIgxCvg");
	this.shape_3.setTransform(58.225,16.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhCBGQgVgWAAgwQAAgvAVgWQAVgWAtAAQAuAAAVAWQAVAWAAAvQAAAwgVAWQgVAWguAAQgtAAgVgWgAgvg0QgPAQAAAkQAAAlAPAQQAOAPAhAAQAiAAAOgPQAPgQAAglQAAgkgPgQQgOgPgiAAQghAAgOAPg");
	this.shape_4.setTransform(33.25,16.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAvBYIhliNIAACNIgYAAIAAivIAfAAIBmCPIAAiPIAYAAIAACvg");
	this.shape_5.setTransform(12.45,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2_5, new cjs.Rectangle(0,0,133.2,33.6), null);


(lib.txt2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBYIAAivIAXAAIAACvg");
	this.shape.setTransform(115.575,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAtBYIgriZIgDAAIgrCZIgsAAIgxivIAaAAIArCZIAEAAIAqiZIAtAAIAqCZIAFAAIAqiZIAaAAIgxCvg");
	this.shape_1.setTransform(97.175,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCBZQgVgWAAgwQAAgwAVgVQAVgWAtAAQAuAAAVAWQAVAVAAAwQAAAwgVAWQgVAVguAAQgtAAgVgVgAgwghQgOAPAAAlQAAAlAOAPQAPAQAhAAQAiAAAOgQQAPgPAAglQAAglgPgPQgOgQgiAAQghAAgPAQgAgMhPIAZgeIAaAAIgcAeg");
	this.shape_2.setTransform(72.2,14.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABEBYIAAiOIg1BoIgdAAIg2hoIAACOIgYAAIAAivIAkAAIA3BuIADAAIA3huIAkAAIAACvg");
	this.shape_3.setTransform(50.05,16.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA/BYIgTgyIhXAAIgTAyIgaAAIBFivIAnAAIBFCvgAAjAPIgghSIgFAAIggBSIBFAAg");
	this.shape_4.setTransform(28.675,16.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhMBYIAAgWIBziCIhtAAIAAgXICMAAIAAAXIhzCBIB6AAIAAAXg");
	this.shape_5.setTransform(10.6,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2_4, new cjs.Rectangle(0,0,121.5,33.6), null);


(lib.txt2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBYIAAhFIhIhqIAdAAIA2BTIA3hTIAdAAIhIBqIAABFg");
	this.shape.setTransform(85.9,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAsBYIghg4IgEAAIg5AAIAAA4IgYAAIAAivIBRAAQAlAAAPANQAQAOAAAhQAAAZgJANQgJANgUAFIAkA7gAgyAJIA5AAQAYAAAJgHQAKgHAAgWQAAgWgKgIQgJgHgYAAIg5AAg");
	this.shape_1.setTransform(67.975,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCBZQgVgWAAgwQAAgwAVgVQAVgWAtAAQAuAAAVAWQAVAVAAAwQAAAwgVAWQgVAVguAAQgtAAgVgVgAgwghQgOAPAAAlQAAAlAOAPQAPAQAhAAQAiAAAOgQQAPgPAAglQAAglgPgPQgOgQgiAAQghAAgPAQgAgMhPIAZgeIAaAAIgcAeg");
	this.shape_2.setTransform(47.55,14.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLBYIAAiYIhDAAIAAgXICdAAIAAAXIhDAAIAACYg");
	this.shape_3.setTransform(28.525,16.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoBYIhYhWIAABWIgYAAIAAivIAYAAIAABNIBXhNIAhAAIhfBTIBgBcg");
	this.shape_4.setTransform(11.875,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2_3, new cjs.Rectangle(0,0,96.9,33.6), null);


(lib.txt2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgWAgIAVg/IAYAAIgYA/g");
	this.shape.setTransform(174.425,26.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABFBYIAAiOIg2BoIgdAAIg2hoIAACOIgYAAIAAivIAkAAIA4BuIABAAIA4huIAkAAIAACvg");
	this.shape_1.setTransform(158.45,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgMBYIAAhFIhIhqIAdAAIA3BTIA4hTIAcAAIhIBqIAABFg");
	this.shape_2.setTransform(137.8,16.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhMBYIAAgWIBziCIhsAAIAAgXICLAAIAAAXIhyCBIB5AAIAAAXg");
	this.shape_3.setTransform(120.45,16.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBTIAAgZQAhAKAgAAQAdAAALgGQALgGAAgPQAAgPgJgGQgJgFgdgFQgrgEgOgKQgOgKAAgbQAAgaARgLQASgNAnAAQAeAAAeAIIAAAYQgggIgcAAQgcAAgLAGQgJAFAAAOQgBAOAJAFQAJAFAeAFQAqAEAOAKQAOALAAAcQAAAcgRAMQgSAMgpAAQghAAgggJg");
	this.shape_4.setTransform(102.9,16.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAtBYIgriZIgDAAIgrCZIgsAAIgxivIAaAAIArCZIAEAAIAqiZIAtAAIAqCZIAFAAIAqiZIAaAAIgxCvg");
	this.shape_5.setTransform(79.075,16.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAsBYIghg4IgEAAIg5AAIAAA4IgYAAIAAivIBRAAQAlAAAPANQAQAOAAAhQAAAZgJANQgJANgUAFIAkA7gAgyAJIA5AAQAYAAAJgHQAKgHAAgWQAAgWgKgIQgJgHgYAAIg5AAg");
	this.shape_6.setTransform(55.325,16.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag/BYIAAivIB/AAIAAAXIhnAAIAAA1IBgAAIAAAWIhgAAIAAA2IBnAAIAAAXg");
	this.shape_7.setTransform(37.05,16.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLBYIAAivIAXAAIAACvg");
	this.shape_8.setTransform(24.325,16.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhKBYIAAivIBRAAQAlAAAPANQAQAOAAAiQAAAhgQAOQgPAOglAAIg5AAIAAA1gAgyAMIA5AAQAYAAAJgIQAKgHAAgXQAAgWgKgIQgJgIgYAAIg5AAg");
	this.shape_9.setTransform(12.075,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2_2, new cjs.Rectangle(0,0,183,33.6), null);


(lib.txt2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhMBtIAAgXIBziCIhtAAIAAgXICMAAIAAAXIhzCBIB6AAIAAAYgAgJhNIAZgeIAaAAIgdAeg");
	this.shape.setTransform(68.55,14.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhPBYIAAivIBJAAQAtAAAUAVQAVAVAAAtQAAAvgVAVQgUAUgtAAgAg2BBIAwAAQAhAAAOgPQAOgPAAgjQAAgigOgPQgOgPghAAIgwAAg");
	this.shape_1.setTransform(50.425,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AApBcQAAgIAEgGQAGgGALgIIgTgxIhWAAIgTAyIgaAAIBFiwIAnAAIBECwIgIAAQgNAIgEAFQgFAEABAGQAAAJAOAAIAQgBIAAAOQgLACgIAAQgdAAAAgUgAAigHIgfhTIgFAAIggBTIBEAAg");
	this.shape_2.setTransform(30.4,19.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhJBYIAAivIBUAAQAeAAAOAKQAOALAAAZQAAAjgbAGQAgAGAAAjQAAAbgPAKQgPAKgiAAgAgwBBIA6AAQAVAAAJgFQAJgGAAgQQAAgQgJgGQgIgFgTAAIg9AAgAgwgLIA7AAQASAAAHgGQAIgFAAgQQAAgPgIgGQgHgFgTAAIg6AAg");
	this.shape_3.setTransform(11.925,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2_1, new cjs.Rectangle(0,0,85,33.6), null);


(lib.txt1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA3B4Ih5h2IAAB2IghAAIAAjvIAhAAIAABoIB4hoIArAAIiBBxICEB+g");
	this.shape.setTransform(334.425,62.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhUBfQgcgeAAhBQAAhAAcgeQAcgeA6AAQAvAAAbASQAbASAKAnIgkAAQgHgXgSgKQgSgKggAAQgqAAgTAVQgTAVAAAyQAAAyATAWQATAVAqAAQA9AAAOgsIAkAAQgKAngbATQgbASgvAAQg6AAgcgeg");
	this.shape_1.setTransform(308.025,62.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABWB4IgahEIh2AAIgaBEIgkAAIBdjvIA3AAIBdDvgAAvAVIgrhxIgHAAIgsBxIBeAAg");
	this.shape_2.setTransform(281.675,62.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhkB4IAAjvIByAAQAqAAATANQASAPABAiQAAAwgkAJQArAIAAAwQgBAkgUAPQgUANguAAgAhDBZIBRAAQAdAAALgIQAMgIAAgVQAAgWgLgIQgLgHgbAAIhUAAgAhDgQIBSAAQAYAAAKgHQAKgIAAgVQAAgVgKgIQgKgHgaAAIhQAAg");
	this.shape_3.setTransform(256.5,62.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgQB4IAAjQIhbAAIAAgfIDXAAIAAAfIhbAAIAADQg");
	this.shape_4.setTransform(231.15,62.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AheBxIAAgiQAsANAsAAQAoAAAPgHQAPgIAAgVQAAgVgMgHQgMgIgpgGQg6gHgTgMQgTgPAAgkQAAgjAXgQQAYgRA2AAQAoAAApALIAAAhQgsgLglAAQgnAAgPAHQgNAHAAATQAAAUAMAHQALAHAqAGQA5AGAUAOQATAPAAAmQAAAlgYARQgYAQg3AAQguAAgrgMg");
	this.shape_5.setTransform(207.025,62.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABWB4IgahEIh2AAIgaBEIgkAAIBdjvIA3AAIBdDvgAAvAVIgrhxIgHAAIgsBxIBeAAg");
	this.shape_6.setTransform(181.475,62.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhVB4IAAjvICrAAIAAAfIiKAAIAABNICAAAIAAAeIiAAAIAABlg");
	this.shape_7.setTransform(158.275,62.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhQBlQgZgWAAg1IAAiUIAhAAIAACUQAAAkARAOQAQAOAnAAQAoAAAQgOQARgOAAgkIAAiUIAhAAIAACUQAAA1gZAWQgYAWg5AAQg4AAgYgWg");
	this.shape_8.setTransform(123.525,62.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhmB4IAAjvIBvAAQAyAAAWASQAVATAAAuQAAAugVATQgWASgyAAIhOAAIAABJgAhFAQIBOAAQAhAAANgLQANgKAAgfQAAgegNgLQgNgLghAAIhOAAg");
	this.shape_9.setTransform(98.3,62.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgQB4IAAheIhiiRIAnAAIBLBxIBMhxIAnAAIhjCRIAABeg");
	this.shape_10.setTransform(72.575,62.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgQB4IAAjQIhbAAIAAgfIDXAAIAAAfIhbAAIAADQg");
	this.shape_11.setTransform(48.75,62.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgcB4IhdjvIAkAAIBSDRIAIAAIBRjRIAkAAIheDvg");
	this.shape_12.setTransform(345.4,22.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhQBlQgZgWAAg1IAAiUIAhAAIAACUQAAAkARAOQAQAOAnAAQAoAAAQgOQARgOAAgkIAAiUIAhAAIAACUQAAA1gZAWQgYAWg5AAQg4AAgYgWg");
	this.shape_13.setTransform(318.725,22.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AheBxIAAgiQAsANAsAAQAoAAAPgHQAPgIAAgVQAAgVgMgHQgMgIgpgGQg6gHgTgMQgTgPAAgkQAAgjAXgQQAYgRA2AAQAoAAApALIAAAhQgsgLglAAQgnAAgPAHQgNAHAAATQAAAUAMAHQALAHAqAGQA5AGAUAOQATAPAAAmQAAAlgYARQgYAQg3AAQguAAgrgMg");
	this.shape_14.setTransform(292.825,22.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgQB4IAAheIhiiRIAnAAIBLBxIBMhxIAnAAIhjCRIAABeg");
	this.shape_15.setTransform(259.275,22.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AA+B4Ig7jRIgFAAIg7DRIg7AAIhDjvIAjAAIA7DRIAGAAIA5jRIA9AAIA5DRIAHAAIA6jRIAjAAIhCDvg");
	this.shape_16.setTransform(227.3,22.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhbBfQgcgdAAhCQAAhBAcgdQAdgeA+AAQA/AAAcAeQAdAdAABBQAABCgdAdQgcAeg/AAQg+AAgdgegAhBhHQgUAVAAAyQAAAyAUAWQATAVAuAAQAvAAATgVQAUgVAAgzQAAgygUgVQgTgVgvAAQguAAgTAVg");
	this.shape_17.setTransform(193.275,22.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhsB4IAAjvIBkAAQA8AAAdAcQAcAdAAA+QAABAgcAcQgcAcg9AAgAhLBZIBDAAQAsAAATgVQAUgUAAgwQAAgvgUgUQgTgVgsAAIhDAAg");
	this.shape_18.setTransform(166.175,22.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgQB4IAAheIhiiRIAnAAIBLBxIBMhxIAnAAIhjCRIAABeg");
	this.shape_19.setTransform(139.825,22.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AA8B4IgshNIgHAAIhOAAIAABNIggAAIAAjvIBuAAQAyAAAVASQAXATAAAtQAAAigNASQgMASgbAHIAwBQgAhFAMIBOAAQAgAAANgKQAOgKABgdQgBgegOgLQgNgKggAAIhOAAg");
	this.shape_20.setTransform(115.35,22.275);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhjB4IAAjvIBxAAQArAAARANQAUAPgBAiQABAwglAJQArAIABAwQAAAkgVAPQgUANguAAgAhDBZIBRAAQAdAAALgIQAMgIAAgVQAAgWgLgIQgLgHgaAAIhVAAgAhDgQIBSAAQAZAAAJgHQAKgIAAgVQAAgVgLgIQgJgHgaAAIhQAAg");
	this.shape_21.setTransform(89.4,22.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgQB4IAAheIhiiRIAnAAIBLBxIBMhxIAnAAIhjCRIAABeg");
	this.shape_22.setTransform(63.875,22.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("ABJB4IAAhpIiRAAIAABpIghAAIAAjvIAhAAIAABnICRAAIAAhnIAhAAIAADvg");
	this.shape_23.setTransform(37.775,22.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1a, new cjs.Rectangle(0,0,382.1,84.9), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiBC3QgrgbAAg9QAAhMBGgUQg/gWAAhMQAAg5ApgbQAogZBUABQBVgBAoAZQAqAbAAA5QAABMg/AWQBFAUAABMQAAA9grAbQgpAahZAAQhXAAgqgagAg5AqQgRAMAAAcQAAAaAQALQASALAoAAQApAAASgLQAQgLAAgaQAAgcgRgMQgRgKgpgBQgoABgRAKgAg1h2QgPAKAAAZQAAAaAPAJQAPALAmAAQAnAAAPgLQAPgJABgaQgBgZgOgKQgPgLgoAAQgmAAgPALg");
	this.shape.setTransform(375.325,35.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiDCeQgogyAAhsQAAhrAogyQApgzBaABQBbgBApAzQAoAyAABrQAABsgoAyQgpAzhbAAQhaAAgpgzgAg6hlQgPAcAABJQAABLAPAbQAQAbAqAAQArAAAQgbQAPgbABhLQgBhJgPgcQgQgbgrAAQgqAAgQAbg");
	this.shape_1.setTransform(337.75,35.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiDCeQgogyAAhsQAAhrAogyQApgzBaABQBagBApAzQApAyAABrQAABsgpAyQgpAzhaAAQhaAAgpgzgAg6hlQgPAcgBBJQABBLAPAbQAPAbArAAQArAAAQgbQAQgbAAhLQAAhJgQgcQgQgbgrAAQgrAAgPAbg");
	this.shape_2.setTransform(300.15,35.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AigDDIAAhOQBGAMA7AAQA4ABAUgKQATgJAAgbQAAgcgPgKQgOgKglAAIhwAAIAAhOIBwAAQAhAAANgIQAOgJAAgbQAAgZgRgKQgRgIgyAAQg7AAhGANIAAhOQA/gNBFAAQBfAAAoAXQArAYAAA8QAABMhAAXQBGATAABNQAABAgtAZQgrAYhkABQhHAAg+gOg");
	this.shape_3.setTransform(262.875,35.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgwDJIAAicIioj1IBwAAIBqCdIBqidIBtAAIioD2IAACbg");
	this.shape_4.setTransform(206.475,35.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABKDJIhGk+IgIAAIhEE+IilAAIhimRIBoAAIBLE/IAIAAIBCk/IClAAIBAE/IAJAAIBMk/IBoAAIhjGRg");
	this.shape_5.setTransform(149.25,35.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AinCeQgxgyAAhsQAAhrAxgyQA0gzBzABQB0gBA0AzQAxAyAABrQAABsgxAyQg0Azh0AAQhzAAg0gzgAhdheQgYAbAABDQAABDAYAbQAbAdBCAAQBEAAAagdQAYgbAAhDQAAhDgYgbQgagchEAAQhCAAgbAcg");
	this.shape_6.setTransform(90.075,35.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABQDJIi5kKIAAEKIhiAAIAAmRIB6AAIC7ERIAAkRIBiAAIAAGRg");
	this.shape_7.setTransform(40.9,35.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-94,0,598.2,71.4), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bitmap1();
	this.instance.setTransform(0,0,0.75,0.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,294.8,303), null);


(lib.img3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img3300x600();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3, new cjs.Rectangle(0,0,300,600), null);


(lib.img2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img2300x600();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2, new cjs.Rectangle(0,0,300,600), null);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1300x600();
	this.instance.setTransform(0,0,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1, new cjs.Rectangle(0,0,600,1200), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.instance = new lib.icon();
	this.instance.setTransform(41,9,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgzBFIAAgXIBBhAIg+AAIAAgYIBiAAIAAAYIhABAIBCAAIAAAXgAgLgxIAPgTIAdAAIgUATg");
	this.shape.setTransform(162.7,19.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag3A4IAAhvIAzAAQAfAAAPANQAOAOAAAcQAAAegOANQgOANggAAgAgcAgIAYAAQASAAAHgHQAHgIAAgRQAAgRgHgHQgHgIgSABIgYAAg");
	this.shape_1.setTransform(150.725,20.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAVA4IgUhYIgCAAIgTBYIguAAIgbhvIAdAAIAVBYIADAAIAShYIAtAAIASBYIACAAIAWhYIAdAAIgbBvg");
	this.shape_2.setTransform(134.1,20.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAiA4IgJgZIgyAAIgIAZIgeAAIAqhvIArAAIApBvgAAQAHIgOgoIgDAAIgPAoIAgAAg");
	this.shape_3.setTransform(117.7,20.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAWA4IgRgeIgfAAIAAAeIgbAAIAAhvIA7AAQAaAAALAJQALAKAAAVQAAAdgVAIIATAigAgaADIAgAAQALAAAFgDQAEgDAAgLQAAgLgEgEQgFgEgLAAIggAAg");
	this.shape_4.setTransform(104.95,20.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag1A4IAAhvIA8AAQAZAAALAKQALAJAAAWQAAAVgLAKQgLAJgZAAIghAAIAAAegAgaAEIAgAAQALgBAFgDQAEgDAAgLQAAgLgEgEQgFgEgLAAIggAAg");
	this.shape_5.setTransform(92.5,20.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgxA0IAAgYQAeAGASABQAOAAAFgCQAFgCAAgHQAAgGgEgCQgFgDgPgCQgcgCgKgHQgLgGAAgSQAAgTAMgHQAMgJAbAAQAWAAAWAEIAAAZQgZgGgSAAQgPAAgEACQgFACAAAGQAAAGAEACIAUAEQAcACAKAHQALAHAAASQAAATgMAJQgMAIgcABQgYAAgYgHg");
	this.shape_6.setTransform(79.875,20.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bgc
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AwZDIIAAmPMAgzAAAIAAGPg");
	this.shape_7.setTransform(105,20);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,210,40), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_6
	this.txt2_6 = new lib.txt2_6();
	this.txt2_6.name = "txt2_6";
	this.txt2_6.setTransform(176.25,77.5,1,1,0,0,0,47.1,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt2_6).wait(1));

	// txt2_5
	this.txt2_5 = new lib.txt2_5();
	this.txt2_5.name = "txt2_5";
	this.txt2_5.setTransform(61.5,77.5,1,1,0,0,0,66.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt2_5).wait(1));

	// txt2_4
	this.txt2_4 = new lib.txt2_4();
	this.txt2_4.name = "txt2_4";
	this.txt2_4.setTransform(155.2,47.4,1,1,0,0,0,60.8,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt2_4).wait(1));

	// txt2_3
	this.txt2_3 = new lib.txt2_3();
	this.txt2_3.name = "txt2_3";
	this.txt2_3.setTransform(43.5,47.4,1,1,0,0,0,48.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt2_3).wait(1));

	// txt2_2
	this.txt2_2 = new lib.txt2_2();
	this.txt2_2.name = "txt2_2";
	this.txt2_2.setTransform(169,17.3,1,1,0,0,0,91.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt2_2).wait(1));

	// txt2_1
	this.txt2_1 = new lib.txt2_1();
	this.txt2_1.name = "txt2_1";
	this.txt2_1.setTransform(37.55,17.3,1,1,0,0,0,42.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt2_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(-5,0.5,265.5,93.8), null);


(lib.group3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(150.5,545.15,1,1,0,0,0,105,20);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// logo_last_frame
	this.logo_last_frame = new lib.logo();
	this.logo_last_frame.name = "logo_last_frame";
	this.logo_last_frame.setTransform(49.8,52.15,0.35,0.35,0,0,0,147.5,151.6);

	this.timeline.addTween(cjs.Tween.get(this.logo_last_frame).wait(1));

	// txt3
	this.txt3 = new lib.txt3();
	this.txt3.name = "txt3";
	this.txt3.setTransform(185.9,37.7,1,1,0,0,0,96.6,15.5);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// txt3a
	this.txt3a = new lib.txt3a();
	this.txt3a.name = "txt3a";
	this.txt3a.setTransform(182.5,65.2,1,1,0,0,0,91.4,18.2);

	this.timeline.addTween(cjs.Tween.get(this.txt3a).wait(1));

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(150,161.65,1,1,0,0,0,135,41.3);

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	// img3
	this.img3 = new lib.img3();
	this.img3.name = "img3";
	this.img3.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.group3, new cjs.Rectangle(-1.8,-0.9,301.8,600.9), null);


(lib.group2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(149.95,306,1,1,0,0,0,133.4,48.4);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// img2
	this.img2 = new lib.img2();
	this.img2.name = "img2";
	this.img2.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.group2, new cjs.Rectangle(0,0,300,600), null);


(lib.group1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.setTransform(300.3,355.3,1,1,0,0,0,147.3,151.5);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(301,514.75,1,1,0,0,0,203,35.6);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// txt1a
	this.txt1a = new lib.txt1a();
	this.txt1a.name = "txt1a";
	this.txt1a.setTransform(306.15,569.4,1,1,0,0,0,194.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.txt1a).wait(1));

	// img1
	this.img1 = new lib.img1();
	this.img1.name = "img1";
	this.img1.setTransform(300,600,1,1,0,0,0,300,600);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.group1, new cjs.Rectangle(0,0,602.2,1200), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var group1 = this.group1;
			var img1 = group1.img1;
			var txt1 = group1.txt1;
			var txt1a = group1.txt1a;
			var logo = group1.logo;
		
		var group2 = this.group2;
			var img2 = group2.img2;
			var txt2 = group2.txt2;
			var txt2_1 = group2.txt2.txt2_1;
			var txt2_2 = group2.txt2.txt2_2;
			var txt2_3 = group2.txt2.txt2_3;
			var txt2_4 = group2.txt2.txt2_4;
			var txt2_5 = group2.txt2.txt2_5;
			var txt2_6 = group2.txt2.txt2_6;
			var elements = [txt2_1, txt2_2, txt2_3, txt2_4, txt2_5, txt2_6];
		
		var group3 = this.group3;
			var img3 = group3.img3;
			var txt3 = group3.txt3;
			var txt3a = group3.txt3a;
			var txt4 = group3.txt4;
			var cta = group3.cta;
			var logo_last_frame = group3.logo_last_frame;
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf);
			}
		}
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat:0, repeatDelay:0});
		
		
		tl
				
			.add("frame2", "+=2")
			.from([group2], {y:"+="+h, duration:.7}, "frame2")
			.staggerFrom(elements, .1, {alpha:0}, .2, "frame2+=.2")
			.add(autoShot)
			
			.add("frame3", "frame2+=4")
			.from([group3], {y:"+="+h, duration:.5}, "frame3")
			.call(autoShot, [true],"+=0")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// group3
	this.group3 = new lib.group3();
	this.group3.name = "group3";
	this.group3.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.group3).wait(1));

	// group2
	this.group2 = new lib.group2();
	this.group2.name = "group2";
	this.group2.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.group2).wait(1));

	// group1
	this.group1 = new lib.group1();
	this.group1.name = "group1";
	this.group1.setTransform(150,300,0.5,0.5,0,0,0,300,600);

	this.timeline.addTween(cjs.Tween.get(this.group1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(148.2,299.1,152.90000000000003,300.9);
// library properties:
lib.properties = {
	id: '336565F901BB4B639513018BB676A918',
	width: 300,
	height: 600,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"bitmap1.png", id:"bitmap1"},
		{src:"icon.png", id:"icon"},
		{src:"img1300x600.jpg", id:"img1300x600"},
		{src:"img2300x600.jpg", id:"img2300x600"},
		{src:"img3300x600.jpg", id:"img3300x600"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['336565F901BB4B639513018BB676A918'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;