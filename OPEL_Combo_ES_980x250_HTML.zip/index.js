(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1960,500);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt3a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFg");
	this.shape.setTransform(57.425,13.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgKAcQgHgHgCgMIgIAAIABgEIAGAAIAAgFIAAgEIgHAAIABgEIAHAAQACgMAIgHQAHgGAKAAQAKAAAKAFIAAAGQgKgGgJAAQgJAAgFAFQgGAFgCAKIAbAAIAAAEIgbAAIgBAEIABAFIAbAAIAAAEIgbAAQADAUATAAQAJAAAKgGIAAAGQgKAFgKAAQgKAAgIgGg");
	this.shape_1.setTransform(53.1,10.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWAiIAAgFIAWgUIALgMQAFgGAAgGQAAgMgQAAQgMAAgKAIIAAgGQAKgIAMAAQALAAAFAFQAGAFAAAIQAAAHgGAHQgEAFgKAJIgQAPIAlAAIAAAGg");
	this.shape_2.setTransform(46.975,10.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgSAbQgGgHAAgSQAAgjAcAAQAJAAAIAEIAAAGQgIgFgJAAQgWAAgBAeQADgEAGgEQAFgDAGAAQAMAAAGAGQAGAFAAAKQAAAJgGAHQgHAGgLAAQgMAAgHgHgAgMAAQgGAEAAAHQAAAIAFAFQAGAFAHAAQAJAAAFgFQAFgFAAgHQAAgIgFgEQgEgEgKAAQgHAAgFAEg");
	this.shape_3.setTransform(41.075,10.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgEAOIAEgbIAGAAIgGAbg");
	this.shape_4.setTransform(36.8,14.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAJAhIAAgOIgkAAIAAgFIAjguIAHAAIAAAuIANAAIAAAFIgNAAIAAAOgAgVAOIAeAAIAAgpg");
	this.shape_5.setTransform(32.625,10.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgWAdIAAgGQALAFAKAAQASAAAAgQQAAgIgEgEQgGgCgJAAQgJAAgJACIAAghIAoAAIAAAGIgjAAIAAAVQAGgBAIAAQAMgBAGAGQAGADAAALQAAALgHAFQgGAGgLAAQgLAAgKgFg");
	this.shape_6.setTransform(26.45,10.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgWAdIAAgGQALAFAKAAQASAAAAgQQAAgIgEgEQgGgCgJAAQgJAAgJACIAAghIAoAAIAAAGIgkAAIAAAVQAIgBAHAAQAMgBAGAGQAGADAAALQAAALgHAFQgGAGgLAAQgLAAgKgFg");
	this.shape_7.setTransform(20.5,10.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFg");
	this.shape_8.setTransform(16.425,13.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgTAdQgHgGAAgIQAAgGAEgEQAFgEAHgBQgGgBgEgEQgEgFAAgFQAAgJAHgFQAGgEALAAQAMAAAGAEQAHAFAAAJQAAAFgEAFQgEAEgGABQAHAAAFAFQAEAEAAAGQAAAJgHAFQgHAFgNAAQgMAAgHgFgAgUAPQAAAGAFAEQAGAEAJAAQAKAAAGgEQAFgEAAgGQAAgNgVAAQgUAAAAANgAgNgYQgFADAAAGQAAAGAFAEQAFADAIAAQATAAAAgNQAAgGgFgDQgFgFgJAAQgIAAgFAFg");
	this.shape_9.setTransform(12.225,10.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAHAhIAAg6IgTAFIAAgFIAagHIAABBg");
	this.shape_10.setTransform(6.75,10.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgEAVQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFgAgEgUQAAgFAEAAQAFAAAAAFQAAAEgFAAQgEAAAAgEg");
	this.shape_11.setTransform(159.775,-0.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgPAWQgEgEAAgHQAAgNASAAIAOAAQABAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgEQAAgMgOAAQgJAAgIAEIAAgFQAJgEAIAAQAUAAgBARIAAAhIgFAAIAAgMQgEANgOAAQgJAAgDgEgAgPALQAAAFADADQAEADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgPAAQgOAAgBAKg");
	this.shape_12.setTransform(156,-0.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgJAMIAAgYIgLAAIAAgFIAJAAQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAIAAgOIAFAAIAAAPIAZAAIAAAFIgZAAIAAAYQAAAQANAAQAGAAAGgCIAAAFQgGACgHAAQgRAAAAgVg");
	this.shape_13.setTransform(151.125,-1.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgYAAQAAgZAYAAQAZAAAAAZQAAAagZAAQgYAAAAgagAgSAAQAAAVASAAQAUAAAAgVQAAgUgUAAQgSAAAAAUg");
	this.shape_14.setTransform(145.825,-0.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgQAVQgGgFABgKIAAgfIAFAAIAAAeQAAAQAPAAQAHAAAGgGQAFgGAAgJIAAgZIAGAAIAAAyIgGAAIAAgOQgFAPgOAAQgJAAgFgFg");
	this.shape_15.setTransform(139.75,-0.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGALAAQAJAAAIAEIAAAFQgIgEgJAAQgSAAAAAUQAAAVASAAQAKAAAHgEIAAAFQgIAEgJAAQgLAAgGgGg");
	this.shape_16.setTransform(134.2,-0.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgPAWQgFgEAAgHQAAgNATAAIAOAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgEQAAgMgOAAQgJAAgIAEIAAgFQAJgEAIAAQAUAAAAARIAAAhIgGAAIAAgMQgFANgNAAQgJAAgDgEgAgOALQAAAFACADQAEADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAABAKg");
	this.shape_17.setTransform(126.45,-0.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAgAaIAAgeQAAgQgNAAQgIAAgEAGQgEAFAAAKIAAAZIgFAAIAAgeQAAgQgNAAQgIAAgEAGQgEAFAAAKIAAAZIgGAAIAAgyIAGAAIAAAMQAEgNANAAQAOAAACAOQAEgOAOAAQASAAAAAUIAAAfg");
	this.shape_18.setTransform(119.575,-0.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgCAkIAAgxIAFAAIAAAxgAgDgfQAAgEADgBQAEABABAEQgBAFgEgBQgDABAAgFg");
	this.shape_19.setTransform(113.75,-1.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgJAMIAAgYIgLAAIAAgFIAJAAQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAIAAgOIAFAAIAAAPIAZAAIAAAFIgZAAIAAAYQAAAQANAAQAGAAAGgCIAAAFQgGACgHAAQgRAAAAgVg");
	this.shape_20.setTransform(110.125,-1.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgCAkIAAhHIAFAAIAABHg");
	this.shape_21.setTransform(106.675,-1.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgTAlQgGgIAAgOIAAglIAGAAIAAAkQgBANAFAFQAFAHAKAAQALAAAFgHQAFgFgBgNIAAgkIAGAAIAAAlQAAAOgGAIQgGAHgOAAQgNAAgGgHgAgEgeIAJgNIAHAAIgLANg");
	this.shape_22.setTransform(102.1,-2.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFg");
	this.shape_23.setTransform(95.225,1.725);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgKAcQgHgHgCgMIgIAAIABgEIAGAAIAAgFIAAgEIgHAAIABgEIAHAAQACgMAIgHQAHgGAKAAQAKAAAKAFIAAAGQgKgGgJAAQgJAAgFAFQgGAFgCAKIAbAAIAAAEIgbAAIgBAEIABAFIAbAAIAAAEIgbAAQADAUATAAQAJAAAKgGIAAAGQgKAFgKAAQgKAAgIgGg");
	this.shape_24.setTransform(90.9,-1.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgWAdIAAgGQALAFAKAAQATAAgBgQQAAgJgEgDQgFgDgKAAQgKAAgIADIAAghIAoAAIAAAGIgkAAIAAAVQAIgBAHAAQAMAAAGAEQAGAFAAAKQAAAKgGAGQgHAGgLgBQgLABgKgFg");
	this.shape_25.setTransform(84.75,-1.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAJAhIAAgOIgkAAIAAgFIAjguIAHAAIAAAuIANAAIAAAFIgNAAIAAAOgAgVAOIAeAAIAAgpg");
	this.shape_26.setTransform(78.375,-1.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgFAOIAFgbIAFAAIgFAbg");
	this.shape_27.setTransform(73.9,2.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgWAiIAAgFIAWgUIALgMQAFgGAAgGQAAgMgQAAQgMAAgKAIIAAgGQAKgIAMAAQALAAAFAFQAGAFAAAIQAAAHgGAHQgEAFgKAJIgQAPIAlAAIAAAGg");
	this.shape_28.setTransform(70.175,-1.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgSAaQgIgJAAgRQAAgPAIgJQAHgJALAAQANAAAGAJQAIAJgBAPQABARgIAJQgGAIgNAAQgLAAgHgIgAgOgVQgFAIAAANQAAAPAFAHQAFAHAJAAQAKAAAFgHQAGgIgBgOQABgNgGgIQgGgHgJAAQgJAAgFAHg");
	this.shape_29.setTransform(64.05,-1.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgSAaQgIgJABgRQgBgPAIgJQAHgJALAAQANAAAGAJQAIAJAAAPQAAARgIAJQgGAIgNAAQgLAAgHgIgAgOgVQgGAIABANQgBAPAGAHQAGAHAIAAQAKAAAFgHQAGgIgBgOQABgNgGgIQgFgHgKAAQgIAAgGAHg");
	this.shape_30.setTransform(57.55,-1.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFg");
	this.shape_31.setTransform(53.325,1.725);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgWAdIAAgGQAKAFALAAQATAAAAgQQAAgJgGgDQgFgDgJAAQgKAAgIADIAAghIAoAAIAAAGIgkAAIAAAVQAIgBAHAAQAMAAAGAEQAGAFAAAKQAAAKgGAGQgHAGgKgBQgMABgKgFg");
	this.shape_32.setTransform(49.45,-1.15);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgEAVQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFgAgEgUQAAgFAEAAQAFAAAAAFQAAAEgFAAQgEAAAAgEg");
	this.shape_33.setTransform(42.925,-0.425);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgPAWQgFgEAAgHQAAgNATAAIAOAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgEQAAgMgOAAQgJAAgIAEIAAgFQAJgEAIAAQAUAAAAARIAAAhIgGAAIAAgMQgFANgNAAQgJAAgDgEgAgOALQAAAFACADQAEADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAABAKg");
	this.shape_34.setTransform(39.15,-0.425);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgQAfQgHgHAAgNQAAgMAHgIQAGgGAJAAQAPAAAEANIAAgiIAGAAIAABHIgGAAIAAgMQgEANgOAAQgKAAgGgFgAgLgFQgGAFAAALQAAAKAGAGQAEAEAHABQAIAAAFgGQAGgEgBgJIAAgEQABgJgGgFQgFgFgIAAQgHAAgEAFg");
	this.shape_35.setTransform(33.45,-1.45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgQAWQgDgEAAgHQAAgNASAAIAOAAQABAAAAAAQAAAAAAgBQABAAAAAAQAAgBAAAAIAAgEQAAgMgOAAQgJAAgIAEIAAgFQAJgEAIAAQATAAAAARIAAAhIgFAAIAAgMQgEANgOAAQgJAAgEgEgAgPALQAAAFAEADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgPAAQgOAAgBAKg");
	this.shape_36.setTransform(27.85,-0.425);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgMAZIAAgxIAFAAIAAAOQAFgOAPAAIAAAFQgJAAgFAGQgFAFAAAJIAAAYg");
	this.shape_37.setTransform(23.875,-0.45);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgJAMIAAgYIgLAAIAAgFIAJAAQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAIAAgOIAFAAIAAAPIAZAAIAAAFIgZAAIAAAYQAAAQANAAQAGAAAGgCIAAAFQgGACgHAAQgRAAAAgVg");
	this.shape_38.setTransform(19.275,-1.175);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_39.setTransform(14.025,-0.475);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgUAhIAAhBIApAAIAAAFIgkAAIAAAYIAhAAIAAAEIghAAIAAAaIAkAAIAAAGg");
	this.shape_40.setTransform(8.025,-1.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgLApQARgQAAgZQAAgYgRgQIADgDQAUAQAAAbQAAAcgUAQg");
	this.shape_41.setTransform(175.4,-12.725);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_42.setTransform(171.175,-12.375);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgYAKQAAgZAYAAQAZAAAAAZQAAAbgZgBQgYAAAAgagAgSAKQAAAWASAAQAUgBAAgVQAAgUgUAAQgSAAAAAUgAgDgWIAIgOIAIAAIgMAOg");
	this.shape_43.setTransform(165.075,-13.35);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgCAkIAAgxIAEAAIAAAxgAgEgfQAAgEAEgBQAFABgBAEQABAEgFAAQgEAAAAgEg");
	this.shape_44.setTransform(160.95,-13.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGALAAQAJAAAIAEIAAAFQgIgEgJAAQgSAAAAAUQAAAVASAAQAKAAAHgEIAAAFQgIAEgJAAQgLAAgGgGg");
	this.shape_45.setTransform(157.15,-12.325);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgPAWQgEgEgBgHQABgNASAAIAOAAQABAAAAAAQAAgBABAAQAAAAAAAAQAAgBAAAAIAAgEQAAgMgOAAQgJAAgIAEIAAgFQAJgEAIAAQAUAAAAARIAAAhIgGAAIAAgMQgEANgOAAQgJAAgDgEgAgOALQAAAFACADQAEADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgPAAQgOAAAAAKg");
	this.shape_46.setTransform(151.85,-12.325);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgCAkIAAgxIAFAAIAAAxgAgEgfQABgEADgBQAFABgBAEQABAEgFAAQgDAAgBgEg");
	this.shape_47.setTransform(148.25,-13.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAHgGAKAAQAJAAAIAEIAAAFQgIgEgIAAQgTAAAAAUQAAAVATAAQAJAAAHgEIAAAFQgIAEgJAAQgKAAgHgGg");
	this.shape_48.setTransform(144.45,-12.325);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_49.setTransform(138.975,-12.375);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgPAWQgFgEAAgHQAAgNATAAIAOAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAgBAAAAIAAgEQAAgMgPAAQgIAAgIAEIAAgFQAJgEAIAAQATAAABARIAAAhIgGAAIAAgMQgEANgOAAQgIAAgEgEgAgOALQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_50.setTransform(133.1,-12.325);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_51.setTransform(127.725,-12.375);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgCAkIAAgxIAEAAIAAAxgAgDgfQgBgEAEgBQAFABAAAEQAAAEgFAAQgEAAABgEg");
	this.shape_52.setTransform(123.45,-13.45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgKAlIAAgtIgJAAIAAgFIAIAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIAAgDQAAgJAFgFQAFgFAHAAQAHAAAGADIAAAFQgGgDgGAAQgMAAAAAOIAAAEIAWAAIAAAFIgWAAIAAAtg");
	this.shape_53.setTransform(120.325,-13.475);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgQAWQgDgEAAgHQAAgNASAAIAOAAQABAAAAAAQAAgBAAAAQABAAAAAAQAAgBAAAAIAAgEQAAgMgOAAQgJAAgIAEIAAgFQAJgEAIAAQATAAAAARIAAAhIgFAAIAAgMQgEANgOAAQgJAAgEgEgAgPALQAAAFAEADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgPAAQgOAAgBAKg");
	this.shape_54.setTransform(112.9,-12.325);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgCAkIAAhHIAFAAIAABHg");
	this.shape_55.setTransform(109.325,-13.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_56.setTransform(102.775,-12.375);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgWAAQAAgMAHgHQAHgGAJAAQALAAAFAGQAGAFAAALIAAADIgoAAQABALAFAGQAEAEAKAAQAKAAAJgEIAAAEQgJAFgLAAQgYAAAAgagAASgDQAAgRgRAAQgHAAgEAEQgFAEgBAJIAiAAIAAAAg");
	this.shape_57.setTransform(96.875,-12.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgYAAQAAgZAYAAQAZAAAAAZQAAAagZAAQgYAAAAgagAgSAAQAAAVASAAQAUAAAAgVQAAgUgUAAQgSAAAAAUg");
	this.shape_58.setTransform(88.675,-12.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgQAfQgHgHAAgOQAAgLAHgIQAGgGAJAAQAPAAAFANIAAgiIAFAAIAABHIgFAAIAAgMQgFANgOAAQgKAAgGgFgAgMgFQgFAFAAAKQAAALAFAGQAFAFAHAAQAIgBAFgFQAGgEAAgJIAAgEQAAgJgGgFQgFgFgIAAQgHAAgFAFg");
	this.shape_59.setTransform(82.45,-13.35);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgCAkIAAgxIAEAAIAAAxgAgDgfQgBgEAEgBQAFABAAAEQAAAEgFAAQgEAAABgEg");
	this.shape_60.setTransform(78.45,-13.45);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgQAVQgFgFAAgKIAAgfIAFAAIAAAeQAAAQAPAAQAHAAAGgGQAFgGAAgJIAAgZIAGAAIAAAyIgGAAIAAgOQgFAPgOAAQgJAAgFgFg");
	this.shape_61.setTransform(74.15,-12.275);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgCAkIAAhHIAFAAIAABHg");
	this.shape_62.setTransform(70.075,-13.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAHgGAKAAQAJAAAHAEIAAAFQgHgEgIAAQgUAAAAAUQAAAVAUAAQAJAAAHgEIAAAFQgIAEgJAAQgKAAgHgGg");
	this.shape_63.setTransform(66.3,-12.325);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_64.setTransform(60.825,-12.375);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgCAkIAAgxIAEAAIAAAxgAgEgfQAAgEAEgBQAFABgBAEQABAEgFAAQgEAAAAgEg");
	this.shape_65.setTransform(56.55,-13.45);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgYAAQAAgZAYAAQAZAAAAAZQAAAagZAAQgYAAAAgagAgSAAQAAAVASAAQAUAAAAgVQAAgUgUAAQgSAAAAAUg");
	this.shape_66.setTransform(49.925,-12.325);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_67.setTransform(44.025,-12.375);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgYAAQAAgZAYAAQAZAAAAAZQAAAagZAAQgYAAAAgagAgSAAQAAAVASAAQAUAAAAgVQAAgUgUAAQgSAAAAAUg");
	this.shape_68.setTransform(35.475,-12.325);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgJAMIAAgYIgLAAIAAgFIAJAAQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAIAAgOIAFAAIAAAPIAZAAIAAAFIgZAAIAAAYQAAAQANAAQAGAAAGgCIAAAFQgGACgHAAQgRAAAAgVg");
	this.shape_69.setTransform(30.075,-13.075);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgCAkIAAgxIAEAAIAAAxgAgDgfQgBgEAEgBQAFABAAAEQAAAEgFAAQgEAAABgEg");
	this.shape_70.setTransform(26.6,-13.45);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgQAfQgHgHAAgOQAAgLAHgIQAGgGAJAAQAPAAAFANIAAgiIAFAAIAABHIgFAAIAAgMQgFANgOAAQgKAAgGgFgAgMgFQgFAFAAAKQAAALAFAGQAFAFAHAAQAIgBAFgFQAGgEAAgJIAAgEQAAgJgGgFQgFgFgIAAQgHAAgFAFg");
	this.shape_71.setTransform(22.15,-13.35);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgWAKQAAgLAHgIQAHgGAJAAQALAAAFAGQAGAFAAALIAAADIgoAAQABALAFAGQAEAFAKAAQAKAAAJgFIAAAFQgJAEgLAAQgYAAAAgagAASAGQAAgQgRAAQgHAAgEAEQgFAFgBAHIAiAAIAAAAgAgCgWIAJgOIAHAAIgMAOg");
	this.shape_72.setTransform(16.525,-13.35);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgMAZIAAgxIAFAAIAAAOQAFgPAPAAIAAAGQgJAAgFAGQgFAFAAAJIAAAYg");
	this.shape_73.setTransform(12.225,-12.35);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAHgGAKAAQAJAAAIAEIAAAFQgIgEgIAAQgUAAABAUQgBAVAUAAQAJAAAHgEIAAAFQgIAEgJAAQgKAAgHgGg");
	this.shape_74.setTransform(7.45,-12.325);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgWAAQAAgMAHgHQAHgGAJAAQALAAAFAGQAGAFAAALIAAADIgoAAQABALAFAGQAEAEAKAAQAKAAAJgEIAAAEQgJAFgLAAQgYAAAAgagAASgDQAAgRgRAAQgHAAgEAEQgFAEgBAJIAiAAIAAAAg");
	this.shape_75.setTransform(177.025,-24.225);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgQAeQgHgGAAgOQAAgMAHgGQAGgHAJAAQAOAAAGANIAAghIAFAAIAABHIgFAAIAAgNQgFANgOAAQgKABgGgHgAgMgFQgFAFAAAKQAAAMAFAFQAFAFAHgBQAIAAAFgEQAGgFAAgJIAAgEQAAgJgGgFQgEgFgJAAQgHAAgFAFg");
	this.shape_76.setTransform(171,-25.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgYAAQAAgZAYAAQAZAAAAAZQAAAagZAAQgYAAAAgagAgSAAQAAAVASAAQAUAAAAgVQAAgUgUAAQgSAAAAAUg");
	this.shape_77.setTransform(162.725,-24.225);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgMAaIAAgyIAFAAIAAAPQAFgPAPgBIAAAGQgJAAgFAFQgFAHAAAIIAAAZg");
	this.shape_78.setTransform(158.225,-24.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgQAVQgGgFAAgKIAAgfIAGAAIAAAeQAAAQAPAAQAHAAAFgGQAGgGAAgJIAAgZIAFAAIAAAyIgFAAIAAgOQgFAPgOAAQgJAAgFgFg");
	this.shape_79.setTransform(152.95,-24.175);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgTAgIAAgGQAJAFAJAAQATAAAAgSIAAgJQgFANgOAAQgJAAgFgGQgIgHAAgMQAAgNAIgHQAFgHAKAAQAOAAAEANIAAgMIAFAAIAAAvQABAXgYAAQgLAAgIgEgAgLgZQgGAGABALQgBAKAGAFQAEAEAHAAQAIAAAFgEQAFgFAAgIIAAgDQAAgVgSAAQgGAAgFAFg");
	this.shape_80.setTransform(146.8,-23.275);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgWAAQAAgMAHgHQAHgGAJAAQALAAAFAGQAGAFAAALIAAADIgoAAQABALAFAGQAEAEAKAAQAKAAAJgEIAAAEQgJAFgLAAQgYAAAAgagAASgDQAAgRgRAAQgHAAgEAEQgFAEgBAJIAiAAIAAAAg");
	this.shape_81.setTransform(141.225,-24.225);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgTAWIAAgGQAJAFAKAAQAPAAAAgJQAAgEgDgDQgCgBgGgBIgJgCQgOgBAAgKQAAgHAFgEQAFgEAJAAQAKAAAIAEIAAAFQgIgEgKAAQgGAAgEACQgEADAAAEQAAAEADACIAHACIAKACQAHABAEACQADADAAAGQAAAHgGAEQgFAEgJAAQgLAAgIgEg");
	this.shape_82.setTransform(135.975,-24.225);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgCAkIAAhHIAFAAIAABHg");
	this.shape_83.setTransform(129.925,-25.3);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgWAAQAAgMAHgHQAHgGAJAAQALAAAFAGQAGAFAAALIAAADIgoAAQABALAFAGQAEAEAKAAQAKAAAJgEIAAAEQgJAFgLAAQgYAAAAgagAASgDQAAgRgRAAQgHAAgEAEQgFAEgBAJIAiAAIAAAAg");
	this.shape_84.setTransform(125.975,-24.225);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AARAaIAAgeQAAgQgPAAQgHAAgFAGQgGAGAAAJIAAAZIgFAAIAAgyIAFAAIAAAOQAFgPAOAAQAJAAAFAFQAFAGAAAJIAAAfg");
	this.shape_85.setTransform(117.825,-24.275);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgYAAQAAgZAYAAQAZAAAAAZQAAAagZAAQgYAAAAgagAgSAAQAAAVASAAQAUAAAAgVQAAgUgUAAQgSAAAAAUg");
	this.shape_86.setTransform(111.725,-24.225);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgTAWIAAgGQAJAFAKAAQAPAAAAgJQAAgEgDgDQgCgBgGgBIgJgCQgOgBAAgKQAAgHAFgEQAFgEAJAAQAKAAAIAEIAAAFQgIgEgKAAQgGAAgEACQgEADAAAEQAAAEADACIAHACIAKACQAHABAEACQADADAAAGQAAAHgGAEQgFAEgJAAQgLAAgIgEg");
	this.shape_87.setTransform(106.275,-24.225);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgJAcQgJgHgBgMIgIAAIABgEIAHAAIAAgFIAAgEIgIAAIABgEIAHAAQACgMAIgHQAHgGALAAQAJAAAKAFIAAAGQgKgGgJAAQgJAAgFAFQgGAFgCAKIAcAAIAAAEIgdAAIAAAEIAAAFIAdAAIAAAEIgcAAQADAUATAAQAJAAAKgGIAAAGQgJAFgKAAQgMAAgGgGg");
	this.shape_88.setTransform(98.05,-25.025);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgTAdQgHgFAAgJQAAgGAEgFQAFgEAHAAQgGgCgEgEQgEgEAAgFQAAgJAHgFQAGgEALAAQAMAAAGAEQAHAFAAAJQAAAFgEAEQgEAEgGACQAHAAAFAEQAEAFAAAGQAAAJgHAFQgHAFgNAAQgMAAgHgFgAgUAPQAAAGAFAEQAGAEAJAAQAKAAAGgEQAFgEAAgGQAAgNgVAAQgUAAAAANgAgNgYQgFADAAAGQAAAGAFADQAFADAIAAQATAAAAgMQAAgGgFgDQgFgEgJgBQgIABgFAEg");
	this.shape_89.setTransform(91.575,-25);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AAJAhIAAgOIgkAAIAAgFIAjguIAHAAIAAAtIANAAIAAAGIgNAAIAAAOgAgVANIAeAAIAAgng");
	this.shape_90.setTransform(85.125,-25);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgFAOIAFgbIAFAAIgFAbg");
	this.shape_91.setTransform(80.65,-21.425);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgWAdIAAgGQAKAFALAAQATAAAAgQQAAgJgGgDQgFgCgJAAQgKgBgIADIAAggIAoAAIAAAEIgkAAIAAAXQAIgDAHAAQAMABAGAFQAGADAAALQAAAKgGAGQgHAFgKAAQgMAAgKgEg");
	this.shape_92.setTransform(76.9,-24.95);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AAIAhIAAg6IgVAFIAAgFIAagHIAABBg");
	this.shape_93.setTransform(71.5,-25);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgTAWIAAgGQAJAFAKAAQAPAAAAgJQAAgEgDgDQgCgBgGgBIgJgCQgOgBAAgKQAAgHAFgEQAFgEAJAAQAKAAAIAEIAAAFQgIgEgKAAQgGAAgEACQgEADAAAEQAAAEADACIAHACIAKACQAHABAEACQADADAAAGQAAAHgGAEQgFAEgJAAQgLAAgIgEg");
	this.shape_94.setTransform(64.725,-24.225);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgWAAQAAgMAHgHQAHgGAJAAQALAAAFAGQAGAFAAALIAAADIgoAAQABALAFAGQAEAEAKAAQAKAAAJgEIAAAEQgJAFgLAAQgYAAAAgagAASgDQAAgRgRAAQgHAAgEAEQgFAEgBAJIAiAAIAAAAg");
	this.shape_95.setTransform(59.475,-24.225);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgCAkIAAhHIAFAAIAABHg");
	this.shape_96.setTransform(55.575,-25.3);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgPAWQgFgEAAgHQAAgNATAAIAOAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAgBAAAAIAAgEQAAgMgPAAQgIAAgIAEIAAgFQAJgEAIAAQATAAABARIAAAhIgGAAIAAgMQgEANgOAAQgIAAgEgEgAgOALQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_97.setTransform(51.65,-24.225);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgQAVQgFgFgBgKIAAgfIAGAAIAAAeQAAAQAPAAQAHAAAFgGQAGgGAAgJIAAgZIAFAAIAAAyIgFAAIAAgOQgFAPgPAAQgIAAgFgFg");
	this.shape_98.setTransform(46.1,-24.175);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGALAAQAJAAAHAEIAAAFQgHgEgIAAQgUAAAAAUQAAAVAUAAQAJAAAHgEIAAAFQgIAEgJAAQgLAAgGgGg");
	this.shape_99.setTransform(40.55,-24.225);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgTAWIAAgGQAJAFAKAAQAPAAAAgJQAAgEgDgDQgCgBgGgBIgJgCQgOgBAAgKQAAgHAFgEQAFgEAJAAQAKAAAIAEIAAAFQgIgEgKAAQgGAAgEACQgEADAAAEQAAAEADACIAHACIAKACQAHABAEACQADADAAAGQAAAHgGAEQgFAEgJAAQgLAAgIgEg");
	this.shape_100.setTransform(33.075,-24.225);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgYAAQAAgZAYAAQAZAAAAAZQAAAagZAAQgYAAAAgagAgSAAQAAAVASAAQAUAAAAgVQAAgUgUAAQgSAAAAAUg");
	this.shape_101.setTransform(27.625,-24.225);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgCAkIAAhHIAFAAIAABHg");
	this.shape_102.setTransform(23.525,-25.3);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AgWAAQAAgMAHgHQAHgGAJAAQALAAAFAGQAGAFAAALIAAADIgoAAQABALAFAGQAEAEAKAAQAKAAAJgEIAAAEQgJAFgLAAQgYAAAAgagAASgDQAAgRgRAAQgHAAgEAEQgFAEgBAJIAiAAIAAAAg");
	this.shape_103.setTransform(17.125,-24.225);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgQAeQgHgGAAgOQAAgMAHgGQAGgHAKAAQAOAAAFANIAAghIAFAAIAABHIgFAAIAAgNQgFANgOAAQgKABgGgHgAgMgFQgFAFAAAKQAAAMAFAFQAFAFAHgBQAHAAAGgEQAFgFABgJIAAgEQgBgJgFgFQgFgFgIAAQgHAAgFAFg");
	this.shape_104.setTransform(11.1,-25.25);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgLAAQAAgbAUgQIADADQgRAQAAAYQAAAZARAQIgDADQgUgQAAgcg");
	this.shape_105.setTransform(7,-24.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Warstwa_1
	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AAAAGIgOAYIgHgFIASgWIgbgGIADgIIAaALIgCgdIAHAAIgCAdIAbgLIACAIIgbAGIASAWIgHAFg");
	this.shape_106.setTransform(162.3,-41.275);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape_107.setTransform(153.925,-38.825);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg7AAIAAAoIA1AAIAAAHIg1AAIAAAsIA7AAIAAAIg");
	this.shape_108.setTransform(144.35,-38.825);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AAvA2IAAhgIgsBgIgFAAIgshgIAABgIgJAAIAAhrIAOAAIApBcIAqhcIAOAAIAABrg");
	this.shape_109.setTransform(132.05,-38.825);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AgXBDIAmiFIAJAAIgmCFg");
	this.shape_110.setTransform(122.425,-38.575);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgYBGQgTgPgGgbIgUAAIAEgUIAOAAIAAgIIAAgHIgSAAIAEgUIARAAQAGgbASgOQATgPAcAAQAaAAATALIAAAiQgSgNgXAAQgPAAgJAGQgIAGgFAMIAqAAIAAAUIgtAAIAAAHIAAAIIAtAAIAAAUIgqAAQAEANAIAFQAJAGAQAAQAOAAAJgEQAKgDAKgHIAAAhQgJAGgLAEQgLADgQAAQgdAAgSgOg");
	this.shape_111.setTransform(111.875,-41.525);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("Ag3BLIAAgiQAKAGAKABQAKADAMAAQAWAAAKgNQALgMABgYQgFAKgLAHQgMAHgOAAQgRAAgNgHQgNgGgHgMQgHgLAAgQQAAgQAHgNQAJgOAOgHQAPgHATAAQAiAAASARQAVATAAArQAAAagIATQgJAVgRALQgSALgaAAQgcAAgSgJgAgVguQgIAHAAAMQAAAMAHAHQAGAFAQAAQANAAAIgFQAIgHgBgLQABgMgIgHQgIgHgNAAQgOAAgHAGg");
	this.shape_112.setTransform(96,-41.55);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgiBRQgOgDgMgFIADgjQAMAGANADQAOADALAAQAOAAAHgFQAIgFAAgJQAAgQgbAAIgbAAIAAgfIAaAAQALAAAGgDQAHgFAAgIQAAgJgIgDQgHgFgPAAQgZAAgUAJIAAgiQAWgJAbAAQAVAAAPAFQAPAGAIAKQAHAKAAANQAAAOgIAJQgHAKgQAFQATADAHAKQAIAJAAAOQAAAOgHAMQgIAKgPAHQgPAGgVAAQgPAAgOgDg");
	this.shape_113.setTransform(81.175,-41.55);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AADBRIAAh3IgsAHIAAgkIBTgNIAAChg");
	this.shape_114.setTransform(67.9,-41.525);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg8AAIAAAoIA2AAIAAAHIg2AAIAAAsIA8AAIAAAIg");
	this.shape_115.setTransform(51.7,-38.825);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AgqA2IAAhrIAiAAQAzAAAAA1QAAAagOAOQgNAOgYAAgAghAuIAZAAQAqAAAAguQAAgtgqAAIgZAAg");
	this.shape_116.setTransform(41.35,-38.825);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape_117.setTransform(30.725,-38.825);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg7AAIAAAoIA1AAIAAAHIg1AAIAAAsIA7AAIAAAIg");
	this.shape_118.setTransform(21.15,-38.825);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AgqA2IAAhrIAhAAQA0AAAAA1QAAAagNAOQgOAOgZAAgAghAuIAYAAQArAAgBguQABgtgrAAIgYAAg");
	this.shape_119.setTransform(10.8,-38.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3a, new cjs.Rectangle(2.9,-60.7,179.1,80.30000000000001), null);


(lib.slash1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7FF14").s().p("AgvA5IAvhxIAwAAIgwBxg");
	this.shape.setTransform(4.7,5.75,1,1,0,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slash1, new cjs.Rectangle(0,0,9.7,11.4), null);


(lib.logo2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0E0E0E").s().p("AOHCyMgm2gEMIAAgBQgBAAAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAICkhVMAu7AAAIABABIgBABIqpFhg");
	this.shape.setTransform(23.1069,17.5804,0.1441,0.144);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0E0E0E").s().p("An4J0Qj8hqjBjBQjCjChrj6QhukEgBkdQAAgiADgrIBkALQgCAeAAAkQAAEJBmDxQBjDoC0C0QCzC0DqBiQDxBnEIAAQGVgBFOjnQFNjnCQl7IBrAAQiSGlltEEQlsEDm/ABQkcAAkEhug");
	this.shape_1.setTransform(32.1809,29.6765,0.1441,0.144);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0E0E0E").s().p("ATrLXQACgeAAgkQAAkJhmjxQhjjoizi0Qi0izjqhkQjxhlkHAAQmWAAlODnQlNDniPF7IhrAAQCSmmFskCQFskDG/gBQEcgBEDBuQD8BqDCDCQDCDBBrD6QBuEEAAEdQAAAigCArg");
	this.shape_2.setTransform(33.2903,10.6376,0.1441,0.144);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0E0E0E").s().p("A4vCzIgBgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIKoljIABAAMAm1AENQABAAAAAAQAAAAABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIijBWg");
	this.shape_3.setTransform(42.3605,22.73,0.1441,0.144);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0E0E0E").s().p("Aj7ExIgBgBIAApfIABgBICIAAIABABIAAHjIABABIFtAAIABABIAAB6IgBABg");
	this.shape_4.setTransform(61.7303,53.3257,0.1438,0.1438);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0E0E0E").s().p("AjHEZQhMgigohIQglhEAAhrQAAhqAlhEQAnhJBNggQBOglB5ABQB5gBBNAlQBOAfAnBKQAmBDAABrQAABsgmBDQgoBJhNAhQhMAjh6AAQh6AAhNgjgAAAi/QhNgBgvAWQgtASgUAsQgVA1ABA4QgBA5AVAzQAWAsArAUQA7AVBBgBQBLAAAvgWQAugRAUgtIAAAAQAVg1gBg4QABg5gVgzQgUgsgsgTQg5gVg6AAIgJABg");
	this.shape_5.setTransform(5.0747,53.3221,0.1438,0.1438);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0E0E0E").s().p("AkjExIgBgBIAApfIABgBIFYAAQBVAAAxAUQA1ARAbAxQAaArAABTQAABvg8AwQg7Ayh5AAIjNAAIgBABIAAC6IgBABgAiZi7IAAC6IABABIDFAAQA+AAAYgWQAagXAAgzQABgbgLgZQgMgUgWgKQgUgKgwAAIjFAAg");
	this.shape_6.setTransform(24.5831,53.3257,0.1438,0.1438);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0E0E0E").s().p("AkCExIgBgBIAApfIABgBIIEAAIABABIAAB2IgBABIl8AAIAAABIAAB8IABABIFXAAIABABIAABtIgBABIlYAAIAAABIAACCIAAABIF+AAIABABIAAB2IgBABg");
	this.shape_7.setTransform(42.4915,53.3257,0.1438,0.1438);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo2, new cjs.Rectangle(0,0,65.4,57.9), null);


(lib.letters2c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgxAAQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoAAQAAAvAoAAQApAAAAgvQAAgvgpABQgoAAAAAug");
	this.shape.setTransform(158.825,39.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgaAqQgNgPAAgbQAAgaANgPQANgOAVAAQAQAAAPAJIAAAJQgPgKgPABQgRgBgKAMQgLANAAAWQAAAYALAMQAKALARAAQAPAAAQgLIAAALQgPAJgRAAQgVAAgNgOg");
	this.shape_1.setTransform(147.975,39.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgEA2IAAhrIAJAAIAABrg");
	this.shape_2.setTransform(140.975,39.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAeA2IgggvIgdAAIAAAvIgKAAIAAhrIAoAAQAmAAAAAeQAAAbgeADIAjAvgAgfAAIAgAAQAaAAAAgXQAAgWgcAAIgeAAg");
	this.shape_3.setTransform(134.225,39.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgEA2IAAhiIgpAAIAAgJIBbAAIAAAJIgpAAIAABig");
	this.shape_4.setTransform(123.025,39.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgaAqQgNgPAAgbQAAgaANgPQANgOAVAAQAQAAAPAJIAAAJQgPgKgPABQgRgBgKAMQgLANAAAWQAAAYALAMQAKALARAAQAPAAAQgLIAAALQgPAJgRAAQgVAAgNgOg");
	this.shape_5.setTransform(112.775,39.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgiBIIAAhsIBFAAIAAAJIg7AAIAAAmIA1AAIAAAJIg1AAIAAArIA7AAIAAAJgAgHgxIAOgWIANAAIgTAWg");
	this.shape_6.setTransform(103.05,37.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AggA2IAAhrIAJAAIAABiIA5AAIAAAJg");
	this.shape_7.setTransform(93.85,39.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg7AAIAAAoIA1AAIAAAHIg1AAIAAAsIA7AAIAAAIg");
	this.shape_8.setTransform(84.15,39.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgxAAQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoAAQAAAvAoAAQApAAAAgvQAAgvgpABQgoAAAAAug");
	this.shape_9.setTransform(69.025,39.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AghA2IAAhrIAKAAIAABiIA5AAIAAAJg");
	this.shape_10.setTransform(54.85,39.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg8AAIAAAoIA2AAIAAAHIg2AAIAAAsIA8AAIAAAIg");
	this.shape_11.setTransform(45.15,39.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape_12.setTransform(35.325,39.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgiBIIAAhsIBFAAIAAAJIg7AAIAAAmIA1AAIAAAJIg1AAIAAArIA7AAIAAAJgAgHgxIAOgWIANAAIgTAWg");
	this.shape_13.setTransform(25.75,37.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgEA2IAAhrIAJAAIAABrg");
	this.shape_14.setTransform(18.625,39.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgqA2IAAhrIAiAAQAzAAAAA1QAAAagOAOQgOAOgXAAgAghAuIAZAAQApAAABguQgBgtgpAAIgZAAg");
	this.shape_15.setTransform(11.3,39.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAgA2IhDhhIAABhIgJAAIAAhrIANAAIBDBhIAAhhIAJAAIAABrg");
	this.shape_16.setTransform(190.35,21.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgxARQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoARQAAAvAoAAQApAAAAgvQAAgugpAAQgogBAAAvgAgGgzIAPgVIALAAIgSAVg");
	this.shape_17.setTransform(178.275,19.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgEA2IAAhrIAJAAIAABrg");
	this.shape_18.setTransform(170.225,21.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape_19.setTransform(163.425,21.525);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAeA2IgggvIgdAAIAAAvIgKAAIAAhrIAoAAQAmAAAAAeQAAAbgeADIAjAvgAgfAAIAgAAQAaAAAAgXQAAgWgcAAIgeAAg");
	this.shape_20.setTransform(153.925,21.525);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg7AAIAAAoIA1AAIAAAHIg1AAIAAAsIA7AAIAAAIg");
	this.shape_21.setTransform(143.4,21.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgHA2IgohrIALAAIAkBkIAmhkIAKAAIgqBrg");
	this.shape_22.setTransform(133.225,21.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAhA2IhEhhIAABhIgJAAIAAhrIANAAIBDBhIAAhhIAJAAIAABrg");
	this.shape_23.setTransform(117.95,21.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg7AAIAAAoIA1AAIAAAHIg1AAIAAAsIA7AAIAAAIg");
	this.shape_24.setTransform(107.1,21.525);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg8AAIAAAoIA2AAIAAAHIg2AAIAAAsIA8AAIAAAIg");
	this.shape_25.setTransform(93.2,21.525);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AghA2IAAhrIAKAAIAABiIA5AAIAAAJg");
	this.shape_26.setTransform(84,21.525);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgnA2IAAhrIAnAAQAkAAAAAbQAAAVgUAFQAYADAAAXQAAAcglAAgAgeAuIAgAAQAcAAAAgVQAAgWgdAAIgfAAgAgegEIAfAAQAaAAAAgVQAAgUgcAAIgdAAg");
	this.shape_27.setTransform(74.275,21.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgEA2IAAhrIAJAAIAABrg");
	this.shape_28.setTransform(66.625,21.525);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAhA2IhEhhIAABhIgJAAIAAhrIANAAIBDBhIAAhhIAJAAIAABrg");
	this.shape_29.setTransform(58.45,21.525);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgxAAQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoAAQAAAvAoAAQApAAAAgvQAAgugpAAQgogBAAAvg");
	this.shape_30.setTransform(46.375,21.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgmA2IAAhrIAoAAQAlAAAAAiQAAAQgKAIQgJAJgRAAIgfAAIAAAogAgcAGIAdAAQAcAAAAgZQAAgagcAAIgdAAg");
	this.shape_31.setTransform(35.65,21.525);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape_32.setTransform(25.475,21.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgEA2IAAhrIAJAAIAABrg");
	this.shape_33.setTransform(18.625,21.525);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgqA2IAAhrIAiAAQAzAAAAA1QAAAagOAOQgOAOgXAAgAghAuIAZAAQApAAABguQgBgtgpAAIgZAAg");
	this.shape_34.setTransform(11.3,21.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letters2c, new cjs.Rectangle(3.4,8.1,269.90000000000003,44.5), null);


(lib.letters2bb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape.setTransform(168.025,24.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAoA2IgMgfIg3AAIgNAfIgKAAIAthrIANAAIAqBrgAAZAOIgYg9IgZA9IAxAAg");
	this.shape_1.setTransform(157.8,24.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgmA2IAAgHIA/hcIg/AAIAAgIIBMAAIAAAGIhBBcIBDAAIAAAJg");
	this.shape_2.setTransform(147.5,24.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAoA2IgNgfIg2AAIgNAfIgJAAIAshrIAMAAIArBrgAAYAOIgYg9IgXA9IAvAAg");
	this.shape_3.setTransform(137.15,24.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AghA2IAAhrIAKAAIAABiIA5AAIAAAJg");
	this.shape_4.setTransform(127.65,24.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgmA2IAAhrIAoAAQAlAAAAAiQAAAQgKAIQgJAJgRAAIgfAAIAAAogAgcAGIAdAAQAcAAAAgZQAAgagcAAIgdAAg");
	this.shape_5.setTransform(118,24.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgRA2IAuhjIhDAAIAAgIIBNAAIAAAHIgtBkg");
	this.shape_6.setTransform(103.85,24.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAoA2IgNgfIg2AAIgNAfIgJAAIAshrIANAAIArBrgAAZAOIgZg9IgYA9IAxAAg");
	this.shape_7.setTransform(89.7,24.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgEA2IAAhiIgpAAIAAgJIBbAAIAAAJIgpAAIAABig");
	this.shape_8.setTransform(78.875,24.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape_9.setTransform(68.725,24.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAoA2IgMgfIg3AAIgNAfIgJAAIAshrIAMAAIArBrgAAYAOIgXg9IgYA9IAvAAg");
	this.shape_10.setTransform(58.5,24.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAeA2IAAgyIg8AAIAAAyIgJAAIAAhrIAJAAIAAAxIA8AAIAAgxIAKAAIAABrg");
	this.shape_11.setTransform(47.55,24.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAgA2IhDhhIAABhIgJAAIAAhrIANAAIBDBhIAAhhIAJAAIAABrg");
	this.shape_12.setTransform(31.8,24.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgxAAQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoAAQAAAvAoAAQApAAAAgvQAAgvgpAAQgoABAAAug");
	this.shape_13.setTransform(19.725,24.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgaAqQgNgOAAgbQAAgbANgPQANgOAVAAQAQAAAPAIIAAAKQgPgJgPgBQgRABgKAMQgLAMAAAXQAAAXALAMQAKALARAAQAPAAAQgKIAAAKQgPAJgRAAQgVAAgNgOg");
	this.shape_14.setTransform(8.875,24.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgEA2IAAgrIgrhAIALAAIAkA4IAlg4IALAAIgsBAIAAArg");
	this.shape_15.setTransform(203.95,6.525);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgxAAQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoAAQAAAvAoAAQApAAAAgvQAAgvgpABQgoAAAAAug");
	this.shape_16.setTransform(189.025,6.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAeA2IgggvIgdAAIAAAvIgKAAIAAhrIAoAAQAmAAAAAeQAAAbgeADIAjAvgAgfAAIAgAAQAaAAAAgXQAAgWgcAAIgeAAg");
	this.shape_17.setTransform(178.325,6.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AggAqQgKgMAAgYIAAg8IAKAAIAAA8QAAAUAHAJQAIALARAAQASAAAIgKQAHgKAAgUIAAg8IAKAAIAAA8QAAAYgKAMQgKANgXAAQgWAAgKgNg");
	this.shape_18.setTransform(166.925,6.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgeAqQgNgPAAgbQAAgaAOgOQANgPAXAAQASAAARAJIAAAJQgSgKgRABQgSgBgKAMQgMANAAAWQAAAvAnAAQAQAAANgFIAAggIgkAAIAAgHIAtAAIAAAsQgSAJgUAAQgXAAgNgOg");
	this.shape_19.setTransform(155.625,6.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgiA2IAAhrIBFAAIAAAIIg8AAIAAAoIA2AAIAAAHIg2AAIAAAsIA8AAIAAAIg");
	this.shape_20.setTransform(145.5,6.525);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgmAuIAAgJQARAKAUAAQAfAAAAgWQAAgJgFgEQgFgEgNgDIgTgDQgagEAAgWQAAgOAKgIQAKgJASAAQAVAAAOAJIAAAKQgQgKgTAAQgNAAgIAGQgIAGAAAKQAAAIAGAFQAEAEAKABIATAEQAPACAHAGQAHAHAAALQAAAPgLAJQgLAIgSAAQgWAAgPgKg");
	this.shape_21.setTransform(135.675,6.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgIAXIAIgsIAJAAIgJAsg");
	this.shape_22.setTransform(124.875,12.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgxAAQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoAAQAAAvAoAAQApAAAAgvQAAgvgpABQgoAAAAAug");
	this.shape_23.setTransform(117.425,6.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgqA2IAAhrIAiAAQAzAAAAA1QAAAagOAOQgNAOgYAAgAghAuIAZAAQAqAAAAguQAAgtgqAAIgZAAg");
	this.shape_24.setTransform(106.15,6.525);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgxAAQAAg3AxAAQAyAAAAA3QAAA4gyAAQgxAAAAg4gAgoAAQAAAvAoAAQApAAAAgvQAAgvgpABQgoAAAAAug");
	this.shape_25.setTransform(94.275,6.55);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAvA2IAAhgIgtBgIgDAAIgthgIAABgIgJAAIAAhrIANAAIAqBcIArhcIANAAIAABrg");
	this.shape_26.setTransform(81.05,6.525);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgxAQQAAg2AxAAQAyAAAAA2QAAA5gyAAQgxAAAAg5gAgoAQQAAAwAoAAQApAAAAgvQAAgvgpABQgoAAAAAtgAgGgyIAPgWIALAAIgSAWg");
	this.shape_27.setTransform(67.875,4.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgaAqQgNgPAAgbQAAgaANgPQANgOAVAAQAQAAAPAJIAAAJQgPgKgPABQgRgBgKAMQgLANAAAWQAAAYALAMQAKALARAAQAPAAAQgLIAAALQgPAJgRAAQgVAAgNgOg");
	this.shape_28.setTransform(57.025,6.55);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAoA2IgMgfIg3AAIgNAfIgKAAIAthrIANAAIAqBrgAAZAOIgYg9IgZA9IAxAAg");
	this.shape_29.setTransform(42.6,6.525);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgcA0IAAgJQAIADAKAAQAQAAAHgKQAHgJAAgWIAAgyIgpAAIAAgJIAyAAIAAA7QAAAagIAMQgKAMgUAAQgMAAgHgDg");
	this.shape_30.setTransform(32.925,6.625);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAoA2IgMgfIg3AAIgNAfIgKAAIAthrIANAAIAqBrgAAYAOIgXg9IgZA9IAwAAg");
	this.shape_31.setTransform(23.6,6.525);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgEA2IAAhrIAJAAIAABrg");
	this.shape_32.setTransform(16.175,6.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgHA2IgohrIALAAIAkBkIAmhkIAKAAIgqBrg");
	this.shape_33.setTransform(9.025,6.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letters2bb, new cjs.Rectangle(1.9,-6.9,321.20000000000005,44.5), null);


(lib.letters2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag/BGQgXgYAAguQAAgtAXgYQAWgXApAAQAqAAAWAXQAXAYAAAtQAAAugXAYQgWAXgqAAQgpAAgWgXgAg4AAQAABDA4AAQA5AAAAhDQAAhDg5AAQg4AAAABDg");
	this.shape.setTransform(274.075,-161.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhGBaIAAizIBGAAQBBAAAAAtQAAAggfAKQAlAHAAAlQAAAwhBAAgAgpBCIAsAAQAnAAAAgcQAAgdgoAAIgrAAgAgpgMIAqAAQAjAAAAgcQAAgagkAAIgpAAg");
	this.shape_1.setTransform(255.825,-161.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABHBaIAAiOIg/COIgPAAIhAiPIAACPIgbAAIAAizIAoAAIA6CHIA7iHIAoAAIAACzg");
	this.shape_2.setTransform(234.225,-161.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag/BGQgXgYAAguQAAgtAXgYQAWgXApAAQAqAAAWAXQAXAYAAAtQAAAugXAYQgWAXgqAAQgpAAgWgXgAg4AAQAABDA4AAQA5AAAAhDQAAhDg5AAQg4AAAABDg");
	this.shape_3.setTransform(211.925,-161.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgsBGQgXgYAAgtQAAgtAXgZQAWgXAmAAQAbAAAYANIAAAcQgXgQgZAAQgZAAgPARQgQASAAAhQAAAiAQARQAPAPAZAAQAYAAAZgRIAAAdQgWAOgeAAQgmAAgWgXg");
	this.shape_4.setTransform(193.625,-161.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag4BaIAAizIAcAAIAACZIBWAAIAAAag");
	this.shape_5.setTransform(171.6,-161.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag7BaIAAizIB3AAIAAAZIhaAAIAAAzIBQAAIAAAXIhQAAIAAA2IBaAAIAAAag");
	this.shape_6.setTransform(155.6,-161.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhDBaIAAizIBEAAQBDAAAAA8QAAAcgRAPQgRAPgeAAIgqAAIAAA9gAgmAEIAnAAQAmAAAAgiQAAgjgmAAIgnAAg");
	this.shape_7.setTransform(139.225,-161.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ag/BGQgXgYAAguQAAgtAXgYQAWgXApAAQAqAAAWAXQAXAYAAAtQAAAugXAYQgWAXgqAAQgpAAgWgXgAg4AAQAABDA4AAQA5AAAAhDQAAhDg5AAQg4AAAABDg");
	this.shape_8.setTransform(120.025,-161.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag/BGQgXgYAAguQAAgtAXgYQAWgXApAAQAqAAAWAXQAXAYAAAtQAAAugXAYQgWAXgqAAQgpAAgWgXgAg4AAQAABDA4AAQA5AAAAhDQAAhDg5AAQg4AAAABDg");
	this.shape_9.setTransform(92.925,-161.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgVBaIg+izIAgAAIAzCdIA2idIAdAAIhACzg");
	this.shape_10.setTransform(74,-161.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("Ag7BaIAAizIB3AAIAAAZIhaAAIAAAzIBQAAIAAAXIhQAAIAAA2IBaAAIAAAag");
	this.shape_11.setTransform(57.2,-161.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag5BGQgRgUAAgpIAAhkIAcAAIAABhQAAAeAJAOQAMAQAZAAQAaAAAKgQQAKgNAAgfIAAhhIAdAAIAABkQAAApgRAUQgSAWgoAAQgmAAgTgWg");
	this.shape_12.setTransform(39.4,-161.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAoBaIhaiSIAACSIgbAAIAAizIAnAAIBZCRIAAiRIAbAAIAACzg");
	this.shape_13.setTransform(19.725,-161.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letters2, new cjs.Rectangle(7.6,-185.8,278.79999999999995,40), null);


(lib.legal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AlnAAILPAA");
	this.shape.setTransform(479.35,95.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1.setTransform(583.675,189.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_2.setTransform(578.925,187.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAEALABQAOgBAKgFIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_3.setTransform(572.15,187.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_4.setTransform(566.975,189.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_5.setTransform(563.8,186.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAAQAAgQAJgJQAIgIAOAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAGAEAKABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_6.setTransform(558.6,187.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAFgRASAAQAMAAAIAIQAIAIAAARQAAAQgIAJQgIAJgMAAQgQAAgHgPIAAAlgAgNgbQgGAFAAAKIAAACQABAVASAAQAJAAAFgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_7.setTransform(551.25,188.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgQAIgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUAAAAAVg");
	this.shape_8.setTransform(543.15,187.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_9.setTransform(537.675,189.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAEALABQAOgBAKgFIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_10.setTransform(532.55,187.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_11.setTransform(526.825,187.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQAAAXATAAQAUgBAAgWQAAgVgUAAQgTAAAAAVg");
	this.shape_12.setTransform(520.15,187.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_13.setTransform(513.075,186.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_14.setTransform(506.875,187.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgTA0IAdhnIAKAAIgcBng");
	this.shape_15.setTransform(501.6,186.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgTA0IAdhnIAKAAIgcBng");
	this.shape_16.setTransform(497.55,186.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgIAZQAAgJAIAAQAJAAAAAJQAAAJgJAAQgIAAAAgJgAgIgYQAAgJAIAAQAJAAAAAJQAAAJgJAAQgIAAAAgJg");
	this.shape_17.setTransform(493.975,187.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_18.setTransform(489.225,187.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AggAtIAAhYIANAAIAAAQQAGgRAQAAQANAAAIAIQAJAIgBARQABAQgJAJQgIAJgMAAQgRAAgFgPIAAAlgAgNgbQgGAFABAKIAAACQAAAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_19.setTransform(482.25,188.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_20.setTransform(474.825,186.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_21.setTransform(468.625,186.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AARAuIAAgmQAAgQgPAAQgIAAgFAGQgFAFAAALIAAAgIgNAAIAAhbIANAAIAAAqQAGgRARAAQAKAAAHAHQAGAGAAALIAAAqg");
	this.shape_22.setTransform(461.825,186.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgIAZQAAgJAIAAQAJAAAAAJQAAAJgJAAQgIAAAAgJgAgIgYQAAgJAIAAQAJAAAAAJQAAAJgJAAQgIAAAAgJg");
	this.shape_23.setTransform(453.075,187.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAEALABQAOgBAKgFIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_24.setTransform(447.95,187.35);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_25.setTransform(442.225,187.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQAAAXATAAQAUgBAAgWQAAgVgUAAQgTAAAAAVg");
	this.shape_26.setTransform(435.55,187.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_27.setTransform(428.475,186.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAgBgNQAAgFgCgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAOAAQASAAALAGIgBANQgNgHgPAAQgIAAgEADQgGAEABAFQAAAGADACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_28.setTransform(421.7,186.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_29.setTransform(413.1,186.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAEALABQAOgBAKgFIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_30.setTransform(407.9,187.35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AggAtIAAhYIANAAIAAAQQAGgRAQAAQAOAAAHAIQAJAIAAARQAAAQgJAJQgHAJgNAAQgRAAgFgPIAAAlgAgNgbQgFAFAAAKIAAACQgBAVATAAQAIAAAGgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_31.setTransform(400.55,188.475);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgdAgQgLgKAAgWQAAgUALgMQALgKASAAQAUAAAKAKQAKAMAAAUQAAAVgKALQgKALgUAAQgSAAgLgLgAgZAAQAAAfAZAAQAbAAAAgfQAAgegbgBQgZABAAAeg");
	this.shape_32.setTransform(391.6,186.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_33.setTransform(382.1,186.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAFAEALABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_34.setTransform(376.9,187.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_35.setTransform(369.075,186.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_36.setTransform(358.925,187.325);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgdANQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAIAAANIAAAHIgwAAQABALAFAGQAFAEALAAQANAAALgFIAAAKQgLAFgPAAQggAAAAghgAATAGQAAgQgSgBQgPABgDAQIAkAAIAAAAgAgFgdIAKgRIAQAAIgPARg");
	this.shape_37.setTransform(352.15,186.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgIAhIgahAIAPAAIATA2IAVg2IANAAIgbBAg");
	this.shape_38.setTransform(344.95,187.35);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgPAOQABAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAgBAKg");
	this.shape_39.setTransform(337.7,187.325);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_40.setTransform(332.375,187.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_41.setTransform(326.375,186.425);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgPAOQABAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAgBAKg");
	this.shape_42.setTransform(316.55,187.325);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAIgIAOAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAGAEAKABQANgBALgFIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_43.setTransform(306.6,187.35);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_44.setTransform(299.825,186.425);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_45.setTransform(293.025,187.275);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAEALABQAOgBAKgFIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_46.setTransform(285.5,187.35);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgQAAgBAWIAAAgIgLAAIAAglQAAgRgOAAQgRAAAAAWIAAAgIgMAAIAAhAIAMAAIAAAPQAFgQARAAQAQAAAEARQAFgRARAAQAWAAAAAZIAAAog");
	this.shape_47.setTransform(276.2,187.275);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_48.setTransform(266.65,187.325);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgHAhIgahAIAOAAIATA2IAUg2IAPAAIgcBAg");
	this.shape_49.setTransform(259.85,187.35);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_50.setTransform(254.55,185.875);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_51.setTransform(249.675,187.325);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_52.setTransform(242.475,187.425);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_53.setTransform(237.1,186.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_54.setTransform(232.175,187.35);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AATAhIgTgaIgTAaIgPAAIAcgiIgageIAQAAIAQAWIARgWIAPAAIgZAeIAcAig");
	this.shape_55.setTransform(225.3,187.35);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAFAEALABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_56.setTransform(218.05,187.35);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_57.setTransform(207.65,187.325);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_58.setTransform(200.225,186.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_59.setTransform(194.8,185.875);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgFAuIAAhbIAMAAIAABbg");
	this.shape_60.setTransform(191.5,186.025);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgWApQgFgFAAgJQAAgTAYAAIAPAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAAgDQAAgLgPAAQgMAAgKAGIAAgMQAMgFAMAAQAaAAAAAVIAAAsIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAbQAAAEAEADQACADAHAAQAGAAAGgFQAFgFAAgJIAAgCIgQAAQgOAAAAALgAgGgdIAKgQIAQAAIgOAQg");
	this.shape_61.setTransform(186.25,186.075);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgIAhIgZhAIAOAAIATA2IAVg2IANAAIgbBAg");
	this.shape_62.setTransform(179.45,187.35);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_63.setTransform(169,187.325);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_64.setTransform(162.625,186.425);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_65.setTransform(157.475,187.3);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgdAAQgBgQAJgJQAKgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAGAEAKABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_66.setTransform(151.1,187.35);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgPAvIAAg2IgKAAIAAgKIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDQAAgLAHgGQAHgHALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAPIAAADIAZAAIAAAKIgZAAIAAA2g");
	this.shape_67.setTransform(144.925,185.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgdAgQgLgKABgWQgBgUALgMQAKgKATAAQATAAALAKQALAMAAAUQAAAVgLALQgLALgTAAQgTAAgKgLgAgaAAQABAfAZAAQAbAAAAgfQAAgegbgBQgZABgBAeg");
	this.shape_68.setTransform(137.3,186.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgIAJQgEgDAAgGQAAgFAEgDQACgDAGAAQAGAAAEADQADADAAAFQAAAGgDADQgEADgGAAQgGAAgCgDg");
	this.shape_69.setTransform(127.55,189.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgMAkQgJgHgDgPIgMAAIADgKIAHAAIAAgEIAAgDIgKAAIADgKIAJAAQACgOALgIQAJgIAOAAQAOAAAJAGIAAASQgJgHgMAAQgHAAgFADQgEADgCAHIAVAAIAAAKIgXAAIAAADIAAAEIAXAAIAAAKIgVAAQACAHADADQAFADAIAAQAHAAAFgCIAKgFIAAARIgKAFQgGACgIAAQgOAAgKgIg");
	this.shape_70.setTransform(121.4,186.375);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_71.setTransform(113.075,186.375);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgRAqIgOgEIACgSQAGADAHABIANACQAGAAAFgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIAOAAQAFAAADgCQADgCABgEQAAgEgEgDQgFgCgHAAQgNAAgKAFIAAgSQALgFAOAAQALAAAIADQAHADAEAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAKABAEAFQADAFAAAHQAAAIgDAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_72.setTransform(105.25,186.375);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_73.setTransform(97.825,186.375);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgIAJQgEgDAAgGQAAgFAEgDQACgDAGAAQAGAAAEADQADADAAAFQAAAGgDADQgEADgGAAQgGAAgCgDg");
	this.shape_74.setTransform(92.35,189.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AAEAqIAAgQIgrAAIAAgPIAmg0IAZAAIAAAzIAQAAIAAAQIgQAAIAAAQgAgSAKIAWAAIAAghg");
	this.shape_75.setTransform(86.05,186.375);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgeArIAAgPIAZgXIAIgHIAEgHIACgFQAAgFgEgDQgDgCgGAAQgGAAgHACQgHACgGAEIAAgSQAGgDAIgDQAGgCAKAAQAIAAAHADQAHADAEAGQADAFAAAHQgBAHgCAGQgCAFgFAEIgNAMIgJAJIAiAAIAAASg");
	this.shape_76.setTransform(78.05,186.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgIAfQgEgDAAgGQAAgFAEgEQACgDAGAAQAGAAAEADQADAEAAAFQAAAGgDADQgEADgGAAQgGAAgCgDgAgIgMQgEgEAAgFQAAgGAEgDQACgDAGAAQAGAAAEADQADADAAAGQAAAFgDAEQgEADgGAAQgGAAgCgDg");
	this.shape_77.setTransform(69.15,187.275);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_78.setTransform(63.475,187.225);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgHAIgFQAHgDAJAAQAPgBAHAJQAIAHAAAPIAAAIIgsAAQABAGACADQACADAEABQAEABAGABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHABgJAAQgPABgKgJgAAOgGQABgOgNAAQgGAAgDAEQgEADgBAHIAaAAIAAAAg");
	this.shape_79.setTransform(55.9,187.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_80.setTransform(50.375,185.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgSAaQgIgJgBgRQABgQAIgIQAJgKAQABQAFgBAFACIAJADIAAAQQgHgEgLAAQgIAAgDAEQgFAEAAAJQAAASAQAAQAHAAAEgCQAEgBAEgCIAAAQQgDADgGABQgEABgHAAQgQABgJgJg");
	this.shape_81.setTransform(45.25,187.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_82.setTransform(38.275,187.225);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIACAAIABgCIAAgDQABgDgEgCQgDgBgFAAQgHAAgGABIgLAEIAAgSIANgDQAGgCAHABQAOAAAIAFQAHAHAAALIAAArIgTAAIAAgMQgFANgOAAQgKABgGgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAADgBQAEgCACgDQABgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_83.setTransform(30.65,187.3);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_84.setTransform(23.525,187.225);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_85.setTransform(17.675,185.8);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgQAvIAAgxIgKAAIAAgQIAGAAIADAAIABgDIAAgBQAAgHADgFQADgGAGgDQAGgDAIAAIAKAAIAHACIAAAQIgGgCIgHgBQgGAAgDADQgDADAAAFIAAACIAWAAIAAAQIgWAAIAAAxg");
	this.shape_86.setTransform(13.125,185.875);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgRAfQgJgEgEgIQgEgHAAgMQAAgKAEgIQAEgHAJgFQAHgDAKAAQALAAAIADQAHAFAFAHQAEAIAAAKQAAAMgEAHQgFAIgHAEQgIADgLAAQgKAAgHgDgAgLgMQgDAEAAAJQAAAIADAEQADAFAIAAQAIAAAEgFQAEgEgBgJQABgIgEgEQgDgFgJABQgHgBgEAFg");
	this.shape_87.setTransform(953.65,169.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_88.setTransform(945.925,169.225);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgHAHgFQAJgDAIAAQAOgBAJAJQAHAHAAAPIAAAIIgrAAQAAAGACADQADADAEABQADABAGABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHABgJAAQgPABgKgJgAAPgGQAAgOgOAAQgEAAgEAEQgEADAAAHIAaAAIAAAAg");
	this.shape_89.setTransform(935.05,169.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgYAcQgHgGABgMIAAgrIATAAIAAAlQAAAHADADQACADAGAAQAFAAAEgEQADgFAAgIIAAghIAUAAIAABBIgTAAIAAgOQgGAQgQAAQgJAAgGgGg");
	this.shape_90.setTransform(927.45,169.375);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AAPAuIAAglQgFAOgPAAQgNAAgIgIQgIgIABgQQgBgMAEgIQADgIAHgEQAGgEAJAAQAGAAAGAEQAGAEADAIIAAgOIASAAIAABZgAgOgKQAAAJAEAEQAEAEAGAAQAHAAAFgFQADgDAAgIIAAgBQAAgJgDgEQgEgFgIAAQgOAAAAASg");
	this.shape_91.setTransform(919.35,170.425);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgPAhQgHgBgFgDIAAgQQAFADAHACQAGACAHAAQALAAAAgHQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAQgBgCgEAAIgKgCQgJgBgFgEQgGgFAAgIQAAgKAIgGQAHgFANAAQAHgBAHACIALADIgBAQIgKgDQgHgCgGAAQgEAAgDACQgDABAAADQAAABABAAQAAAAAAABQAAAAABAAQAAABABAAQABABAEABIAIABQAIABAFACQAEACACADQADAEAAAGQgBALgHAGQgIAFgOAAQgHAAgHgBg");
	this.shape_92.setTransform(908.9,169.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgHAIgFQAIgDAIAAQAPgBAHAJQAIAHAAAPIAAAIIgsAAQABAGACADQACADAEABQADABAHABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHABgJAAQgPABgKgJgAAOgGQAAgOgMAAQgFAAgEAEQgEADgBAHIAaAAIAAAAg");
	this.shape_93.setTransform(902,169.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgJAkQgGgHgBgOIAAgXIgLAAIAAgPIAIAAIACgBIABgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_94.setTransform(895.1,168.425);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_95.setTransform(888.225,169.225);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgHAIgFQAIgDAIAAQAPgBAHAJQAIAHAAAPIAAAIIgsAAQABAGACADQADADADABQADABAHABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHABgIAAQgQABgJgJgAAOgGQABgOgNAAQgGAAgDAEQgDADgCAHIAaAAIAAAAg");
	this.shape_96.setTransform(880.65,169.3);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_97.setTransform(875.125,167.8);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_98.setTransform(871.475,168.025);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgSAaQgJgJAAgRQAAgQAJgIQAJgKAQABQAFgBAFACIAJADIAAAQQgHgEgLAAQgIAAgDAEQgFAEAAAJQAAASAQAAQAHAAAEgCQAEgBAEgCIAAAQQgDADgGABQgFABgGAAQgQABgJgJg");
	this.shape_99.setTransform(866.4,169.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgFANAAIAKAAIADAAIACgCIAAgDQAAgDgEgCQgDgBgGAAQgGAAgGABIgKAEIAAgSIAMgDQAGgCAIABQANAAAIAFQAHAHAAALIAAArIgSAAIAAgMQgGANgPAAQgJABgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAAEgBQACgCACgDQACgDABgFIAAgBIgNAAQgEAAgDACg");
	this.shape_100.setTransform(856.25,169.3);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgFAIgBIAAAWQgGAAgFABQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_101.setTransform(850.575,169.25);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIADAAIABgCIAAgDQgBgDgDgCQgDgBgFAAQgHAAgGABIgKAEIAAgSIAMgDQAGgCAIABQAOAAAGAFQAIAHAAALIAAArIgTAAIAAgMQgEANgPAAQgKABgGgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQADgCADgDQACgDAAgFIAAgBIgMAAQgGAAgCACg");
	this.shape_102.setTransform(844.05,169.3);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AgiAuIAAhZIATAAIAAAPQAFgRAQAAQANAAAIAJQAHAIAAARQAAALgDAHQgEAIgFAEQgHAEgIAAQgPAAgGgNIAAAkgAgKgXQgEAEAAAIIAAABQAAAJAEADQADAFAHAAQAHAAAFgFQADgDAAgJQAAgSgPAAQgHAAgDAFg");
	this.shape_103.setTransform(836.8,170.425);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgRAfQgJgEgDgIQgFgHAAgMQAAgKAFgIQADgHAJgFQAHgDAKAAQALAAAIADQAIAFAEAHQAEAIAAAKQAAAMgEAHQgEAIgIAEQgIADgLAAQgKAAgHgDgAgKgMQgFAEAAAJQABAIADAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgIgEgEQgDgFgJABQgHgBgDAFg");
	this.shape_104.setTransform(825.25,169.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgaAmQgIgIAAgRQAAgMAEgGQAEgIAGgFQAGgDAJAAQAPAAAFANIAAgmIATAAIAABbIgSAAIAAgPQgFAQgQAAQgNABgIgJgAgOANQAAAIAEAFQAEAEAGAAQAHAAAFgFQADgEAAgIIAAgBQAAgJgDgDQgEgFgIABQgOgBAAASg");
	this.shape_105.setTransform(817,168.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgFANAAIAKAAIADAAIACgCIAAgDQAAgDgEgCQgDgBgGAAQgGAAgGABIgKAEIAAgSIAMgDQAGgCAIABQANAAAIAFQAHAHAAALIAAArIgSAAIAAgMQgGANgPAAQgJABgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQADAAADgBQACgCACgDQACgDABgFIAAgBIgNAAQgEAAgDACg");
	this.shape_106.setTransform(809.45,169.3);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgJAkQgGgHgBgOIAAgXIgLAAIAAgPIAIAAIACgBIABgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_107.setTransform(802.85,168.425);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_108.setTransform(795.975,169.225);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgRAfQgJgEgEgIQgEgHAAgMQAAgKAEgIQAEgHAJgFQAHgDAKAAQALAAAIADQAHAFAFAHQAEAIAAAKQAAAMgEAHQgFAIgHAEQgIADgLAAQgKAAgHgDgAgLgMQgDAEAAAJQgBAIAEAEQADAFAIAAQAIAAAEgFQAEgEgBgJQABgIgEgEQgDgFgJABQgHgBgEAFg");
	this.shape_109.setTransform(788.05,169.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgKAPABQAHgBAFACIAJADIAAAQQgIgEgKAAQgJAAgEAEQgEAEAAAJQAAASARAAQAGAAAEgCQAEgBAFgCIAAAQQgFADgEABQgGABgHAAQgPABgIgJg");
	this.shape_110.setTransform(780.85,169.3);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_111.setTransform(772.575,168.025);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIADAAIABgCIAAgDQgBgDgDgCQgDgBgFAAQgHAAgGABIgKAEIAAgSIAMgDQAGgCAHABQAPAAAGAFQAIAHAAALIAAArIgTAAIAAgMQgEANgPAAQgKABgGgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQADgCADgDQACgDAAgFIAAgBIgMAAQgGAAgCACg");
	this.shape_112.setTransform(767.1,169.3);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgRAfQgJgEgDgIQgFgHAAgMQAAgKAFgIQADgHAJgFQAIgDAJAAQALAAAHADQAJAFAEAHQAEAIAAAKQAAAMgEAHQgEAIgJAEQgHADgLAAQgJAAgIgDgAgKgMQgFAEAAAJQAAAIAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgIgEgEQgDgFgJABQgHgBgDAFg");
	this.shape_113.setTransform(756.5,169.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_114.setTransform(750.675,167.8);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgSAaQgIgJgBgRQABgQAIgIQAJgKAPABQAHgBAEACIAJADIAAAQQgHgEgLAAQgIAAgDAEQgFAEAAAJQAAASAQAAQAHAAAEgCQAEgBAEgCIAAAQQgDADgGABQgEABgIAAQgPABgJgJg");
	this.shape_115.setTransform(745.55,169.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgHAHgFQAJgDAIAAQAPgBAIAJQAHAHAAAPIAAAIIgsAAQABAGACADQACADAEABQAEABAGABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHABgJAAQgPABgKgJgAAOgGQAAgOgMAAQgFAAgEAEQgEADgBAHIAaAAIAAAAg");
	this.shape_116.setTransform(738.75,169.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgFAIgBIAAAWQgGAAgFABQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_117.setTransform(732.775,169.25);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AghAqIAAhTIAhAAQASAAAIAHQAIAIAAAOQAAAKgEAFQgEAHgHADQgHAEgJAAIgQAAIAAAZgAgNAAIANAAQAHAAADgCQAEgEAAgGQAAgGgDgDQgEgDgHAAIgNAAg");
	this.shape_118.setTransform(726.075,168.375);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_119.setTransform(716.925,171.825);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_120.setTransform(711.75,169.325);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_121.setTransform(706.425,169.3);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgQAIgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUAAAAAVg");
	this.shape_122.setTransform(699.75,169.35);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_123.setTransform(691.625,168.1);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_124.setTransform(684.25,169.325);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_125.setTransform(678.925,169.3);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_126.setTransform(672.125,169.425);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AgZApIAAgLQAKAFANAAQAUAAABgTIAAgKQgGAPgQAAQgNAAgGgIQgJgJAAgPQAAgRAJgJQAGgIANAAQARAAAFAQIAAgPIANAAIAAA8QAAAPgKAIQgJAHgPAAQgPAAgIgFgAgMgdQgGAGAAAMQAAAUASAAQAIAAAFgFQAGgEAAgJIAAgDQAAgWgTAAQgHAAgFAFg");
	this.shape_127.setTransform(664.2,170.575);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgdAAQAAgQAJgJQAIgIAOAAQANAAAIAHQAIAJgBAOIAAAFIguAAQAAAMAFAFQAFAEALABQAOgBAKgFIAAAKQgKAGgQAAQghAAABgigAATgGQAAgRgSAAQgPAAgCARIAjAAIAAAAg");
	this.shape_128.setTransform(656.95,169.35);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_129.setTransform(650.175,169.325);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_130.setTransform(643.35,169.325);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_131.setTransform(633.35,169.325);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_132.setTransform(628.55,168.025);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AgdAAQAAgQAJgJQAIgIAOAAQAOAAAHAHQAIAJgBAOIAAAFIgvAAQABAMAFAFQAGAEAKABQANgBALgFIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_133.setTransform(620.15,169.35);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_134.setTransform(612.325,168.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_135.setTransform(601.575,169.275);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AgYAmQgIgJAAgQQAAgQAIgJQAJgIAPAAQAQAAAIAIQAJAIAAARQAAAQgJAJQgIAJgQgBQgPABgJgJgAgUANQABAWATAAQAUAAAAgWQAAgWgUAAQgTAAgBAWgAgHgdIAKgRIAQAAIgPARg");
	this.shape_136.setTransform(593.75,168.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_137.setTransform(588.2,167.875);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_138.setTransform(583.225,169.35);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAFgRASAAQANAAAHAIQAJAIAAARQAAAQgJAJQgHAJgNAAQgQAAgHgPIAAAlgAgNgbQgFAFgBAKIAAACQAAAVATAAQAIAAAGgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_139.setTransform(576.25,170.475);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_140.setTransform(570.35,167.875);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_141.setTransform(566.525,169.3);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_142.setTransform(560.425,169.35);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_143.setTransform(554.025,169.325);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_144.setTransform(546.825,169.425);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_145.setTransform(539.875,169.325);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAFAEALABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_146.setTransform(529.9,169.35);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_147.setTransform(522.075,168.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_148.setTransform(511.925,169.325);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_149.setTransform(505.1,169.325);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgOAAQgPAAAAAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgOAAIAAhAIANAAIAAAPQAFgQARAAQAQAAADARQAGgRARAAQAVAAAAAZIAAAog");
	this.shape_150.setTransform(496.2,169.275);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_151.setTransform(488.125,169.3);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQAAAXATAAQAUgBAAgWQAAgVgUAAQgTAAAAAVg");
	this.shape_152.setTransform(481.45,169.35);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_153.setTransform(473.775,169.275);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_154.setTransform(463,169.325);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_155.setTransform(453,169.325);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_156.setTransform(446.625,168.425);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#000000").s().p("AgdAAQAAgQAJgJQAIgIAOAAQANAAAIAHQAIAJgBAOIAAAFIguAAQAAAMAFAFQAGAEAKABQAOgBAKgFIAAAKQgKAGgQAAQghAAABgigAATgGQAAgRgSAAQgPAAgCARIAjAAIAAAAg");
	this.shape_157.setTransform(440.05,169.35);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#000000").s().p("AgSA6IAAgLIAKACQALAAAAgNIAAhBIANAAIAABCQAAAXgWAAQgGAAgGgCgAAAgzQAAgIAJAAQAKAAgBAIQABAJgKAAQgJAAAAgJg");
	this.shape_158.setTransform(433.85,169.15);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_159.setTransform(429.125,169.425);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAAAgNQAAgFgDgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAPAAQARAAALAGIgBANQgNgHgOAAQgJAAgFADQgEAEAAAFQAAAGADACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_160.setTransform(421.6,168.375);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_161.setTransform(413.025,171.825);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUAAAAAVg");
	this.shape_162.setTransform(407.6,169.35);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_163.setTransform(399.475,168.1);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgPAOQABAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_164.setTransform(392.1,169.325);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_165.setTransform(385.725,168.425);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_166.setTransform(379.1,169.325);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_167.setTransform(373.775,169.3);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_168.setTransform(367.775,168.425);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_169.setTransform(360.975,169.275);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUAAAAAVg");
	this.shape_170.setTransform(353.15,169.35);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_171.setTransform(345.975,169.35);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_172.setTransform(337.95,168.025);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_173.setTransform(334.65,167.875);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#000000").s().p("AgIAhIgahAIAPAAIATA2IAUg2IAPAAIgcBAg");
	this.shape_174.setTransform(329.35,169.35);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_175.setTransform(324.05,167.875);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_176.setTransform(319.075,169.35);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_177.setTransform(308.425,168.1);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_178.setTransform(301.05,169.325);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_179.setTransform(293.625,168.1);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_180.setTransform(288.2,167.875);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_181.setTransform(284.9,168.025);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_182.setTransform(281.6,167.875);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#000000").s().p("AgTAfIAAAOIgNAAIAAhbIAOAAIAAApQAFgPAQAAQANgBAIAJQAJAIgBAQQABARgJAJQgIAJgMgBQgRAAgGgPgAgNgDQgGAEABAJIAAADQAAAWASAAQAJAAAEgFQAGgGAAgLQAAgWgTAAQgIAAgFAGg");
	this.shape_183.setTransform(276.15,168.1);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_184.setTransform(268.3,169.325);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_185.setTransform(261.925,169.325);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_186.setTransform(254.925,169.275);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQgBAXAUAAQAUgBAAgWQAAgVgUAAQgUAAABAVg");
	this.shape_187.setTransform(247.1,169.35);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#000000").s().p("AggAtIAAhYIANAAIAAAQQAGgRAQAAQAOAAAHAIQAJAIAAARQAAAQgJAJQgHAJgNAAQgRAAgFgPIAAAlgAgNgbQgFAFAAAKIAAACQgBAVATAAQAIAAAGgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_188.setTransform(239.45,170.475);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_189.setTransform(232.025,169.325);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAFAEALABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_190.setTransform(225.25,169.35);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_191.setTransform(219.525,169.3);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAFAEALABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_192.setTransform(209.95,169.35);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgIANAAQAQgBAGAQIAAgpIANAAIAABbIgMAAIAAgPQgGAQgRAAQgNAAgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_193.setTransform(202.125,168.1);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQgBAXAUAAQAUgBAAgWQAAgVgUAAQgUAAABAVg");
	this.shape_194.setTransform(191.3,169.35);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAALIAAAeg");
	this.shape_195.setTransform(185.275,169.3);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_196.setTransform(178.475,169.425);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#000000").s().p("AgZApIAAgLQAKAFANAAQAUAAABgTIAAgKQgGAPgQAAQgNAAgGgIQgJgJABgPQgBgRAJgJQAGgIANAAQARAAAFAQIAAgPIAMAAIAAA8QABAPgKAIQgJAHgPAAQgPAAgIgFgAgMgdQgGAGAAAMQAAAUASAAQAIAAAFgFQAGgEAAgJIAAgDQAAgWgTAAQgHAAgFAFg");
	this.shape_197.setTransform(170.55,170.575);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#000000").s().p("AgdAAQAAgQAJgJQAIgIAOAAQANAAAIAHQAIAJgBAOIAAAFIguAAQAAAMAFAFQAGAEAKABQAOgBAKgFIAAAKQgKAGgQAAQghAAABgigAATgGQAAgRgSAAQgPAAgCARIAjAAIAAAAg");
	this.shape_198.setTransform(163.3,169.35);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_199.setTransform(156.525,169.325);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_200.setTransform(146.325,169.275);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUAAAAAVg");
	this.shape_201.setTransform(138.5,169.35);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_202.setTransform(131.325,169.35);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_203.setTransform(123.25,172.9);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#000000").s().p("AAGAqIAAhEIgYAGIAAgNIAlgIIAABTg");
	this.shape_204.setTransform(118.875,168.375);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#000000").s().p("AgQAqIAghHIguAAIAAgMIA9AAIAAAJIghBKg");
	this.shape_205.setTransform(112.8,168.375);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#000000").s().p("AAGAqIAAhEIgYAGIAAgNIAlgIIAABTg");
	this.shape_206.setTransform(106.175,168.375);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#000000").s().p("AgSAGIAAgLIAlAAIAAALg");
	this.shape_207.setTransform(100.675,169.4);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#000000").s().p("AgXApIAAgMQAGACAGAAQALAAAFgGQAFgHAAgQIAAgfIgbAAIAAgNIApAAIAAAuQAAAUgIAJQgIAKgQAAQgJAAgGgCg");
	this.shape_208.setTransform(94.375,168.45);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#000000").s().p("AAaAqIgHgVIglAAIgIAVIgOAAIAghTIASAAIAfBTgAAPAJIgPgoIgOAoIAdAAg");
	this.shape_209.setTransform(87.025,168.375);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAGAEAKABQANgBALgFIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_210.setTransform(75.95,169.35);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#000000").s().p("AgIAhIgZhAIAOAAIATA2IAVg2IANAAIgbBAg");
	this.shape_211.setTransform(68.75,169.35);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_212.setTransform(61.5,169.325);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_213.setTransform(56.7,168.025);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_214.setTransform(51.775,169.35);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFACADQAEADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_215.setTransform(41.75,169.325);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_216.setTransform(36.95,168.025);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_217.setTransform(28.325,169.275);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAJAIQAJAJAAAQQAAARgJAJQgJAIgQAAQgPAAgJgIgAgTAAQgBAXAUAAQAUgBAAgWQAAgVgUAAQgUAAABAVg");
	this.shape_218.setTransform(20.5,169.35);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_219.setTransform(13.325,169.35);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_220.setTransform(964.775,153.525);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQANAAAIAIQAIAHgBAOIAAAHIgvAAQABALAFAFQAGAFAKgBQAOABAKgGIAAAKQgKAGgQAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_221.setTransform(958,153.55);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_222.setTransform(950.625,153.475);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTABQAAAVATAAQAUABAAgXQAAgWgUAAQgTAAAAAXg");
	this.shape_223.setTransform(942.8,153.55);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_224.setTransform(937.25,152.075);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_225.setTransform(932.375,153.525);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_226.setTransform(925.375,153.475);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_227.setTransform(917.85,153.55);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#000000").s().p("AgfAqIAAhTIAgAAQAfAAAAAcQAAANgIAHQgIAHgOAAIgTAAIAAAcgAgRACIARAAQASAAAAgPQAAgRgSAAIgRAAg");
	this.shape_228.setTransform(910.525,152.575);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQANAAAIAIQAIAHgBAOIAAAHIgvAAQABALAFAFQAGAFAKgBQAOABAKgGIAAAKQgKAGgQAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_229.setTransform(899.5,153.55);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQAAAGAQIAAgoIANAAIAABaIgMAAIAAgPQgGARgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_230.setTransform(891.675,152.3);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_231.setTransform(881.525,153.525);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#000000").s().p("AgYAZQgIgIAAgRQAAgQAIgIQAJgJAPAAQAQAAAIAJQAJAIAAAQQAAARgJAIQgIAJgQAAQgPAAgJgJgAgUABQABAVATAAQAUABAAgXQAAgWgUAAQgTAAgBAXg");
	this.shape_232.setTransform(874.45,153.55);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQAAAGAQIAAgoIANAAIAABaIgMAAIAAgPQgGARgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_233.setTransform(866.325,152.3);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_234.setTransform(858.775,153.475);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#000000").s().p("AgYAZQgIgIAAgRQAAgQAIgIQAJgJAPAAQAQAAAIAJQAKAIgBAQQABARgKAIQgIAJgQAAQgPAAgJgJgAgUABQAAAVAUAAQAUABAAgXQAAgWgUAAQgUAAAAAXg");
	this.shape_235.setTransform(850.95,153.55);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAbIAmAAIAAAKIgmAAIAAAig");
	this.shape_236.setTransform(843.525,152.575);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#000000").s().p("AggAsIAAgLIAJABQAGAAAEgDQAEgDAEgIIgchAIAOAAIAUA0IAUg0IANAAIgaBAQgGANgFAGQgIAGgLAAIgKgBg");
	this.shape_237.setTransform(832.85,154.825);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_238.setTransform(822.775,153.525);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTABQAAAVATAAQAUABAAgXQAAgWgUAAQgTAAAAAXg");
	this.shape_239.setTransform(815.7,153.55);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAJIAAAfg");
	this.shape_240.setTransform(809.675,153.5);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_241.setTransform(802.875,153.625);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#000000").s().p("AgaApIAAgLQALAFANAAQAUAAAAgTIAAgKQgFAPgQAAQgNAAgGgIQgJgJABgPQgBgRAJgJQAGgIANAAQARAAAFAQIAAgPIANAAIAAA8QgBAPgJAIQgJAHgOAAQgPAAgKgFgAgMgdQgFAGgBAMQABAUARAAQAIAAAFgFQAGgEgBgJIAAgDQABgWgTAAQgHAAgFAFg");
	this.shape_242.setTransform(794.95,154.775);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_243.setTransform(787.7,153.55);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAgBgNQAAgFgCgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAOAAQASAAALAGIgBANQgNgHgPAAQgIAAgEADQgGAEABAFQAAAGADACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_244.setTransform(780.35,152.575);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_245.setTransform(769.8,153.55);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQAAAGAQIAAgoIANAAIAABaIgMAAIAAgPQgGARgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_246.setTransform(761.975,152.3);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_247.setTransform(753.4,152.225);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_248.setTransform(748.15,153.525);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAJIAAAfg");
	this.shape_249.setTransform(742.825,153.5);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#000000").s().p("AgdAAQgBgQAKgIQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAHIgwAAQABALAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_250.setTransform(736.45,153.55);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_251.setTransform(729.075,153.475);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_252.setTransform(721.55,153.55);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#000000").s().p("AgYAhQgKgMAAgVQAAgUALgLQAKgMATAAQAPAAAMAHIAAAMQgMgGgOAAQgMgBgIAIQgHAIAAAPQAAAfAbABQAIgBAIgCIAAgUIgXAAIAAgJIAjAAIAAAlQgNAGgRABQgSgBgLgKg");
	this.shape_253.setTransform(713.575,152.6);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_254.setTransform(702.425,153.475);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#000000").s().p("AgYAmQgJgIABgSQgBgPAJgJQAJgJAPAAQAQAAAIAJQAKAIAAAQQAAASgKAIQgIAJgQAAQgPAAgJgJgAgUANQAAAWAUAAQAUAAAAgXQAAgVgUAAQgUAAAAAWgAgIgdIALgQIAPAAIgOAQg");
	this.shape_255.setTransform(694.6,152.3);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_256.setTransform(689.05,152.075);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLAAQgUAAAAAWQAAAXAUgBQALAAAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_257.setTransform(684.075,153.55);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLAAQgUAAAAAWQAAAXAUgBQALAAAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_258.setTransform(677.575,153.55);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_259.setTransform(670.8,153.55);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAJIAAAfg");
	this.shape_260.setTransform(665.075,153.5);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_261.setTransform(660.6,152.075);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#000000").s().p("AgiAqIAAhTIAbAAQAqAAAAApQAAAVgLALQgLAKgUAAgAgVAeIAOAAQAcAAAAgeQAAgdgcAAIgOAAg");
	this.shape_262.setTransform(654.8,152.575);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFADADQADADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_263.setTransform(643.4,153.525);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_264.setTransform(638.6,152.225);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_265.setTransform(629.975,153.475);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAKgJANAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQANABALgGIAAAKQgKAGgQAAQggAAgBgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_266.setTransform(622.45,153.55);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#000000").s().p("AgYAZQgJgIABgRQgBgQAJgIQAJgJAPAAQAQAAAJAJQAJAIAAAQQAAARgJAIQgJAJgQAAQgPAAgJgJgAgTABQgBAVAUAAQAUABAAgXQAAgWgUAAQgUAAABAXg");
	this.shape_267.setTransform(611.8,153.55);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_268.setTransform(604.725,152.625);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_269.setTransform(600.05,152.075);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAJIAAAfg");
	this.shape_270.setTransform(596.225,153.5);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLAAQgUAAAAAWQAAAXAUgBQALAAAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_271.setTransform(590.125,153.55);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_272.setTransform(583.725,153.525);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_273.setTransform(576.725,153.475);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_274.setTransform(571.1,152.075);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTABQAAAVATAAQAUABAAgXQAAgWgUAAQgTAAAAAXg");
	this.shape_275.setTransform(562.35,153.55);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQAAAGAQIAAgoIANAAIAABaIgMAAIAAgPQgGARgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_276.setTransform(554.225,152.3);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_277.setTransform(546.85,153.525);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#000000").s().p("AgFAuIAAhbIAMAAIAABbg");
	this.shape_278.setTransform(542.05,152.225);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_279.setTransform(536.425,153.625);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLAAQgUAAAAAWQAAAXAUgBQALAAAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_280.setTransform(529.375,153.55);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_281.setTransform(522.375,153.475);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_282.setTransform(516.75,152.075);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#000000").s().p("AgIAgIgag/IAPAAIATA1IAVg1IANAAIgbA/g");
	this.shape_283.setTransform(511.45,153.55);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_284.setTransform(501.425,153.525);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#000000").s().p("AgYAZQgJgIABgRQgBgQAJgIQAJgJAPAAQAQAAAJAJQAJAIAAAQQAAARgJAIQgJAJgQAAQgPAAgJgJgAgTABQgBAVAUAAQAUABAAgXQAAgWgUAAQgUAAABAXg");
	this.shape_285.setTransform(494.35,153.55);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAJIAAAfg");
	this.shape_286.setTransform(488.325,153.5);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_287.setTransform(481.525,153.625);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#000000").s().p("AgZApIAAgLQALAFAMAAQAUAAABgTIAAgKQgGAPgQAAQgMAAgIgIQgHgJgBgPQABgRAHgJQAIgIAMAAQARAAAFAQIAAgPIAMAAIAAA8QABAPgLAIQgIAHgPAAQgPAAgIgFgAgMgdQgGAGABAMQgBAUASAAQAIAAAFgFQAFgEABgJIAAgDQgBgWgSAAQgIAAgEAFg");
	this.shape_288.setTransform(473.6,154.775);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#000000").s().p("AgdAAQgBgQAKgIQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAHIgwAAQABALAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_289.setTransform(466.35,153.55);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_290.setTransform(459.575,153.525);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQAOAAAHAIQAIAHgBAOIAAAHIgvAAQABALAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_291.setTransform(449.6,153.55);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQAAAGAQIAAgoIANAAIAABaIgMAAIAAgPQgGARgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_292.setTransform(441.775,152.3);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#000000").s().p("AgdAAQgBgQAKgIQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAHIgwAAQABALAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_293.setTransform(431.25,153.55);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_294.setTransform(424.475,152.625);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_295.setTransform(417.675,153.475);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_296.setTransform(410.15,153.55);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#000000").s().p("AgZApIAAgLQAKAFANAAQAUAAABgTIAAgKQgGAPgQAAQgMAAgHgIQgJgJAAgPQAAgRAJgJQAHgIAMAAQARAAAFAQIAAgPIAMAAIAAA8QABAPgKAIQgJAHgPAAQgPAAgIgFgAgMgdQgGAGABAMQgBAUASAAQAIAAAFgFQAGgEAAgJIAAgDQAAgWgTAAQgIAAgEAFg");
	this.shape_297.setTransform(402.4,154.775);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_298.setTransform(395.1,153.525);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_299.setTransform(387.05,157.1);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#000000").s().p("AAaAqIgHgVIglAAIgIAVIgOAAIAghTIASAAIAfBTgAAPAJIgPgoIgOAoIAdAAg");
	this.shape_300.setTransform(381.325,152.575);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQATAAABgNQAAgFgEgCQgDgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAPAAQARAAALAGIgBANQgNgHgOAAQgIAAgGADQgEAEAAAFQgBAGAEACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_301.setTransform(373.25,152.575);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#000000").s().p("AgUAhQgLgMAAgVQAAgUALgMQAKgKARgBQANAAALAHIAAAMQgLgGgLAAQgLgBgHAIQgIAIAAAPQAAAQAIAIQAGAIAMAAQALgBAMgHIAAAMQgLAIgOAAQgRgBgKgKg");
	this.shape_302.setTransform(362.425,152.6);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAbIAmAAIAAAKIgmAAIAAAig");
	this.shape_303.setTransform(355.075,152.575);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAYIAlAAIAAAKIglAAIAAAZIApAAIAAAMg");
	this.shape_304.setTransform(347.55,152.575);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_305.setTransform(338.8,157.1);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_306.setTransform(333.8,153.525);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#000000").s().p("AARAuIAAgmQAAgQgPAAQgIAAgFAGQgFAFAAALIAAAgIgNAAIAAhAIANAAIAAAQQAGgSARAAQAKAAAHAHQAGAGAAALIAAAqgAAAggIgHgEQgEAAAAAHIgJAAQAAgIAEgEQADgEAFAAQAEAAAEAEQAEADACAAQAEAAAAgHIAJAAQAAAIgEAFQgDADgFAAQgEAAgDgDg");
	this.shape_307.setTransform(326.825,152.225);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAABAKg");
	this.shape_308.setTransform(319.25,153.525);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAGgRARAAQAMAAAIAIQAIAIAAARQAAAQgIAJQgIAJgMAAQgQAAgHgPIAAAlgAgNgbQgGAFAAAKIAAACQABAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_309.setTransform(312.3,154.675);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_310.setTransform(304.875,153.525);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAYIAkAAIAAAKIgkAAIAAAZIApAAIAAAMg");
	this.shape_311.setTransform(298,152.575);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_312.setTransform(287.725,153.525);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#000000").s().p("AgdAAQgBgQAKgIQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAHIgwAAQABALAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_313.setTransform(280.95,153.55);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLAAQgUAAAAAWQAAAXAUgBQALAAAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_314.setTransform(274.075,153.55);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_315.setTransform(269.2,152.075);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#000000").s().p("AgHAgIgag/IAOAAIATA1IAVg1IAOAAIgcA/g");
	this.shape_316.setTransform(263.9,153.55);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAJIAAAfg");
	this.shape_317.setTransform(258.125,153.5);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_318.setTransform(251.75,153.55);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAgBgNQAAgFgCgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAOAAQASAAALAGIgBANQgNgHgPAAQgIAAgEADQgGAEABAFQAAAGADACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_319.setTransform(244.4,152.575);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_320.setTransform(235.8,152.225);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgPAOQABAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_321.setTransform(230.55,153.525);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#000000").s().p("AgFAvIAAhAIAMAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_322.setTransform(225.7,152.075);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLAAQgUAAAAAWQAAAXAUgBQALAAAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_323.setTransform(220.725,153.55);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_324.setTransform(213.725,153.475);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_325.setTransform(206.15,153.525);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_326.setTransform(199.175,153.475);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_327.setTransform(193.55,152.075);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAbIAmAAIAAAKIgmAAIAAAig");
	this.shape_328.setTransform(188.325,152.575);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_329.setTransform(178.075,153.525);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_330.setTransform(173.2,152.075);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_331.setTransform(168.325,152.625);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_332.setTransform(161.525,153.475);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_333.setTransform(153.95,153.525);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#000000").s().p("AgGAuIAAhbIAMAAIAABbg");
	this.shape_334.setTransform(149.15,152.225);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_335.setTransform(145.9,152.225);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_336.setTransform(140.7,153.55);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_337.setTransform(133.925,152.625);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQATAAAAgNQAAgFgDgCQgDgDgIgBIgOgDQgVgDAAgSQAAgMAJgGQAIgHAOAAQASAAALAGIgBANQgNgHgPAAQgHAAgFADQgGAEAAAFQABAGADACQADACAHACIAMACQANACAFAFQAGAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_338.setTransform(127.15,152.575);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQAOAAAHAIQAIAHgBAOIAAAHIgvAAQABALAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_339.setTransform(116.6,153.55);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQAAAGAQIAAgoIANAAIAABaIgMAAIAAgPQgGARgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_340.setTransform(108.775,152.3);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_341.setTransform(98.025,153.475);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#000000").s().p("AgYAmQgIgIgBgSQABgPAIgJQAJgJAPAAQAQAAAIAJQAJAIAAAQQAAASgJAIQgIAJgQAAQgPAAgJgJgAgUANQABAWATAAQAUAAAAgXQAAgVgUAAQgTAAgBAWgAgHgdIAKgQIAQAAIgPAQg");
	this.shape_342.setTransform(90.2,152.3);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_343.setTransform(84.65,152.075);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLAAQgUAAAAAWQAAAXAUgBQALAAAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_344.setTransform(79.675,153.55);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_345.setTransform(72.85,153.525);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_346.setTransform(68,152.075);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQAAAGAQIAAgoIANAAIAABaIgMAAIAAgPQgGARgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_347.setTransform(62.075,152.3);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAHIguAAQAAALAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_348.setTransform(54.75,153.55);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgQAAgBAWIAAAgIgLAAIAAglQAAgRgOAAQgQAAgBAWIAAAgIgNAAIAAhAIANAAIAAAPQAFgQARAAQAQAAADARQAGgRARAAQAWAAAAAZIAAAog");
	this.shape_349.setTransform(45.45,153.475);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAJIAAAfg");
	this.shape_350.setTransform(37.375,153.5);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQANAAAIAIQAIAHgBAOIAAAHIgvAAQABALAFAFQAGAFAKgBQAOABAKgGIAAAKQgKAGgQAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_351.setTransform(31,153.55);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_352.setTransform(24.225,152.625);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_353.setTransform(17.425,153.475);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_354.setTransform(11.8,152.075);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_355.setTransform(909.1,137.725);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#000000").s().p("AgFAuIAAhbIAMAAIAABbg");
	this.shape_356.setTransform(904.3,136.425);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_357.setTransform(895.675,137.675);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgQAIgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUgBAAAWg");
	this.shape_358.setTransform(887.85,137.75);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_359.setTransform(880.675,137.75);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#000000").s().p("AggAsIAAgLIAJABQAGAAAEgDQAEgDAEgIIgchAIAOAAIAUA0IAUg0IANAAIgaBAQgGANgFAGQgIAGgLAAIgKgBg");
	this.shape_360.setTransform(870.65,139.025);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_361.setTransform(862.1,141.3);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_362.setTransform(857.525,137.725);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQAAAXATAAQAUgBAAgWQAAgVgUAAQgTgBAAAWg");
	this.shape_363.setTransform(850.45,137.75);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_364.setTransform(844.425,137.7);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_365.setTransform(837.625,137.825);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#000000").s().p("AgaApIAAgLQAMAFAMAAQAUAAAAgTIAAgKQgFAPgQAAQgMAAgHgIQgJgJABgPQgBgRAJgJQAHgIAMAAQARAAAFAQIAAgPIANAAIAAA8QgBAPgJAIQgJAHgPAAQgOAAgKgFgAgMgdQgGAGAAAMQAAAUASAAQAIAAAFgFQAGgEgBgJIAAgDQABgWgTAAQgHAAgFAFg");
	this.shape_366.setTransform(829.7,138.975);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_367.setTransform(822.45,137.75);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_368.setTransform(815.675,137.725);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_369.setTransform(805.7,137.75);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgIANAAQAQgBAGAPIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_370.setTransform(797.875,136.5);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_371.setTransform(787.3,137.725);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#000000").s().p("AgKAuIAAhAIALAAIAABAgAgNgcIAMgRIAOAAIgNARg");
	this.shape_372.setTransform(782.95,136.425);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#000000").s().p("AARAuIAAgmQAAgQgPAAQgIAAgFAGQgFAFAAALIAAAgIgNAAIAAhAIANAAIAAAQQAGgSARAAQAKAAAHAHQAGAGAAALIAAAqgAAAggIgHgEQgEAAAAAHIgJAAQAAgIAEgEQADgEAFAAQAEAAAEAEQAEADACAAQAEAAAAgHIAJAAQAAAIgEAFQgDADgFAAQgEAAgDgDg");
	this.shape_373.setTransform(776.975,136.425);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_374.setTransform(769.4,137.725);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAFgRASAAQANAAAHAIQAJAIAAARQAAAQgJAJQgHAJgNAAQgRAAgGgPIAAAlgAgNgbQgFAFgBAKIAAACQAAAVATAAQAIAAAGgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_375.setTransform(762.45,138.875);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgOAAQgQAAAAAWIAAAgIgLAAIAAglQAAgRgOAAQgQAAAAAWIAAAgIgOAAIAAhAIANAAIAAAPQAFgQARAAQAQAAADARQAGgRARAAQAWAAgBAZIAAAog");
	this.shape_376.setTransform(752.5,137.675);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgQAIgJQAJgIAPAAQAQAAAIAIQAJAJAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUAAQABAXATAAQAUgBAAgWQAAgVgUAAQgTgBgBAWg");
	this.shape_377.setTransform(742.7,137.75);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_378.setTransform(735.525,137.75);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQAAAXATAAQAUgBAAgWQAAgVgUAAQgTgBAAAWg");
	this.shape_379.setTransform(725.25,137.75);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgRAAAAAWIAAAgIgMAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_380.setTransform(715.65,137.675);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAIAIQAKAJAAAQQAAARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUgBAAAWg");
	this.shape_381.setTransform(705.85,137.75);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_382.setTransform(698.675,137.75);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_383.setTransform(690.6,141.3);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_384.setTransform(685.6,137.725);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_385.setTransform(679.225,136.825);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_386.setTransform(674.6,136.425);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_387.setTransform(669.35,137.725);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#000000").s().p("AAhAqIAAhCIgdBCIgGAAIgehCIAABCIgNAAIAAhTIASAAIAbA/IAbg/IATAAIAABTg");
	this.shape_388.setTransform(660.5,136.775);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#000000").s().p("AgdArIAAgLIAagYIANgNQAFgGAAgGQAAgNgQAAQgPAAgNAJIAAgMQANgJAQAAQAOAAAHAGQAIAGAAALQAAAJgHAJQgFAGgMALIgQAPIApAAIAAAMg");
	this.shape_389.setTransform(647.975,136.725);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#000000").s().p("AgdArIAAgLIAagYIANgNQAFgGAAgGQAAgNgQAAQgPAAgNAJIAAgMQANgJAQAAQAOAAAHAGQAIAGAAALQAAAJgHAJQgFAGgMALIgQAPIApAAIAAAMg");
	this.shape_390.setTransform(640.675,136.725);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#000000").s().p("AAGAqIAAhEIgYAGIAAgNIAlgIIAABTg");
	this.shape_391.setTransform(634.025,136.775);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#000000").s().p("AAGAqIAAhEIgYAGIAAgNIAlgIIAABTg");
	this.shape_392.setTransform(628.575,136.775);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#000000").s().p("AAYAqIgYgjIgYAjIgQAAIAhgrIgdgoIAQAAIAUAeIAVgeIAQAAIgdAnIAhAsg");
	this.shape_393.setTransform(621.925,136.775);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#000000").s().p("AggAqIAAhTIAgAAQAfAAAAAVQgBAPgOAFQARADAAARQAAAWgeAAgAgTAfIAUAAQASAAAAgNQAAgOgSAAIgUAAgAgTgFIATAAQARAAAAgNQAAgMgRAAIgTAAg");
	this.shape_394.setTransform(613.95,136.775);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#000000").s().p("AAYAqIgYgjIgYAjIgQAAIAhgrIgdgoIAQAAIAUAeIAVgeIAQAAIgdAnIAhAsg");
	this.shape_395.setTransform(605.375,136.775);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_396.setTransform(596.35,141.3);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#000000").s().p("AAUAhIgUgaIgUAaIgOAAIAcghIgZggIAPAAIAQAYIARgYIAPAAIgZAgIAcAhg");
	this.shape_397.setTransform(591.3,137.75);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#000000").s().p("AgdAAQAAgQAJgJQAIgIAOAAQANAAAIAHQAIAJgBAOIAAAFIgvAAQABAMAFAFQAGAFAKAAQAOAAAKgGIAAAKQgKAGgQAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_398.setTransform(584.05,137.75);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_399.setTransform(578.8,136.275);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#000000").s().p("AgTAfIAAAOIgNAAIAAhaIAOAAIAAAoQAFgPAQAAQAOgBAHAJQAJAIAAAQQAAARgJAJQgHAJgNgBQgRAAgGgPgAgNgDQgFAEAAAJIAAADQgBAWATAAQAIAAAGgFQAFgGAAgLQAAgWgTAAQgIAAgFAGg");
	this.shape_400.setTransform(573.35,136.5);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#000000").s().p("AAYAqIgYgjIgYAjIgQAAIAhgrIgdgoIAQAAIAUAeIAVgeIAQAAIgdAnIAhAsg");
	this.shape_401.setTransform(564.925,136.775);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_402.setTransform(556,134.35);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_403.setTransform(550.7,137.725);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#000000").s().p("AgGAqIAAhHIgdAAIAAgMIBHAAIAAAMIgdAAIAABHg");
	this.shape_404.setTransform(543.375,136.775);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_405.setTransform(534.35,141.3);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_406.setTransform(529.775,136.825);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_407.setTransform(523.2,137.75);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_408.setTransform(516.05,137.75);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_409.setTransform(510.325,137.7);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_410.setTransform(504.325,136.825);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAAAgNQAAgFgDgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAPAAQARAAALAGIgBANQgNgHgOAAQgIAAgGADQgEAEAAAFQgBAGAEACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_411.setTransform(497.55,136.775);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgIANAAQAQgBAGAPIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_412.setTransform(486.325,136.5);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_413.setTransform(480.425,137.7);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUgBAAAWg");
	this.shape_414.setTransform(473.75,137.75);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#000000").s().p("AgZApIAAgLQALAFAMAAQAVAAAAgTIAAgKQgGAPgQAAQgMAAgIgIQgHgJgBgPQABgRAHgJQAIgIAMAAQAQAAAGAQIAAgPIAMAAIAAA8QAAAPgKAIQgIAHgOAAQgPAAgJgFgAgMgdQgFAGAAAMQAAAUARAAQAIAAAFgFQAFgEABgJIAAgDQgBgWgSAAQgIAAgEAFg");
	this.shape_415.setTransform(465.7,138.975);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_416.setTransform(460.35,136.275);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#000000").s().p("AASAqIgVgiIgRAAIAAAiIgNAAIAAhTIAhAAQAfAAAAAZQAAAUgVAEIAYAigAgUgCIAVAAQARAAAAgOQAAgNgSAAIgUAAg");
	this.shape_417.setTransform(454.825,136.775);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_418.setTransform(443.55,137.75);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_419.setTransform(436.775,136.825);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_420.setTransform(430.15,137.725);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#000000").s().p("AgTAfIAAAOIgNAAIAAhaIAOAAIAAAoQAFgPAQAAQANgBAIAJQAIAIAAAQQAAARgIAJQgIAJgMgBQgSAAgFgPgAgNgDQgGAEABAJIAAADQAAAWASAAQAJAAAEgFQAGgGAAgLQAAgWgTAAQgIAAgFAGg");
	this.shape_421.setTransform(423.2,136.5);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#000000").s().p("AAaAqIgHgVIglAAIgIAVIgOAAIAghTIASAAIAfBTgAAPAJIgPgoIgOAoIAdAAg");
	this.shape_422.setTransform(414.625,136.775);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#000000").s().p("AgeAlIABgNQANAHAOAAQAIAAAGgDQAFgEAAgGQAAgNgSAAIgNAAIAAgKIANAAQAGAAAFgDQAFgEAAgGQAAgGgFgDQgGgDgIAAQgOAAgLAGIAAgNQAMgFAOAAQAPAAAIAGQAJAGAAAKQAAAPgRAFQATADAAAQQAAALgJAHQgJAGgOAAQgQAAgNgGg");
	this.shape_423.setTransform(403.475,136.775);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#000000").s().p("AgeAlIABgMQAOAGANAAQATAAAAgQQAAgJgGgDQgFgDgMAAQgLAAgKACIAAgsIA2AAIAAAMIgqAAIAAAVQAHgBAIAAQAfAAAAAZQAAANgJAIQgJAHgOAAQgPAAgOgGg");
	this.shape_424.setTransform(396.125,136.825);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_425.setTransform(387.35,141.3);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#000000").s().p("AgdAAQgBgQAKgJQAJgIANAAQAOAAAHAHQAIAJAAAOIAAAFIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_426.setTransform(382.4,137.75);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_427.setTransform(375.625,137.725);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_428.setTransform(369.225,137.725);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_429.setTransform(362.025,137.825);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAJAIQAJAJAAAQQAAARgJAJQgJAIgQAAQgPAAgJgIgAgTAAQgBAXAUAAQAUgBAAgWQAAgVgUAAQgUgBABAWg");
	this.shape_430.setTransform(354.4,137.75);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#000000").s().p("AAUAqIAAglIgnAAIAAAlIgOAAIAAhTIAOAAIAAAjIAnAAIAAgjIAOAAIAABTg");
	this.shape_431.setTransform(346.1,136.775);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#000000").s().p("AggAqIAAhTIAgAAQAfAAgBAVQAAAPgOAFQARADAAARQAAAWgeAAgAgSAfIATAAQATAAAAgNQAAgOgTAAIgTAAgAgSgFIATAAQAQAAAAgNQAAgMgRAAIgSAAg");
	this.shape_432.setTransform(334.65,136.775);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#000000").s().p("AgGAqIAAhTIANAAIAABTg");
	this.shape_433.setTransform(328.525,136.775);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#000000").s().p("AAhAqIAAhCIgdBCIgGAAIgehCIAABCIgNAAIAAhTIASAAIAbA/IAbg/IATAAIAABTg");
	this.shape_434.setTransform(321.1,136.775);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_435.setTransform(308.425,137.675);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_436.setTransform(300.9,137.75);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_437.setTransform(292.5,136.425);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgPAOQABAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_438.setTransform(287.25,137.725);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#000000").s().p("AgFAvIAAhAIAMAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_439.setTransform(282.4,136.275);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_440.setTransform(277.425,137.75);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUgBAAAWg");
	this.shape_441.setTransform(270.35,137.75);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_442.setTransform(263.275,137.725);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgQAIgJQAJgIAPAAQAQAAAIAIQAJAJAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUAAQABAXATAAQAUgBAAgWQAAgVgUAAQgTgBgBAWg");
	this.shape_443.setTransform(253,137.75);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_444.setTransform(247.45,136.275);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#000000").s().p("AgFAuIAAhbIAMAAIAABbg");
	this.shape_445.setTransform(244.15,136.425);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_446.setTransform(240.85,136.275);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_447.setTransform(235.875,137.75);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_448.setTransform(231,136.275);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgOAAQgPAAAAAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgOAAIAAhAIANAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAAAAZIAAAog");
	this.shape_449.setTransform(223.6,137.675);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQgBAXAUAAQAUgBAAgWQAAgVgUAAQgUgBABAWg");
	this.shape_450.setTransform(213.8,137.75);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgIANAAQAQgBAGAPIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_451.setTransform(205.675,136.5);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_452.setTransform(194.925,137.675);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgQAJgJQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUAAQAAAXAUAAQAUgBAAgWQAAgVgUAAQgUgBAAAWg");
	this.shape_453.setTransform(187.1,137.75);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#000000").s().p("AgRAaQgJgKAAgQQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAALQgIgEgLAAQgUAAAAAVQAAAWAUABQALAAAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_454.setTransform(179.925,137.75);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#000000").s().p("AggAsIAAgLIAJABQAGAAAEgDQAEgDAEgIIgdhAIAPAAIAUA0IAUg0IANAAIgaBAQgGANgFAGQgHAGgMAAIgKgBg");
	this.shape_455.setTransform(169.9,139.025);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#000000").s().p("AgRAyQAWgTAAgfQAAgegWgTIAGgIQAdAVAAAkQAAAmgdAUg");
	this.shape_456.setTransform(160.225,137.275);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#000000").s().p("AgXAiQgKgJAAgWQAAgtAmAAQANAAAKAEIAAANQgKgGgMAAQgZAAgBAgQADgFAHgEQAHgEAHAAQAOAAAIAIQAIAGAAANQAAAMgJAIQgIAIgPAAQgQAAgJgJgAgNACQgGAEAAAIQAAAIAGAFQAFAFAIAAQAKAAAFgFQAFgEAAgIQAAgQgTAAQgIAAgGADg");
	this.shape_457.setTransform(154.35,136.775);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#000000").s().p("AgXAiQgKgJAAgWQAAgtAmAAQANAAAKAEIAAANQgJgGgNAAQgZAAgBAgQAEgFAGgEQAGgEAIAAQAOAAAIAIQAIAGAAANQAAAMgJAIQgIAIgPAAQgQAAgJgJgAgNACQgGAEAAAIQAAAIAGAFQAFAFAIAAQAKAAAFgFQAFgEAAgIQAAgQgTAAQgJAAgFADg");
	this.shape_458.setTransform(146.35,136.775);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#000000").s().p("AgbAnIAAgMQAKAEAMAAQAZAAABgfQgDAFgHAEQgHAEgHAAQgOAAgIgHQgIgHAAgNQAAgMAIgIQAJgJAPAAQAQAAAJAKQAKAJAAAXQAAAsgmABQgNgBgKgEgAgOgaQgFAEAAAIQAAAQATAAQAIABAGgEQAFgEAAgIQAAgIgFgFQgFgGgJAAQgJABgFAFg");
	this.shape_459.setTransform(138.275,136.75);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#000000").s().p("AgZAlQgKgHABgLQAAgHAEgGQAGgFAJgBQgRgFAAgOQAAgLAJgGQAIgGAPAAQAPAAAJAGQAJAGAAALQAAAOgSAFQAKABAFAFQAFAGABAHQAAAMgKAGQgJAGgRAAQgQAAgJgGgAgVATQABAOAUAAQAWAAgBgOQABgOgWAAQgUAAgBAOgAgSgSQAAANASAAQATAAAAgNQAAgOgTAAQgSAAAAAOg");
	this.shape_460.setTransform(130.25,136.775);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#000000").s().p("AgXAiQgKgJAAgWQAAgtAmAAQANAAAKAEIAAANQgKgGgMAAQgZAAAAAgQACgFAHgEQAHgEAHAAQAOAAAIAIQAIAGAAANQAAAMgJAIQgIAIgQAAQgPAAgJgJgAgNACQgFAEgBAIQABAIAFAFQAFAFAIAAQAKAAAFgFQAFgEAAgIQAAgQgUAAQgHAAgGADg");
	this.shape_461.setTransform(122.2,136.775);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#000000").s().p("AgUAgQgLgLAAgVQAAgUALgLQAKgLARAAQANAAALAFIAAAOQgLgIgLABQgLAAgHAHQgIAJAAAOQAAAQAIAIQAGAHAMAAQALABAMgJIAAAOQgLAGgOAAQgRAAgKgLg");
	this.shape_462.setTransform(114.325,136.8);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTAAQAAAXATAAQAUgBAAgWQAAgVgUAAQgTgBAAAWg");
	this.shape_463.setTransform(103.45,137.75);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_464.setTransform(97.425,137.7);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_465.setTransform(91.425,136.825);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_466.setTransform(85.225,137.725);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#000000").s().p("AgFAvIAAhAIAMAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_467.setTransform(80.35,136.275);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#000000").s().p("AgaApIAAgLQAMAFAMAAQAUAAAAgTIAAgKQgFAPgQAAQgNAAgGgIQgJgJABgPQgBgRAJgJQAGgIANAAQAQAAAGAQIAAgPIANAAIAAA8QgBAPgJAIQgJAHgPAAQgOAAgKgFgAgMgdQgFAGgBAMQABAUARAAQAIAAAFgFQAGgEgBgJIAAgDQABgWgTAAQgHAAgFAFg");
	this.shape_468.setTransform(74.5,138.975);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_469.setTransform(67.25,137.75);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_470.setTransform(61.525,137.7);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_471.setTransform(51.95,137.75);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgIANAAQAQgBAGAPIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNAAgHgIgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_472.setTransform(44.125,136.5);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#000000").s().p("AgQASQgGgHAAgLQAAgLAGgGQAGgFAKAAQAXAAAAAWQAAALgGAHQgGAFgLAAQgKAAgGgFgAgMAAQAAAOAMAAQANAAAAgOQAAgOgNAAQgMAAAAAOg");
	this.shape_473.setTransform(34.325,134.825);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_474.setTransform(27.675,137.675);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_475.setTransform(18.9,136.425);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#000000").s().p("AgeAAQABgQAIgJQAJgIAOAAQANAAAIAHQAHAJAAAOIAAAFIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_476.setTransform(13.7,137.75);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_477.setTransform(953.225,121.875);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTABQAAAVATABQAUAAAAgXQAAgWgUABQgTAAAAAWg");
	this.shape_478.setTransform(945.4,121.95);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_479.setTransform(938.225,121.95);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_480.setTransform(930.15,125.5);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQABAGAPIAAgpIANAAIAABbIgMAAIAAgPQgGARgRAAQgNgBgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_481.setTransform(924.525,120.7);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAKgJANAAQANAAAIAIQAHAHAAAPIAAAGIguAAQAAALAFAFQAFAEALAAQANAAALgFIAAAKQgKAGgQAAQggAAgBgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_482.setTransform(917.2,121.95);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_483.setTransform(910.425,121.025);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_484.setTransform(905.75,120.475);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgRAAAAAWIAAAgIgMAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_485.setTransform(898.35,121.875);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_486.setTransform(890.75,120.475);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#000000").s().p("AgaAqIAAhTIAOAAIAABHIAnAAIAAAMg");
	this.shape_487.setTransform(885.825,120.975);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQAOAAAHAIQAIAHgBAPIAAAGIgvAAQABALAFAFQAGAEAKAAQANAAALgFIAAAKQgLAGgPAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_488.setTransform(875.3,121.95);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAFgRASAAQANAAAHAIQAIAIABARQgBAQgIAJQgIAJgMAAQgQAAgHgPIAAAlgAgNgbQgFAFgBAKIAAACQAAAVATAAQAIAAAGgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_489.setTransform(867.95,123.075);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#000000").s().p("AgYAZQgJgIABgRQgBgQAJgIQAJgJAPAAQAQAAAIAJQAKAIgBAQQABARgKAIQgIAJgQAAQgPAAgJgJgAgUABQAAAVAUABQAUAAAAgXQAAgWgUABQgUAAAAAWg");
	this.shape_490.setTransform(859.85,121.95);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAAKIAAAfg");
	this.shape_491.setTransform(853.825,121.9);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_492.setTransform(847.025,122.025);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAYIAlAAIAAAKIglAAIAAAZIApAAIAAAMg");
	this.shape_493.setTransform(839.6,120.975);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQAOAAAHAIQAIAHgBAPIAAAGIgvAAQABALAFAFQAGAEAKAAQANAAALgFIAAAKQgLAGgPAAQghAAABgigAATgFQAAgSgSAAQgPAAgDASIAkAAIAAAAg");
	this.shape_494.setTransform(828.95,121.95);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_495.setTransform(822.075,121.95);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_496.setTransform(815.075,121.875);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_497.setTransform(807.5,121.925);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAAKIAAAfg");
	this.shape_498.setTransform(802.175,121.9);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_499.setTransform(795.375,122.025);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_500.setTransform(788.425,121.925);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_501.setTransform(781.425,121.875);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#000000").s().p("AgGAqIAAhTIANAAIAABTg");
	this.shape_502.setTransform(775.725,120.975);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQANAAAIAIQAIAHgBAPIAAAGIguAAQAAALAFAFQAFAEALAAQAOAAAKgFIAAAKQgKAGgQAAQghAAABgigAATgFQAAgSgSAAQgPAAgCASIAjAAIAAAAg");
	this.shape_503.setTransform(767.2,121.95);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAgBIAAgCQAAgLAHgGQAHgHALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAPIAAADIAZAAIAAALIgZAAIAAA1g");
	this.shape_504.setTransform(761.025,120.5);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_505.setTransform(756.45,120.475);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#000000").s().p("AgaAqIAAhTIAOAAIAABHIAnAAIAAAMg");
	this.shape_506.setTransform(751.525,120.975);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_507.setTransform(741.375,121.925);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_508.setTransform(736.5,120.475);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_509.setTransform(731.625,121.025);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_510.setTransform(724.825,121.875);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_511.setTransform(717.25,121.925);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_512.setTransform(712.45,120.625);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_513.setTransform(709.2,120.625);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAPIAAAGIguAAQAAALAFAFQAFAEALAAQAOAAAKgFIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_514.setTransform(704,121.95);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_515.setTransform(697.225,121.025);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAgBgNQAAgFgCgCQgEgDgIgBIgNgDQgWgDAAgSQAAgMAJgGQAIgHAOAAQASAAALAGIgBANQgNgHgPAAQgHAAgFADQgGAEAAAFQABAGADACQADACAHACIAMACQANACAFAFQAGAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_516.setTransform(690.45,120.975);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_517.setTransform(679.675,121.875);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#000000").s().p("AgYAZQgIgIAAgRQAAgQAIgIQAJgJAPAAQAQAAAIAJQAKAIgBAQQABARgKAIQgIAJgQAAQgPAAgJgJgAgUABQAAAVAUABQAUAAAAgXQAAgWgUABQgUAAAAAWg");
	this.shape_518.setTransform(671.85,121.95);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_519.setTransform(664.675,121.95);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFADADQADADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_520.setTransform(654.65,121.925);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_521.setTransform(648.275,121.025);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_522.setTransform(643.6,120.475);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAAKIAAAfg");
	this.shape_523.setTransform(639.775,121.9);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_524.setTransform(633.675,121.95);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_525.setTransform(627.275,121.925);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_526.setTransform(620.075,122.025);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_527.setTransform(613.125,121.925);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_528.setTransform(605.05,125.5);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTABQAAAVATABQAUAAAAgXQAAgWgUABQgTAAAAAWg");
	this.shape_529.setTransform(599.8,121.95);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQABAGAPIAAgpIANAAIAABbIgMAAIAAgPQgGARgRAAQgNgBgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_530.setTransform(591.675,120.7);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_531.setTransform(584.3,121.925);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_532.setTransform(579.45,120.475);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_533.setTransform(574.475,121.95);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_534.setTransform(567.475,121.875);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_535.setTransform(559.9,121.925);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_536.setTransform(552.925,121.875);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_537.setTransform(547.3,120.475);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAgBIAAgCQAAgLAHgGQAHgHALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAPIAAADIAZAAIAAALIgZAAIAAA1g");
	this.shape_538.setTransform(543.025,120.5);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#000000").s().p("AgFAuIAAhbIAMAAIAABbg");
	this.shape_539.setTransform(535.3,120.625);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_540.setTransform(530.05,121.925);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_541.setTransform(523.675,121.025);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_542.setTransform(519,120.475);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAGgRARAAQAMAAAIAIQAIAIAAARQAAAQgIAJQgIAJgMAAQgRAAgGgPIAAAlgAgNgbQgGAFAAAKIAAACQABAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_543.setTransform(513.55,123.075);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_544.setTransform(505.7,121.925);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_545.setTransform(499.225,121.95);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#000000").s().p("AgFAuIAAhbIAMAAIAABbg");
	this.shape_546.setTransform(491.2,120.625);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#000000").s().p("AgeAAQAAgQAJgIQAKgJANAAQANAAAIAIQAHAHABAPIAAAGIgvAAQAAALAFAFQAFAEALAAQANAAALgFIAAAKQgLAGgPAAQggAAgBgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_547.setTransform(486,121.95);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_548.setTransform(475.425,121.875);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#000000").s().p("AgdAAQgBgQAKgIQAJgJANAAQAOAAAHAIQAIAHAAAPIAAAGIgwAAQABALAFAFQAGAEAKAAQANAAALgFIAAAKQgLAGgPAAQggAAAAgigAATgFQAAgSgRAAQgQAAgDASIAkAAIAAAAg");
	this.shape_549.setTransform(467.9,121.95);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTABQgBAVAUABQAUAAAAgXQAAgWgUABQgUAAABAWg");
	this.shape_550.setTransform(457.25,121.95);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_551.setTransform(449.575,121.875);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#000000").s().p("AggAsIAAgLIAIABQAHAAAEgDQAEgDADgIIgchAIAPAAIAUA0IATg0IAPAAIgbBAQgGANgFAGQgIAGgMAAIgJgBg");
	this.shape_552.setTransform(438.8,123.225);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQABAGAPIAAgpIANAAIAABbIgMAAIAAgPQgGARgRAAQgNgBgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_553.setTransform(427.675,120.7);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_554.setTransform(420.3,121.925);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQABAGAPIAAgpIANAAIAABbIgMAAIAAgPQgGARgRAAQgNgBgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_555.setTransform(412.875,120.7);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_556.setTransform(407.45,120.475);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_557.setTransform(404.15,120.625);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_558.setTransform(398.9,121.925);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_559.setTransform(391.725,122.025);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_560.setTransform(384.775,121.925);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_561.setTransform(377.775,121.875);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#000000").s().p("AgdAAQgBgQAKgIQAJgJANAAQAOAAAHAIQAIAHAAAPIAAAGIgwAAQABALAFAFQAGAEAKAAQANAAALgFIAAAKQgLAGgPAAQggAAAAgigAATgFQAAgSgRAAQgQAAgDASIAkAAIAAAAg");
	this.shape_562.setTransform(370.25,121.95);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgNAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_563.setTransform(360.95,121.875);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_564.setTransform(348.2,121.925);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_565.setTransform(343.4,120.625);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_566.setTransform(334.775,121.875);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAKgJANAAQANAAAIAIQAHAHABAPIAAAGIgvAAQAAALAFAFQAFAEALAAQAOAAAKgFIAAAKQgKAGgQAAQggAAgBgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_567.setTransform(327.25,121.95);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#000000").s().p("AgYAZQgJgIABgRQgBgQAJgIQAJgJAPAAQAQAAAJAJQAJAIAAAQQAAARgJAIQgJAJgQAAQgPAAgJgJgAgTABQgBAVAUABQAUAAAAgXQAAgWgUABQgUAAABAWg");
	this.shape_568.setTransform(316.6,121.95);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQABAGAPIAAgpIANAAIAABbIgMAAIAAgPQgGARgRAAQgNgBgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_569.setTransform(308.475,120.7);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#000000").s().p("AgGAvIAAhAIAMAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_570.setTransform(303.05,120.475);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_571.setTransform(297.375,122.025);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_572.setTransform(292,120.625);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_573.setTransform(287.075,121.95);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_574.setTransform(280.075,121.875);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_575.setTransform(274.45,120.475);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#000000").s().p("AgRAyQAWgTAAgfQAAgegWgTIAGgIQAdAVAAAkQAAAmgdAUg");
	this.shape_576.setTransform(266.775,121.475);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_577.setTransform(261.675,121.925);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAIQAHAHAAAPIAAAGIguAAQAAALAFAFQAFAEALAAQAOAAAKgFIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_578.setTransform(254.9,121.95);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgQAAgBAWIAAAgIgLAAIAAglQAAgRgOAAQgRAAAAAWIAAAgIgMAAIAAhAIAMAAIAAAPQAFgQARAAQAQAAAEARQAFgRARAAQAWAAAAAZIAAAog");
	this.shape_579.setTransform(245.6,121.875);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_580.setTransform(234.85,120.625);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_581.setTransform(229.6,121.925);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#000000").s().p("AgZAMIgKAAIABgIIAIAAIAAgEIAAgFIgJAAIABgHIAJAAQAEgPAJgHQAJgJAPAAQANAAAKAHIAAAMQgKgHgMAAQgTAAgFATIAcAAIAAAHIgdAAIAAAFIAAAEIAdAAIAAAIIgcAAQAEAUAUgBQAMAAALgGIAAAMQgKAHgOAAQgfAAgGggg");
	this.shape_582.setTransform(218.95,121);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#000000").s().p("AgaAlQgIgHgBgLQAAgHAGgGQAFgFAJgBQgRgFAAgOQAAgLAJgGQAJgGAOAAQAQAAAIAGQAJAGAAALQAAAOgRAFQAJABAGAFQAEAGAAAHQAAAMgJAGQgJAGgRAAQgQAAgKgGgAgUATQgBAOAVAAQAVAAABgOQgBgOgVAAQgVAAABAOgAgSgSQAAANASAAQATAAAAgNQAAgOgTAAQgSAAAAAOg");
	this.shape_583.setTransform(210.75,120.975);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#000000").s().p("AAIAqIAAgRIgtAAIAAgKIApg4IASAAIAAA3IAQAAIAAALIgQAAIAAARgAgWAOIAeAAIAAgrg");
	this.shape_584.setTransform(202.325,120.975);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_585.setTransform(196.35,125.5);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#000000").s().p("AgeAlIABgMQAOAGANAAQATAAAAgQQAAgJgGgDQgFgDgMAAQgLAAgKACIAAgsIA2AAIAAAMIgqAAIAAAVQAHgBAIAAQAfAAAAAZQAAANgJAIQgJAHgOAAQgPAAgOgGg");
	this.shape_586.setTransform(191.325,121.025);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#000000").s().p("AAGAqIAAhEIgYAGIAAgNIAlgIIAABTg");
	this.shape_587.setTransform(184.425,120.975);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#000000").s().p("AgRAAQAAgkAdgVIAGAIQgWATAAAeQAAAfAWATIgGAIQgdgUAAgmg");
	this.shape_588.setTransform(180.05,121.475);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_589.setTransform(172.45,120.625);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_590.setTransform(167.2,121.925);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_591.setTransform(160.225,121.875);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTABQAAAVATABQAUAAAAgXQAAgWgUABQgTAAAAAWg");
	this.shape_592.setTransform(152.4,121.95);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_593.setTransform(146.85,120.475);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgGgLABQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_594.setTransform(141.875,121.95);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAFgRASAAQANAAAHAIQAIAIABARQgBAQgIAJQgIAJgMAAQgQAAgHgPIAAAlgAgNgbQgFAFgBAKIAAACQAAAVATAAQAJAAAFgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_595.setTransform(134.9,123.075);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#000000").s().p("AgYAZQgJgIABgRQgBgQAJgIQAJgJAPAAQAQAAAIAJQAKAIgBAQQABARgKAIQgIAJgQAAQgPAAgJgJgAgUABQAAAVAUABQAUAAAAgXQAAgWgUABQgUAAAAAWg");
	this.shape_596.setTransform(126.8,121.95);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#000000").s().p("AgYAZQgIgIAAgRQAAgQAIgIQAJgJAPAAQAQAAAIAJQAJAIAAAQQAAARgJAIQgIAJgQAAQgPAAgJgJgAgUABQABAVATABQAUAAAAgXQAAgWgUABQgTAAgBAWg");
	this.shape_597.setTransform(115.85,121.95);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_598.setTransform(108.775,121.025);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_599.setTransform(104.1,120.475);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQABAGAPIAAgpIANAAIAABbIgMAAIAAgPQgGARgRAAQgNgBgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_600.setTransform(98.175,120.7);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#000000").s().p("AgdANQAAgQAJgJQAIgJAOAAQANAAAIAIQAIAIgBANIAAAHIgvAAQABAMAFAEQAGAFAKAAQAOAAAKgFIAAAJQgKAHgQAAQghAAABgigAATAGQAAgRgSAAQgPAAgDARIAkAAIAAAAgAgGgdIAKgRIAQAAIgOARg");
	this.shape_601.setTransform(90.85,120.7);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAAKIAAAfg");
	this.shape_602.setTransform(85.125,121.9);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#000000").s().p("AgUAhQgLgMAAgVQAAgUALgMQAKgKARgBQANAAALAHIAAAMQgLgGgLgBQgLAAgHAIQgIAIAAAPQAAAQAIAIQAGAIAMgBQALAAAMgHIAAANQgLAHgOAAQgRgBgKgKg");
	this.shape_603.setTransform(78.475,121);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQANAAAIAIQAIAHgBAPIAAAGIguAAQAAALAFAFQAGAEAKAAQAOAAAKgFIAAAKQgKAGgQAAQghAAABgigAATgFQAAgSgSAAQgPAAgCASIAjAAIAAAAg");
	this.shape_604.setTransform(67.9,121.95);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#000000").s().p("AgXAnQgIgJAAgRQAAgQAIgJQAHgJANAAQAQABAGAPIAAgpIANAAIAABbIgMAAIAAgPQgGARgRAAQgNgBgHgHgAgSANQAAAWASAAQAJAAAFgFQAFgGAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_605.setTransform(60.075,120.7);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#000000").s().p("AgYAZQgIgIAAgRQAAgQAIgIQAJgJAPAAQAQAAAIAJQAJAIAAAQQAAARgJAIQgIAJgQAAQgPAAgJgJgAgUABQABAVATABQAUAAAAgXQAAgWgUABQgTAAgBAWg");
	this.shape_606.setTransform(49.25,121.95);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAAKIAAAfg");
	this.shape_607.setTransform(43.225,121.9);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_608.setTransform(36.425,122.025);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#000000").s().p("AgaApIAAgLQALAFANAAQAVAAgBgTIAAgKQgFAPgQAAQgNAAgGgIQgIgJAAgPQAAgRAIgJQAGgIANAAQARAAAFAQIAAgPIANAAIAAA8QgBAPgJAIQgJAHgOAAQgPAAgKgFgAgMgdQgFAGgBAMQABAUARAAQAIAAAFgFQAGgEgBgJIAAgDQABgWgTAAQgHAAgFAFg");
	this.shape_609.setTransform(28.5,123.175);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAKgJANAAQANAAAIAIQAHAHABAPIAAAGIgvAAQAAALAFAFQAFAEALAAQAOAAAKgFIAAAKQgKAGgQAAQggAAgBgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_610.setTransform(21.25,121.95);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAgBgNQABgFgDgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAPAAQARAAALAGIgBANQgNgHgOAAQgJAAgFADQgEAEAAAFQAAAGADACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_611.setTransform(13.9,120.975);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_612.setTransform(926.225,108.625);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgKQAJgIAPAAQAQAAAIAIQAJAJAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUABQABAWATgBQAUAAAAgWQAAgVgUgBQgTAAgBAXg");
	this.shape_613.setTransform(920.8,106.15);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_614.setTransform(912.675,104.9);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_615.setTransform(905.3,106.125);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_616.setTransform(898.925,105.225);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_617.setTransform(893.775,106.1);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#000000").s().p("AgeAAQAAgPAJgKQAKgIANAAQANAAAIAHQAHAJABANIAAAGIgvAAQAAAMAFAFQAFAFALAAQANAAALgGIAAAKQgLAGgPAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_618.setTransform(887.4,106.15);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_619.setTransform(881.225,104.7);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgKQAJgIAPAAQAQAAAIAIQAJAJAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUABQABAWATgBQAUAAAAgWQAAgVgUgBQgTAAgBAXg");
	this.shape_620.setTransform(874.45,106.15);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_621.setTransform(865.75,104.825);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#000000").s().p("AgdAAQAAgPAJgKQAIgIAOAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_622.setTransform(860.55,106.15);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_623.setTransform(849.975,106.075);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgKQAJgIAPAAQAQAAAIAIQAJAJAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUABQABAWATgBQAUAAAAgWQAAgVgUgBQgTAAgBAXg");
	this.shape_624.setTransform(842.15,106.15);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_625.setTransform(834.975,106.15);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_626.setTransform(826.425,106.1);

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#000000").s().p("AgFAvIAAhAIAMAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_627.setTransform(821.95,104.675);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_628.setTransform(816.025,104.9);

	this.shape_629 = new cjs.Shape();
	this.shape_629.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_629.setTransform(810.6,104.675);

	this.shape_630 = new cjs.Shape();
	this.shape_630.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_630.setTransform(805.625,106.15);

	this.shape_631 = new cjs.Shape();
	this.shape_631.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_631.setTransform(798.625,106.075);

	this.shape_632 = new cjs.Shape();
	this.shape_632.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_632.setTransform(793,104.675);

	this.shape_633 = new cjs.Shape();
	this.shape_633.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQAAAWATgBQAUAAAAgWQAAgVgUgBQgTAAAAAXg");
	this.shape_633.setTransform(787.45,106.15);

	this.shape_634 = new cjs.Shape();
	this.shape_634.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_634.setTransform(780.275,106.15);

	this.shape_635 = new cjs.Shape();
	this.shape_635.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQgBAWAUgBQAUAAAAgWQAAgVgUgBQgUAAABAXg");
	this.shape_635.setTransform(770,106.15);

	this.shape_636 = new cjs.Shape();
	this.shape_636.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_636.setTransform(762.325,106.075);

	this.shape_637 = new cjs.Shape();
	this.shape_637.graphics.f("#000000").s().p("AgeAAQABgPAIgKQAKgIANAAQANAAAIAHQAHAJABANIAAAGIgvAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_637.setTransform(751.6,106.15);

	this.shape_638 = new cjs.Shape();
	this.shape_638.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_638.setTransform(743.775,104.9);

	this.shape_639 = new cjs.Shape();
	this.shape_639.graphics.f("#000000").s().p("AgdAAQgBgPAKgKQAJgIANAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAFAFALAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_639.setTransform(736.45,106.15);

	this.shape_640 = new cjs.Shape();
	this.shape_640.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_640.setTransform(728.875,106.225);

	this.shape_641 = new cjs.Shape();
	this.shape_641.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAGgRARAAQAMAAAIAIQAIAIAAARQAAAQgIAJQgIAJgMAAQgQAAgHgPIAAAlgAgNgbQgGAFAAAKIAAACQABAVASAAQAJAAAFgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_641.setTransform(721.35,107.275);

	this.shape_642 = new cjs.Shape();
	this.shape_642.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQAAAWATgBQAUAAAAgWQAAgVgUgBQgTAAAAAXg");
	this.shape_642.setTransform(710.05,106.15);

	this.shape_643 = new cjs.Shape();
	this.shape_643.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_643.setTransform(701.925,104.9);

	this.shape_644 = new cjs.Shape();
	this.shape_644.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_644.setTransform(694.55,106.125);

	this.shape_645 = new cjs.Shape();
	this.shape_645.graphics.f("#000000").s().p("AgbAhIAAgLIAngrIgnAAIAAgLIA2AAIAAALIgnArIAoAAIAAALg");
	this.shape_645.setTransform(688.025,106.15);

	this.shape_646 = new cjs.Shape();
	this.shape_646.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_646.setTransform(683.05,104.675);

	this.shape_647 = new cjs.Shape();
	this.shape_647.graphics.f("#000000").s().p("AgFAuIAAhbIAMAAIAABbg");
	this.shape_647.setTransform(679.75,104.825);

	this.shape_648 = new cjs.Shape();
	this.shape_648.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_648.setTransform(674.5,106.125);

	this.shape_649 = new cjs.Shape();
	this.shape_649.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_649.setTransform(667.325,106.225);

	this.shape_650 = new cjs.Shape();
	this.shape_650.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_650.setTransform(660.375,106.125);

	this.shape_651 = new cjs.Shape();
	this.shape_651.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_651.setTransform(655.5,104.675);

	this.shape_652 = new cjs.Shape();
	this.shape_652.graphics.f("#000000").s().p("AgHAhIgbhBIAPAAIATA2IAUg2IAPAAIgcBBg");
	this.shape_652.setTransform(650.2,106.15);

	this.shape_653 = new cjs.Shape();
	this.shape_653.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQgBAWAUgBQAUAAAAgWQAAgVgUgBQgUAAABAXg");
	this.shape_653.setTransform(639.5,106.15);

	this.shape_654 = new cjs.Shape();
	this.shape_654.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_654.setTransform(634,104.825);

	this.shape_655 = new cjs.Shape();
	this.shape_655.graphics.f("#000000").s().p("AgdAAQAAgPAJgKQAIgIAOAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_655.setTransform(628.8,106.15);

	this.shape_656 = new cjs.Shape();
	this.shape_656.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_656.setTransform(620.975,104.9);

	this.shape_657 = new cjs.Shape();
	this.shape_657.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgKQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUABQAAAWAUgBQAUAAAAgWQAAgVgUgBQgUAAAAAXg");
	this.shape_657.setTransform(613.35,106.15);

	this.shape_658 = new cjs.Shape();
	this.shape_658.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgOAAQgPAAAAAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgOAAIAAhAIANAAIAAAPQAFgQARAAQAQAAADARQAGgRARAAQAVAAAAAZIAAAog");
	this.shape_658.setTransform(603.75,106.075);

	this.shape_659 = new cjs.Shape();
	this.shape_659.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_659.setTransform(593,104.825);

	this.shape_660 = new cjs.Shape();
	this.shape_660.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAYIAkAAIAAAKIgkAAIAAAZIApAAIAAAMg");
	this.shape_660.setTransform(587.7,105.175);

	this.shape_661 = new cjs.Shape();
	this.shape_661.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_661.setTransform(579.025,108.625);

	this.shape_662 = new cjs.Shape();
	this.shape_662.graphics.f("#000000").s().p("AAIAqIAAgRIgtAAIAAgKIApg4IASAAIAAA3IAQAAIAAALIgQAAIAAARgAgWAOIAeAAIAAgrg");
	this.shape_662.setTransform(573.125,105.175);

	this.shape_663 = new cjs.Shape();
	this.shape_663.graphics.f("#000000").s().p("AgdArIAAgLIAagYIANgNQAFgGAAgGQAAgNgQAAQgPAAgNAJIAAgMQANgJAQAAQAOAAAHAGQAIAGAAALQAAAJgHAJQgFAGgMALIgQAPIApAAIAAAMg");
	this.shape_663.setTransform(565.175,105.125);

	this.shape_664 = new cjs.Shape();
	this.shape_664.graphics.f("#000000").s().p("AgZAgQgJgLAAgVQAAgUAJgLQAJgLAQAAQARAAAJALQAJALAAAUQAAAVgJALQgJALgRAAQgQAAgJgLgAgUAAQAAAfAUABQAWgBAAgfQAAgegWAAQgUAAAAAeg");
	this.shape_664.setTransform(557.325,105.2);

	this.shape_665 = new cjs.Shape();
	this.shape_665.graphics.f("#000000").s().p("AgdArIAAgLIAagYIANgNQAFgGAAgGQAAgNgQAAQgPAAgNAJIAAgMQANgJAQAAQAOAAAHAGQAIAGAAALQAAAJgHAJQgFAGgMALIgQAPIApAAIAAAMg");
	this.shape_665.setTransform(549.525,105.125);

	this.shape_666 = new cjs.Shape();
	this.shape_666.graphics.f("#000000").s().p("AgUA0IAehnIALAAIgdBng");
	this.shape_666.setTransform(543.8,105.35);

	this.shape_667 = new cjs.Shape();
	this.shape_667.graphics.f("#000000").s().p("AAIAqIAAgRIgtAAIAAgKIApg4IASAAIAAA3IAQAAIAAALIgQAAIAAARgAgWAOIAeAAIAAgrg");
	this.shape_667.setTransform(537.475,105.175);

	this.shape_668 = new cjs.Shape();
	this.shape_668.graphics.f("#000000").s().p("AgZAgQgJgLAAgVQAAgUAJgLQAJgLAQAAQARAAAJALQAJALAAAUQAAAVgJALQgJALgRAAQgQAAgJgLgAgUAAQAAAfAUABQAWgBAAgfQAAgegWAAQgUAAAAAeg");
	this.shape_668.setTransform(528.975,105.2);

	this.shape_669 = new cjs.Shape();
	this.shape_669.graphics.f("#000000").s().p("AgTA0IAdhnIAKAAIgcBng");
	this.shape_669.setTransform(522.75,105.35);

	this.shape_670 = new cjs.Shape();
	this.shape_670.graphics.f("#000000").s().p("AgZAgQgJgLAAgVQAAgUAJgLQAJgLAQAAQARAAAJALQAJALAAAUQAAAVgJALQgJALgRAAQgQAAgJgLgAgUAAQAAAfAUABQAWgBAAgfQAAgegWAAQgUAAAAAeg");
	this.shape_670.setTransform(516.575,105.2);

	this.shape_671 = new cjs.Shape();
	this.shape_671.graphics.f("#000000").s().p("AgeAlIABgNQANAHAOAAQAIAAAGgDQAFgEAAgGQAAgNgSAAIgNAAIAAgKIANAAQAGAAAFgDQAFgEAAgGQAAgGgFgDQgGgDgIAAQgOAAgLAGIAAgNQAMgFAOAAQAPAAAIAGQAJAGAAAKQAAAPgRAFQATADAAAQQAAALgJAHQgJAGgOAAQgQAAgNgGg");
	this.shape_671.setTransform(508.775,105.175);

	this.shape_672 = new cjs.Shape();
	this.shape_672.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_672.setTransform(500.25,104.825);

	this.shape_673 = new cjs.Shape();
	this.shape_673.graphics.f("#000000").s().p("AgdAAQAAgPAJgKQAIgIAOAAQAOAAAHAHQAIAJgBANIAAAGIgvAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_673.setTransform(495.05,106.15);

	this.shape_674 = new cjs.Shape();
	this.shape_674.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_674.setTransform(484.65,106.125);

	this.shape_675 = new cjs.Shape();
	this.shape_675.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_675.setTransform(478.275,105.225);

	this.shape_676 = new cjs.Shape();
	this.shape_676.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_676.setTransform(472.075,106.125);

	this.shape_677 = new cjs.Shape();
	this.shape_677.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_677.setTransform(465.25,106.125);

	this.shape_678 = new cjs.Shape();
	this.shape_678.graphics.f("#000000").s().p("AARAuIAAgmQAAgQgPAAQgIAAgFAGQgFAFAAALIAAAgIgNAAIAAhbIANAAIAAAqQAGgRARAAQAKAAAHAHQAGAGAAALIAAAqg");
	this.shape_678.setTransform(458.275,104.825);

	this.shape_679 = new cjs.Shape();
	this.shape_679.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQgBAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_679.setTransform(447.5,106.125);

	this.shape_680 = new cjs.Shape();
	this.shape_680.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_680.setTransform(440.075,104.9);

	this.shape_681 = new cjs.Shape();
	this.shape_681.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_681.setTransform(434.65,104.675);

	this.shape_682 = new cjs.Shape();
	this.shape_682.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_682.setTransform(431.35,104.825);

	this.shape_683 = new cjs.Shape();
	this.shape_683.graphics.f("#000000").s().p("AgWApQgFgFAAgJQAAgTAYAAIAPAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAAgDQAAgLgPAAQgMAAgKAGIAAgMQAMgFAMAAQAaAAAAAVIAAAsIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAbQAAAEAEADQACADAHAAQAGAAAGgFQAFgFAAgJIAAgCIgQAAQgOAAAAALgAgGgdIAKgQIAQAAIgOAQg");
	this.shape_683.setTransform(426.1,104.875);

	this.shape_684 = new cjs.Shape();
	this.shape_684.graphics.f("#000000").s().p("AgIAhIgZhBIAOAAIATA2IAVg2IANAAIgbBBg");
	this.shape_684.setTransform(419.3,106.15);

	this.shape_685 = new cjs.Shape();
	this.shape_685.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_685.setTransform(408.85,106.125);

	this.shape_686 = new cjs.Shape();
	this.shape_686.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_686.setTransform(402.475,105.225);

	this.shape_687 = new cjs.Shape();
	this.shape_687.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_687.setTransform(397.325,106.1);

	this.shape_688 = new cjs.Shape();
	this.shape_688.graphics.f("#000000").s().p("AgdAAQgBgPAKgKQAJgIANAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_688.setTransform(390.95,106.15);

	this.shape_689 = new cjs.Shape();
	this.shape_689.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_689.setTransform(384.775,104.7);

	this.shape_690 = new cjs.Shape();
	this.shape_690.graphics.f("#000000").s().p("AgdAhQgLgMABgVQgBgVALgLQAKgLATABQATgBALALQALALAAAVQAAAVgLAMQgLALgTgBQgTABgKgLgAgaAAQABAfAZABQAbgBAAgfQAAgegbAAQgZAAgBAeg");
	this.shape_690.setTransform(377.15,105.2);

	this.shape_691 = new cjs.Shape();
	this.shape_691.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_691.setTransform(367.675,108.625);

	this.shape_692 = new cjs.Shape();
	this.shape_692.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_692.setTransform(362.5,106.125);

	this.shape_693 = new cjs.Shape();
	this.shape_693.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_693.setTransform(356.125,105.225);

	this.shape_694 = new cjs.Shape();
	this.shape_694.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQgBAWAUgBQAUAAAAgWQAAgVgUgBQgUAAABAXg");
	this.shape_694.setTransform(349.25,106.15);

	this.shape_695 = new cjs.Shape();
	this.shape_695.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_695.setTransform(341.375,106.225);

	this.shape_696 = new cjs.Shape();
	this.shape_696.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_696.setTransform(334.325,106.15);

	this.shape_697 = new cjs.Shape();
	this.shape_697.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_697.setTransform(324.3,106.125);

	this.shape_698 = new cjs.Shape();
	this.shape_698.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgOAAQgPAAAAAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgOAAIAAhAIANAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAAAAZIAAAog");
	this.shape_698.setTransform(315.4,106.075);

	this.shape_699 = new cjs.Shape();
	this.shape_699.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_699.setTransform(307.8,104.675);

	this.shape_700 = new cjs.Shape();
	this.shape_700.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_700.setTransform(302.925,105.225);

	this.shape_701 = new cjs.Shape();
	this.shape_701.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_701.setTransform(298.3,104.825);

	this.shape_702 = new cjs.Shape();
	this.shape_702.graphics.f("#000000").s().p("AgXApQgGgHAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgLIAAgfIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgFgAgGgdIAKgQIAQAAIgOAQg");
	this.shape_702.setTransform(292.675,104.9);

	this.shape_703 = new cjs.Shape();
	this.shape_703.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_703.setTransform(282.1,106.125);

	this.shape_704 = new cjs.Shape();
	this.shape_704.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_704.setTransform(277.3,104.825);

	this.shape_705 = new cjs.Shape();
	this.shape_705.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_705.setTransform(270.325,106.1);

	this.shape_706 = new cjs.Shape();
	this.shape_706.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_706.setTransform(263.9,106.125);

	this.shape_707 = new cjs.Shape();
	this.shape_707.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_707.setTransform(259.05,104.675);

	this.shape_708 = new cjs.Shape();
	this.shape_708.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_708.setTransform(254.075,106.15);

	this.shape_709 = new cjs.Shape();
	this.shape_709.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_709.setTransform(247.075,106.075);

	this.shape_710 = new cjs.Shape();
	this.shape_710.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_710.setTransform(239.5,106.125);

	this.shape_711 = new cjs.Shape();
	this.shape_711.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_711.setTransform(232.525,106.075);

	this.shape_712 = new cjs.Shape();
	this.shape_712.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_712.setTransform(226.9,104.675);

	this.shape_713 = new cjs.Shape();
	this.shape_713.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_713.setTransform(222.625,104.7);

	this.shape_714 = new cjs.Shape();
	this.shape_714.graphics.f("#000000").s().p("AgdAAQgBgPAKgKQAIgIAOAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_714.setTransform(216.15,106.15);

	this.shape_715 = new cjs.Shape();
	this.shape_715.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_715.setTransform(210.425,106.1);

	this.shape_716 = new cjs.Shape();
	this.shape_716.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQAAAWATgBQAUAAAAgWQAAgVgUgBQgTAAAAAXg");
	this.shape_716.setTransform(200.55,106.15);

	this.shape_717 = new cjs.Shape();
	this.shape_717.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_717.setTransform(191.325,106.1);

	this.shape_718 = new cjs.Shape();
	this.shape_718.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_718.setTransform(184.9,106.125);

	this.shape_719 = new cjs.Shape();
	this.shape_719.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_719.setTransform(177.925,106.075);

	this.shape_720 = new cjs.Shape();
	this.shape_720.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgKQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUABQAAAWAUgBQAUAAAAgWQAAgVgUgBQgUAAAAAXg");
	this.shape_720.setTransform(170.1,106.15);

	this.shape_721 = new cjs.Shape();
	this.shape_721.graphics.f("#000000").s().p("AgTAeIAAAPIgMAAIAAhaIAMAAIAAAoQAGgPARAAQAMAAAIAIQAIAIAAAQQAAARgIAJQgIAIgMAAQgSABgFgRgAgNgDQgGAEAAAJIAAADQABAWASAAQAJAAAFgFQAFgGAAgMQAAgVgTAAQgIAAgFAGg");
	this.shape_721.setTransform(162.45,104.9);

	this.shape_722 = new cjs.Shape();
	this.shape_722.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_722.setTransform(154.6,106.125);

	this.shape_723 = new cjs.Shape();
	this.shape_723.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgPAJgKQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUABQAAAWAUgBQAUAAAAgWQAAgVgUgBQgUAAAAAXg");
	this.shape_723.setTransform(144.35,106.15);

	this.shape_724 = new cjs.Shape();
	this.shape_724.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_724.setTransform(135.6,109.7);

	this.shape_725 = new cjs.Shape();
	this.shape_725.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQAAAWATgBQAUAAAAgWQAAgVgUgBQgTAAAAAXg");
	this.shape_725.setTransform(130.35,106.15);

	this.shape_726 = new cjs.Shape();
	this.shape_726.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_726.setTransform(124.85,104.825);

	this.shape_727 = new cjs.Shape();
	this.shape_727.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_727.setTransform(119.225,106.225);

	this.shape_728 = new cjs.Shape();
	this.shape_728.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_728.setTransform(112.175,106.15);

	this.shape_729 = new cjs.Shape();
	this.shape_729.graphics.f("#000000").s().p("AgKAuIAAhAIALAAIAABAgAgMgcIALgRIAPAAIgOARg");
	this.shape_729.setTransform(107.8,104.825);

	this.shape_730 = new cjs.Shape();
	this.shape_730.graphics.f("#000000").s().p("AARAuIAAgmQAAgQgPAAQgIAAgFAGQgFAFAAALIAAAgIgNAAIAAhbIANAAIAAAqQAGgRARAAQAKAAAHAHQAGAGAAALIAAAqg");
	this.shape_730.setTransform(101.825,104.825);

	this.shape_731 = new cjs.Shape();
	this.shape_731.graphics.f("#000000").s().p("AgdAAQgBgPAKgKQAJgIANAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAFAFALAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_731.setTransform(94.3,106.15);

	this.shape_732 = new cjs.Shape();
	this.shape_732.graphics.f("#000000").s().p("AgIAhIgahBIAPAAIATA2IAVg2IANAAIgbBBg");
	this.shape_732.setTransform(87.1,106.15);

	this.shape_733 = new cjs.Shape();
	this.shape_733.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_733.setTransform(76.275,106.225);

	this.shape_734 = new cjs.Shape();
	this.shape_734.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_734.setTransform(69.325,106.125);

	this.shape_735 = new cjs.Shape();
	this.shape_735.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_735.setTransform(60.775,106.1);

	this.shape_736 = new cjs.Shape();
	this.shape_736.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_736.setTransform(54.35,106.125);

	this.shape_737 = new cjs.Shape();
	this.shape_737.graphics.f("#000000").s().p("AgZApIAAgLQALAFAMAAQAUAAABgTIAAgKQgGAPgQAAQgMAAgIgIQgHgJgBgPQABgRAHgJQAIgIAMAAQARAAAFAQIAAgPIAMAAIAAA8QABAPgLAIQgIAHgPAAQgPAAgIgFgAgMgdQgGAGABAMQgBAUASAAQAIAAAFgFQAFgEABgJIAAgDQgBgWgSAAQgIAAgEAFg");
	this.shape_737.setTransform(47,107.375);

	this.shape_738 = new cjs.Shape();
	this.shape_738.graphics.f("#000000").s().p("AgdAAQgBgPAKgKQAIgIAOAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_738.setTransform(39.75,106.15);

	this.shape_739 = new cjs.Shape();
	this.shape_739.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_739.setTransform(34.025,106.1);

	this.shape_740 = new cjs.Shape();
	this.shape_740.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_740.setTransform(28.025,105.225);

	this.shape_741 = new cjs.Shape();
	this.shape_741.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_741.setTransform(21.225,106.075);

	this.shape_742 = new cjs.Shape();
	this.shape_742.graphics.f("#000000").s().p("AgeAAQABgPAIgKQAJgIAOAAQANAAAIAHQAHAJAAANIAAAGIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_742.setTransform(13.7,106.15);

	this.shape_743 = new cjs.Shape();
	this.shape_743.graphics.f("#000000").s().p("AgeAAQABgPAIgKQAJgIAOAAQAOAAAHAHQAHAJAAANIAAAGIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_743.setTransform(952.05,88.15);

	this.shape_744 = new cjs.Shape();
	this.shape_744.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_744.setTransform(946.325,88.1);

	this.shape_745 = new cjs.Shape();
	this.shape_745.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_745.setTransform(940.325,87.225);

	this.shape_746 = new cjs.Shape();
	this.shape_746.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_746.setTransform(933.525,88.075);

	this.shape_747 = new cjs.Shape();
	this.shape_747.graphics.f("#000000").s().p("AgdAAQgBgPAKgKQAJgIANAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_747.setTransform(926,88.15);

	this.shape_748 = new cjs.Shape();
	this.shape_748.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_748.setTransform(917.075,88.1);

	this.shape_749 = new cjs.Shape();
	this.shape_749.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_749.setTransform(912.6,86.675);

	this.shape_750 = new cjs.Shape();
	this.shape_750.graphics.f("#000000").s().p("AgZApIAAgLQAKAFANAAQAUAAABgTIAAgKQgGAPgQAAQgNAAgGgIQgJgJABgPQgBgRAJgJQAGgIANAAQARAAAFAQIAAgPIANAAIAAA8QAAAPgKAIQgJAHgPAAQgPAAgIgFgAgMgdQgGAGAAAMQAAAUASAAQAIAAAFgFQAGgEAAgJIAAgDQAAgWgTAAQgHAAgFAFg");
	this.shape_750.setTransform(906.75,89.375);

	this.shape_751 = new cjs.Shape();
	this.shape_751.graphics.f("#000000").s().p("AgdAAQAAgPAJgKQAIgIAOAAQANAAAIAHQAIAJgBANIAAAGIgvAAQABAMAFAFQAGAFAKAAQAOAAAKgGIAAAKQgKAGgQAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_751.setTransform(899.5,88.15);

	this.shape_752 = new cjs.Shape();
	this.shape_752.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_752.setTransform(894.3,86.825);

	this.shape_753 = new cjs.Shape();
	this.shape_753.graphics.f("#000000").s().p("AgdAAQgBgPAKgKQAJgIANAAQAOAAAHAHQAIAJAAANIAAAGIgwAAQABAMAFAFQAGAFAKAAQANAAALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_753.setTransform(889.1,88.15);

	this.shape_754 = new cjs.Shape();
	this.shape_754.graphics.f("#000000").s().p("AgWApQgFgFAAgJQAAgTAYAAIAPAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAAgDQAAgLgPAAQgNAAgJAGIAAgMQAMgFAMAAQAaAAAAAVIAAAsIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAbQAAAEADADQAEADAFAAQAIAAAFgFQAFgFAAgJIAAgCIgQAAQgOAAAAALgAgGgdIAKgQIAQAAIgOAQg");
	this.shape_754.setTransform(878.7,86.875);

	this.shape_755 = new cjs.Shape();
	this.shape_755.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_755.setTransform(873.375,88.1);

	this.shape_756 = new cjs.Shape();
	this.shape_756.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_756.setTransform(866.325,86.9);

	this.shape_757 = new cjs.Shape();
	this.shape_757.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgKQAJgIAPAAQAQAAAIAIQAJAJAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUABQABAWATgBQAUAAAAgWQAAgVgUgBQgTAAgBAXg");
	this.shape_757.setTransform(858.7,88.15);

	this.shape_758 = new cjs.Shape();
	this.shape_758.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAGgRARAAQAMAAAIAIQAIAIAAARQAAAQgIAJQgIAJgMAAQgRAAgGgPIAAAlgAgNgbQgGAFAAAKIAAACQABAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_758.setTransform(851.05,89.275);

	this.shape_759 = new cjs.Shape();
	this.shape_759.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQgBAWAUgBQAUAAAAgWQAAgVgUgBQgUAAABAXg");
	this.shape_759.setTransform(839.75,88.15);

	this.shape_760 = new cjs.Shape();
	this.shape_760.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_760.setTransform(832.675,87.225);

	this.shape_761 = new cjs.Shape();
	this.shape_761.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_761.setTransform(826.05,88.125);

	this.shape_762 = new cjs.Shape();
	this.shape_762.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_762.setTransform(820.725,88.1);

	this.shape_763 = new cjs.Shape();
	this.shape_763.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_763.setTransform(814.725,87.225);

	this.shape_764 = new cjs.Shape();
	this.shape_764.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_764.setTransform(807.925,88.075);

	this.shape_765 = new cjs.Shape();
	this.shape_765.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgKQAJgIAPAAQAQAAAIAIQAKAJgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUABQAAAWAUgBQAUAAAAgWQAAgVgUgBQgUAAAAAXg");
	this.shape_765.setTransform(800.1,88.15);

	this.shape_766 = new cjs.Shape();
	this.shape_766.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_766.setTransform(792.925,88.15);

	this.shape_767 = new cjs.Shape();
	this.shape_767.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_767.setTransform(784.9,86.825);

	this.shape_768 = new cjs.Shape();
	this.shape_768.graphics.f("#000000").s().p("AgeAAQABgPAIgKQAJgIAOAAQANAAAIAHQAHAJAAANIAAAGIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_768.setTransform(779.7,88.15);

	this.shape_769 = new cjs.Shape();
	this.shape_769.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_769.setTransform(771.875,86.9);

	this.shape_770 = new cjs.Shape();
	this.shape_770.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_770.setTransform(763.3,86.825);

	this.shape_771 = new cjs.Shape();
	this.shape_771.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_771.setTransform(758.05,88.125);

	this.shape_772 = new cjs.Shape();
	this.shape_772.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_772.setTransform(751.075,88.075);

	this.shape_773 = new cjs.Shape();
	this.shape_773.graphics.f("#000000").s().p("AgFAvIAAhAIAMAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_773.setTransform(745.45,86.675);

	this.shape_774 = new cjs.Shape();
	this.shape_774.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_774.setTransform(741.175,86.7);

	this.shape_775 = new cjs.Shape();
	this.shape_775.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_775.setTransform(733.45,86.825);

	this.shape_776 = new cjs.Shape();
	this.shape_776.graphics.f("#000000").s().p("AAaAqIgHgVIglAAIgIAVIgOAAIAghTIASAAIAfBTgAAPAJIgPgoIgOAoIAdAAg");
	this.shape_776.setTransform(727.475,87.175);

	this.shape_777 = new cjs.Shape();
	this.shape_777.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_777.setTransform(718.375,90.625);

	this.shape_778 = new cjs.Shape();
	this.shape_778.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_778.setTransform(713.625,88.125);

	this.shape_779 = new cjs.Shape();
	this.shape_779.graphics.f("#000000").s().p("AgeAMQAAgPAKgJQAJgJANABQAOgBAHAIQAIAIAAANIAAAHIgwAAQABALAFAGQAGAEAKAAQANAAALgGIAAALQgLAFgPAAQggABgBgjgAATAGQAAgQgRAAQgQAAgDAQIAkAAIAAAAgAgFgdIAKgQIAQAAIgPAQg");
	this.shape_779.setTransform(706.85,86.9);

	this.shape_780 = new cjs.Shape();
	this.shape_780.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_780.setTransform(699.975,88.15);

	this.shape_781 = new cjs.Shape();
	this.shape_781.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_781.setTransform(692.975,88.075);

	this.shape_782 = new cjs.Shape();
	this.shape_782.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_782.setTransform(685.4,88.125);

	this.shape_783 = new cjs.Shape();
	this.shape_783.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_783.setTransform(680.075,88.1);

	this.shape_784 = new cjs.Shape();
	this.shape_784.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_784.setTransform(674.675,86.7);

	this.shape_785 = new cjs.Shape();
	this.shape_785.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_785.setTransform(664.775,88.075);

	this.shape_786 = new cjs.Shape();
	this.shape_786.graphics.f("#000000").s().p("AgYAmQgJgIAAgSQAAgPAJgJQAJgJAPABQAQgBAJAJQAIAJABAPQgBASgIAIQgJAIgQAAQgPAAgJgIgAgTANQAAAWATAAQAUAAAAgXQAAgVgUAAQgTAAAAAWgAgHgdIAJgQIAQAAIgOAQg");
	this.shape_786.setTransform(656.95,86.9);

	this.shape_787 = new cjs.Shape();
	this.shape_787.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_787.setTransform(651.4,86.675);

	this.shape_788 = new cjs.Shape();
	this.shape_788.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgIAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAALQgJAGgMAAQgPAAgIgIg");
	this.shape_788.setTransform(646.425,88.15);

	this.shape_789 = new cjs.Shape();
	this.shape_789.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_789.setTransform(639.6,88.125);

	this.shape_790 = new cjs.Shape();
	this.shape_790.graphics.f("#000000").s().p("AgbAhIAAgLIAngrIgnAAIAAgLIA2AAIAAALIgnArIAoAAIAAALg");
	this.shape_790.setTransform(633.075,88.15);

	this.shape_791 = new cjs.Shape();
	this.shape_791.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_791.setTransform(628.1,86.675);

	this.shape_792 = new cjs.Shape();
	this.shape_792.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_792.setTransform(623.225,87.225);

	this.shape_793 = new cjs.Shape();
	this.shape_793.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_793.setTransform(618.075,88.1);

	this.shape_794 = new cjs.Shape();
	this.shape_794.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgKQAJgIAPAAQAQAAAJAIQAIAJABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQAAAWATgBQAUAAAAgWQAAgVgUgBQgTAAAAAXg");
	this.shape_794.setTransform(611.4,88.15);

	this.shape_795 = new cjs.Shape();
	this.shape_795.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgRAAAAAWIAAAgIgMAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_795.setTransform(601.8,88.075);

	this.shape_796 = new cjs.Shape();
	this.shape_796.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_796.setTransform(592.25,88.125);

	this.shape_797 = new cjs.Shape();
	this.shape_797.graphics.f("#000000").s().p("AgeAAQAAgPAJgKQAKgIANAAQANAAAIAHQAHAJABANIAAAGIgvAAQAAAMAFAFQAFAFALAAQANAAALgGIAAAKQgLAGgPAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_797.setTransform(582.3,88.15);

	this.shape_798 = new cjs.Shape();
	this.shape_798.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_798.setTransform(574.475,86.9);

	this.shape_799 = new cjs.Shape();
	this.shape_799.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_799.setTransform(563.9,88.125);

	this.shape_800 = new cjs.Shape();
	this.shape_800.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgRAAAAAWIAAAgIgMAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_800.setTransform(555,88.075);

	this.shape_801 = new cjs.Shape();
	this.shape_801.graphics.f("#000000").s().p("AgeAAQABgPAIgKQAKgIANAAQANAAAIAHQAHAJAAANIAAAGIguAAQAAAMAFAFQAFAFALAAQAOAAAKgGIAAAKQgKAGgQAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_801.setTransform(545.5,88.15);

	this.shape_802 = new cjs.Shape();
	this.shape_802.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_802.setTransform(538.725,87.225);

	this.shape_803 = new cjs.Shape();
	this.shape_803.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_803.setTransform(532.525,88.125);

	this.shape_804 = new cjs.Shape();
	this.shape_804.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_804.setTransform(527.65,86.675);

	this.shape_805 = new cjs.Shape();
	this.shape_805.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQATAAABgNQAAgFgEgCQgDgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAPAAQARAAALAGIgBANQgNgHgOAAQgIAAgGADQgEAEAAAFQgBAGAEACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_805.setTransform(522.2,87.175);

	this.shape_806 = new cjs.Shape();
	this.shape_806.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAADADQAEAEAAAEQAAAGgEADQgDADgGAAQgFAAgEgDg");
	this.shape_806.setTransform(513.35,90.3);

	this.shape_807 = new cjs.Shape();
	this.shape_807.graphics.f("#000000").s().p("AAXApQgFgDgDgFQgCgFAAgHQAAgGACgGQADgFAFgDQAGgCAIAAQAIAAAFACQAGADADAFQACAGAAAGQAAAGgCAGQgDAFgGADQgFADgIAAQgIAAgGgDgAAfAOQgCACAAAFQAAAFACACQACACAEAAQAEAAACgCQACgCAAgFQAAgFgCgCQgCgDgEAAQgEAAgCADgAgmAqIAggsIAWgnIAXAAIggAtIgXAmgAgxAAQgGgDgDgFQgCgFAAgHQAAgGACgFQADgGAGgDQAFgDAIAAQAIAAAGADQAFADADAGQACAFAAAGQAAAHgCAFQgDAFgFADQgGACgIAAQgIAAgFgCgAgqgbQgCADAAAEQAAAFACACQACADAEAAQADAAADgDQACgCAAgFQAAgEgCgDQgDgCgDAAQgEAAgCACg");
	this.shape_807.setTransform(504.9,87.175);

	this.shape_808 = new cjs.Shape();
	this.shape_808.graphics.f("#000000").s().p("AACAqIAAg9IgXADIAAgSIAqgHIAABTg");
	this.shape_808.setTransform(495.2,87.175);

	this.shape_809 = new cjs.Shape();
	this.shape_809.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_809.setTransform(488.975,87.175);

	this.shape_810 = new cjs.Shape();
	this.shape_810.graphics.f("#000000").s().p("AgMASIAFgjIAVAAIgNAjg");
	this.shape_810.setTransform(483.45,91.625);

	this.shape_811 = new cjs.Shape();
	this.shape_811.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_811.setTransform(478.175,87.175);

	this.shape_812 = new cjs.Shape();
	this.shape_812.graphics.f("#000000").s().p("AgIAfQgEgDAAgGQAAgFAEgEQADgDAFAAQAGAAADADQAEAEAAAFQAAAGgEADQgDADgGAAQgFAAgDgDgAgIgMQgEgEAAgFQAAgGAEgDQADgDAFAAQAGAAADADQAEADAAAGQAAAFgEAEQgDADgGAAQgFAAgDgDg");
	this.shape_812.setTransform(469.4,88.075);

	this.shape_813 = new cjs.Shape();
	this.shape_813.graphics.f("#000000").s().p("AgcAqIAAhTIA5AAIAAARIglAAIAAARIAgAAIAAAPIggAAIAAARIAlAAIAAARg");
	this.shape_813.setTransform(463.875,87.175);

	this.shape_814 = new cjs.Shape();
	this.shape_814.graphics.f("#000000").s().p("AAVAqIgGgRIgfAAIgFARIgUAAIAdhTIAbAAIAbBTgAAKAIIgKgiIgKAiIAUAAg");
	this.shape_814.setTransform(455.575,87.175);

	this.shape_815 = new cjs.Shape();
	this.shape_815.graphics.f("#000000").s().p("AgJAqIAAhBIgbAAIAAgSIBIAAIAAASIgaAAIAABBg");
	this.shape_815.setTransform(447,87.175);

	this.shape_816 = new cjs.Shape();
	this.shape_816.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAADADQAEAEAAAEQAAAGgEADQgDADgGAAQgFAAgEgDg");
	this.shape_816.setTransform(437.75,90.3);

	this.shape_817 = new cjs.Shape();
	this.shape_817.graphics.f("#000000").s().p("AAXApQgFgDgDgFQgCgFAAgHQAAgGACgGQADgFAFgDQAGgCAIAAQAIAAAFACQAGADADAFQACAGAAAGQAAAGgCAGQgDAFgGADQgFADgIAAQgIAAgGgDgAAfAOQgCACAAAFQAAAFACACQACACAEAAQAEAAACgCQACgCAAgFQAAgFgCgCQgCgDgEAAQgEAAgCADgAgmAqIAggsIAWgnIAXAAIggAtIgXAmgAgxAAQgGgDgDgFQgCgFAAgHQAAgGACgFQADgGAGgDQAFgDAIAAQAIAAAGADQAFADADAGQACAFAAAGQAAAHgCAFQgDAFgFADQgGACgIAAQgIAAgFgCgAgqgbQgCADAAAEQAAAFACACQACADAEAAQADAAADgDQACgCAAgFQAAgEgCgDQgDgCgDAAQgEAAgCACg");
	this.shape_817.setTransform(429.3,87.175);

	this.shape_818 = new cjs.Shape();
	this.shape_818.graphics.f("#000000").s().p("AgcAnIAAgSQAFADAFACIAMABQAKgBAGgGQAGgHAAgLQgDAFgGADQgGAEgGgBQgJABgHgEQgHgDgDgGQgEgGAAgIQAAgIAEgHQAEgHAIgEQAHgDAKAAQARgBAKAKQALAJAAAXQAAAMgFALQgEAKgJAGQgJAGgNAAQgPAAgJgFgAgLgXQgEADAAAHQAAAGAEADQADAEAIAAQAHAAAEgEQAEgDAAgGQAAgGgEgEQgEgDgHAAQgHgBgEAEg");
	this.shape_818.setTransform(418.575,87.15);

	this.shape_819 = new cjs.Shape();
	this.shape_819.graphics.f("#000000").s().p("AgcAnIAAgSQAFADAFACIAMABQAKgBAGgGQAGgHAAgLQgDAFgGADQgGAEgGgBQgJABgHgEQgHgDgDgGQgEgGAAgIQAAgIAEgHQAEgHAIgEQAHgDAKAAQARgBAKAKQALAJAAAXQAAAMgFALQgEAKgJAGQgJAGgNAAQgPAAgJgFgAgLgXQgEADAAAHQAAAGAEADQADAEAIAAQAHAAAEgEQAEgDAAgGQAAgGgEgEQgEgDgHAAQgHgBgEAEg");
	this.shape_819.setTransform(410.375,87.15);

	this.shape_820 = new cjs.Shape();
	this.shape_820.graphics.f("#000000").s().p("AgNASIAHgjIATAAIgLAjg");
	this.shape_820.setTransform(404.4,91.625);

	this.shape_821 = new cjs.Shape();
	this.shape_821.graphics.f("#000000").s().p("AgRAqIgOgFIACgSIANAFIANABQAHAAAEgDQAEgCAAgHQAAgGgGgCQgFgCgJgBIgKABIgKABIAAguIA4AAIAAARIgmAAIAAAPIAKgBQAQAAAIAGQAIAGAAAMQAAAKgEAGQgEAHgIADQgIAEgKAAIgPgBg");
	this.shape_821.setTransform(399.125,87.25);

	this.shape_822 = new cjs.Shape();
	this.shape_822.graphics.f("#000000").s().p("AgJAfQgDgDAAgGQAAgFADgEQAEgDAFAAQAGAAADADQAEAEAAAFQAAAGgEADQgDADgGAAQgFAAgEgDgAgJgMQgDgEAAgFQAAgGADgDQAEgDAFAAQAGAAADADQAEADAAAGQAAAFgEAEQgDADgGAAQgFAAgEgDg");
	this.shape_822.setTransform(390.05,88.075);

	this.shape_823 = new cjs.Shape();
	this.shape_823.graphics.f("#000000").s().p("AAMAqIgeg6IAAA6IgTAAIAAhTIAbAAIAeA6IAAg6IASAAIAABTg");
	this.shape_823.setTransform(383.425,87.175);

	this.shape_824 = new cjs.Shape();
	this.shape_824.graphics.f("#000000").s().p("AgJAqIAAhTIATAAIAABTg");
	this.shape_824.setTransform(376.75,87.175);

	this.shape_825 = new cjs.Shape();
	this.shape_825.graphics.f("#000000").s().p("AgJAqIAAhBIgaAAIAAgSIBHAAIAAASIgaAAIAABBg");
	this.shape_825.setTransform(370.75,87.175);

	this.shape_826 = new cjs.Shape();
	this.shape_826.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAADADQAEAEAAAEQAAAGgEADQgDADgGAAQgFAAgEgDg");
	this.shape_826.setTransform(361.5,90.3);

	this.shape_827 = new cjs.Shape();
	this.shape_827.graphics.f("#000000").s().p("AgMAkQgKgHgCgPIgLAAIACgKIAHAAIAAgEIAAgDIgJAAIACgKIAJAAQADgOAJgIQAKgIAOAAQAOAAAKAGIAAASQgKgHgMAAQgIAAgFADQgDADgDAHIAWAAIAAAKIgXAAIAAADIAAAEIAXAAIAAAKIgWAAQACAHAEADQAFADAIAAQAHAAAFgCIALgFIAAARIgLAFQgGACgIAAQgOAAgKgIg");
	this.shape_827.setTransform(355.35,87.175);

	this.shape_828 = new cjs.Shape();
	this.shape_828.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_828.setTransform(347.625,87.175);

	this.shape_829 = new cjs.Shape();
	this.shape_829.graphics.f("#000000").s().p("AgeArIAAgQIAZgVIAIgIIAEgHIABgFQABgGgEgCQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAHgDAGgCQAHgDAJAAQAJAAAHAEQAHADADAFQADAFAAAHQAAAHgCAGQgDAFgEAFIgMALIgKAJIAiAAIAAASg");
	this.shape_829.setTransform(340.45,87.1);

	this.shape_830 = new cjs.Shape();
	this.shape_830.graphics.f("#000000").s().p("AgMASIAGgjIATAAIgLAjg");
	this.shape_830.setTransform(334.8,91.625);

	this.shape_831 = new cjs.Shape();
	this.shape_831.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_831.setTransform(328.925,87.175);

	this.shape_832 = new cjs.Shape();
	this.shape_832.graphics.f("#000000").s().p("AgaAkQgKgGAAgMQAAgHAFgFQAFgGAKgBQgJgCgFgFQgDgEAAgHQAAgHAEgGQAEgFAIgCQAHgDAKAAQALAAAHADQAIACAEAFQAFAGAAAHQgBAHgEAEQgEAFgIACQAJABAFAGQAFAFAAAHQAAANgKAFQgKAHgRAAQgRAAgJgHgAgLAJQgDADAAAFQAAAFADADQAEADAHAAQAIAAAEgDQADgDAAgFQAAgFgDgDQgEgDgIAAQgHAAgEADgAgJgYQgEACAAAEQAAAJANAAQAOAAAAgJQAAgKgOAAQgGAAgDAEg");
	this.shape_832.setTransform(320.6,87.2);

	this.shape_833 = new cjs.Shape();
	this.shape_833.graphics.f("#000000").s().p("AgaAkQgKgGAAgMQAAgHAFgFQAFgGAJgBQgJgCgDgFQgFgEAAgHQABgHAEgGQAEgFAHgCQAJgDAJAAQAKAAAIADQAIACAEAFQAEAGABAHQAAAHgFAEQgEAFgIACQAJABAFAGQAFAFAAAHQAAANgKAFQgKAHgRAAQgRAAgJgHgAgLAJQgEADAAAFQAAAFAEADQADADAIAAQAIAAAEgDQADgDABgFQgBgFgDgDQgEgDgIAAQgIAAgDADgAgJgYQgEACAAAEQAAAJANAAQAOAAAAgJQAAgKgOAAQgHAAgCAEg");
	this.shape_833.setTransform(312.35,87.2);

	this.shape_834 = new cjs.Shape();
	this.shape_834.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAADADQAEAEAAAEQAAAGgEADQgDADgGAAQgFAAgEgDg");
	this.shape_834.setTransform(306.35,90.3);

	this.shape_835 = new cjs.Shape();
	this.shape_835.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_835.setTransform(300.825,87.175);

	this.shape_836 = new cjs.Shape();
	this.shape_836.graphics.f("#000000").s().p("AgeArIAAgQIAZgVIAIgIIAEgHIABgFQABgGgEgCQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAHgDAGgCQAHgDAJAAQAJAAAIAEQAGADADAFQADAFAAAHQAAAHgCAGQgDAFgEAFIgMALIgKAJIAiAAIAAASg");
	this.shape_836.setTransform(293.65,87.1);

	this.shape_837 = new cjs.Shape();
	this.shape_837.graphics.f("#000000").s().p("AgJAfQgDgDAAgGQAAgFADgEQAEgDAFAAQAGAAADADQAEAEAAAFQAAAGgEADQgDADgGAAQgFAAgEgDgAgJgMQgDgEAAgFQAAgGADgDQAEgDAFAAQAGAAADADQAEADAAAGQAAAFgEAEQgDADgGAAQgFAAgEgDg");
	this.shape_837.setTransform(284.75,88.075);

	this.shape_838 = new cjs.Shape();
	this.shape_838.graphics.f("#000000").s().p("AgQAhQgGgCgFgCIAAgQQAFADAGABQAHACAHABQALgBAAgFQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgBgFgBIgJgCQgKgBgEgFQgGgDAAgJQAAgKAIgGQAGgFAOAAQAHAAAHABIALADIgBARIgKgFQgHgBgGAAQgFAAgCABQgCACgBADQAAAAABABQAAAAAAABQAAAAABAAQAAABAAAAQACACAEAAIAIABQAIABAEADQAFACACACQACAEAAAGQAAALgIAGQgHAFgNAAQgJABgHgCg");
	this.shape_838.setTransform(279.6,88.1);

	this.shape_839 = new cjs.Shape();
	this.shape_839.graphics.f("#000000").s().p("AgRAfQgJgEgEgIQgEgIAAgLQAAgKAEgIQAFgIAIgDQAHgEAKAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgKAAgHgDgAgLgMQgDAFAAAHQgBAJAEAFQADAEAIAAQAIAAAEgEQAEgFgBgJQABgHgEgFQgDgFgJAAQgHAAgEAFg");
	this.shape_839.setTransform(272.35,88.1);

	this.shape_840 = new cjs.Shape();
	this.shape_840.graphics.f("#000000").s().p("AgbAhIAAgPIAggjIggAAIAAgPIA2AAIAAAPIggAjIAhAAIAAAPg");
	this.shape_840.setTransform(265.1,88.1);

	this.shape_841 = new cjs.Shape();
	this.shape_841.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAHgFQAFgEANAAIAKAAIADgBIABgDIAAgCQAAgDgDgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgBAHAAQAOAAAIAFQAHAHAAALIAAArIgSAAIAAgMQgGANgPAAQgJABgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAAEgBQADgCABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_841.setTransform(258.1,88.1);

	this.shape_842 = new cjs.Shape();
	this.shape_842.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_842.setTransform(252.975,86.825);

	this.shape_843 = new cjs.Shape();
	this.shape_843.graphics.f("#000000").s().p("AghAuIAAhZIASAAIAAAPQAFgRAQAAQAOAAAHAJQAIAIAAARQAAALgEAHQgEAIgGAEQgGAEgJAAQgPAAgFgNIAAAkgAgLgXQgDAEAAAIIAAABQAAAJADADQAFAFAGAAQAIAAAEgFQADgDAAgJQAAgSgPAAQgGAAgFAFg");
	this.shape_843.setTransform(247.25,89.225);

	this.shape_844 = new cjs.Shape();
	this.shape_844.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAGgFQAHgEALAAIALAAIAEgBIABgDIAAgCQgBgDgDgCQgDgCgGAAQgGAAgGACIgKAEIAAgSIAMgDQAGgBAIAAQAOAAAGAFQAIAHAAALIAAArIgSAAIAAgMQgFANgPAAQgKABgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQAEgCACgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_844.setTransform(236,88.1);

	this.shape_845 = new cjs.Shape();
	this.shape_845.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_845.setTransform(227.575,86.825);

	this.shape_846 = new cjs.Shape();
	this.shape_846.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAHgFQAFgEANAAIALAAIACgBIABgDIAAgCQAAgDgDgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgBAHAAQAOAAAIAFQAHAHAAALIAAArIgSAAIAAgMQgGANgPAAQgJABgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAAEgBQADgCABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_846.setTransform(222.1,88.1);

	this.shape_847 = new cjs.Shape();
	this.shape_847.graphics.f("#000000").s().p("AgJAkQgGgHgBgOIAAgXIgLAAIAAgPIAIAAIACgBIABgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_847.setTransform(215.5,87.225);

	this.shape_848 = new cjs.Shape();
	this.shape_848.graphics.f("#000000").s().p("AgRAfQgIgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAIgDQAHgEAKAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgKAAgHgDgAgLgMQgDAFAAAHQAAAJADAFQADAEAIAAQAIAAAEgEQAEgFgBgJQABgHgEgFQgDgFgJAAQgHAAgEAFg");
	this.shape_848.setTransform(208.45,88.1);

	this.shape_849 = new cjs.Shape();
	this.shape_849.graphics.f("#000000").s().p("AgJAkQgGgHAAgOIAAgXIgMAAIAAgPIAIAAIADgBIABgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHACADQADADAGAAQAIAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_849.setTransform(201.25,87.225);

	this.shape_850 = new cjs.Shape();
	this.shape_850.graphics.f("#000000").s().p("AgRAfQgIgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAIgDQAHgEAKAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgKAAgHgDgAgLgMQgDAFAAAHQAAAJADAFQADAEAIAAQAIAAAEgEQAEgFgBgJQABgHgEgFQgDgFgJAAQgHAAgEAFg");
	this.shape_850.setTransform(190.9,88.1);

	this.shape_851 = new cjs.Shape();
	this.shape_851.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDADgGAAQgLAAAAgMg");
	this.shape_851.setTransform(185.075,86.6);

	this.shape_852 = new cjs.Shape();
	this.shape_852.graphics.f("#000000").s().p("AgRAaQgKgJABgRQgBgQAKgIQAIgJAQAAQAGAAAFABIAJADIAAARQgIgFgKAAQgJAAgEAEQgEAFAAAIQAAASARAAQAFAAAFgCQAEgBAEgCIAAAQQgEADgEABQgFACgHgBQgQAAgIgIg");
	this.shape_852.setTransform(179.95,88.1);

	this.shape_853 = new cjs.Shape();
	this.shape_853.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgIAIgDQAHgEAJAAQAPAAAHAHQAIAIAAAPIAAAJIgrAAQAAAFACADQADADAEABQACACAHAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgIgBQgQAAgJgIgAAPgGQAAgOgNAAQgGABgDADQgDADgBAHIAaAAIAAAAg");
	this.shape_853.setTransform(173.15,88.1);

	this.shape_854 = new cjs.Shape();
	this.shape_854.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_854.setTransform(167.175,88.05);

	this.shape_855 = new cjs.Shape();
	this.shape_855.graphics.f("#000000").s().p("AghAqIAAhTIAhAAQASAAAIAHQAIAIAAAOQAAAKgEAFQgEAHgHADQgHAEgJAAIgQAAIAAAZgAgNAAIANAAQAHAAADgCQAEgEAAgGQAAgGgDgDQgEgDgHAAIgNAAg");
	this.shape_855.setTransform(160.475,87.175);

	this.shape_856 = new cjs.Shape();
	this.shape_856.graphics.f("#000000").s().p("AgIAJQgEgDAAgGQAAgEAEgEQACgDAGAAQAGAAAEADQADAEAAAEQAAAGgDADQgEADgGAAQgGAAgCgDg");
	this.shape_856.setTransform(151.05,90.3);

	this.shape_857 = new cjs.Shape();
	this.shape_857.graphics.f("#000000").s().p("AgMAkQgJgHgDgPIgMAAIADgKIAHAAIAAgEIAAgDIgKAAIADgKIAJAAQACgOAKgIQAKgIAOAAQAOAAAJAGIAAASQgJgHgMAAQgIAAgEADQgEADgCAHIAVAAIAAAKIgXAAIAAADIAAAEIAXAAIAAAKIgVAAQACAHADADQAFADAIAAQAHAAAFgCIALgFIAAARIgLAFQgGACgIAAQgPAAgJgIg");
	this.shape_857.setTransform(144.9,87.175);

	this.shape_858 = new cjs.Shape();
	this.shape_858.graphics.f("#000000").s().p("AgeArIAAgQIAZgVIAIgIIAEgHIABgFQAAgGgDgCQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAGgDAIgCQAHgDAIAAQAKAAAGAEQAHADADAFQAEAFAAAHQAAAHgDAGQgDAFgEAFIgNALIgJAJIAiAAIAAASg");
	this.shape_858.setTransform(137.25,87.1);

	this.shape_859 = new cjs.Shape();
	this.shape_859.graphics.f("#000000").s().p("AgbAkQgJgGAAgMQAAgHAFgFQAFgGAJgBQgIgCgEgFQgEgEgBgHQAAgHAFgGQAEgFAHgCQAJgDAJAAQALAAAHADQAIACAEAFQAEAGAAAHQAAAHgDAEQgFAFgJACQAKABAFAGQAFAFAAAHQAAANgKAFQgKAHgRAAQgRAAgKgHgAgLAJQgDADAAAFQAAAFADADQAEADAHAAQAIAAAEgDQADgDAAgFQAAgFgDgDQgEgDgIAAQgHAAgEADgAgKgYQgDACAAAEQAAAJANAAQAOAAAAgJQAAgKgOAAQgHAAgDAEg");
	this.shape_859.setTransform(129.4,87.2);

	this.shape_860 = new cjs.Shape();
	this.shape_860.graphics.f("#000000").s().p("AgMASIAFgjIAVAAIgNAjg");
	this.shape_860.setTransform(123.35,91.625);

	this.shape_861 = new cjs.Shape();
	this.shape_861.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_861.setTransform(118.075,87.175);

	this.shape_862 = new cjs.Shape();
	this.shape_862.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_862.setTransform(110.825,87.175);

	this.shape_863 = new cjs.Shape();
	this.shape_863.graphics.f("#000000").s().p("AgaAkQgKgGAAgMQAAgHAFgFQAFgGAJgBQgJgCgDgFQgFgEAAgHQABgHAEgGQAEgFAIgCQAIgDAJAAQAKAAAIADQAIACAEAFQAEAGABAHQAAAHgFAEQgEAFgIACQAJABAFAGQAFAFAAAHQAAANgKAFQgKAHgRAAQgRAAgJgHgAgLAJQgEADAAAFQAAAFAEADQADADAIAAQAIAAAEgDQADgDABgFQgBgFgDgDQgEgDgIAAQgIAAgDADgAgJgYQgEACAAAEQAAAJANAAQAOAAAAgJQAAgKgOAAQgHAAgCAEg");
	this.shape_863.setTransform(103.1,87.2);

	this.shape_864 = new cjs.Shape();
	this.shape_864.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAADADQAEAEAAAEQAAAGgEADQgDADgGAAQgFAAgEgDg");
	this.shape_864.setTransform(97.1,90.3);

	this.shape_865 = new cjs.Shape();
	this.shape_865.graphics.f("#000000").s().p("AgeArIAAgQIAYgVIAIgIIAFgHIACgFQgBgGgDgCQgDgCgGAAQgGAAgHACQgHACgGAEIAAgSQAGgDAIgCQAGgDAKAAQAIAAAIAEQAGADAEAFQACAFAAAHQAAAHgCAGQgCAFgFAFIgMALIgKAJIAiAAIAAASg");
	this.shape_865.setTransform(91.65,87.1);

	this.shape_866 = new cjs.Shape();
	this.shape_866.graphics.f("#000000").s().p("AgeArIAAgQIAZgVIAHgIIAFgHIACgFQAAgGgEgCQgDgCgGAAQgGAAgHACQgHACgGAEIAAgSQAGgDAIgCQAGgDAKAAQAIAAAHAEQAHADAEAFQADAFAAAHQgBAHgCAGQgCAFgFAFIgNALIgJAJIAiAAIAAASg");
	this.shape_866.setTransform(84.35,87.1);

	this.shape_867 = new cjs.Shape();
	this.shape_867.graphics.f("#000000").s().p("AgIAfQgEgDAAgGQAAgFAEgEQACgDAGAAQAGAAAEADQADAEAAAFQAAAGgDADQgEADgGAAQgGAAgCgDgAgIgMQgEgEAAgFQAAgGAEgDQACgDAGAAQAGAAAEADQADADAAAGQAAAFgDAEQgEADgGAAQgGAAgCgDg");
	this.shape_867.setTransform(75.45,88.075);

	this.shape_868 = new cjs.Shape();
	this.shape_868.graphics.f("#000000").s().p("AgRAfQgIgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAIgDQAIgEAJAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgJAAgIgDgAgKgMQgFAFAAAHQABAJADAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgDAFg");
	this.shape_868.setTransform(69.6,88.1);

	this.shape_869 = new cjs.Shape();
	this.shape_869.graphics.f("#000000").s().p("AgaAmQgIgIAAgRQAAgLAEgIQADgHAHgEQAGgEAIAAQAQAAAFANIAAglIAUAAIAABaIgTAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAHAAAEgEQAEgFAAgIIAAgBQAAgIgEgEQgDgFgIAAQgOAAAAARg");
	this.shape_869.setTransform(61.35,86.9);

	this.shape_870 = new cjs.Shape();
	this.shape_870.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAHgFQAFgEANAAIALAAIACgBIABgDIAAgCQAAgDgDgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgBAHAAQAOAAAIAFQAHAHAAALIAAArIgSAAIAAgMQgGANgPAAQgJABgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAAEgBQADgCABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_870.setTransform(53.8,88.1);

	this.shape_871 = new cjs.Shape();
	this.shape_871.graphics.f("#000000").s().p("AgaAmQgIgIAAgRQAAgLAEgIQAEgHAGgEQAGgEAJAAQAPAAAFANIAAglIATAAIAABaIgSAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAHAAAFgEQADgFAAgIIAAgBQAAgIgDgEQgEgFgIAAQgOAAAAARg");
	this.shape_871.setTransform(46.15,86.9);

	this.shape_872 = new cjs.Shape();
	this.shape_872.graphics.f("#000000").s().p("AgZAcQgFgGAAgMIAAgrIATAAIAAAlQAAAHADADQADADAFAAQAFAAAEgEQADgFAAgIIAAghIAUAAIAABBIgUAAIAAgOQgFAQgPAAQgKAAgHgGg");
	this.shape_872.setTransform(38.3,88.175);

	this.shape_873 = new cjs.Shape();
	this.shape_873.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAHgDQAJgEAIAAQAPAAAIAHQAHAIAAAPIAAAJIgsAAQABAFACADQACADAEABQAEACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAOgGQAAgOgMAAQgFABgEADQgDADgCAHIAaAAIAAAAg");
	this.shape_873.setTransform(30.9,88.1);

	this.shape_874 = new cjs.Shape();
	this.shape_874.graphics.f("#000000").s().p("AgaAmQgIgIABgRQgBgLAEgIQADgHAHgEQAGgEAJAAQAOAAAGANIAAglIATAAIAABaIgSAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAHAAAFgEQADgFAAgIIAAgBQAAgIgDgEQgEgFgIAAQgOAAAAARg");
	this.shape_874.setTransform(22.95,86.9);

	this.shape_875 = new cjs.Shape();
	this.shape_875.graphics.f("#000000").s().p("AAVAqIgGgRIgfAAIgFARIgUAAIAdhTIAbAAIAbBTgAAKAIIgKgiIgKAiIAUAAg");
	this.shape_875.setTransform(14.575,87.175);

	this.shape_876 = new cjs.Shape();
	this.shape_876.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_876.setTransform(935.875,68.825);

	this.shape_877 = new cjs.Shape();
	this.shape_877.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAHgFQAFgEANAAIALAAIACgBIABgDIAAgCQAAgDgDgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgBAHAAQAOAAAIAFQAHAHAAALIAAArIgSAAIAAgMQgGANgPAAQgJABgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAAEgBQADgCABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_877.setTransform(930.4,70.1);

	this.shape_878 = new cjs.Shape();
	this.shape_878.graphics.f("#000000").s().p("AgJAkQgGgHgBgOIAAgXIgLAAIAAgPIAIAAIADgBIAAgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_878.setTransform(923.8,69.225);

	this.shape_879 = new cjs.Shape();
	this.shape_879.graphics.f("#000000").s().p("AgRAfQgIgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAIgDQAHgEAKAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgKAAgHgDgAgLgMQgDAFAAAHQgBAJAEAFQADAEAIAAQAIAAAEgEQAEgFgBgJQABgHgEgFQgDgFgJAAQgHAAgEAFg");
	this.shape_879.setTransform(916.75,70.1);

	this.shape_880 = new cjs.Shape();
	this.shape_880.graphics.f("#000000").s().p("AgJAqIAAhBIgbAAIAAgSIBIAAIAAASIgaAAIAABBg");
	this.shape_880.setTransform(908.7,69.175);

	this.shape_881 = new cjs.Shape();
	this.shape_881.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAHgDQAJgEAIAAQAPAAAIAHQAHAIAAAPIAAAJIgrAAQAAAFACADQACADAFABQADACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAPgGQAAgOgOAAQgEABgEADQgEADAAAHIAaAAIAAAAg");
	this.shape_881.setTransform(897.7,70.1);

	this.shape_882 = new cjs.Shape();
	this.shape_882.graphics.f("#000000").s().p("AgJAkQgHgHAAgOIAAgXIgLAAIAAgPIAIAAIACgBIABgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_882.setTransform(890.8,69.225);

	this.shape_883 = new cjs.Shape();
	this.shape_883.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_883.setTransform(885.375,70.05);

	this.shape_884 = new cjs.Shape();
	this.shape_884.graphics.f("#000000").s().p("AgSAfQgHgEgEgIQgFgIAAgLQAAgKAFgIQAEgIAHgDQAJgEAJAAQALAAAHAEQAJADAEAIQAEAIAAAKQAAALgEAIQgEAIgJAEQgHADgLAAQgJAAgJgDgAgKgMQgEAFgBAHQAAAJAEAFQAEAEAHAAQAIAAAEgEQADgFABgJQgBgHgDgFQgEgFgIAAQgHAAgDAFg");
	this.shape_884.setTransform(878.55,70.1);

	this.shape_885 = new cjs.Shape();
	this.shape_885.graphics.f("#000000").s().p("AgiAuIAAhZIATAAIAAAPQAFgRAQAAQAOAAAHAJQAIAIAAARQgBALgDAHQgDAIgHAEQgGAEgIAAQgQAAgFgNIAAAkgAgKgXQgEAEAAAIIAAABQAAAJAEADQAEAFAGAAQAIAAADgFQAEgDAAgJQAAgSgPAAQgGAAgEAFg");
	this.shape_885.setTransform(870.7,71.225);

	this.shape_886 = new cjs.Shape();
	this.shape_886.graphics.f("#000000").s().p("AAgAiIAAglQgBgHgCgDQgCgDgFAAQgHAAgCAEQgEAFAAAIIAAAhIgSAAIAAglQAAgHgCgDQgDgDgFAAQgGAAgDAEQgCAFAAAIIAAAhIgUAAIAAhBIATAAIAAAOQACgIAGgEQAFgEAIAAQAIAAADAEQAGAEABAIQADgIAFgEQAHgEAHAAQAJAAAGAGQAGAGAAAMIAAArg");
	this.shape_886.setTransform(860.65,70.025);

	this.shape_887 = new cjs.Shape();
	this.shape_887.graphics.f("#000000").s().p("AgJAqIAAhTIATAAIAABTg");
	this.shape_887.setTransform(852.75,69.175);

	this.shape_888 = new cjs.Shape();
	this.shape_888.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAADADQAEAEAAAEQAAAGgEADQgDADgGAAQgFAAgEgDg");
	this.shape_888.setTransform(845.7,72.3);

	this.shape_889 = new cjs.Shape();
	this.shape_889.graphics.f("#000000").s().p("AgMAkQgKgHgCgPIgLAAIACgKIAHAAIAAgEIAAgDIgJAAIACgKIAJAAQADgOAJgIQAKgIAOAAQAOAAAKAGIAAASQgKgHgMAAQgIAAgEADQgEADgDAHIAWAAIAAAKIgXAAIAAADIAAAEIAXAAIAAAKIgWAAQACAHAEADQAFADAIAAQAHAAAFgCIALgFIAAARIgLAFQgGACgIAAQgOAAgKgIg");
	this.shape_889.setTransform(839.55,69.175);

	this.shape_890 = new cjs.Shape();
	this.shape_890.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_890.setTransform(831.825,69.175);

	this.shape_891 = new cjs.Shape();
	this.shape_891.graphics.f("#000000").s().p("AgeArIAAgQIAZgVIAIgIIAEgHIABgFQABgGgEgCQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAHgDAGgCQAHgDAJAAQAJAAAIAEQAGADADAFQADAFAAAHQAAAHgCAGQgDAFgEAFIgMALIgKAJIAiAAIAAASg");
	this.shape_891.setTransform(824.65,69.1);

	this.shape_892 = new cjs.Shape();
	this.shape_892.graphics.f("#000000").s().p("AgMASIAGgjIAUAAIgMAjg");
	this.shape_892.setTransform(819,73.625);

	this.shape_893 = new cjs.Shape();
	this.shape_893.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_893.setTransform(813.125,69.175);

	this.shape_894 = new cjs.Shape();
	this.shape_894.graphics.f("#000000").s().p("AgRAqIgOgFIACgSIANAFIANABQAHAAAEgDQAEgCAAgHQAAgGgGgCQgFgCgJgBIgKABIgKABIAAguIA4AAIAAARIgmAAIAAAPIAKgBQAQAAAIAGQAIAGAAAMQAAAKgEAGQgEAHgIADQgIAEgKAAIgPgBg");
	this.shape_894.setTransform(805.275,69.25);

	this.shape_895 = new cjs.Shape();
	this.shape_895.graphics.f("#000000").s().p("AACAqIAAg9IgWADIAAgSIApgHIAABTg");
	this.shape_895.setTransform(798.25,69.175);

	this.shape_896 = new cjs.Shape();
	this.shape_896.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAAEADQADAEAAAEQAAAGgDADQgEADgGAAQgFAAgEgDg");
	this.shape_896.setTransform(793.8,72.3);

	this.shape_897 = new cjs.Shape();
	this.shape_897.graphics.f("#000000").s().p("AAEAqIAAgQIgrAAIAAgPIAmg0IAZAAIAAAzIAQAAIAAAQIgQAAIAAAQgAgSAKIAWAAIAAghg");
	this.shape_897.setTransform(787.5,69.175);

	this.shape_898 = new cjs.Shape();
	this.shape_898.graphics.f("#000000").s().p("AgIAfQgEgDAAgGQAAgFAEgEQACgDAGAAQAGAAAEADQADAEAAAFQAAAGgDADQgEADgGAAQgGAAgCgDgAgIgMQgEgEAAgFQAAgGAEgDQACgDAGAAQAGAAAEADQADADAAAGQAAAFgDAEQgEADgGAAQgGAAgCgDg");
	this.shape_898.setTransform(777.9,70.075);

	this.shape_899 = new cjs.Shape();
	this.shape_899.graphics.f("#000000").s().p("AgRAfQgIgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAIgDQAIgEAJAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgJAAgIgDgAgKgMQgFAFAAAHQABAJADAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgDAFg");
	this.shape_899.setTransform(772.05,70.1);

	this.shape_900 = new cjs.Shape();
	this.shape_900.graphics.f("#000000").s().p("AgJAkQgGgHAAgOIAAgXIgMAAIAAgPIAIAAIADgBIABgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHACADQAEADAFAAQAIAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_900.setTransform(764.85,69.225);

	this.shape_901 = new cjs.Shape();
	this.shape_901.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDADgGAAQgLAAAAgMg");
	this.shape_901.setTransform(759.875,68.6);

	this.shape_902 = new cjs.Shape();
	this.shape_902.graphics.f("#000000").s().p("AgaAmQgHgIgBgRQABgLADgIQAEgHAGgEQAGgEAIAAQAQAAAFANIAAglIAUAAIAABaIgTAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAIAAADgEQAEgFAAgIIAAgBQAAgIgEgEQgDgFgIAAQgOAAAAARg");
	this.shape_902.setTransform(753.7,68.9);

	this.shape_903 = new cjs.Shape();
	this.shape_903.graphics.f("#000000").s().p("AgWAmQgJgJAAgSQAAgKAFgHQAEgIAIgDQAHgEAJAAQAPAAAHAHQAIAIAAAOIAAAKIgsAAQABAFACADQADADADABQADACAHAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAOAFQABgNgNAAQgGABgDADQgEADgBAGIAaAAIAAAAgAgIgcIAJgRIAXAAIgPARg");
	this.shape_903.setTransform(746.2,68.9);

	this.shape_904 = new cjs.Shape();
	this.shape_904.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_904.setTransform(740.225,70.05);

	this.shape_905 = new cjs.Shape();
	this.shape_905.graphics.f("#000000").s().p("AgSAaQgJgJAAgRQAAgQAJgIQAJgJAQAAQAFAAAFABIAJADIAAARQgHgFgLAAQgIAAgDAEQgFAFAAAIQAAASAQAAQAHAAAEgCQAEgBAEgCIAAAQQgDADgGABQgFACgGgBQgQAAgJgIg");
	this.shape_905.setTransform(734.1,70.1);

	this.shape_906 = new cjs.Shape();
	this.shape_906.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_906.setTransform(725.825,68.825);

	this.shape_907 = new cjs.Shape();
	this.shape_907.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAHgDQAJgEAIAAQAOAAAJAHQAHAIAAAPIAAAJIgrAAQAAAFACADQACADAFABQADACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAPgGQAAgOgOAAQgEABgEADQgEADAAAHIAaAAIAAAAg");
	this.shape_907.setTransform(720.4,70.1);

	this.shape_908 = new cjs.Shape();
	this.shape_908.graphics.f("#000000").s().p("AgaAmQgHgIAAgRQgBgLAEgIQADgHAHgEQAGgEAJAAQAOAAAGANIAAglIATAAIAABaIgSAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAIAAAEgEQADgFAAgIIAAgBQAAgIgDgEQgEgFgIAAQgOAAAAARg");
	this.shape_908.setTransform(712.45,68.9);

	this.shape_909 = new cjs.Shape();
	this.shape_909.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_909.setTransform(703.475,68.825);

	this.shape_910 = new cjs.Shape();
	this.shape_910.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgJAGgFQAHgEALAAIAMAAIACgBIABgDIAAgCQABgDgEgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgBAHAAQAOAAAIAFQAHAHAAALIAAArIgTAAIAAgMQgFANgPAAQgJABgGgGgAgJAIQgCACAAAEQAAADACACQACACAFAAQACAAADgBQAEgCACgDQABgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_910.setTransform(698,70.1);

	this.shape_911 = new cjs.Shape();
	this.shape_911.graphics.f("#000000").s().p("AgJAkQgGgHAAgOIAAgXIgMAAIAAgPIAIAAIADgBIABgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHACADQAEADAFAAQAIAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_911.setTransform(691.4,69.225);

	this.shape_912 = new cjs.Shape();
	this.shape_912.graphics.f("#000000").s().p("AgSAfQgHgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAHgDQAJgEAJAAQALAAAHAEQAJADAEAIQAEAIAAAKQAAALgEAIQgEAIgJAEQgHADgLAAQgJAAgJgDgAgLgMQgDAFAAAHQgBAJAEAFQADAEAIAAQAIAAAEgEQADgFAAgJQAAgHgDgFQgDgFgJAAQgHAAgEAFg");
	this.shape_912.setTransform(684.35,70.1);

	this.shape_913 = new cjs.Shape();
	this.shape_913.graphics.f("#000000").s().p("AgJAkQgHgHABgOIAAgXIgMAAIAAgPIAIAAIACgBIACgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQADADAGAAQAHAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_913.setTransform(677.15,69.225);

	this.shape_914 = new cjs.Shape();
	this.shape_914.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgIAIgDQAHgEAJAAQAOAAAJAHQAHAIAAAPIAAAJIgrAAQAAAFACADQADADAEABQACACAHAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgIgBQgQAAgJgIgAAPgGQgBgOgNAAQgFABgDADQgDADgBAHIAaAAIAAAAg");
	this.shape_914.setTransform(667.15,70.1);

	this.shape_915 = new cjs.Shape();
	this.shape_915.graphics.f("#000000").s().p("AgJAkQgHgHABgOIAAgXIgMAAIAAgPIAIAAIADgBIABgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHACADQADADAGAAQAIAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_915.setTransform(660.25,69.225);

	this.shape_916 = new cjs.Shape();
	this.shape_916.graphics.f("#000000").s().p("AgQAhQgGgCgEgCIAAgQQAEADAGABQAHACAHABQALgBAAgFQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgBgFgBIgJgCQgJgBgGgFQgEgDAAgJQgBgKAIgGQAGgFAOAAQAIAAAGABIALADIgBARIgKgFQgHgBgGAAQgFAAgCABQgCACAAADQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQACACAEAAIAIABQAIABAEADQAFACACACQADAEgBAGQABALgJAGQgHAFgNAAQgIABgIgCg");
	this.shape_916.setTransform(653.9,70.1);

	this.shape_917 = new cjs.Shape();
	this.shape_917.graphics.f("#000000").s().p("AgSAfQgHgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAHgDQAIgEAKAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgKAAgIgDgAgLgMQgDAFAAAHQgBAJAEAFQADAEAIAAQAIAAAEgEQAEgFgBgJQABgHgEgFQgDgFgJAAQgHAAgEAFg");
	this.shape_917.setTransform(646.65,70.1);

	this.shape_918 = new cjs.Shape();
	this.shape_918.graphics.f("#000000").s().p("AgNAnQgIgFgFgKQgGgKAAgOQAAgNAGgKQAFgJAIgGQAJgFAMAAQANAAAKAGIAAATQgJgHgLAAQgLAAgFAHQgGAGAAAMQAAAOAGAGQAFAGALAAIAIgBQAEgBADgCIAGgEIAAATIgKAFQgGACgIAAQgMAAgJgFg");
	this.shape_918.setTransform(638.85,69.175);

	this.shape_919 = new cjs.Shape();
	this.shape_919.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAADADQAEAEAAAEQAAAGgEADQgDADgGAAQgFAAgEgDg");
	this.shape_919.setTransform(629.9,72.3);

	this.shape_920 = new cjs.Shape();
	this.shape_920.graphics.f("#000000").s().p("AgMAkQgKgHgDgPIgKAAIACgKIAHAAIAAgEIAAgDIgJAAIACgKIAIAAQADgOALgIQAJgIAOAAQANAAAKAGIAAASQgJgHgMAAQgHAAgGADQgDADgDAHIAWAAIAAAKIgXAAIgBADIABAEIAXAAIAAAKIgWAAQADAHADADQAFADAIAAQAHAAAFgCIAKgFIAAARIgKAFQgGACgIAAQgOAAgKgIg");
	this.shape_920.setTransform(623.75,69.175);

	this.shape_921 = new cjs.Shape();
	this.shape_921.graphics.f("#000000").s().p("AgRAqIgNgEIABgSQAGADAHABIANACQAGAAAEgDQAEgCAAgFQAAgIgNAAIgOAAIAAgQIANAAQAFAAAEgCQAEgCAAgEQgBgEgEgDQgEgCgGAAQgOAAgKAFIAAgSQALgFAPAAQAKAAAHADQAJADADAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAJABAFAFQAEAFAAAHQgBAIgDAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_921.setTransform(616.05,69.175);

	this.shape_922 = new cjs.Shape();
	this.shape_922.graphics.f("#000000").s().p("AgRAqIgOgFIACgSIANAFIANABQAHAAAEgDQAEgCAAgHQAAgGgGgCQgFgCgJgBIgKABIgKABIAAguIA4AAIAAARIgmAAIAAAPIAKgBQAQAAAIAGQAIAGAAAMQAAAKgEAGQgEAHgIADQgIAEgKAAIgPgBg");
	this.shape_922.setTransform(608.625,69.25);

	this.shape_923 = new cjs.Shape();
	this.shape_923.graphics.f("#000000").s().p("AgMASIAFgjIAVAAIgNAjg");
	this.shape_923.setTransform(602.8,73.625);

	this.shape_924 = new cjs.Shape();
	this.shape_924.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_924.setTransform(596.925,69.175);

	this.shape_925 = new cjs.Shape();
	this.shape_925.graphics.f("#000000").s().p("AACAqIAAg9IgXADIAAgSIAqgHIAABTg");
	this.shape_925.setTransform(589.6,69.175);

	this.shape_926 = new cjs.Shape();
	this.shape_926.graphics.f("#000000").s().p("AAEAqIAAgQIgrAAIAAgPIAmg0IAZAAIAAAzIAQAAIAAAQIgQAAIAAAQgAgSAKIAWAAIAAghg");
	this.shape_926.setTransform(582.6,69.175);

	this.shape_927 = new cjs.Shape();
	this.shape_927.graphics.f("#000000").s().p("AgIAJQgEgDAAgGQAAgEAEgEQACgDAGAAQAGAAAEADQADAEAAAEQAAAGgDADQgEADgGAAQgGAAgCgDg");
	this.shape_927.setTransform(576.3,72.3);

	this.shape_928 = new cjs.Shape();
	this.shape_928.graphics.f("#000000").s().p("AgRAqIgOgEIACgSQAGADAHABIANACQAGAAAFgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIANAAQAGAAADgCQAEgCAAgEQAAgEgFgDQgDgCgHAAQgNAAgLAFIAAgSQALgFAOAAQALAAAHADQAJADADAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAJABAFAFQADAFAAAHQABAIgEAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_928.setTransform(570.8,69.175);

	this.shape_929 = new cjs.Shape();
	this.shape_929.graphics.f("#000000").s().p("AgJAfQgDgDAAgGQAAgFADgEQADgDAGAAQAGAAADADQAEAEAAAFQAAAGgEADQgDADgGAAQgGAAgDgDgAgJgMQgDgEAAgFQAAgGADgDQADgDAGAAQAGAAADADQAEADAAAGQAAAFgEAEQgDADgGAAQgGAAgDgDg");
	this.shape_929.setTransform(561.85,70.075);

	this.shape_930 = new cjs.Shape();
	this.shape_930.graphics.f("#000000").s().p("AgQAhQgGgCgEgCIAAgQQAEADAGABQAHACAHABQALgBAAgFQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgBgFgBIgJgCQgJgBgGgFQgEgDAAgJQgBgKAIgGQAGgFAOAAQAIAAAGABIALADIgBARIgKgFQgHgBgGAAQgFAAgCABQgCACgBADQAAAAABABQAAAAAAABQAAAAABAAQAAABAAAAQACACAEAAIAIABQAIABAEADQAFACACACQADAEgBAGQABALgJAGQgHAFgNAAQgIABgIgCg");
	this.shape_930.setTransform(556.7,70.1);

	this.shape_931 = new cjs.Shape();
	this.shape_931.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgIAIgDQAHgEAJAAQAPAAAHAHQAIAIAAAPIAAAJIgsAAQABAFACADQADADAEABQACACAHAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgIgBQgQAAgJgIgAAPgGQgBgOgMAAQgGABgDADQgDADgCAHIAbAAIAAAAg");
	this.shape_931.setTransform(549.8,70.1);

	this.shape_932 = new cjs.Shape();
	this.shape_932.graphics.f("#000000").s().p("AgPAhQgHgCgEgCIAAgQQAEADAHABQAGACAHABQAMgBAAgFQAAgBgBgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgBgEgBIgJgCQgLgBgFgFQgEgDAAgJQAAgKAGgGQAIgFANAAQAHAAAHABIALADIgBARIgLgFQgFgBgHAAQgEAAgDABQgCACAAADQAAAAAAABQAAAAAAABQAAAAABAAQAAABABAAQABACAEAAIAIABQAIABAFADQAEACACACQACAEABAGQAAALgIAGQgIAFgNAAQgJABgGgCg");
	this.shape_932.setTransform(542.9,70.1);

	this.shape_933 = new cjs.Shape();
	this.shape_933.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgIAHgDQAJgEAIAAQAOAAAJAHQAHAIAAAPIAAAJIgrAAQAAAFACADQACADAFABQADACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgJgIgAAPgGQAAgOgOAAQgEABgEADQgEADAAAHIAaAAIAAAAg");
	this.shape_933.setTransform(536,70.1);

	this.shape_934 = new cjs.Shape();
	this.shape_934.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_934.setTransform(530.025,70.05);

	this.shape_935 = new cjs.Shape();
	this.shape_935.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAIgDQAIgEAIAAQAPAAAHAHQAIAIAAAPIAAAJIgsAAQABAFACADQACADAEABQAEACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAOgGQAAgOgMAAQgFABgEADQgEADgBAHIAaAAIAAAAg");
	this.shape_935.setTransform(523.55,70.1);

	this.shape_936 = new cjs.Shape();
	this.shape_936.graphics.f("#000000").s().p("AgJAkQgGgHgBgOIAAgXIgLAAIAAgPIAIAAIACgBIABgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_936.setTransform(516.65,69.225);

	this.shape_937 = new cjs.Shape();
	this.shape_937.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_937.setTransform(509.775,70.025);

	this.shape_938 = new cjs.Shape();
	this.shape_938.graphics.f("#000000").s().p("AgJAqIAAhTIATAAIAABTg");
	this.shape_938.setTransform(503.85,69.175);

	this.shape_939 = new cjs.Shape();
	this.shape_939.graphics.f("#000000").s().p("AgJAJQgDgDAAgGQAAgEADgEQAEgDAFAAQAGAAAEADQADAEAAAEQAAAGgDADQgEADgGAAQgFAAgEgDg");
	this.shape_939.setTransform(496.8,72.3);

	this.shape_940 = new cjs.Shape();
	this.shape_940.graphics.f("#000000").s().p("AgMAkQgJgHgEgPIgLAAIADgKIAHAAIAAgEIAAgDIgKAAIADgKIAIAAQAEgOAKgIQAJgIAOAAQANAAAKAGIAAASQgJgHgMAAQgHAAgGADQgDADgCAHIAVAAIAAAKIgXAAIgBADIABAEIAXAAIAAAKIgVAAQABAHAEADQAFADAIAAQAHAAAFgCIAKgFIAAARIgKAFQgGACgIAAQgOAAgKgIg");
	this.shape_940.setTransform(490.65,69.175);

	this.shape_941 = new cjs.Shape();
	this.shape_941.graphics.f("#000000").s().p("AAEAqIAAgQIgrAAIAAgPIAmg0IAZAAIAAAzIAQAAIAAAQIgQAAIAAAQgAgSAKIAWAAIAAghg");
	this.shape_941.setTransform(482.15,69.175);

	this.shape_942 = new cjs.Shape();
	this.shape_942.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_942.setTransform(474.075,69.175);

	this.shape_943 = new cjs.Shape();
	this.shape_943.graphics.f("#000000").s().p("AgNASIAHgjIATAAIgLAjg");
	this.shape_943.setTransform(468.55,73.625);

	this.shape_944 = new cjs.Shape();
	this.shape_944.graphics.f("#000000").s().p("AgcAnIAAgSQAFADAFACIAMABQAKgBAGgGQAGgHAAgLQgDAFgGADQgGAEgGgBQgJABgHgEQgHgDgDgGQgEgGAAgIQAAgIAEgHQAEgHAIgEQAHgDAKAAQARgBAKAKQALAJAAAXQAAAMgFALQgEAKgJAGQgJAGgNAAQgPAAgJgFgAgLgXQgEADAAAHQAAAGAEADQADAEAIAAQAHAAAEgEQAEgDAAgGQAAgGgEgEQgEgDgHAAQgHgBgEAEg");
	this.shape_944.setTransform(462.775,69.15);

	this.shape_945 = new cjs.Shape();
	this.shape_945.graphics.f("#000000").s().p("AgRAqIgNgEIABgSQAGADAHABIANACQAHAAAEgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIAOAAQAEAAAEgCQAEgCgBgEQAAgEgDgDQgFgCgHAAQgNAAgKAFIAAgSQALgFAPAAQAKAAAIADQAHADAEAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAKABADAFQAFAFAAAHQAAAIgEAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_945.setTransform(455.1,69.175);

	this.shape_946 = new cjs.Shape();
	this.shape_946.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_946.setTransform(447.675,69.175);

	this.shape_947 = new cjs.Shape();
	this.shape_947.graphics.f("#000000").s().p("AgJAfQgDgDAAgGQAAgFADgEQAEgDAFAAQAGAAADADQAEAEAAAFQAAAGgEADQgDADgGAAQgFAAgEgDgAgJgMQgDgEAAgFQAAgGADgDQAEgDAFAAQAGAAADADQAEADAAAGQAAAFgEAEQgDADgGAAQgFAAgEgDg");
	this.shape_947.setTransform(438.9,70.075);

	this.shape_948 = new cjs.Shape();
	this.shape_948.graphics.f("#000000").s().p("AgUAwQAMgJAFgMQAFgMgBgPQABgOgFgMQgFgMgMgJIAJgLQAPAKAJAPQAIAPAAASQAAATgIAPQgJAPgPAKg");
	this.shape_948.setTransform(434.1,69.675);

	this.shape_949 = new cjs.Shape();
	this.shape_949.graphics.f("#000000").s().p("AAXApQgFgDgDgFQgCgFAAgHQAAgGACgGQADgFAFgDQAGgCAIAAQAIAAAFACQAGADACAFQADAGAAAGQAAAGgDAGQgCAFgGADQgFADgIAAQgIAAgGgDgAAfAOQgCACAAAFQAAAFACACQACACAEAAQADAAADgCQACgCAAgFQAAgFgCgCQgDgDgDAAQgEAAgCADgAgmAqIAggsIAWgnIAXAAIggAtIgXAmgAgxAAQgGgDgDgFQgDgFABgHQgBgGADgFQADgGAGgDQAFgDAIAAQAIAAAFADQAGADADAGQACAFAAAGQAAAHgCAFQgDAFgGADQgFACgIAAQgIAAgFgCgAgqgbQgCADAAAEQAAAFACACQACADAEAAQADAAADgDQACgCAAgFQAAgEgCgDQgDgCgDAAQgEAAgCACg");
	this.shape_949.setTransform(425.35,69.175);

	this.shape_950 = new cjs.Shape();
	this.shape_950.graphics.f("#000000").s().p("AgRAqIgOgFIACgSIANAFIANABQAHAAAEgDQAEgCAAgHQAAgGgGgCQgFgCgJgBIgKABIgKABIAAguIA4AAIAAARIgmAAIAAAPIAKgBQAQAAAIAGQAIAGAAAMQAAAKgEAGQgEAHgIADQgIAEgKAAIgPgBg");
	this.shape_950.setTransform(415.125,69.25);

	this.shape_951 = new cjs.Shape();
	this.shape_951.graphics.f("#000000").s().p("AgcAnIAAgSQAFADAFACIAMABQAKgBAGgGQAGgHAAgLQgDAFgGADQgGAEgGgBQgJABgHgEQgHgDgDgGQgEgGAAgIQAAgIAEgHQAEgHAIgEQAHgDAKAAQARgBAKAKQALAJAAAXQAAAMgFALQgEAKgJAGQgJAGgNAAQgPAAgJgFgAgLgXQgEADAAAHQAAAGAEADQADAEAIAAQAHAAAEgEQAEgDAAgGQAAgGgEgEQgEgDgHAAQgHgBgEAEg");
	this.shape_951.setTransform(407.075,69.15);

	this.shape_952 = new cjs.Shape();
	this.shape_952.graphics.f("#000000").s().p("AgMASIAFgjIAVAAIgNAjg");
	this.shape_952.setTransform(401.1,73.625);

	this.shape_953 = new cjs.Shape();
	this.shape_953.graphics.f("#000000").s().p("AgRAqIgOgEIACgSQAGADAHABIANACQAGAAAFgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIANAAQAGAAADgCQADgCABgEQAAgEgFgDQgDgCgIAAQgMAAgLAFIAAgSQALgFAOAAQALAAAHADQAJADADAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAKABAEAFQADAFAAAHQABAIgEAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_953.setTransform(395.85,69.175);

	this.shape_954 = new cjs.Shape();
	this.shape_954.graphics.f("#000000").s().p("AgMAiQgIgPAAgTQAAgSAIgPQAIgPAQgKIAJALQgMAJgFAMQgEAMAAAOQgBAPAFAMQAFAMAMAJIgJALQgQgKgIgPg");
	this.shape_954.setTransform(389.875,69.675);

	this.shape_955 = new cjs.Shape();
	this.shape_955.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAGgFQAHgEALAAIALAAIAEgBIABgDIAAgCQgBgDgDgCQgDgCgGAAQgGAAgGACIgKAEIAAgSIAMgDQAGgBAIAAQAOAAAGAFQAIAHAAALIAAArIgSAAIAAgMQgFANgPAAQgKABgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQAEgCACgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_955.setTransform(380,70.1);

	this.shape_956 = new cjs.Shape();
	this.shape_956.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_956.setTransform(374.325,70.05);

	this.shape_957 = new cjs.Shape();
	this.shape_957.graphics.f("#000000").s().p("AgYAcQgGgGgBgMIAAgrIAUAAIAAAlQAAAHADADQADADAFAAQAGAAADgEQADgFAAgIIAAghIATAAIAABBIgTAAIAAgOQgEAQgQAAQgLAAgFgGg");
	this.shape_957.setTransform(367.5,70.175);

	this.shape_958 = new cjs.Shape();
	this.shape_958.graphics.f("#000000").s().p("AgJAkQgHgHABgOIAAgXIgMAAIAAgPIAIAAIADgBIABgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHACADQAEADAFAAQAIAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_958.setTransform(360.45,69.225);

	this.shape_959 = new cjs.Shape();
	this.shape_959.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_959.setTransform(355.025,70.05);

	this.shape_960 = new cjs.Shape();
	this.shape_960.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgIAIgDQAHgEAJAAQAOAAAIAHQAIAIAAAPIAAAJIgrAAQAAAFACADQADADAEABQACACAHAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgIgBQgQAAgJgIgAAPgGQgBgOgNAAQgFABgDADQgDADgBAHIAaAAIAAAAg");
	this.shape_960.setTransform(348.55,70.1);

	this.shape_961 = new cjs.Shape();
	this.shape_961.graphics.f("#000000").s().p("AghAuIAAhZIASAAIAAAPQAFgRAQAAQANAAAIAJQAHAIAAARQABALgEAHQgEAIgFAEQgHAEgJAAQgOAAgGgNIAAAkgAgLgXQgDAEAAAIIAAABQAAAJADADQAEAFAHAAQAHAAAFgFQADgDAAgJQAAgSgPAAQgHAAgEAFg");
	this.shape_961.setTransform(341,71.225);

	this.shape_962 = new cjs.Shape();
	this.shape_962.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgJAGgFQAHgEALAAIAMAAIACgBIABgDIAAgCQABgDgEgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgBAHAAQAOAAAIAFQAHAHAAALIAAArIgTAAIAAgMQgFANgOAAQgKABgGgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAADgBQAEgCABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_962.setTransform(333.05,70.1);

	this.shape_963 = new cjs.Shape();
	this.shape_963.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgIAHgDQAIgEAJAAQAOAAAJAHQAHAIAAAPIAAAJIgrAAQAAAFACADQACADAFABQADACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgIgBQgQAAgJgIgAAPgGQgBgOgNAAQgEABgEADQgDADgBAHIAaAAIAAAAg");
	this.shape_963.setTransform(322.8,70.1);

	this.shape_964 = new cjs.Shape();
	this.shape_964.graphics.f("#000000").s().p("AgaAmQgHgIgBgRQABgLADgIQAEgHAGgEQAGgEAIAAQAQAAAFANIAAglIAUAAIAABaIgTAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAIAAADgEQAEgFAAgIIAAgBQAAgIgEgEQgDgFgIAAQgOAAAAARg");
	this.shape_964.setTransform(314.85,68.9);

	this.shape_965 = new cjs.Shape();
	this.shape_965.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_965.setTransform(303.875,70.025);

	this.shape_966 = new cjs.Shape();
	this.shape_966.graphics.f("#000000").s().p("AgRArQgIgEgFgIQgEgIAAgLQAAgLAEgHQAFgIAIgDQAIgEAJAAQALAAAIAEQAHADAFAIQAEAHAAALQAAALgEAIQgFAIgHAEQgIADgLAAQgJAAgIgDgAgKAAQgFAEAAAIQABAJADAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgFgIAAQgHAAgDAFgAgKgcIAKgRIAWAAIgOARg");
	this.shape_966.setTransform(295.95,68.9);

	this.shape_967 = new cjs.Shape();
	this.shape_967.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDADgGAAQgLAAAAgMg");
	this.shape_967.setTransform(290.125,68.6);

	this.shape_968 = new cjs.Shape();
	this.shape_968.graphics.f("#000000").s().p("AgQAhQgGgCgFgCIAAgQQAFADAGABQAHACAHABQALgBAAgFQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgBgFgBIgJgCQgKgBgEgFQgGgDAAgJQAAgKAIgGQAGgFAOAAQAIAAAGABIALADIgBARIgKgFQgHgBgGAAQgFAAgCABQgCACgBADQAAAAABABQAAAAAAABQAAAAABAAQAAABAAAAQACACAEAAIAIABQAIABAEADQAFACACACQACAEAAAGQAAALgIAGQgHAFgNAAQgJABgHgCg");
	this.shape_968.setTransform(285,70.1);

	this.shape_969 = new cjs.Shape();
	this.shape_969.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDADgGAAQgLAAAAgMg");
	this.shape_969.setTransform(279.825,68.6);

	this.shape_970 = new cjs.Shape();
	this.shape_970.graphics.f("#000000").s().p("AAfAiIAAglQAAgHgCgDQgDgDgFAAQgFAAgEAEQgCAFgBAIIAAAhIgSAAIAAglQAAgHgCgDQgDgDgEAAQgHAAgCAEQgDAFgBAIIAAAhIgTAAIAAhBIATAAIAAAOQADgIAEgEQAGgEAIAAQAHAAAEAEQAGAEACAIQACgIAGgEQAFgEAIAAQAJAAAGAGQAGAGAAAMIAAArg");
	this.shape_970.setTransform(272.2,70.025);

	this.shape_971 = new cjs.Shape();
	this.shape_971.graphics.f("#000000").s().p("AgRAfQgJgEgDgIQgFgIAAgLQAAgKAFgIQADgIAJgDQAHgEAKAAQALAAAHAEQAJADAEAIQAEAIAAAKQAAALgEAIQgEAIgJAEQgHADgLAAQgKAAgHgDgAgKgMQgFAFAAAHQABAJADAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgHgEgFQgDgFgJAAQgHAAgDAFg");
	this.shape_971.setTransform(262.3,70.1);

	this.shape_972 = new cjs.Shape();
	this.shape_972.graphics.f("#000000").s().p("AgMAnQgJgFgGgKQgEgKAAgOQAAgNAEgKQAGgJAJgGQAIgFAMAAQAOAAAJAGIAAATQgJgHgMAAQgKAAgFAHQgGAGAAAMQAAAOAGAGQAFAGAKAAIAJgBQAEgBACgCIAIgEIAAATIgLAFQgGACgIAAQgMAAgIgFg");
	this.shape_972.setTransform(254.5,69.175);

	this.shape_973 = new cjs.Shape();
	this.shape_973.graphics.f("#000000").s().p("AgIAJQgEgDAAgGQAAgEAEgEQACgDAGAAQAGAAAEADQADAEAAAEQAAAGgDADQgEADgGAAQgGAAgCgDg");
	this.shape_973.setTransform(245.55,72.3);

	this.shape_974 = new cjs.Shape();
	this.shape_974.graphics.f("#000000").s().p("AgMAkQgJgHgDgPIgMAAIADgKIAHAAIAAgEIAAgDIgKAAIADgKIAJAAQACgOAKgIQAKgIAOAAQAOAAAJAGIAAASQgJgHgMAAQgIAAgEADQgEADgCAHIAVAAIAAAKIgXAAIAAADIAAAEIAXAAIAAAKIgVAAQACAHADADQAFADAIAAQAHAAAFgCIALgFIAAARIgLAFQgGACgIAAQgPAAgJgIg");
	this.shape_974.setTransform(239.4,69.175);

	this.shape_975 = new cjs.Shape();
	this.shape_975.graphics.f("#000000").s().p("AgcAnIAAgSQAFADAFACIAMABQAKgBAGgGQAGgHAAgLQgDAFgGADQgGAEgGgBQgJABgHgEQgHgDgDgGQgEgGAAgIQAAgIAEgHQAEgHAIgEQAHgDAKAAQARgBAKAKQALAJAAAXQAAAMgFALQgEAKgJAGQgJAGgNAAQgPAAgJgFgAgLgXQgEADAAAHQAAAGAEADQADAEAIAAQAHAAAEgEQAEgDAAgGQAAgGgEgEQgEgDgHAAQgHgBgEAEg");
	this.shape_975.setTransform(231.175,69.15);

	this.shape_976 = new cjs.Shape();
	this.shape_976.graphics.f("#000000").s().p("AgeArIAAgQIAZgVIAIgIIAEgHIABgFQABgGgEgCQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAHgDAGgCQAIgDAIAAQAKAAAGAEQAHADADAFQADAFABAHQAAAHgDAGQgCAFgFAFIgNALIgJAJIAiAAIAAASg");
	this.shape_976.setTransform(223.55,69.1);

	this.shape_977 = new cjs.Shape();
	this.shape_977.graphics.f("#000000").s().p("AgNASIAHgjIATAAIgLAjg");
	this.shape_977.setTransform(217.9,73.625);

	this.shape_978 = new cjs.Shape();
	this.shape_978.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_978.setTransform(212.625,69.175);

	this.shape_979 = new cjs.Shape();
	this.shape_979.graphics.f("#000000").s().p("AgYAjQgLgKAAgXQAAgMAFgLQAEgKAJgGQAJgGANAAQAPAAAJAFIAAASQgFgDgFgBIgMgBQgKAAgGAGQgFAHgBAMQADgGAGgDQAGgDAGAAQAJAAAHADQAHADADAGQAEAGAAAIQAAAJgEAGQgEAHgIAEQgHAEgKAAQgRAAgKgJgAgKAFQgEADAAAGQAAAGAEAEQAEAEAGAAQAIAAAEgEQAEgDAAgHQAAgGgEgDQgDgDgJAAQgGAAgEADg");
	this.shape_979.setTransform(204.925,69.175);

	this.shape_980 = new cjs.Shape();
	this.shape_980.graphics.f("#000000").s().p("AAEAqIAAgQIgrAAIAAgPIAmg0IAZAAIAAAzIAQAAIAAAQIgQAAIAAAQgAgSAKIAWAAIAAghg");
	this.shape_980.setTransform(196.4,69.175);

	this.shape_981 = new cjs.Shape();
	this.shape_981.graphics.f("#000000").s().p("AgIAJQgEgDAAgGQAAgEAEgEQACgDAGAAQAGAAAEADQADAEAAAEQAAAGgDADQgEADgGAAQgGAAgCgDg");
	this.shape_981.setTransform(190.1,72.3);

	this.shape_982 = new cjs.Shape();
	this.shape_982.graphics.f("#000000").s().p("AgcAnIAAgSQAFADAFACIAMABQAKgBAGgGQAGgHAAgLQgDAFgGADQgGAEgGgBQgJABgHgEQgHgDgDgGQgEgGAAgIQAAgIAEgHQAEgHAIgEQAHgDAKAAQARgBAKAKQALAJAAAXQAAAMgFALQgEAKgJAGQgJAGgNAAQgPAAgJgFgAgLgXQgEADAAAHQAAAGAEADQADAEAIAAQAHAAAEgEQAEgDAAgGQAAgGgEgEQgEgDgHAAQgHgBgEAEg");
	this.shape_982.setTransform(184.075,69.15);

	this.shape_983 = new cjs.Shape();
	this.shape_983.graphics.f("#000000").s().p("AACAqIAAg9IgWADIAAgSIApgHIAABTg");
	this.shape_983.setTransform(176.9,69.175);

	this.shape_984 = new cjs.Shape();
	this.shape_984.graphics.f("#000000").s().p("AgIAfQgEgDAAgGQAAgFAEgEQACgDAGAAQAGAAAEADQADAEAAAFQAAAGgDADQgEADgGAAQgGAAgCgDgAgIgMQgEgEAAgFQAAgGAEgDQACgDAGAAQAGAAAEADQADADAAAGQAAAFgDAEQgEADgGAAQgGAAgCgDg");
	this.shape_984.setTransform(169.15,70.075);

	this.shape_985 = new cjs.Shape();
	this.shape_985.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAHgFQAFgEANAAIALAAIACgBIABgDIAAgCQAAgDgDgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgBAHAAQAOAAAIAFQAHAHAAALIAAArIgSAAIAAgMQgGANgPAAQgJABgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAAEgBQADgCABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_985.setTransform(163.6,70.1);

	this.shape_986 = new cjs.Shape();
	this.shape_986.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_986.setTransform(157.925,70.05);

	this.shape_987 = new cjs.Shape();
	this.shape_987.graphics.f("#000000").s().p("AgYAcQgHgGABgMIAAgrIATAAIAAAlQAAAHADADQACADAGAAQAGAAADgEQADgFAAgIIAAghIAUAAIAABBIgTAAIAAgOQgFAQgRAAQgJAAgGgGg");
	this.shape_987.setTransform(151.1,70.175);

	this.shape_988 = new cjs.Shape();
	this.shape_988.graphics.f("#000000").s().p("AgJAkQgGgHgBgOIAAgXIgLAAIAAgPIAIAAIACgBIABgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_988.setTransform(144.05,69.225);

	this.shape_989 = new cjs.Shape();
	this.shape_989.graphics.f("#000000").s().p("AgTAiIAAhCIASAAIAAATQACgKAFgEQAGgGAIAAIAAAVQgGAAgFACQgEABgDADQgCAEAAAFIAAAfg");
	this.shape_989.setTransform(138.625,70.05);

	this.shape_990 = new cjs.Shape();
	this.shape_990.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAHgDQAJgEAIAAQAPAAAIAHQAHAIAAAPIAAAJIgsAAQABAFACADQACADAEABQAEACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAOgGQAAgOgMAAQgFABgEADQgDADgCAHIAaAAIAAAAg");
	this.shape_990.setTransform(132.15,70.1);

	this.shape_991 = new cjs.Shape();
	this.shape_991.graphics.f("#000000").s().p("AgiAuIAAhZIATAAIAAAPQAFgRAQAAQAOAAAHAJQAIAIAAARQgBALgDAHQgDAIgHAEQgGAEgIAAQgQAAgFgNIAAAkgAgKgXQgEAEAAAIIAAABQAAAJAEADQAEAFAGAAQAIAAADgFQAEgDAAgJQAAgSgPAAQgGAAgEAFg");
	this.shape_991.setTransform(124.6,71.225);

	this.shape_992 = new cjs.Shape();
	this.shape_992.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgJAHgFQAFgEANAAIAKAAIAEgBIABgDIAAgCQgBgDgDgCQgDgCgGAAQgGAAgGACIgKAEIAAgSIAMgDQAGgBAIAAQAOAAAGAFQAIAHAAALIAAArIgSAAIAAgMQgFANgPAAQgKABgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQADgCADgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_992.setTransform(116.65,70.1);

	this.shape_993 = new cjs.Shape();
	this.shape_993.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAIgDQAIgEAIAAQAPAAAHAHQAIAIAAAPIAAAJIgsAAQABAFACADQACADAEABQAEACAGAAQAHAAAGgCQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAOgGQAAgOgMAAQgFABgEADQgEADgBAHIAaAAIAAAAg");
	this.shape_993.setTransform(106.4,70.1);

	this.shape_994 = new cjs.Shape();
	this.shape_994.graphics.f("#000000").s().p("AgaAmQgIgIABgRQAAgLADgIQAEgHAGgEQAGgEAJAAQAOAAAGANIAAglIATAAIAABaIgSAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAHAAAFgEQADgFAAgIIAAgBQAAgIgDgEQgEgFgIAAQgOAAAAARg");
	this.shape_994.setTransform(98.45,68.9);

	this.shape_995 = new cjs.Shape();
	this.shape_995.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_995.setTransform(87.475,70.025);

	this.shape_996 = new cjs.Shape();
	this.shape_996.graphics.f("#000000").s().p("AgSArQgHgEgEgIQgFgIAAgLQAAgLAFgHQAEgIAHgDQAJgEAJAAQALAAAHAEQAJADAEAIQAEAHAAALQAAALgEAIQgEAIgJAEQgHADgLAAQgJAAgJgDgAgLAAQgDAEAAAIQgBAJAEAFQADAEAIAAQAIAAAEgEQADgFAAgJQAAgIgDgEQgDgFgJAAQgHAAgEAFgAgKgcIAJgRIAXAAIgPARg");
	this.shape_996.setTransform(79.55,68.9);

	this.shape_997 = new cjs.Shape();
	this.shape_997.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDADgGAAQgLAAAAgMg");
	this.shape_997.setTransform(73.725,68.6);

	this.shape_998 = new cjs.Shape();
	this.shape_998.graphics.f("#000000").s().p("AgPAhQgHgCgEgCIAAgQQAEADAHABQAGACAHABQAMgBAAgFQAAgBgBgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgBgEgBIgJgCQgLgBgFgFQgEgDAAgJQAAgKAGgGQAIgFANAAQAHAAAHABIALADIgBARIgLgFQgFgBgHAAQgEAAgDABQgCACAAADQAAAAAAABQAAAAAAABQAAAAABAAQAAABABAAQABACAEAAIAIABQAIABAFADQAEACACACQACAEABAGQAAALgIAGQgIAFgNAAQgJABgGgCg");
	this.shape_998.setTransform(68.6,70.1);

	this.shape_999 = new cjs.Shape();
	this.shape_999.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDADQgDADgGAAQgLAAAAgMg");
	this.shape_999.setTransform(63.425,68.6);

	this.shape_1000 = new cjs.Shape();
	this.shape_1000.graphics.f("#000000").s().p("AAgAiIAAglQgBgHgCgDQgDgDgEAAQgHAAgCAEQgDAFAAAIIAAAhIgTAAIAAglQAAgHgDgDQgBgDgGAAQgGAAgDAEQgCAFAAAIIAAAhIgUAAIAAhBIATAAIAAAOQADgIAFgEQAFgEAHAAQAIAAAFAEQAFAEABAIQADgIAFgEQAHgEAHAAQAKAAAFAGQAGAGAAAMIAAArg");
	this.shape_1000.setTransform(55.8,70.025);

	this.shape_1001 = new cjs.Shape();
	this.shape_1001.graphics.f("#000000").s().p("AgSAfQgIgEgEgIQgEgIAAgLQAAgKAEgIQAEgIAIgDQAIgEAKAAQALAAAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgKAAgIgDgAgLgMQgDAFAAAHQgBAJAEAFQADAEAIAAQAIAAAEgEQAEgFgBgJQABgHgEgFQgDgFgJAAQgHAAgEAFg");
	this.shape_1001.setTransform(45.9,70.1);

	this.shape_1002 = new cjs.Shape();
	this.shape_1002.graphics.f("#000000").s().p("AgSAaQgIgJgBgRQABgQAIgIQAJgJAPAAQAHAAAEABIAJADIAAARQgHgFgLAAQgIAAgEAEQgEAFAAAIQAAASAQAAQAHAAAEgCQAEgBAFgCIAAAQQgFADgEABQgFACgIgBQgPAAgJgIg");
	this.shape_1002.setTransform(38.7,70.1);

	this.shape_1003 = new cjs.Shape();
	this.shape_1003.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1003.setTransform(28.425,70.025);

	this.shape_1004 = new cjs.Shape();
	this.shape_1004.graphics.f("#000000").s().p("AgSAfQgHgEgEgIQgFgIAAgLQAAgKAFgIQAEgIAHgDQAJgEAJAAQALAAAHAEQAJADAEAIQAEAIAAAKQAAALgEAIQgEAIgJAEQgHADgLAAQgJAAgJgDgAgKgMQgEAFAAAHQAAAJADAFQAEAEAHAAQAIAAAEgEQADgFABgJQgBgHgDgFQgEgFgIAAQgHAAgDAFg");
	this.shape_1004.setTransform(20.5,70.1);

	this.shape_1005 = new cjs.Shape();
	this.shape_1005.graphics.f("#000000").s().p("AgSAaQgIgJgBgRQABgQAIgIQAJgJAQAAQAFAAAFABIAJADIAAARQgHgFgLAAQgIAAgDAEQgFAFAAAIQAAASAQAAQAHAAAEgCQAEgBAEgCIAAAQQgDADgGABQgEACgHgBQgQAAgJgIg");
	this.shape_1005.setTransform(13.3,70.1);

	this.shape_1006 = new cjs.Shape();
	this.shape_1006.graphics.f("#000000").s().p("AgSAeQgHgDgEgIQgFgHAAgMQAAgKAFgIQAEgHAHgFQAJgDAJAAQALAAAHADQAJAFAEAHQAEAIAAAKQAAAMgEAHQgEAIgJADQgHAFgLAAQgJAAgJgFgAgKgMQgEAEAAAJQAAAIADAEQAEAFAHAAQAIAAAEgFQADgEABgJQgBgHgDgFQgEgEgIAAQgHAAgDAEg");
	this.shape_1006.setTransform(943.9,53.4);

	this.shape_1007 = new cjs.Shape();
	this.shape_1007.graphics.f("#000000").s().p("AgaAmQgHgIAAgRQgBgLAEgHQADgIAHgFQAGgDAJAAQAOAAAGANIAAgmIATAAIAABbIgSAAIAAgPQgFARgQAAQgNAAgIgJgAgOANQAAAJAEAEQAEAEAGAAQAIAAAEgFQADgEAAgIIAAgBQAAgIgDgEQgEgEgIAAQgOAAAAARg");
	this.shape_1007.setTransform(935.65,52.2);

	this.shape_1008 = new cjs.Shape();
	this.shape_1008.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAGgEQAHgFALAAIALAAIAEgBIABgBIAAgCQgBgEgDgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgTAAIAAgMQgEAOgPAAQgKAAgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQADgCADgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_1008.setTransform(928.1,53.4);

	this.shape_1009 = new cjs.Shape();
	this.shape_1009.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADACAAAGQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_1009.setTransform(922.875,51.9);

	this.shape_1010 = new cjs.Shape();
	this.shape_1010.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgKAPABQAGAAAGABIAJADIAAAQQgIgEgKAAQgJAAgEAEQgEAFAAAIQAAASARAAQAFAAAFgBQAEgCAFgDIAAARQgFADgEABQgGACgHAAQgPAAgIgJg");
	this.shape_1010.setTransform(917.75,53.4);

	this.shape_1011 = new cjs.Shape();
	this.shape_1011.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1011.setTransform(910.775,53.325);

	this.shape_1012 = new cjs.Shape();
	this.shape_1012.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgFANAAIAKAAIAEgBIABgBIAAgCQAAgEgEgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQANgBAIAHQAHAFAAAMIAAArIgSAAIAAgMQgFAOgQAAQgJAAgFgGgAgJAIQgCACAAAEQAAADACACQADACADAAQADAAAEgBQACgCACgDQADgDAAgFIAAgBIgNAAQgEAAgDACg");
	this.shape_1012.setTransform(903.15,53.4);

	this.shape_1013 = new cjs.Shape();
	this.shape_1013.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1013.setTransform(896.025,53.325);

	this.shape_1014 = new cjs.Shape();
	this.shape_1014.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADACAAAGQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_1014.setTransform(890.175,51.9);

	this.shape_1015 = new cjs.Shape();
	this.shape_1015.graphics.f("#000000").s().p("AgQAvIAAgxIgKAAIAAgQIAGAAIADAAIABgDIAAgBQAAgHADgFQADgGAGgDQAGgDAIAAIAKAAIAHACIAAAQIgGgCIgHgBQgGAAgDADQgDADAAAFIAAACIAWAAIAAAQIgWAAIAAAxg");
	this.shape_1015.setTransform(885.625,51.975);

	this.shape_1016 = new cjs.Shape();
	this.shape_1016.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_1016.setTransform(877.525,52.125);

	this.shape_1017 = new cjs.Shape();
	this.shape_1017.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIADgBIAAgBIAAgCQAAgEgDgCQgDgCgFABQgHgBgGACIgLAEIAAgRIANgEQAGgBAHAAQAPgBAGAHQAIAFAAAMIAAArIgTAAIAAgMQgEAOgPAAQgKAAgGgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQADAAACgBQAEgCACgDQABgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_1017.setTransform(872.05,53.4);

	this.shape_1018 = new cjs.Shape();
	this.shape_1018.graphics.f("#000000").s().p("AgJAkQgHgHABgOIAAgXIgMAAIAAgPIAIAAIADgBIABgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHACADQAEADAFAAQAIAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_1018.setTransform(865.45,52.525);

	this.shape_1019 = new cjs.Shape();
	this.shape_1019.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADACAAAGQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_1019.setTransform(860.475,51.9);

	this.shape_1020 = new cjs.Shape();
	this.shape_1020.graphics.f("#000000").s().p("AgiAuIAAhZIATAAIAAAPQAFgRAQAAQANAAAIAJQAHAIABARQgBALgDAHQgDAIgGAEQgHAEgIAAQgQAAgFgNIAAAkgAgKgXQgEAEAAAIIAAABQAAAJAEADQADAFAHAAQAHAAAEgFQAEgDAAgJQAAgSgPAAQgHAAgDAFg");
	this.shape_1020.setTransform(854.7,54.525);

	this.shape_1021 = new cjs.Shape();
	this.shape_1021.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIADgBIABgBIAAgCQgBgEgDgCQgDgCgFABQgHgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgTAAIAAgMQgEAOgPAAQgKAAgGgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQADgCADgDQACgDAAgFIAAgBIgMAAQgGAAgCACg");
	this.shape_1021.setTransform(846.75,53.4);

	this.shape_1022 = new cjs.Shape();
	this.shape_1022.graphics.f("#000000").s().p("AgNAnQgIgFgFgKQgGgKAAgOQAAgNAGgKQAFgJAIgGQAJgFAMAAQANAAAKAGIAAATQgJgHgLAAQgLAAgFAHQgGAGAAAMQAAAOAGAGQAFAGALAAIAIgBQAEgBADgCIAGgEIAAATIgKAFQgGACgIAAQgMAAgJgFg");
	this.shape_1022.setTransform(839.55,52.475);

	this.shape_1023 = new cjs.Shape();
	this.shape_1023.graphics.f("#000000").s().p("AgJAIQgDgDAAgFQAAgFADgDQAEgDAFAAQAGAAADADQAEADAAAFQAAAFgEADQgDAEgGAAQgFAAgEgEg");
	this.shape_1023.setTransform(830.6,55.6);

	this.shape_1024 = new cjs.Shape();
	this.shape_1024.graphics.f("#000000").s().p("AgMAkQgKgHgDgPIgKAAIACgKIAHAAIAAgEIAAgDIgJAAIACgKIAIAAQADgOALgIQAJgIAOAAQANAAAKAGIAAASQgJgHgMAAQgHAAgGADQgDADgDAHIAWAAIAAAKIgXAAIgBADIABAEIAXAAIAAAKIgWAAQADAHADADQAFADAIAAQAHAAAFgCIAKgFIAAARIgKAFQgGACgIAAQgOAAgKgIg");
	this.shape_1024.setTransform(824.45,52.475);

	this.shape_1025 = new cjs.Shape();
	this.shape_1025.graphics.f("#000000").s().p("AgeArIAAgPIAYgXIAIgHIAFgGIACgGQgBgFgDgDQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAHgEAGgCQAIgCAJAAQAJAAAHADQAGAEAEAFQACAFAAAIQABAGgDAFQgDAGgEAEIgMANIgKAJIAiAAIAAARg");
	this.shape_1025.setTransform(816.8,52.4);

	this.shape_1026 = new cjs.Shape();
	this.shape_1026.graphics.f("#000000").s().p("AgRAqIgOgEIACgSIANAEIANABQAHAAAEgCQAEgDAAgGQAAgGgGgDQgFgCgJAAIgKAAIgKACIAAgvIA4AAIAAASIgmAAIAAANIAKAAQAQgBAIAIQAIAFAAANQAAAJgEAHQgEAGgIAEQgIADgKAAIgPgBg");
	this.shape_1026.setTransform(809.425,52.55);

	this.shape_1027 = new cjs.Shape();
	this.shape_1027.graphics.f("#000000").s().p("AgMASIAGgjIAUAAIgMAjg");
	this.shape_1027.setTransform(803.6,56.925);

	this.shape_1028 = new cjs.Shape();
	this.shape_1028.graphics.f("#000000").s().p("AgRAqIgNgEIABgSQAGADAHABIANACQAHAAAEgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIAOAAQAEAAAEgCQADgCAAgEQAAgEgDgDQgFgCgHAAQgNAAgKAFIAAgSQALgFAPAAQAKAAAIADQAHADAEAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAKABADAFQAEAFABAHQAAAIgEAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_1028.setTransform(798.35,52.475);

	this.shape_1029 = new cjs.Shape();
	this.shape_1029.graphics.f("#000000").s().p("AgeArIAAgPIAZgXIAIgHIAEgGIABgGQABgFgEgDQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAHgEAGgCQAIgCAIAAQAKAAAGADQAHAEADAFQADAFABAIQAAAGgDAFQgCAGgFAEIgNANIgJAJIAiAAIAAARg");
	this.shape_1029.setTransform(791,52.4);

	this.shape_1030 = new cjs.Shape();
	this.shape_1030.graphics.f("#000000").s().p("AACAqIAAg9IgWADIAAgSIAqgHIAABTg");
	this.shape_1030.setTransform(784.15,52.475);

	this.shape_1031 = new cjs.Shape();
	this.shape_1031.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgHAIgFQAIgDAIAAQAOgBAIAJQAIAHAAAPIAAAIIgsAAQABAGACADQACADAEABQAEABAGABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHACgJAAQgPAAgKgJgAAOgGQAAgNgMAAQgFAAgEADQgEADgBAHIAaAAIAAAAg");
	this.shape_1031.setTransform(774.65,53.4);

	this.shape_1032 = new cjs.Shape();
	this.shape_1032.graphics.f("#000000").s().p("AgaAmQgIgIABgRQAAgLADgHQAEgIAGgFQAGgDAJAAQAOAAAGANIAAgmIATAAIAABbIgSAAIAAgPQgFARgQAAQgNAAgIgJgAgOANQAAAJAEAEQAEAEAGAAQAHAAAFgFQADgEAAgIIAAgBQAAgIgDgEQgEgEgIAAQgOAAAAARg");
	this.shape_1032.setTransform(766.7,52.2);

	this.shape_1033 = new cjs.Shape();
	this.shape_1033.graphics.f("#000000").s().p("AAgAiIAAglQgBgHgCgDQgDgDgEAAQgHAAgCAEQgDAFAAAIIAAAhIgTAAIAAglQAAgHgDgDQgBgDgGAAQgGAAgDAEQgCAFAAAIIAAAhIgUAAIAAhBIATAAIAAAOQADgIAFgEQAFgEAHAAQAIAAAFAEQAFAEABAIQADgIAFgEQAHgEAHAAQAKAAAFAGQAGAGAAAMIAAArg");
	this.shape_1033.setTransform(753.75,53.325);

	this.shape_1034 = new cjs.Shape();
	this.shape_1034.graphics.f("#000000").s().p("AAIAuIgVgeIAAAeIgUAAIAAhbIAUAAIAAAzIAVgZIAYAAIgdAeIAfAjg");
	this.shape_1034.setTransform(744.325,52.125);

	this.shape_1035 = new cjs.Shape();
	this.shape_1035.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1035.setTransform(732.575,52.475);

	this.shape_1036 = new cjs.Shape();
	this.shape_1036.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1036.setTransform(724.125,52.475);

	this.shape_1037 = new cjs.Shape();
	this.shape_1037.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1037.setTransform(715.675,52.475);

	this.shape_1038 = new cjs.Shape();
	this.shape_1038.graphics.f("#000000").s().p("AgIAIQgEgDAAgFQAAgFAEgDQACgDAGAAQAGAAADADQAEADAAAFQAAAFgEADQgDAEgGAAQgGAAgCgEg");
	this.shape_1038.setTransform(709.6,55.6);

	this.shape_1039 = new cjs.Shape();
	this.shape_1039.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1039.setTransform(703.475,52.475);

	this.shape_1040 = new cjs.Shape();
	this.shape_1040.graphics.f("#000000").s().p("AgRAqIgOgEIACgSQAGADAHABIANACQAGAAAFgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIAOAAQAFAAADgCQADgCABgEQAAgEgEgDQgFgCgHAAQgNAAgKAFIAAgSQALgFAOAAQALAAAIADQAHADAEAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAKABAEAFQADAFAAAHQAAAIgDAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_1040.setTransform(695.65,52.475);

	this.shape_1041 = new cjs.Shape();
	this.shape_1041.graphics.f("#000000").s().p("AggAtIAAgRIAJABIAGAAIAFgDIADgGIgbhBIAWAAIAPAvIAQgvIAUAAIgZBBQgEAJgEAGQgEAFgHADQgGADgIAAIgLgBg");
	this.shape_1041.setTransform(684.7,54.675);

	this.shape_1042 = new cjs.Shape();
	this.shape_1042.graphics.f("#000000").s().p("AgQAhQgGgCgFgDIAAgPQAFADAGACQAHACAHAAQALAAAAgHQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgCgFAAIgJgBQgKgCgEgEQgGgEABgJQgBgKAIgFQAGgHAOABQAIAAAGABIALAEIgBAPIgKgDQgHgCgGAAQgFAAgCACQgCABgBADQAAABABAAQAAAAAAABQAAAAABAAQAAABAAAAQACABAEABIAIABQAIABAEACQAFADACACQACAEAAAFQAAAMgIAFQgHAGgNABQgJAAgHgCg");
	this.shape_1042.setTransform(674.25,53.4);

	this.shape_1043 = new cjs.Shape();
	this.shape_1043.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgHAIgFQAIgDAIAAQAPgBAHAJQAIAHAAAPIAAAIIgsAAQABAGACADQADADADABQADABAHABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHACgIAAQgQAAgJgJgAAOgGQABgNgNAAQgGAAgDADQgDADgCAHIAaAAIAAAAg");
	this.shape_1043.setTransform(667.35,53.4);

	this.shape_1044 = new cjs.Shape();
	this.shape_1044.graphics.f("#000000").s().p("AgQAhQgGgCgEgDIAAgPQAEADAGACQAHACAHAAQAMAAAAgHQAAAAgBgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgCgEAAIgJgBQgKgCgGgEQgEgEAAgJQAAgKAGgFQAIgHANABQAHAAAHABIALAEIgBAPIgLgDQgFgCgHAAQgEAAgDACQgDABABADQAAABAAAAQAAAAAAABQAAAAABAAQAAABABAAQABABAEABIAIABQAIABAFACQAEADACACQACAEAAAFQABAMgJAFQgHAGgNABQgJAAgHgCg");
	this.shape_1044.setTransform(660.45,53.4);

	this.shape_1045 = new cjs.Shape();
	this.shape_1045.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgHAHgFQAIgDAJAAQAOgBAJAJQAHAHAAAPIAAAIIgrAAQAAAGACADQACADAFABQADABAGABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHACgIAAQgQAAgJgJgAAPgGQAAgNgOAAQgEAAgEADQgEADAAAHIAaAAIAAAAg");
	this.shape_1045.setTransform(653.55,53.4);

	this.shape_1046 = new cjs.Shape();
	this.shape_1046.graphics.f("#000000").s().p("AAfAiIAAglQABgHgDgDQgDgDgFAAQgFAAgEAEQgCAFAAAIIAAAhIgTAAIAAglQAAgHgDgDQgCgDgEAAQgHAAgCAEQgEAFAAAIIAAAhIgTAAIAAhBIATAAIAAAOQADgIAFgEQAFgEAHAAQAJAAAEAEQAFAEACAIQACgIAGgEQAFgEAIAAQAJAAAGAGQAGAGAAAMIAAArg");
	this.shape_1046.setTransform(644.15,53.325);

	this.shape_1047 = new cjs.Shape();
	this.shape_1047.graphics.f("#000000").s().p("AgYAjQgLgKAAgXQAAgMAFgLQAEgKAJgGQAJgGANAAQAPAAAJAFIAAASQgFgDgFgBIgMgBQgKAAgGAGQgFAHgBAMQADgGAGgDQAGgDAGAAQAJAAAHADQAHADADAGQAEAGAAAIQAAAJgEAGQgEAHgIAEQgHAEgKAAQgRAAgKgJgAgKAFQgEADAAAGQAAAGAEAEQAEAEAGAAQAIAAAEgEQAEgDAAgHQAAgGgEgDQgDgDgJAAQgGAAgEADg");
	this.shape_1047.setTransform(630.825,52.475);

	this.shape_1048 = new cjs.Shape();
	this.shape_1048.graphics.f("#000000").s().p("AgRAqIgOgEIACgSQAGADAHABIANACQAGAAAFgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIANAAQAGAAADgCQADgCABgEQAAgEgFgDQgDgCgIAAQgMAAgLAFIAAgSQALgFAOAAQALAAAHADQAJADADAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAKABAEAFQADAFAAAHQABAIgEAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_1048.setTransform(623.1,52.475);

	this.shape_1049 = new cjs.Shape();
	this.shape_1049.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgHAHgFQAJgDAIAAQAOgBAJAJQAHAHAAAPIAAAIIgrAAQAAAGACADQACADAFABQADABAGABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHACgJAAQgPAAgKgJgAAPgGQAAgNgOAAQgEAAgEADQgEADAAAHIAaAAIAAAAg");
	this.shape_1049.setTransform(612.4,53.4);

	this.shape_1050 = new cjs.Shape();
	this.shape_1050.graphics.f("#000000").s().p("AgaAmQgHgIAAgRQgBgLAEgHQADgIAHgFQAGgDAJAAQAOAAAGANIAAgmIATAAIAABbIgSAAIAAgPQgFARgQAAQgNAAgIgJgAgOANQAAAJAEAEQAEAEAGAAQAIAAAEgFQADgEAAgIIAAgBQAAgIgDgEQgEgEgIAAQgOAAAAARg");
	this.shape_1050.setTransform(604.45,52.2);

	this.shape_1051 = new cjs.Shape();
	this.shape_1051.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1051.setTransform(593.475,53.325);

	this.shape_1052 = new cjs.Shape();
	this.shape_1052.graphics.f("#000000").s().p("AgRAqQgJgDgEgIQgEgHAAgMQAAgLAEgHQAEgHAJgFQAHgDAKAAQALAAAIADQAHAFAFAHQAEAHAAALQAAAMgEAHQgFAIgHADQgIAFgLAAQgKAAgHgFgAgLAAQgDADAAAKQgBAIAEAEQADAFAIAAQAIAAAEgFQAEgEgBgJQABgIgEgEQgDgEgJAAQgHAAgEAEgAgKgdIAJgRIAXAAIgPARg");
	this.shape_1052.setTransform(585.55,52.2);

	this.shape_1053 = new cjs.Shape();
	this.shape_1053.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADACAAAGQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_1053.setTransform(579.725,51.9);

	this.shape_1054 = new cjs.Shape();
	this.shape_1054.graphics.f("#000000").s().p("AgRAaQgKgJABgRQgBgQAKgIQAIgKAQABQAFAAAGABIAJADIAAAQQgIgEgKAAQgJAAgEAEQgEAFAAAIQAAASARAAQAFAAAFgBQAEgCAFgDIAAARQgFADgEABQgFACgHAAQgQAAgIgJg");
	this.shape_1054.setTransform(574.6,53.4);

	this.shape_1055 = new cjs.Shape();
	this.shape_1055.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIADgBIAAgBIAAgCQAAgEgDgCQgDgCgFABQgHgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgTAAIAAgMQgEAOgPAAQgKAAgGgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQADgCADgDQABgDAAgFIAAgBIgLAAQgGAAgCACg");
	this.shape_1055.setTransform(567.75,53.4);

	this.shape_1056 = new cjs.Shape();
	this.shape_1056.graphics.f("#000000").s().p("AgTAiIAAhBIASAAIAAASQACgKAFgFQAGgEAIAAIAAAVQgGgBgFACQgEABgDAEQgCADAAAGIAAAeg");
	this.shape_1056.setTransform(562.075,53.35);

	this.shape_1057 = new cjs.Shape();
	this.shape_1057.graphics.f("#000000").s().p("AgZAcQgFgGgBgMIAAgrIAUAAIAAAlQAAAHADADQADADAFAAQAGAAADgEQADgFAAgIIAAghIATAAIAABBIgTAAIAAgOQgFAQgPAAQgKAAgHgGg");
	this.shape_1057.setTransform(555.25,53.475);

	this.shape_1058 = new cjs.Shape();
	this.shape_1058.graphics.f("#000000").s().p("AgaAmQgHgIgBgRQABgLADgHQAEgIAGgFQAGgDAIAAQAQAAAFANIAAgmIAUAAIAABbIgTAAIAAgPQgFARgQAAQgNAAgIgJgAgOANQAAAJAEAEQAEAEAGAAQAIAAADgFQAEgEAAgIIAAgBQAAgIgEgEQgDgEgIAAQgOAAAAARg");
	this.shape_1058.setTransform(547.15,52.2);

	this.shape_1059 = new cjs.Shape();
	this.shape_1059.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgFANAAIAKAAIADgBIACgBIAAgCQAAgEgEgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQANgBAIAHQAHAFAAAMIAAArIgSAAIAAgMQgFAOgQAAQgJAAgFgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQADAAADgBQACgCACgDQACgDABgFIAAgBIgNAAQgEAAgDACg");
	this.shape_1059.setTransform(536.3,53.4);

	this.shape_1060 = new cjs.Shape();
	this.shape_1060.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1060.setTransform(529.175,53.325);

	this.shape_1061 = new cjs.Shape();
	this.shape_1061.graphics.f("#000000").s().p("AgZAcQgFgGAAgMIAAgrIATAAIAAAlQAAAHADADQACADAGAAQAFAAAEgEQADgFAAgIIAAghIAUAAIAABBIgTAAIAAgOQgGAQgQAAQgJAAgHgGg");
	this.shape_1061.setTransform(521.25,53.475);

	this.shape_1062 = new cjs.Shape();
	this.shape_1062.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAGgEQAHgFALAAIALAAIAEgBIABgBIAAgCQgBgEgDgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgSAAIAAgMQgFAOgPAAQgKAAgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQAEgCACgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_1062.setTransform(510.5,53.4);

	this.shape_1063 = new cjs.Shape();
	this.shape_1063.graphics.f("#000000").s().p("AgTAiIAAhBIASAAIAAASQACgKAFgFQAGgEAIAAIAAAVQgGgBgFACQgEABgDAEQgCADAAAGIAAAeg");
	this.shape_1063.setTransform(504.825,53.35);

	this.shape_1064 = new cjs.Shape();
	this.shape_1064.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAHgEQAGgFAMAAIALAAIACgBIABgBIAAgCQABgEgEgCQgDgCgFABQgHgBgGACIgLAEIAAgRIANgEQAGgBAHAAQAOgBAIAHQAHAFAAAMIAAArIgTAAIAAgMQgFAOgPAAQgJAAgGgGgAgJAIQgCACAAAEQAAADACACQACACAFAAQACAAAEgBQADgCABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_1064.setTransform(498.3,53.4);

	this.shape_1065 = new cjs.Shape();
	this.shape_1065.graphics.f("#000000").s().p("AghAuIAAhZIASAAIAAAPQAFgRAQAAQAOAAAHAJQAIAIgBARQAAALgDAHQgEAIgFAEQgHAEgJAAQgOAAgGgNIAAAkgAgLgXQgDAEAAAIIAAABQAAAJADADQAFAFAGAAQAIAAAEgFQADgDAAgJQAAgSgPAAQgGAAgFAFg");
	this.shape_1065.setTransform(491.05,54.525);

	this.shape_1066 = new cjs.Shape();
	this.shape_1066.graphics.f("#000000").s().p("AgJAuIAAhbIATAAIAABbg");
	this.shape_1066.setTransform(481.675,52.125);

	this.shape_1067 = new cjs.Shape();
	this.shape_1067.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgFANAAIAKAAIAEgBIABgBIAAgCQgBgEgDgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgSAAIAAgMQgFAOgPAAQgKAAgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAADgBQACgCADgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_1067.setTransform(476.2,53.4);

	this.shape_1068 = new cjs.Shape();
	this.shape_1068.graphics.f("#000000").s().p("AgYAcQgHgGABgMIAAgrIATAAIAAAlQAAAHADADQACADAGAAQAFAAAEgEQADgFAAgIIAAghIAUAAIAABBIgTAAIAAgOQgFAQgRAAQgJAAgGgGg");
	this.shape_1068.setTransform(468.9,53.475);

	this.shape_1069 = new cjs.Shape();
	this.shape_1069.graphics.f("#000000").s().p("AgQAhQgGgCgFgDIAAgPQAFADAGACQAHACAHAAQALAAAAgHQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgCgFAAIgJgBQgKgCgEgEQgGgEAAgJQAAgKAIgFQAGgHAOABQAIAAAGABIALAEIgBAPIgKgDQgHgCgGAAQgFAAgCACQgCABgBADQAAABABAAQAAAAAAABQAAAAABAAQAAABAAAAQACABAEABIAIABQAIABAEACQAFADACACQACAEAAAFQAAAMgIAFQgHAGgNABQgJAAgHgCg");
	this.shape_1069.setTransform(461.85,53.4);

	this.shape_1070 = new cjs.Shape();
	this.shape_1070.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1070.setTransform(454.775,53.325);

	this.shape_1071 = new cjs.Shape();
	this.shape_1071.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgHAIgFQAHgDAJAAQAPgBAHAJQAIAHAAAPIAAAIIgrAAQAAAGACADQADADAEABQACABAHABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHACgIAAQgQAAgJgJgAAPgGQAAgNgNAAQgGAAgDADQgDADgBAHIAaAAIAAAAg");
	this.shape_1071.setTransform(447.2,53.4);

	this.shape_1072 = new cjs.Shape();
	this.shape_1072.graphics.f("#000000").s().p("AAfAiIAAglQAAgHgCgDQgDgDgFAAQgFAAgEAEQgCAFAAAIIAAAhIgTAAIAAglQAAgHgCgDQgDgDgEAAQgHAAgCAEQgDAFgBAIIAAAhIgTAAIAAhBIATAAIAAAOQADgIAEgEQAGgEAIAAQAHAAAEAEQAGAEACAIQACgIAGgEQAFgEAIAAQAJAAAGAGQAGAGAAAMIAAArg");
	this.shape_1072.setTransform(437.8,53.325);

	this.shape_1073 = new cjs.Shape();
	this.shape_1073.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgFANAAIAKAAIAEgBIABgBIAAgCQgBgEgDgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgSAAIAAgMQgFAOgPAAQgKAAgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAADgBQACgCADgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_1073.setTransform(424.9,53.4);

	this.shape_1074 = new cjs.Shape();
	this.shape_1074.graphics.f("#000000").s().p("AgTAiIAAhBIASAAIAAASQACgKAFgFQAGgEAIAAIAAAVQgGgBgFACQgEABgDAEQgCADAAAGIAAAeg");
	this.shape_1074.setTransform(419.225,53.35);

	this.shape_1075 = new cjs.Shape();
	this.shape_1075.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgHAIgFQAHgDAJAAQAPgBAHAJQAIAHAAAPIAAAIIgsAAQABAGACADQACADAEABQADABAHABQAHgBAGgBQAGgBAEgDIAAAPQgEADgHABQgHACgIAAQgQAAgKgJgAAOgGQABgNgNAAQgGAAgDADQgEADgBAHIAaAAIAAAAg");
	this.shape_1075.setTransform(412.75,53.4);

	this.shape_1076 = new cjs.Shape();
	this.shape_1076.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADACAAAGQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_1076.setTransform(407.225,51.9);

	this.shape_1077 = new cjs.Shape();
	this.shape_1077.graphics.f("#000000").s().p("AgSAaQgIgJgBgRQABgQAIgIQAJgKAPABQAGAAAFABIAJADIAAAQQgHgEgLAAQgIAAgDAEQgFAFAAAIQAAASAQAAQAHAAAEgBQAEgCAEgDIAAARQgDADgGABQgEACgIAAQgPAAgJgJg");
	this.shape_1077.setTransform(402.1,53.4);

	this.shape_1078 = new cjs.Shape();
	this.shape_1078.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1078.setTransform(395.125,53.325);

	this.shape_1079 = new cjs.Shape();
	this.shape_1079.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIACgBIABgBIAAgCQABgEgEgCQgDgCgFABQgHgBgGACIgLAEIAAgRIANgEQAGgBAHAAQAOgBAIAHQAHAFAAAMIAAArIgTAAIAAgMQgFAOgOAAQgKAAgGgGgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAADgBQAEgCACgDQABgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_1079.setTransform(387.5,53.4);

	this.shape_1080 = new cjs.Shape();
	this.shape_1080.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1080.setTransform(380.375,53.325);

	this.shape_1081 = new cjs.Shape();
	this.shape_1081.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADACAAAGQAAAGgDADQgDACgGAAQgLAAAAgLg");
	this.shape_1081.setTransform(374.525,51.9);

	this.shape_1082 = new cjs.Shape();
	this.shape_1082.graphics.f("#000000").s().p("AgQAvIAAgxIgKAAIAAgQIAGAAIADAAIABgDIAAgBQAAgHADgFQADgGAGgDQAGgDAIAAIAKAAIAHACIAAAQIgGgCIgHgBQgGAAgDADQgDADAAAFIAAACIAWAAIAAAQIgWAAIAAAxg");
	this.shape_1082.setTransform(369.975,51.975);

	this.shape_1083 = new cjs.Shape();
	this.shape_1083.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgFANAAIAKAAIAEgBIABgBIAAgCQAAgEgEgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQANgBAIAHQAHAFAAAMIAAArIgSAAIAAgMQgFAOgQAAQgJAAgFgGgAgJAIQgCACAAAEQAAADACACQADACADAAQADAAAEgBQACgCACgDQADgDAAgFIAAgBIgNAAQgEAAgDACg");
	this.shape_1083.setTransform(360,53.4);

	this.shape_1084 = new cjs.Shape();
	this.shape_1084.graphics.f("#000000").s().p("AgJAkQgHgHAAgOIAAgXIgLAAIAAgPIAIAAIACgBIABgCIAAgQIATAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHADADQACADAHAAQAHAAAGgCIAAAQIgIACIgKABQgMAAgHgHg");
	this.shape_1084.setTransform(353.4,52.525);

	this.shape_1085 = new cjs.Shape();
	this.shape_1085.graphics.f("#000000").s().p("AgRAeQgIgDgFgIQgEgHAAgMQAAgKAEgIQAFgHAIgFQAIgDAJAAQALAAAIADQAHAFAFAHQAEAIAAAKQAAAMgEAHQgFAIgHADQgIAFgLAAQgJAAgIgFgAgKgMQgFAEAAAJQABAIADAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgEgIAAQgHAAgDAEg");
	this.shape_1085.setTransform(346.35,53.4);

	this.shape_1086 = new cjs.Shape();
	this.shape_1086.graphics.f("#000000").s().p("AgZAcQgFgGAAgMIAAgrIATAAIAAAlQAAAHADADQADADAFAAQAFAAAEgEQADgFAAgIIAAghIAUAAIAABBIgUAAIAAgOQgFAQgQAAQgJAAgHgGg");
	this.shape_1086.setTransform(338.45,53.475);

	this.shape_1087 = new cjs.Shape();
	this.shape_1087.graphics.f("#000000").s().p("AgMAnQgKgFgEgKQgFgKgBgOQABgNAFgKQAEgJAKgGQAJgFALAAQANAAAKAGIAAATQgJgHgMAAQgKAAgFAHQgGAGAAAMQAAAOAGAGQAFAGAKAAIAJgBQAEgBADgCIAHgEIAAATIgLAFQgFACgJAAQgLAAgJgFg");
	this.shape_1087.setTransform(330.8,52.475);

	this.shape_1088 = new cjs.Shape();
	this.shape_1088.graphics.f("#000000").s().p("AgIAIQgEgDAAgFQAAgFAEgDQACgDAGAAQAGAAAEADQADADAAAFQAAAFgDADQgEAEgGAAQgGAAgCgEg");
	this.shape_1088.setTransform(321.85,55.6);

	this.shape_1089 = new cjs.Shape();
	this.shape_1089.graphics.f("#000000").s().p("AgMAkQgJgHgEgPIgLAAIADgKIAHAAIAAgEIAAgDIgKAAIADgKIAIAAQAEgOAKgIQAJgIAOAAQANAAAKAGIAAASQgJgHgMAAQgHAAgGADQgDADgCAHIAVAAIAAAKIgXAAIgBADIABAEIAXAAIAAAKIgVAAQACAHADADQAFADAIAAQAHAAAFgCIAKgFIAAARIgKAFQgGACgIAAQgOAAgKgIg");
	this.shape_1089.setTransform(315.7,52.475);

	this.shape_1090 = new cjs.Shape();
	this.shape_1090.graphics.f("#000000").s().p("AgRAqIgOgEIACgSIANAEIANABQAHAAAEgCQAEgDAAgGQAAgGgGgDQgFgCgJAAIgKAAIgKACIAAgvIA4AAIAAASIgmAAIAAANIAKAAQAQgBAIAIQAIAFAAANQAAAJgEAHQgEAGgIAEQgIADgKAAIgPgBg");
	this.shape_1090.setTransform(307.975,52.55);

	this.shape_1091 = new cjs.Shape();
	this.shape_1091.graphics.f("#000000").s().p("AAEAqIAAgQIgrAAIAAgPIAmg0IAZAAIAAAzIAQAAIAAAQIgQAAIAAAQgAgSAKIAWAAIAAghg");
	this.shape_1091.setTransform(299.65,52.475);

	this.shape_1092 = new cjs.Shape();
	this.shape_1092.graphics.f("#000000").s().p("AgMASIAGgjIAUAAIgMAjg");
	this.shape_1092.setTransform(293.3,56.925);

	this.shape_1093 = new cjs.Shape();
	this.shape_1093.graphics.f("#000000").s().p("AgeArIAAgPIAZgXIAIgHIAEgGIACgGQAAgFgEgDQgDgCgGAAQgGAAgHACQgHACgGAEIAAgSQAGgEAIgCQAHgCAIAAQAKAAAGADQAHAEADAFQAEAFAAAIQgBAGgCAFQgCAGgFAEIgNANIgJAJIAiAAIAAARg");
	this.shape_1093.setTransform(288.1,52.4);

	this.shape_1094 = new cjs.Shape();
	this.shape_1094.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1094.setTransform(280.125,52.475);

	this.shape_1095 = new cjs.Shape();
	this.shape_1095.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1095.setTransform(271.675,52.475);

	this.shape_1096 = new cjs.Shape();
	this.shape_1096.graphics.f("#000000").s().p("AgIAIQgEgDAAgFQAAgFAEgDQACgDAGAAQAGAAAEADQADADAAAFQAAAFgDADQgEAEgGAAQgGAAgCgEg");
	this.shape_1096.setTransform(265.6,55.6);

	this.shape_1097 = new cjs.Shape();
	this.shape_1097.graphics.f("#000000").s().p("AgRAqIgOgEIACgSIANAEIANABQAHAAAEgCQAEgDAAgGQAAgGgGgDQgFgCgJAAIgKAAIgKACIAAgvIA4AAIAAASIgmAAIAAANIAKAAQAQgBAIAIQAIAFAAANQAAAJgEAHQgEAGgIAEQgIADgKAAIgPgBg");
	this.shape_1097.setTransform(260.075,52.55);

	this.shape_1098 = new cjs.Shape();
	this.shape_1098.graphics.f("#000000").s().p("AgJAfQgDgDAAgGQAAgFADgEQAEgDAFAAQAGAAADADQAEAEAAAFQAAAGgEADQgDADgGAAQgFAAgEgDgAgJgMQgDgEAAgFQAAgGADgDQAEgDAFAAQAGAAADADQAEADAAAGQAAAFgEAEQgDADgGAAQgFAAgEgDg");
	this.shape_1098.setTransform(251,53.375);

	this.shape_1099 = new cjs.Shape();
	this.shape_1099.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAGgEQAHgFALAAIALAAIAEgBIABgBIAAgCQgBgEgDgCQgDgCgGABQgGgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgSAAIAAgMQgFAOgPAAQgKAAgFgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQAEgCACgDQACgDAAgFIAAgBIgNAAQgFAAgCACg");
	this.shape_1099.setTransform(245.45,53.4);

	this.shape_1100 = new cjs.Shape();
	this.shape_1100.graphics.f("#000000").s().p("AgaAmQgHgIAAgRQAAgLADgHQADgIAHgFQAGgDAJAAQAOAAAGANIAAgmIAUAAIAABbIgTAAIAAgPQgFARgQAAQgNAAgIgJgAgOANQAAAJAEAEQAEAEAGAAQAIAAAEgFQADgEAAgIIAAgBQAAgIgDgEQgEgEgIAAQgOAAAAARg");
	this.shape_1100.setTransform(237.8,52.2);

	this.shape_1101 = new cjs.Shape();
	this.shape_1101.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgFALAAIAMAAIADgBIABgBIAAgCQgBgEgDgCQgDgCgFABQgHgBgGACIgKAEIAAgRIAMgEQAGgBAIAAQAOgBAGAHQAIAFAAAMIAAArIgTAAIAAgMQgEAOgPAAQgKAAgGgGgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgBQADgCADgDQABgDABgFIAAgBIgMAAQgGAAgCACg");
	this.shape_1101.setTransform(230.25,53.4);

	this.shape_1102 = new cjs.Shape();
	this.shape_1102.graphics.f("#000000").s().p("AgTAiIAAhBIASAAIAAASQACgKAFgFQAGgEAIAAIAAAVQgGgBgFACQgEABgDAEQgCADAAAGIAAAeg");
	this.shape_1102.setTransform(224.575,53.35);

	this.shape_1103 = new cjs.Shape();
	this.shape_1103.graphics.f("#000000").s().p("AgJAkQgGgHAAgOIAAgXIgMAAIAAgPIAIAAIADgBIABgCIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAAHACADQAEADAFAAQAIAAAGgCIAAAQIgIACIgJABQgNAAgHgHg");
	this.shape_1103.setTransform(218.45,52.525);

	this.shape_1104 = new cjs.Shape();
	this.shape_1104.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1104.setTransform(211.575,53.325);

	this.shape_1105 = new cjs.Shape();
	this.shape_1105.graphics.f("#000000").s().p("AgcAqIAAhTIA5AAIAAARIglAAIAAARIAgAAIAAAPIggAAIAAARIAlAAIAAARg");
	this.shape_1105.setTransform(203.975,52.475);

	this.shape_1106 = new cjs.Shape();
	this.shape_1106.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1106.setTransform(195.375,55.925);

	this.shape_1107 = new cjs.Shape();
	this.shape_1107.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1107.setTransform(190.2,53.425);

	this.shape_1108 = new cjs.Shape();
	this.shape_1108.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAAKIAAAfg");
	this.shape_1108.setTransform(184.875,53.4);

	this.shape_1109 = new cjs.Shape();
	this.shape_1109.graphics.f("#000000").s().p("AgeAAQABgQAIgIQAJgJAOAAQANAAAIAHQAHAJAAAOIAAAGIguAAQAAALAFAFQAFAEALABQAOgBAKgFIAAAKQgKAGgQAAQghAAAAgigAATgFQAAgSgRAAQgQAAgCASIAjAAIAAAAg");
	this.shape_1109.setTransform(178.5,53.45);

	this.shape_1110 = new cjs.Shape();
	this.shape_1110.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1110.setTransform(173.25,51.975);

	this.shape_1111 = new cjs.Shape();
	this.shape_1111.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAALQgIgEgLAAQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_1111.setTransform(168.275,53.45);

	this.shape_1112 = new cjs.Shape();
	this.shape_1112.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1112.setTransform(161.275,53.375);

	this.shape_1113 = new cjs.Shape();
	this.shape_1113.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1113.setTransform(153.7,53.425);

	this.shape_1114 = new cjs.Shape();
	this.shape_1114.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1114.setTransform(146.725,53.375);

	this.shape_1115 = new cjs.Shape();
	this.shape_1115.graphics.f("#000000").s().p("AgFAvIAAhAIAMAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1115.setTransform(141.1,51.975);

	this.shape_1116 = new cjs.Shape();
	this.shape_1116.graphics.f("#000000").s().p("AgPAvIAAg2IgKAAIAAgKIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDQAAgLAHgGQAHgHALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAPIAAADIAZAAIAAAKIgZAAIAAA2g");
	this.shape_1116.setTransform(136.825,52);

	this.shape_1117 = new cjs.Shape();
	this.shape_1117.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1117.setTransform(126.925,53.375);

	this.shape_1118 = new cjs.Shape();
	this.shape_1118.graphics.f("#000000").s().p("AgYAmQgJgIAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAIAJABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTANQAAAWATAAQAUAAAAgWQAAgWgUAAQgTAAAAAWgAgHgdIAJgRIARAAIgPARg");
	this.shape_1118.setTransform(119.1,52.2);

	this.shape_1119 = new cjs.Shape();
	this.shape_1119.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1119.setTransform(113.55,51.975);

	this.shape_1120 = new cjs.Shape();
	this.shape_1120.graphics.f("#000000").s().p("AgRAZQgJgIAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAALQgIgEgLAAQgUgBAAAWQAAAXAUAAQALgBAJgFIAAAMQgJAFgMAAQgPAAgIgJg");
	this.shape_1120.setTransform(108.575,53.45);

	this.shape_1121 = new cjs.Shape();
	this.shape_1121.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1121.setTransform(101.75,53.425);

	this.shape_1122 = new cjs.Shape();
	this.shape_1122.graphics.f("#000000").s().p("AgTAfIAAAOIgNAAIAAhbIAOAAIAAApQAFgQAQAAQANAAAIAJQAJAIgBAQQABARgJAJQgIAJgMAAQgRAAgGgQgAgNgEQgGAFABAKIAAACQAAAWASAAQAJAAAEgFQAGgGAAgLQAAgWgTAAQgIAAgFAFg");
	this.shape_1122.setTransform(94.8,52.2);

	this.shape_1123 = new cjs.Shape();
	this.shape_1123.graphics.f("#000000").s().p("AgYAZQgJgIAAgRQAAgQAJgIQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAIQgJAJgQAAQgPAAgJgJgAgTAAQAAAXATAAQAUAAAAgXQAAgWgUABQgTAAAAAVg");
	this.shape_1123.setTransform(86.7,53.45);

	this.shape_1124 = new cjs.Shape();
	this.shape_1124.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAASQAFgTASAAIAAAOQgKAAgGAFQgGAFAAAKIAAAfg");
	this.shape_1124.setTransform(80.675,53.4);

	this.shape_1125 = new cjs.Shape();
	this.shape_1125.graphics.f("#000000").s().p("AggAtIAAhYIANAAIAAAQQAGgRAQAAQANAAAIAIQAJAIgBARQABAQgJAJQgIAJgMAAQgRAAgFgPIAAAlgAgNgbQgGAFABAKIAAACQAAAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_1125.setTransform(74.1,54.575);

	this.shape_1126 = new cjs.Shape();
	this.shape_1126.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1126.setTransform(66.25,53.425);

	this.shape_1127 = new cjs.Shape();
	this.shape_1127.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1127.setTransform(56.25,53.425);

	this.shape_1128 = new cjs.Shape();
	this.shape_1128.graphics.f("#000000").s().p("AgYAZQgIgIAAgRQAAgQAIgIQAJgJAPAAQAQAAAIAJQAJAIAAAQQAAARgJAIQgIAJgQAAQgPAAgJgJgAgUAAQABAXATAAQAUAAAAgXQAAgWgUABQgTAAgBAVg");
	this.shape_1128.setTransform(46,53.45);

	this.shape_1129 = new cjs.Shape();
	this.shape_1129.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1129.setTransform(38.925,52.525);

	this.shape_1130 = new cjs.Shape();
	this.shape_1130.graphics.f("#000000").s().p("AgdAAQAAgQAJgIQAIgJAOAAQANAAAIAHQAIAJgBAOIAAAGIguAAQAAALAFAFQAGAEAKABQAOgBAKgFIAAAKQgKAGgQAAQghAAABgigAATgFQAAgSgSAAQgPAAgCASIAjAAIAAAAg");
	this.shape_1130.setTransform(32.35,53.45);

	this.shape_1131 = new cjs.Shape();
	this.shape_1131.graphics.f("#000000").s().p("AgRA6IAAgLQAEACAFAAQALAAAAgNIAAhBIANAAIAABBQAAAYgWAAQgGAAgFgCgAAAgzQAAgIAJAAQAKAAgBAIQABAJgKAAQgJAAAAgJg");
	this.shape_1131.setTransform(26.15,53.25);

	this.shape_1132 = new cjs.Shape();
	this.shape_1132.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1132.setTransform(21.425,53.525);

	this.shape_1133 = new cjs.Shape();
	this.shape_1133.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAgBgNQABgFgDgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAPAAQARAAALAGIgBANQgNgHgOAAQgJAAgFADQgEAEAAAFQAAAGADACQADACAGACIAOACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_1133.setTransform(13.9,52.475);

	this.shape_1134 = new cjs.Shape();
	this.shape_1134.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1134.setTransform(927.525,40.125);

	this.shape_1135 = new cjs.Shape();
	this.shape_1135.graphics.f("#000000").s().p("AAaAqIgHgVIglAAIgIAVIgOAAIAghTIASAAIAfBTgAAPAJIgPgoIgOAoIAdAAg");
	this.shape_1135.setTransform(921.625,36.675);

	this.shape_1136 = new cjs.Shape();
	this.shape_1136.graphics.f("#000000").s().p("AgIAAQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1136.setTransform(915.725,40.125);

	this.shape_1137 = new cjs.Shape();
	this.shape_1137.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQAUAAgBgNQAAgFgCgCQgEgDgJgBIgMgDQgWgDAAgSQAAgMAIgGQAJgHAOAAQASAAALAGIgBANQgNgHgPAAQgIAAgEADQgGAEABAFQAAAGADACQADACAGACIANACQANACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_1137.setTransform(910.4,36.675);

	this.shape_1138 = new cjs.Shape();
	this.shape_1138.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_1138.setTransform(901.75,41.2);

	this.shape_1139 = new cjs.Shape();
	this.shape_1139.graphics.f("#000000").s().p("AgUAhQgLgMAAgVQAAgUALgLQAKgMARAAQANABALAFIAAAOQgLgIgLABQgLAAgHAHQgIAJAAAOQAAAQAIAIQAGAIAMAAQALgBAMgHIAAAMQgLAIgOgBQgRABgKgLg");
	this.shape_1139.setTransform(896.525,36.7);

	this.shape_1140 = new cjs.Shape();
	this.shape_1140.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAbIAmAAIAAAKIgmAAIAAAig");
	this.shape_1140.setTransform(889.175,36.675);

	this.shape_1141 = new cjs.Shape();
	this.shape_1141.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAYIAkAAIAAAKIgkAAIAAAZIApAAIAAAMg");
	this.shape_1141.setTransform(881.65,36.675);

	this.shape_1142 = new cjs.Shape();
	this.shape_1142.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1142.setTransform(870.95,37.625);

	this.shape_1143 = new cjs.Shape();
	this.shape_1143.graphics.f("#000000").s().p("AARAuIAAgmQAAgQgPAAQgIAAgFAGQgFAFAAALIAAAgIgNAAIAAhAIANAAIAAAQQAGgSARAAQAKAAAHAHQAGAGAAALIAAAqgAAAggIgHgEQgEAAAAAHIgJAAQAAgIAEgEQADgEAFAAQAEAAAEAEQAEADACAAQAEAAAAgHIAJAAQAAAIgEAFQgDADgFAAQgEAAgDgDg");
	this.shape_1143.setTransform(863.975,36.325);

	this.shape_1144 = new cjs.Shape();
	this.shape_1144.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1144.setTransform(856.4,37.625);

	this.shape_1145 = new cjs.Shape();
	this.shape_1145.graphics.f("#000000").s().p("AggAtIAAhYIANAAIAAAQQAFgRARAAQANAAAIAIQAJAIgBARQABAQgJAJQgIAJgMAAQgRAAgFgPIAAAlgAgNgbQgGAFABAKIAAACQAAAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_1145.setTransform(849.45,38.775);

	this.shape_1146 = new cjs.Shape();
	this.shape_1146.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1146.setTransform(842.025,37.625);

	this.shape_1147 = new cjs.Shape();
	this.shape_1147.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgqAAIAAAYIAmAAIAAAKIgmAAIAAAZIAqAAIAAAMg");
	this.shape_1147.setTransform(835.15,36.675);

	this.shape_1148 = new cjs.Shape();
	this.shape_1148.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1148.setTransform(824.875,37.625);

	this.shape_1149 = new cjs.Shape();
	this.shape_1149.graphics.f("#000000").s().p("AgeAAQAAgPAJgJQAKgJANAAQANAAAIAIQAHAHABAOIAAAGIgvAAQAAAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_1149.setTransform(818.1,37.65);

	this.shape_1150 = new cjs.Shape();
	this.shape_1150.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1150.setTransform(811.225,37.65);

	this.shape_1151 = new cjs.Shape();
	this.shape_1151.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1151.setTransform(806.35,36.175);

	this.shape_1152 = new cjs.Shape();
	this.shape_1152.graphics.f("#000000").s().p("AgIAgIgahAIAPAAIATA2IAUg2IAPAAIgcBAg");
	this.shape_1152.setTransform(801.05,37.65);

	this.shape_1153 = new cjs.Shape();
	this.shape_1153.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1153.setTransform(795.275,37.6);

	this.shape_1154 = new cjs.Shape();
	this.shape_1154.graphics.f("#000000").s().p("AgdAAQAAgPAJgJQAIgJAOAAQAOAAAHAIQAIAHgBAOIAAAGIgvAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1154.setTransform(788.9,37.65);

	this.shape_1155 = new cjs.Shape();
	this.shape_1155.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQATAAAAgNQAAgFgDgCQgDgDgIgBIgOgDQgVgDAAgSQAAgMAJgGQAIgHAOAAQASAAALAGIgBANQgNgHgPAAQgHAAgFADQgGAEAAAFQAAAGAEACQADACAHACIAMACQANACAFAFQAGAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_1155.setTransform(781.55,36.675);

	this.shape_1156 = new cjs.Shape();
	this.shape_1156.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_1156.setTransform(772.95,36.325);

	this.shape_1157 = new cjs.Shape();
	this.shape_1157.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1157.setTransform(767.7,37.625);

	this.shape_1158 = new cjs.Shape();
	this.shape_1158.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1158.setTransform(762.85,36.175);

	this.shape_1159 = new cjs.Shape();
	this.shape_1159.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1159.setTransform(757.875,37.65);

	this.shape_1160 = new cjs.Shape();
	this.shape_1160.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1160.setTransform(750.875,37.575);

	this.shape_1161 = new cjs.Shape();
	this.shape_1161.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFACADQAEADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1161.setTransform(743.3,37.625);

	this.shape_1162 = new cjs.Shape();
	this.shape_1162.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1162.setTransform(736.325,37.575);

	this.shape_1163 = new cjs.Shape();
	this.shape_1163.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1163.setTransform(730.7,36.175);

	this.shape_1164 = new cjs.Shape();
	this.shape_1164.graphics.f("#000000").s().p("AgbAqIAAhTIA3AAIAAAMIgpAAIAAAbIAmAAIAAAKIgmAAIAAAig");
	this.shape_1164.setTransform(725.475,36.675);

	this.shape_1165 = new cjs.Shape();
	this.shape_1165.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1165.setTransform(715.225,37.625);

	this.shape_1166 = new cjs.Shape();
	this.shape_1166.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1166.setTransform(710.35,36.175);

	this.shape_1167 = new cjs.Shape();
	this.shape_1167.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1167.setTransform(705.475,36.725);

	this.shape_1168 = new cjs.Shape();
	this.shape_1168.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1168.setTransform(698.675,37.575);

	this.shape_1169 = new cjs.Shape();
	this.shape_1169.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1169.setTransform(691.1,37.625);

	this.shape_1170 = new cjs.Shape();
	this.shape_1170.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_1170.setTransform(686.3,36.325);

	this.shape_1171 = new cjs.Shape();
	this.shape_1171.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_1171.setTransform(683.05,36.325);

	this.shape_1172 = new cjs.Shape();
	this.shape_1172.graphics.f("#000000").s().p("AgdAAQAAgPAJgJQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1172.setTransform(677.85,37.65);

	this.shape_1173 = new cjs.Shape();
	this.shape_1173.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1173.setTransform(671.075,36.725);

	this.shape_1174 = new cjs.Shape();
	this.shape_1174.graphics.f("#000000").s().p("AgeAlIAAgNQAMAHARAAQATAAABgNQAAgFgEgCQgDgDgIgBIgOgDQgVgDAAgSQAAgMAJgGQAIgHAPAAQARAAALAGIgBANQgNgHgOAAQgJAAgFADQgEAEAAAFQAAAGADACQADACAHACIANACQAMACAGAFQAFAFAAAKQAAAMgJAHQgJAGgPAAQgRAAgMgGg");
	this.shape_1174.setTransform(664.3,36.675);

	this.shape_1175 = new cjs.Shape();
	this.shape_1175.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_1175.setTransform(653.75,37.65);

	this.shape_1176 = new cjs.Shape();
	this.shape_1176.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_1176.setTransform(645.925,36.4);

	this.shape_1177 = new cjs.Shape();
	this.shape_1177.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1177.setTransform(635.775,37.625);

	this.shape_1178 = new cjs.Shape();
	this.shape_1178.graphics.f("#000000").s().p("AgdAMQgBgPAKgJQAJgJANABQAOgBAHAIQAIAIAAANIAAAHIgwAAQABAMAFAEQAGAFAKAAQANAAALgGIAAAKQgLAHgPgBQggABAAgjgAATAGQAAgQgRAAQgQAAgDAQIAkAAIAAAAgAgFgdIAKgQIAQAAIgPAQg");
	this.shape_1178.setTransform(629,36.4);

	this.shape_1179 = new cjs.Shape();
	this.shape_1179.graphics.f("#000000").s().p("AgIAgIgZhAIAOAAIATA2IAVg2IANAAIgbBAg");
	this.shape_1179.setTransform(621.8,37.65);

	this.shape_1180 = new cjs.Shape();
	this.shape_1180.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1180.setTransform(614.55,37.625);

	this.shape_1181 = new cjs.Shape();
	this.shape_1181.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1181.setTransform(609.225,37.6);

	this.shape_1182 = new cjs.Shape();
	this.shape_1182.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1182.setTransform(603.225,36.725);

	this.shape_1183 = new cjs.Shape();
	this.shape_1183.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFADADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1183.setTransform(593.4,37.625);

	this.shape_1184 = new cjs.Shape();
	this.shape_1184.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1184.setTransform(583.825,37.625);

	this.shape_1185 = new cjs.Shape();
	this.shape_1185.graphics.f("#000000").s().p("AgdAAQAAgPAJgJQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1185.setTransform(577.05,37.65);

	this.shape_1186 = new cjs.Shape();
	this.shape_1186.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1186.setTransform(570.275,37.625);

	this.shape_1187 = new cjs.Shape();
	this.shape_1187.graphics.f("#000000").s().p("AgeAAQABgPAIgJQAKgJANAAQANAAAIAIQAHAHAAAOIAAAGIguAAQAAAMAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_1187.setTransform(563.5,37.65);

	this.shape_1188 = new cjs.Shape();
	this.shape_1188.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgQAAAAAWIAAAgIgMAAIAAglQAAgRgOAAQgRAAAAAWIAAAgIgMAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_1188.setTransform(554.2,37.575);

	this.shape_1189 = new cjs.Shape();
	this.shape_1189.graphics.f("#000000").s().p("AgXAiQgKgJAAgWQAAgtAmAAQANAAAKAEIAAANQgJgGgNAAQgZAAgBAgQADgFAHgEQAGgEAIAAQAOAAAIAIQAIAGAAANQAAAMgIAIQgKAIgOAAQgQAAgJgJgAgNACQgGAEABAIQgBAIAGAFQAFAFAIAAQAKAAAFgFQAFgEAAgIQAAgQgTAAQgJAAgFADg");
	this.shape_1189.setTransform(541.1,36.675);

	this.shape_1190 = new cjs.Shape();
	this.shape_1190.graphics.f("#000000").s().p("AgeAlIABgNQANAHAOAAQAIAAAGgDQAFgEAAgGQAAgNgSAAIgNAAIAAgKIANAAQAGAAAFgDQAFgEAAgGQAAgGgFgDQgGgDgIAAQgOAAgLAGIAAgNQAMgFAOAAQAPAAAIAGQAJAGAAAKQAAAPgRAFQATADAAAQQAAALgJAHQgJAGgOAAQgQAAgNgGg");
	this.shape_1190.setTransform(533.425,36.675);

	this.shape_1191 = new cjs.Shape();
	this.shape_1191.graphics.f("#000000").s().p("AgYAaQgIgJgBgRQABgPAIgJQAJgJAPAAQAQAAAIAJQAJAIAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUABQABAWATgBQAUAAAAgWQAAgVgUgBQgTAAgBAXg");
	this.shape_1191.setTransform(522.65,37.65);

	this.shape_1192 = new cjs.Shape();
	this.shape_1192.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgNAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_1192.setTransform(513.05,37.575);

	this.shape_1193 = new cjs.Shape();
	this.shape_1193.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1193.setTransform(505.45,36.175);

	this.shape_1194 = new cjs.Shape();
	this.shape_1194.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1194.setTransform(499.975,37.575);

	this.shape_1195 = new cjs.Shape();
	this.shape_1195.graphics.f("#000000").s().p("AgKAuIAAhAIALAAIAABAgAgNgcIAMgRIAOAAIgNARg");
	this.shape_1195.setTransform(494.85,36.325);

	this.shape_1196 = new cjs.Shape();
	this.shape_1196.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgNAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_1196.setTransform(486.95,37.575);

	this.shape_1197 = new cjs.Shape();
	this.shape_1197.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1197.setTransform(474.025,37.575);

	this.shape_1198 = new cjs.Shape();
	this.shape_1198.graphics.f("#000000").s().p("AgeAAQABgPAIgJQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAGIguAAQAAAMAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_1198.setTransform(466.5,37.65);

	this.shape_1199 = new cjs.Shape();
	this.shape_1199.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1199.setTransform(461.25,36.175);

	this.shape_1200 = new cjs.Shape();
	this.shape_1200.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1200.setTransform(456.275,37.65);

	this.shape_1201 = new cjs.Shape();
	this.shape_1201.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1201.setTransform(449.275,37.575);

	this.shape_1202 = new cjs.Shape();
	this.shape_1202.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1202.setTransform(441.7,37.625);

	this.shape_1203 = new cjs.Shape();
	this.shape_1203.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1203.setTransform(434.725,37.575);

	this.shape_1204 = new cjs.Shape();
	this.shape_1204.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1204.setTransform(429.1,36.175);

	this.shape_1205 = new cjs.Shape();
	this.shape_1205.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAgBIAAgCQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_1205.setTransform(424.825,36.2);

	this.shape_1206 = new cjs.Shape();
	this.shape_1206.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1206.setTransform(415.15,37.65);

	this.shape_1207 = new cjs.Shape();
	this.shape_1207.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1207.setTransform(407.575,37.725);

	this.shape_1208 = new cjs.Shape();
	this.shape_1208.graphics.f("#000000").s().p("AATAtIAAgmQgFAQgRAAQgNAAgHgIQgIgJAAgQQAAgRAIgJQAHgIANAAQARAAAGAQIAAgPIAMAAIAABYgAgSgKQAAAVASAAQAJAAAFgFQAFgGAAgIIAAgDQAAgWgTAAQgSAAAAAXg");
	this.shape_1208.setTransform(399.575,38.775);

	this.shape_1209 = new cjs.Shape();
	this.shape_1209.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1209.setTransform(389.425,37.625);

	this.shape_1210 = new cjs.Shape();
	this.shape_1210.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1210.setTransform(382.65,37.65);

	this.shape_1211 = new cjs.Shape();
	this.shape_1211.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1211.setTransform(376.925,37.6);

	this.shape_1212 = new cjs.Shape();
	this.shape_1212.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgPAOQABAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1212.setTransform(370.5,37.625);

	this.shape_1213 = new cjs.Shape();
	this.shape_1213.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_1213.setTransform(365.7,36.325);

	this.shape_1214 = new cjs.Shape();
	this.shape_1214.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1214.setTransform(360.075,37.725);

	this.shape_1215 = new cjs.Shape();
	this.shape_1215.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1215.setTransform(353.025,37.65);

	this.shape_1216 = new cjs.Shape();
	this.shape_1216.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1216.setTransform(348.15,36.175);

	this.shape_1217 = new cjs.Shape();
	this.shape_1217.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1217.setTransform(343.275,36.725);

	this.shape_1218 = new cjs.Shape();
	this.shape_1218.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1218.setTransform(338.125,37.6);

	this.shape_1219 = new cjs.Shape();
	this.shape_1219.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1219.setTransform(331.7,37.625);

	this.shape_1220 = new cjs.Shape();
	this.shape_1220.graphics.f("#000000").s().p("AggAtIAAhYIANAAIAAAQQAGgRAQAAQANAAAIAIQAJAIgBARQABAQgJAJQgIAJgMAAQgRAAgFgPIAAAlgAgNgbQgGAFABAKIAAACQAAAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_1220.setTransform(324.75,38.775);

	this.shape_1221 = new cjs.Shape();
	this.shape_1221.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1221.setTransform(314.125,37.625);

	this.shape_1222 = new cjs.Shape();
	this.shape_1222.graphics.f("#000000").s().p("AgeAAQAAgPAJgJQAKgJANAAQANAAAIAIQAHAHABAOIAAAGIgvAAQAAAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_1222.setTransform(307.35,37.65);

	this.shape_1223 = new cjs.Shape();
	this.shape_1223.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1223.setTransform(300.575,36.725);

	this.shape_1224 = new cjs.Shape();
	this.shape_1224.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1224.setTransform(293.775,37.575);

	this.shape_1225 = new cjs.Shape();
	this.shape_1225.graphics.f("#000000").s().p("AgdAAQAAgPAJgJQAIgJAOAAQAOAAAHAIQAIAHgBAOIAAAGIgvAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1225.setTransform(286.25,37.65);

	this.shape_1226 = new cjs.Shape();
	this.shape_1226.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1226.setTransform(281,36.175);

	this.shape_1227 = new cjs.Shape();
	this.shape_1227.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_1227.setTransform(277.7,36.325);

	this.shape_1228 = new cjs.Shape();
	this.shape_1228.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1228.setTransform(272.775,37.65);

	this.shape_1229 = new cjs.Shape();
	this.shape_1229.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1229.setTransform(262.75,37.625);

	this.shape_1230 = new cjs.Shape();
	this.shape_1230.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1230.setTransform(257.425,37.6);

	this.shape_1231 = new cjs.Shape();
	this.shape_1231.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFACADQAEADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1231.setTransform(251,37.625);

	this.shape_1232 = new cjs.Shape();
	this.shape_1232.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAFgRASAAQANAAAHAIQAJAIAAARQAAAQgJAJQgHAJgNAAQgRAAgFgPIAAAlgAgNgbQgFAFAAAKIAAACQgBAVATAAQAIAAAGgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_1232.setTransform(244.05,38.775);

	this.shape_1233 = new cjs.Shape();
	this.shape_1233.graphics.f("#000000").s().p("AgRAyQAWgTAAgfQAAgegWgTIAGgIQAdAVAAAkQAAAmgdAUg");
	this.shape_1233.setTransform(233.825,37.175);

	this.shape_1234 = new cjs.Shape();
	this.shape_1234.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1234.setTransform(228.725,37.625);

	this.shape_1235 = new cjs.Shape();
	this.shape_1235.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgPAJgJQAJgJAPAAQAQAAAJAJQAJAIgBAQQABARgJAJQgJAIgQAAQgPAAgJgIgAgTABQgBAWAUgBQAUAAAAgWQAAgVgUgBQgUAAABAXg");
	this.shape_1235.setTransform(221.65,37.65);

	this.shape_1236 = new cjs.Shape();
	this.shape_1236.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1236.setTransform(214.575,36.725);

	this.shape_1237 = new cjs.Shape();
	this.shape_1237.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1237.setTransform(207.775,37.575);

	this.shape_1238 = new cjs.Shape();
	this.shape_1238.graphics.f("#000000").s().p("AgeAAQAAgPAJgJQAKgJANAAQANAAAIAIQAHAHABAOIAAAGIgvAAQAAAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_1238.setTransform(200.25,37.65);

	this.shape_1239 = new cjs.Shape();
	this.shape_1239.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1239.setTransform(192.675,37.725);

	this.shape_1240 = new cjs.Shape();
	this.shape_1240.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1240.setTransform(185.625,37.65);

	this.shape_1241 = new cjs.Shape();
	this.shape_1241.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1241.setTransform(179.225,37.625);

	this.shape_1242 = new cjs.Shape();
	this.shape_1242.graphics.f("#000000").s().p("AgeAAQABgPAIgJQAKgJANAAQANAAAIAIQAHAHABAOIAAAGIgvAAQAAAMAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQggAAgBgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_1242.setTransform(172.45,37.65);

	this.shape_1243 = new cjs.Shape();
	this.shape_1243.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_1243.setTransform(164.625,36.4);

	this.shape_1244 = new cjs.Shape();
	this.shape_1244.graphics.f("#000000").s().p("AggAsIAAgLIAIABQAHAAAEgDQAEgDADgIIgchAIAPAAIAUA0IATg0IAOAAIgaBAQgGANgFAGQgIAGgLAAIgKgBg");
	this.shape_1244.setTransform(154.05,38.925);

	this.shape_1245 = new cjs.Shape();
	this.shape_1245.graphics.f("#000000").s().p("AgdAAQAAgPAJgJQAIgJAOAAQAOAAAHAIQAIAHgBAOIAAAGIgvAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1245.setTransform(143.6,37.65);

	this.shape_1246 = new cjs.Shape();
	this.shape_1246.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1246.setTransform(136.825,36.725);

	this.shape_1247 = new cjs.Shape();
	this.shape_1247.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1247.setTransform(131.675,37.6);

	this.shape_1248 = new cjs.Shape();
	this.shape_1248.graphics.f("#000000").s().p("AgYAaQgJgJABgRQgBgPAJgJQAJgJAPAAQAQAAAIAJQAKAIgBAQQABARgKAJQgIAIgQAAQgPAAgJgIgAgUABQAAAWAUgBQAUAAAAgWQAAgVgUgBQgUAAAAAXg");
	this.shape_1248.setTransform(125,37.65);

	this.shape_1249 = new cjs.Shape();
	this.shape_1249.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAFgRASAAQANAAAHAIQAIAIABARQgBAQgIAJQgIAJgMAAQgQAAgHgPIAAAlgAgNgbQgFAFgBAKIAAACQAAAVATAAQAJAAAFgFQAFgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_1249.setTransform(117.35,38.775);

	this.shape_1250 = new cjs.Shape();
	this.shape_1250.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1250.setTransform(109.925,37.625);

	this.shape_1251 = new cjs.Shape();
	this.shape_1251.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1251.setTransform(102.925,37.575);

	this.shape_1252 = new cjs.Shape();
	this.shape_1252.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgGgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1252.setTransform(95.35,37.625);

	this.shape_1253 = new cjs.Shape();
	this.shape_1253.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1253.setTransform(90.025,37.6);

	this.shape_1254 = new cjs.Shape();
	this.shape_1254.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1254.setTransform(84.025,36.725);

	this.shape_1255 = new cjs.Shape();
	this.shape_1255.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgJAjg");
	this.shape_1255.setTransform(76.15,41.2);

	this.shape_1256 = new cjs.Shape();
	this.shape_1256.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1256.setTransform(71.575,37.625);

	this.shape_1257 = new cjs.Shape();
	this.shape_1257.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgJQAJgJAPAAQAQAAAJAJQAJAIAAAQQAAARgJAJQgJAIgQAAQgPAAgJgIgAgTABQgBAWAUgBQAUAAAAgWQAAgVgUgBQgUAAABAXg");
	this.shape_1257.setTransform(64.5,37.65);

	this.shape_1258 = new cjs.Shape();
	this.shape_1258.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1258.setTransform(57.425,36.725);

	this.shape_1259 = new cjs.Shape();
	this.shape_1259.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1259.setTransform(51.225,37.625);

	this.shape_1260 = new cjs.Shape();
	this.shape_1260.graphics.f("#000000").s().p("AgdAAQgBgPAJgJQAKgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_1260.setTransform(44.45,37.65);

	this.shape_1261 = new cjs.Shape();
	this.shape_1261.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1261.setTransform(36.875,37.725);

	this.shape_1262 = new cjs.Shape();
	this.shape_1262.graphics.f("#000000").s().p("AgfAtIAAhYIAMAAIAAAQQAGgRARAAQAMAAAIAIQAIAIAAARQAAAQgIAJQgIAJgMAAQgRAAgGgPIAAAlgAgNgbQgGAFAAAKIAAACQABAVASAAQAJAAAEgFQAGgGAAgKQAAgXgTAAQgIAAgFAGg");
	this.shape_1262.setTransform(29.35,38.775);

	this.shape_1263 = new cjs.Shape();
	this.shape_1263.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgNAAQgRAAABAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgNAAIAAhAIAMAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAABAZIAAAog");
	this.shape_1263.setTransform(19.4,37.575);

	this.shape_1264 = new cjs.Shape();
	this.shape_1264.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1264.setTransform(11.8,36.175);

	this.shape_1265 = new cjs.Shape();
	this.shape_1265.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1265.setTransform(947.325,19.625);

	this.shape_1266 = new cjs.Shape();
	this.shape_1266.graphics.f("#000000").s().p("AgYAaQgIgJAAgRQAAgPAIgJQAJgJAPAAQAQAAAIAJQAJAIAAAQQAAARgJAJQgIAIgQAAQgPAAgJgIgAgUABQABAWATgBQAUAAAAgWQAAgVgUgBQgTAAgBAXg");
	this.shape_1266.setTransform(940.25,19.65);

	this.shape_1267 = new cjs.Shape();
	this.shape_1267.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_1267.setTransform(932.125,18.4);

	this.shape_1268 = new cjs.Shape();
	this.shape_1268.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1268.setTransform(926.7,18.175);

	this.shape_1269 = new cjs.Shape();
	this.shape_1269.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1269.setTransform(921.025,19.725);

	this.shape_1270 = new cjs.Shape();
	this.shape_1270.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_1270.setTransform(915.65,18.325);

	this.shape_1271 = new cjs.Shape();
	this.shape_1271.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1271.setTransform(910.725,19.65);

	this.shape_1272 = new cjs.Shape();
	this.shape_1272.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1272.setTransform(903.725,19.575);

	this.shape_1273 = new cjs.Shape();
	this.shape_1273.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1273.setTransform(898.1,18.175);

	this.shape_1274 = new cjs.Shape();
	this.shape_1274.graphics.f("#000000").s().p("AgRAAQAAgkAdgVIAGAIQgWATAAAeQAAAfAWATIgGAIQgdgUAAgmg");
	this.shape_1274.setTransform(894.5,19.175);

	this.shape_1275 = new cjs.Shape();
	this.shape_1275.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1275.setTransform(885.325,19.625);

	this.shape_1276 = new cjs.Shape();
	this.shape_1276.graphics.f("#000000").s().p("AgdAAQAAgPAJgJQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQghAAABgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1276.setTransform(878.55,19.65);

	this.shape_1277 = new cjs.Shape();
	this.shape_1277.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1277.setTransform(872.825,19.6);

	this.shape_1278 = new cjs.Shape();
	this.shape_1278.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQABAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1278.setTransform(866.4,19.625);

	this.shape_1279 = new cjs.Shape();
	this.shape_1279.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAIgJAOAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1279.setTransform(859.65,19.65);

	this.shape_1280 = new cjs.Shape();
	this.shape_1280.graphics.f("#000000").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_1280.setTransform(854.45,18.325);

	this.shape_1281 = new cjs.Shape();
	this.shape_1281.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgGAPgQAAQgKAAgFgFgAgPAOQAAAFAEADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1281.setTransform(849.2,19.625);

	this.shape_1282 = new cjs.Shape();
	this.shape_1282.graphics.f("#000000").s().p("AggAqIAAhTIAgAAQAfAAAAAVQAAAPgPAFQARADAAARQAAAWgeAAgAgTAfIAUAAQASAAAAgNQAAgOgSAAIgUAAgAgTgFIATAAQARAAAAgNQAAgMgRAAIgTAAg");
	this.shape_1282.setTransform(842.2,18.675);

	this.shape_1283 = new cjs.Shape();
	this.shape_1283.graphics.f("#000000").s().p("AggAsIAAgLIAIABQAHAAAEgDQAEgDADgIIgbhAIAOAAIAUA0IATg0IAPAAIgbBAQgFANgHAGQgGAGgNAAIgJgBg");
	this.shape_1283.setTransform(831,20.925);

	this.shape_1284 = new cjs.Shape();
	this.shape_1284.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgPAOQABAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1284.setTransform(820.5,19.625);

	this.shape_1285 = new cjs.Shape();
	this.shape_1285.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_1285.setTransform(815.7,18.325);

	this.shape_1286 = new cjs.Shape();
	this.shape_1286.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1286.setTransform(810.075,19.725);

	this.shape_1287 = new cjs.Shape();
	this.shape_1287.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1287.setTransform(803.125,19.625);

	this.shape_1288 = new cjs.Shape();
	this.shape_1288.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1288.setTransform(796.125,19.575);

	this.shape_1289 = new cjs.Shape();
	this.shape_1289.graphics.f("#000000").s().p("AgLAuIAAhAIANAAIAABAgAgMgcIAKgRIAQAAIgOARg");
	this.shape_1289.setTransform(791,18.325);

	this.shape_1290 = new cjs.Shape();
	this.shape_1290.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1290.setTransform(785.025,19.575);

	this.shape_1291 = new cjs.Shape();
	this.shape_1291.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_1291.setTransform(777.5,19.65);

	this.shape_1292 = new cjs.Shape();
	this.shape_1292.graphics.f("#000000").s().p("AgfAqIAAhTIAgAAQAfAAAAAcQAAANgIAHQgIAHgOAAIgTAAIAAAcgAgRACIARAAQASAAAAgPQAAgRgSAAIgRAAg");
	this.shape_1292.setTransform(770.175,18.675);

	this.shape_1293 = new cjs.Shape();
	this.shape_1293.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1293.setTransform(758.925,19.575);

	this.shape_1294 = new cjs.Shape();
	this.shape_1294.graphics.f("#000000").s().p("AgdAAQgBgPAJgJQAKgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAGAFAKgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgRAAQgQAAgDARIAkAAIAAAAg");
	this.shape_1294.setTransform(751.4,19.65);

	this.shape_1295 = new cjs.Shape();
	this.shape_1295.graphics.f("#000000").s().p("AgMAkQgKgHgCgPIgLAAIACgKIAHAAIAAgEIAAgDIgJAAIACgKIAJAAQACgOAKgIQAKgIAOAAQANAAALAGIAAASQgKgHgMAAQgIAAgEADQgEADgDAHIAWAAIAAAKIgXAAIAAADIAAAEIAXAAIAAAKIgWAAQADAHADADQAFADAIAAQAHAAAFgCIALgFIAAARIgLAFQgGACgIAAQgPAAgJgIg");
	this.shape_1295.setTransform(740.35,18.675);

	this.shape_1296 = new cjs.Shape();
	this.shape_1296.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1296.setTransform(732.025,18.675);

	this.shape_1297 = new cjs.Shape();
	this.shape_1297.graphics.f("#000000").s().p("AgRAqIgNgEIABgSQAGADAHABIANACQAHAAAEgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIAOAAQAEAAAEgCQAEgCgBgEQAAgEgDgDQgFgCgHAAQgNAAgKAFIAAgSQALgFAPAAQAKAAAIADQAHADAEAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAKABADAFQAFAFAAAHQAAAIgEAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_1297.setTransform(724.2,18.675);

	this.shape_1298 = new cjs.Shape();
	this.shape_1298.graphics.f("#000000").s().p("AgUAqIAehCIgpAAIAAgRIA/AAIAAAOIggBFg");
	this.shape_1298.setTransform(716.775,18.675);

	this.shape_1299 = new cjs.Shape();
	this.shape_1299.graphics.f("#000000").s().p("AgIAJQgEgEAAgFQAAgFAEgDQACgDAGAAQAGAAAEADQADADAAAFQAAAFgDAEQgEADgGAAQgGAAgCgDg");
	this.shape_1299.setTransform(711.3,21.8);

	this.shape_1300 = new cjs.Shape();
	this.shape_1300.graphics.f("#000000").s().p("AgRAqIgOgEIACgSQAGADAHABIANACQAGAAAFgDQADgCAAgFQAAgIgNAAIgOAAIAAgQIANAAQAGAAADgCQAEgCAAgEQAAgEgFgDQgDgCgHAAQgNAAgLAFIAAgSQALgFAOAAQALAAAHADQAJADADAFQAEAFAAAHQAAAHgEAFQgEAFgIADQAJABAFAFQADAFAAAHQABAIgEAFQgEAGgIADQgIAEgKAAQgIAAgHgCg");
	this.shape_1300.setTransform(705.8,18.675);

	this.shape_1301 = new cjs.Shape();
	this.shape_1301.graphics.f("#000000").s().p("AgeArIAAgQIAYgVIAIgIIAFgHIABgGQAAgFgDgCQgDgCgFAAQgHAAgHACQgHACgGAEIAAgSQAHgDAGgCQAIgDAJAAQAJAAAHAEQAGADAEAFQACAFAAAHQABAHgDAFQgDAGgEAFIgMALIgKAJIAiAAIAAASg");
	this.shape_1301.setTransform(698.45,18.6);

	this.shape_1302 = new cjs.Shape();
	this.shape_1302.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAIgDQAIgEAIgBQAPABAHAHQAIAJAAAOIAAAJIgsAAQABAFACADQACADAEABQAEABAGAAQAHAAAGgBQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgKgIgAAOgGQAAgNgMAAQgFAAgEADQgEADgBAHIAaAAIAAAAg");
	this.shape_1302.setTransform(687.8,19.6);

	this.shape_1303 = new cjs.Shape();
	this.shape_1303.graphics.f("#000000").s().p("AgaAmQgIgIABgRQAAgLADgIQAEgHAGgEQAGgEAJgBQAOAAAGAOIAAglIATAAIAABaIgSAAIAAgPQgFAQgQAAQgNAAgIgIgAgOAMQAAAKAEAEQAEAEAGAAQAHAAAFgEQADgFAAgIIAAgBQAAgIgDgEQgEgFgIAAQgOAAAAARg");
	this.shape_1303.setTransform(679.85,18.4);

	this.shape_1304 = new cjs.Shape();
	this.shape_1304.graphics.f("#000000").s().p("AgQAhQgGgBgFgEIAAgPQAFADAGABQAHACAHAAQALAAAAgFQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAQgBgBgFgBIgJgCQgJgBgFgFQgGgDAAgJQAAgKAIgGQAGgFAOgBQAHAAAHACIALADIgBARIgKgFQgHgBgGAAQgFAAgCABQgCACgBADQAAAAABABQAAAAAAABQAAAAABAAQAAABAAAAQACACAEAAIAIABQAIABAEADQAFACACACQACAEAAAGQAAALgHAFQgIAHgOgBQgHABgIgCg");
	this.shape_1304.setTransform(669.4,19.6);

	this.shape_1305 = new cjs.Shape();
	this.shape_1305.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgJAGgFQAHgEALAAIAMAAIACgBIABgDIAAgCQABgDgEgCQgDgCgFAAQgHAAgGACIgLAEIAAgSIANgDQAGgCAHAAQAOABAIAFQAHAHAAALIAAArIgTAAIAAgMQgEANgQAAQgJAAgGgFgAgJAIQgCACAAAEQAAADACACQADACAEAAQACAAADgCQAEgBABgDQACgDAAgFIAAgBIgLAAQgFAAgDACg");
	this.shape_1305.setTransform(662.45,19.6);

	this.shape_1306 = new cjs.Shape();
	this.shape_1306.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDACQgDAEgGAAQgLAAAAgMg");
	this.shape_1306.setTransform(657.225,18.1);

	this.shape_1307 = new cjs.Shape();
	this.shape_1307.graphics.f("#000000").s().p("AgSAaQgJgJABgRQgBgQAJgJQAJgIAQgBQAGAAAFACIAIADIAAARQgHgFgKAAQgJAAgDAEQgFAFAAAIQAAASARAAQAFAAAFgCQAEAAAEgDIAAAQQgEADgFABQgFACgGgBQgQAAgJgIg");
	this.shape_1307.setTransform(652.1,19.6);

	this.shape_1308 = new cjs.Shape();
	this.shape_1308.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1308.setTransform(645.125,19.525);

	this.shape_1309 = new cjs.Shape();
	this.shape_1309.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgJAGgFQAHgEALAAIAMAAIADgBIAAgDIAAgCQAAgDgDgCQgDgCgFAAQgHAAgGACIgKAEIAAgSIAMgDQAGgCAIAAQAOABAGAFQAIAHAAALIAAArIgTAAIAAgMQgEANgPAAQgKAAgGgFgAgJAIQgCACAAAEQAAADACACQACACAEAAQAEAAACgCQADgBADgDQABgDAAgFIAAgBIgLAAQgGAAgCACg");
	this.shape_1309.setTransform(637.5,19.6);

	this.shape_1310 = new cjs.Shape();
	this.shape_1310.graphics.f("#000000").s().p("AAMAiIAAglQAAgHgDgDQgCgDgGAAQgFAAgEAFQgDAEAAAIIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAGAHQAFAGAAALIAAArg");
	this.shape_1310.setTransform(630.375,19.525);

	this.shape_1311 = new cjs.Shape();
	this.shape_1311.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDACQgDAEgGAAQgLAAAAgMg");
	this.shape_1311.setTransform(624.525,18.1);

	this.shape_1312 = new cjs.Shape();
	this.shape_1312.graphics.f("#000000").s().p("AgQAvIAAgxIgKAAIAAgQIAGAAIADAAIABgDIAAgBQAAgHADgFQADgGAGgDQAGgDAIAAIAKAAIAHACIAAAQIgGgCIgHgBQgGAAgDADQgDADAAAFIAAACIAWAAIAAAQIgWAAIAAAxg");
	this.shape_1312.setTransform(619.975,18.175);

	this.shape_1313 = new cjs.Shape();
	this.shape_1313.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDACQgDAEgGAAQgLAAAAgMg");
	this.shape_1313.setTransform(611.775,18.1);

	this.shape_1314 = new cjs.Shape();
	this.shape_1314.graphics.f("#000000").s().p("AgQAhQgGgBgEgEIAAgPQAEADAGABQAHACAHAAQALAAAAgFQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQgCgBgFgBIgJgCQgJgBgGgFQgEgDAAgJQgBgKAIgGQAGgFAOgBQAIAAAGACIALADIgBARIgKgFQgHgBgGAAQgFAAgCABQgCACAAADQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQACACAEAAIAIABQAIABAEADQAFACACACQADAEgBAGQABALgJAFQgHAHgNgBQgIABgIgCg");
	this.shape_1314.setTransform(606.65,19.6);

	this.shape_1315 = new cjs.Shape();
	this.shape_1315.graphics.f("#000000").s().p("AgRAfQgIgEgFgIQgEgIAAgLQAAgKAEgIQAFgIAIgDQAHgEAKgBQALABAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgJAAgIgDgAgKgMQgFAFAAAHQABAJADAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgDAFg");
	this.shape_1315.setTransform(596.1,19.6);

	this.shape_1316 = new cjs.Shape();
	this.shape_1316.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAGAAADADQADADAAAFQAAAGgDACQgDAEgGAAQgLAAAAgMg");
	this.shape_1316.setTransform(590.275,18.1);

	this.shape_1317 = new cjs.Shape();
	this.shape_1317.graphics.f("#000000").s().p("AgSAaQgJgJAAgRQAAgQAJgJQAJgIAQgBQAFAAAFACIAJADIAAARQgHgFgLAAQgIAAgDAEQgFAFAAAIQAAASAQAAQAGAAAFgCQAEAAAEgDIAAAQQgDADgGABQgFACgGgBQgQAAgJgIg");
	this.shape_1317.setTransform(585.15,19.6);

	this.shape_1318 = new cjs.Shape();
	this.shape_1318.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgKAFgIQAEgIAIgDQAHgEAJgBQAPABAHAHQAIAJAAAOIAAAJIgsAAQABAFACADQACADAEABQADABAHAAQAHAAAGgBQAGgBAEgCIAAAOQgEACgHACQgHACgIgBQgQAAgKgIgAAOgGQABgNgNAAQgGAAgDADQgEADgBAHIAaAAIAAAAg");
	this.shape_1318.setTransform(578.35,19.6);

	this.shape_1319 = new cjs.Shape();
	this.shape_1319.graphics.f("#000000").s().p("AgTAhIAAhBIASAAIAAATQACgKAFgEQAGgGAIABIAAAUQgGAAgFACQgEABgDADQgCAEAAAFIAAAeg");
	this.shape_1319.setTransform(572.375,19.55);

	this.shape_1320 = new cjs.Shape();
	this.shape_1320.graphics.f("#000000").s().p("AghAqIAAhTIAhAAQASAAAIAHQAIAIAAAOQAAAKgEAFQgEAHgHADQgHAEgJAAIgQAAIAAAZgAgNAAIANAAQAHAAADgCQAEgEAAgGQAAgGgDgDQgEgDgHAAIgNAAg");
	this.shape_1320.setTransform(565.675,18.675);

	this.shape_1321 = new cjs.Shape();
	this.shape_1321.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1321.setTransform(554.425,19.575);

	this.shape_1322 = new cjs.Shape();
	this.shape_1322.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgPAJgJQAJgJAPAAQAQAAAJAJQAIAIABAQQgBARgIAJQgJAIgQAAQgPAAgJgIgAgTABQAAAWATgBQAUAAAAgWQAAgVgUgBQgTAAAAAXg");
	this.shape_1322.setTransform(546.6,19.65);

	this.shape_1323 = new cjs.Shape();
	this.shape_1323.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1323.setTransform(539.425,19.65);

	this.shape_1324 = new cjs.Shape();
	this.shape_1324.graphics.f("#000000").s().p("AAEAqIAAgQIgrAAIAAgPIAmg0IAZAAIAAAzIAQAAIAAAQIgQAAIAAAQgAgSAKIAWAAIAAghg");
	this.shape_1324.setTransform(528.6,18.675);

	this.shape_1325 = new cjs.Shape();
	this.shape_1325.graphics.f("#000000").s().p("AgIAJQgEgEAAgFQAAgFAEgDQACgDAGAAQAGAAAEADQADADAAAFQAAAFgDAEQgEADgGAAQgGAAgCgDg");
	this.shape_1325.setTransform(522.3,21.8);

	this.shape_1326 = new cjs.Shape();
	this.shape_1326.graphics.f("#000000").s().p("AgYAjQgLgKAAgXQAAgMAFgLQAEgKAJgGQAJgGANAAQAPAAAJAFIAAASQgFgDgFgBIgMgBQgKAAgGAGQgFAHgBAMQADgGAGgDQAGgDAGAAQAJAAAHADQAHADADAGQAEAGAAAIQAAAJgEAGQgEAHgIAEQgHAEgKAAQgRAAgKgJgAgKAFQgEADAAAGQAAAGAEAEQAEAEAGAAQAIAAAEgEQAEgDAAgHQAAgGgEgDQgDgDgJAAQgGAAgEADg");
	this.shape_1326.setTransform(516.325,18.675);

	this.shape_1327 = new cjs.Shape();
	this.shape_1327.graphics.f("#000000").s().p("AgMAkQgJgHgDgPIgMAAIADgKIAHAAIAAgEIAAgDIgKAAIADgKIAJAAQACgOALgIQAJgIAOAAQAOAAAJAGIAAASQgJgHgMAAQgHAAgFADQgEADgCAHIAVAAIAAAKIgXAAIAAADIAAAEIAXAAIAAAKIgVAAQACAHADADQAFADAIAAQAHAAAFgCIAKgFIAAARIgKAFQgGACgIAAQgOAAgKgIg");
	this.shape_1327.setTransform(507.95,18.675);

	this.shape_1328 = new cjs.Shape();
	this.shape_1328.graphics.f("#000000").s().p("AgYAjQgLgKAAgXQAAgMAFgLQAEgKAJgGQAJgGANAAQAPAAAJAFIAAASQgFgDgFgBIgMgBQgKAAgGAGQgFAHgBAMQADgGAGgDQAGgDAGAAQAJAAAHADQAHADADAGQAEAGAAAIQAAAJgEAGQgEAHgIAEQgHAEgKAAQgRAAgKgJgAgKAFQgEADAAAGQAAAGAEAEQAEAEAGAAQAIAAAEgEQAEgDAAgHQAAgGgEgDQgDgDgJAAQgGAAgEADg");
	this.shape_1328.setTransform(496.475,18.675);

	this.shape_1329 = new cjs.Shape();
	this.shape_1329.graphics.f("#000000").s().p("AgJAqIAAhBIgbAAIAAgSIBJAAIAAASIgbAAIAABBg");
	this.shape_1329.setTransform(488.25,18.675);

	this.shape_1330 = new cjs.Shape();
	this.shape_1330.graphics.f("#000000").s().p("AAeAqIAAg5IgYA5IgKAAIgZg5IAAA5IgTAAIAAhTIAbAAIAVA1IAWg1IAbAAIAABTg");
	this.shape_1330.setTransform(478.375,18.675);

	this.shape_1331 = new cjs.Shape();
	this.shape_1331.graphics.f("#000000").s().p("AgSAqQgHgCgGgDIAAgTQAGAEAHACQAIACAIAAQAHAAAEgCQAFgCAAgEIgBgEIgEgDIgIgBIgKgDQgYgDAAgUQABgIAEgGQAEgGAHgDQAJgEAJAAQAJAAAIACIANAFIgCASIgNgFQgHgCgIAAQgGAAgEACQgDADAAAEQAAADACACIAIACIALACQANACAFAFQAHAGAAAKQAAAOgKAHQgJAHgQAAQgJAAgIgCg");
	this.shape_1331.setTransform(465.45,18.675);

	this.shape_1332 = new cjs.Shape();
	this.shape_1332.graphics.f("#000000").s().p("AgWA0IAchnIARAAIgdBng");
	this.shape_1332.setTransform(459.375,18.85);

	this.shape_1333 = new cjs.Shape();
	this.shape_1333.graphics.f("#000000").s().p("AgSAqQgHgCgGgDIAAgTQAGAEAHACQAIACAIAAQAHAAAEgCQAFgCAAgEIgBgEIgEgDIgIgBIgKgDQgYgDAAgUQABgIAEgGQAEgGAHgDQAJgEAJAAQAJAAAIACIANAFIgCASIgNgFQgHgCgIAAQgGAAgEACQgDADAAAEQAAADACACIAIACIALACQANACAFAFQAHAGAAAKQAAAOgKAHQgJAHgQAAQgJAAgIgCg");
	this.shape_1333.setTransform(453.3,18.675);

	this.shape_1334 = new cjs.Shape();
	this.shape_1334.graphics.f("#000000").s().p("AgkAqIAAhTIAeAAQAUAAALAKQAMALAAAUQAAAVgMALQgMAKgTAAgAgQAZIAKAAQAHAAAFgDQAFgCADgGQACgFAAgJQAAgIgCgFQgDgGgFgCQgFgDgHAAIgKAAg");
	this.shape_1334.setTransform(441.975,18.675);

	this.shape_1335 = new cjs.Shape();
	this.shape_1335.graphics.f("#000000").s().p("AgJAqIAAhBIgaAAIAAgSIBIAAIAAASIgbAAIAABBg");
	this.shape_1335.setTransform(433.3,18.675);

	this.shape_1336 = new cjs.Shape();
	this.shape_1336.graphics.f("#000000").s().p("AgRApIgOgDIACgSIANADIANACQAHAAAEgDQAEgCAAgHQAAgFgGgDQgFgCgJgBIgKABIgKABIAAguIA4AAIAAASIgmAAIAAAOIAKgCQAQABAIAGQAIAGAAAMQAAAKgEAGQgEAHgIADQgIAEgKAAIgPgCg");
	this.shape_1336.setTransform(422.275,18.75);

	this.shape_1337 = new cjs.Shape();
	this.shape_1337.graphics.f("#000000").s().p("AgJAJQgDgEAAgFQAAgFADgDQADgDAGAAQAGAAADADQAEADAAAFQAAAFgEAEQgDADgGAAQgGAAgDgDg");
	this.shape_1337.setTransform(416.5,21.8);

	this.shape_1338 = new cjs.Shape();
	this.shape_1338.graphics.f("#000000").s().p("AACAqIAAg9IgXADIAAgSIAqgHIAABTg");
	this.shape_1338.setTransform(411.5,18.675);

	this.shape_1339 = new cjs.Shape();
	this.shape_1339.graphics.f("#000000").s().p("AgOAqIgahTIAVAAIATBDIAVhDIAUAAIgcBTg");
	this.shape_1339.setTransform(401.3,18.675);

	this.shape_1340 = new cjs.Shape();
	this.shape_1340.graphics.f("#000000").s().p("AgMAnQgJgFgGgKQgEgKAAgOQAAgNAEgKQAGgJAJgGQAIgFAMAAQAOAAAJAGIAAATQgJgHgMAAQgKAAgFAHQgGAGAAAMQAAAOAGAGQAFAGAKAAIAJgBQAEgBACgCIAIgEIAAATIgLAFQgGACgIAAQgMAAgIgFg");
	this.shape_1340.setTransform(393.1,18.675);

	this.shape_1341 = new cjs.Shape();
	this.shape_1341.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1341.setTransform(381.775,18.675);

	this.shape_1342 = new cjs.Shape();
	this.shape_1342.graphics.f("#000000").s().p("AgTAnQgIgFgEgKQgFgKAAgOQAAgNAFgJQAEgKAIgFQAJgGAKAAQAMAAAIAGQAIAFAEAJQAFAKAAANQAAAOgFAKQgEAJgIAGQgJAFgLAAQgLAAgIgFgAgLgTQgEAHAAAMQAAAaAPAAQAIAAAFgGQAEgHAAgNQAAgMgFgHQgEgGgIAAQgHAAgEAGg");
	this.shape_1342.setTransform(373.325,18.675);

	this.shape_1343 = new cjs.Shape();
	this.shape_1343.graphics.f("#000000").s().p("AACAqIAAg9IgWADIAAgSIAqgHIAABTg");
	this.shape_1343.setTransform(366,18.675);

	this.shape_1344 = new cjs.Shape();
	this.shape_1344.graphics.f("#000000").s().p("AACAqIAAg9IgWADIAAgSIAqgHIAABTg");
	this.shape_1344.setTransform(357,18.675);

	this.shape_1345 = new cjs.Shape();
	this.shape_1345.graphics.f("#000000").s().p("AAeAqIAAg5IgYA5IgKAAIgZg5IAAA5IgTAAIAAhTIAbAAIAVA1IAWg1IAbAAIAABTg");
	this.shape_1345.setTransform(348.625,18.675);

	this.shape_1346 = new cjs.Shape();
	this.shape_1346.graphics.f("#000000").s().p("AgSAfQgHgEgEgIQgFgIAAgLQAAgKAFgIQAEgIAHgDQAJgEAJgBQALABAHAEQAJADAEAIQAEAIAAAKQAAALgEAIQgEAIgJAEQgHADgLAAQgJAAgJgDgAgLgMQgDAFAAAHQgBAJAEAFQADAEAIAAQAIAAAEgEQADgFAAgJQAAgHgDgFQgEgFgIAAQgHAAgEAFg");
	this.shape_1346.setTransform(335.6,19.6);

	this.shape_1347 = new cjs.Shape();
	this.shape_1347.graphics.f("#000000").s().p("AgHArQgFgEgDgIIAAAOIgTAAIAAhaIAUAAIAAAmQAFgPAPAAQANAAAIAJQAHAJABAPQgBAMgDAHQgDAIgGAFQgHADgIAAQgIAAgGgDgAgKAAQgEAEAAAHIAAABQAAAJAEAFQADAEAHAAQAHAAAEgEQAEgFAAgJQAAgRgPAAQgHAAgDAFg");
	this.shape_1347.setTransform(327.75,18.4);

	this.shape_1348 = new cjs.Shape();
	this.shape_1348.graphics.f("#000000").s().p("AAgAiIAAglQgBgHgCgDQgDgDgEAAQgHAAgCAEQgDAFAAAIIAAAhIgTAAIAAglQAAgHgDgDQgBgDgGAAQgGAAgDAEQgCAFAAAIIAAAhIgUAAIAAhBIATAAIAAAOQADgIAFgEQAFgEAHAAQAIAAAFAEQAFAEABAIQADgIAFgEQAHgEAHAAQAKAAAFAGQAGAGAAAMIAAArg");
	this.shape_1348.setTransform(317.7,19.525);

	this.shape_1349 = new cjs.Shape();
	this.shape_1349.graphics.f("#000000").s().p("AgSAfQgIgEgEgIQgEgIAAgLQAAgKAEgIQAEgIAIgDQAIgEAKgBQALABAIAEQAHADAFAIQAEAIAAAKQAAALgEAIQgFAIgHAEQgIADgLAAQgKAAgIgDgAgLgMQgDAFAAAHQgBAJAEAFQADAEAIAAQAIAAAEgEQAEgFgBgJQABgHgEgFQgDgFgJAAQgHAAgEAFg");
	this.shape_1349.setTransform(307.8,19.6);

	this.shape_1350 = new cjs.Shape();
	this.shape_1350.graphics.f("#000000").s().p("AgNAnQgIgFgFgKQgGgKAAgOQAAgNAGgKQAFgJAIgGQAJgFAMAAQANAAAKAGIAAATQgJgHgLAAQgLAAgFAHQgGAGAAAMQAAAOAGAGQAFAGALAAIAIgBQAEgBADgCIAGgEIAAATIgKAFQgGACgIAAQgMAAgJgFg");
	this.shape_1350.setTransform(300,18.675);

	this.shape_1351 = new cjs.Shape();
	this.shape_1351.graphics.f("#000000").s().p("AgRAfQgJgEgDgIQgFgIAAgLQAAgKAFgIQADgIAJgDQAIgEAJgBQALABAHAEQAJADAEAIQAEAIAAAKQAAALgEAIQgEAIgJAEQgHADgLAAQgJAAgIgDgAgKgMQgFAFAAAHQAAAJAEAFQADAEAIAAQAIAAAEgEQADgFABgJQgBgHgDgFQgEgFgIAAQgHAAgDAFg");
	this.shape_1351.setTransform(288.95,19.6);

	this.shape_1352 = new cjs.Shape();
	this.shape_1352.graphics.f("#000000").s().p("AgLAhIgZhBIAVAAIAPAwIARgwIAUAAIgaBBg");
	this.shape_1352.setTransform(281.125,19.6);

	this.shape_1353 = new cjs.Shape();
	this.shape_1353.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgKAEgIQAFgIAHgDQAJgEAIgBQAOABAJAHQAHAJAAAOIAAAJIgrAAQAAAFACADQADADAEABQADABAGAAQAHAAAGgBQAGgBAEgCIAAAOQgEACgHACQgHACgJgBQgPAAgJgIgAAPgGQAAgNgOAAQgEAAgEADQgEADAAAHIAaAAIAAAAg");
	this.shape_1353.setTransform(273.65,19.6);

	this.shape_1354 = new cjs.Shape();
	this.shape_1354.graphics.f("#000000").s().p("AgYAcQgHgGAAgMIAAgrIAUAAIAAAlQAAAHADADQADADAFAAQAFAAAEgEQADgFAAgIIAAghIATAAIAABBIgSAAIAAgOQgFAQgQAAQgLAAgFgGg");
	this.shape_1354.setTransform(266.05,19.675);

	this.shape_1355 = new cjs.Shape();
	this.shape_1355.graphics.f("#000000").s().p("AAMAqIgeg6IAAA6IgTAAIAAhTIAbAAIAeA6IAAg6IASAAIAABTg");
	this.shape_1355.setTransform(257.525,18.675);

	this.shape_1356 = new cjs.Shape();
	this.shape_1356.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1356.setTransform(246.425,19.625);

	this.shape_1357 = new cjs.Shape();
	this.shape_1357.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1357.setTransform(239.65,19.65);

	this.shape_1358 = new cjs.Shape();
	this.shape_1358.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_1358.setTransform(231.825,18.4);

	this.shape_1359 = new cjs.Shape();
	this.shape_1359.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgFAPgQAAQgKAAgFgFgAgOAOQAAAFADADQADADAGAAQAHAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1359.setTransform(224.45,19.625);

	this.shape_1360 = new cjs.Shape();
	this.shape_1360.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_1360.setTransform(217.025,18.4);

	this.shape_1361 = new cjs.Shape();
	this.shape_1361.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1361.setTransform(211.6,18.175);

	this.shape_1362 = new cjs.Shape();
	this.shape_1362.graphics.f("#000000").s().p("AgGAuIAAhbIANAAIAABbg");
	this.shape_1362.setTransform(208.3,18.325);

	this.shape_1363 = new cjs.Shape();
	this.shape_1363.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQALgGANAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQADADAGAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1363.setTransform(203.05,19.625);

	this.shape_1364 = new cjs.Shape();
	this.shape_1364.graphics.f("#000000").s().p("AgXAbQgGgGAAgMIAAgpIANAAIAAAlQAAARAPAAQAIAAAFgGQAFgGAAgKIAAggIANAAIAABAIgNAAIAAgQQgGARgRAAQgKAAgHgGg");
	this.shape_1364.setTransform(195.875,19.725);

	this.shape_1365 = new cjs.Shape();
	this.shape_1365.graphics.f("#000000").s().p("AgZAcIAAgLQAKAHAOAAQAPAAAAgKQAAgHgLgBIgKgCQgTgDAAgOQAAgJAHgFQAHgGAMAAQAOAAAKAFIgBAMQgKgGgMAAQgOAAAAAJQAAAGAKACIAKABQALACAEADQAFAEAAAIQAAAKgIAGQgHAFgMAAQgQAAgJgGg");
	this.shape_1365.setTransform(188.925,19.625);

	this.shape_1366 = new cjs.Shape();
	this.shape_1366.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1366.setTransform(181.925,19.575);

	this.shape_1367 = new cjs.Shape();
	this.shape_1367.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1367.setTransform(174.4,19.65);

	this.shape_1368 = new cjs.Shape();
	this.shape_1368.graphics.f("#000000").s().p("AAkAhIAAglQAAgRgOAAQgPAAAAAWIAAAgIgNAAIAAglQAAgRgNAAQgQAAAAAWIAAAgIgOAAIAAhAIANAAIAAAPQAGgQAQAAQAQAAAEARQAFgRARAAQAVAAAAAZIAAAog");
	this.shape_1368.setTransform(165.1,19.575);

	this.shape_1369 = new cjs.Shape();
	this.shape_1369.graphics.f("#000000").s().p("AgXAiQgKgJAAgWQAAgtAmAAQANAAAKAEIAAANQgKgGgMAAQgZAAgBAgQADgFAHgEQAHgEAHAAQAOAAAIAIQAIAGAAANQAAAMgJAIQgIAIgPAAQgQAAgJgJgAgNACQgFAEgBAIQABAIAFAFQAFAFAIAAQAKAAAFgFQAFgEAAgIQAAgQgUAAQgHAAgGADg");
	this.shape_1369.setTransform(152,18.675);

	this.shape_1370 = new cjs.Shape();
	this.shape_1370.graphics.f("#000000").s().p("AgeAlIABgNQANAHAOAAQAIAAAGgDQAFgEAAgGQAAgNgSAAIgNAAIAAgKIANAAQAGAAAFgDQAFgEAAgGQAAgGgFgDQgGgDgIAAQgOAAgLAGIAAgNQAMgFAOAAQAPAAAIAGQAJAGAAAKQAAAPgRAFQATADAAAQQAAALgJAHQgJAGgOAAQgQAAgNgGg");
	this.shape_1370.setTransform(144.325,18.675);

	this.shape_1371 = new cjs.Shape();
	this.shape_1371.graphics.f("#000000").s().p("AgeAAQABgPAIgJQAJgJAOAAQANAAAIAIQAHAHAAAOIAAAGIguAAQAAAMAFAFQAFAFALgBQAOABAKgGIAAAKQgKAGgQAAQghAAAAgigAATgGQAAgRgRAAQgQAAgCARIAjAAIAAAAg");
	this.shape_1371.setTransform(133.85,19.65);

	this.shape_1372 = new cjs.Shape();
	this.shape_1372.graphics.f("#000000").s().p("AgXAmQgIgIAAgRQAAgQAIgJQAHgJANABQAQAAAGAOIAAgnIANAAIAABaIgMAAIAAgPQgGAQgRAAQgNABgHgJgAgSANQAAAWASAAQAJAAAFgGQAFgFAAgJIAAgDQAAgVgTAAQgSAAAAAWg");
	this.shape_1372.setTransform(126.025,18.4);

	this.shape_1373 = new cjs.Shape();
	this.shape_1373.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgFgFgAgOAOQAAAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgNAAAAAKg");
	this.shape_1373.setTransform(115.45,19.625);

	this.shape_1374 = new cjs.Shape();
	this.shape_1374.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1374.setTransform(110.125,19.6);

	this.shape_1375 = new cjs.Shape();
	this.shape_1375.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1375.setTransform(103.75,19.65);

	this.shape_1376 = new cjs.Shape();
	this.shape_1376.graphics.f("#000000").s().p("AgGAvIAAhAIANAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1376.setTransform(98.5,18.175);

	this.shape_1377 = new cjs.Shape();
	this.shape_1377.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgIQAIgJAPAAQAKAAAKAFIAAAMQgIgFgLgBQgUABAAAVQAAAWAUAAQALABAJgGIAAAMQgJAFgMAAQgPAAgIgIg");
	this.shape_1377.setTransform(93.525,19.65);

	this.shape_1378 = new cjs.Shape();
	this.shape_1378.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1378.setTransform(86.525,19.575);

	this.shape_1379 = new cjs.Shape();
	this.shape_1379.graphics.f("#000000").s().p("AgWAdQgFgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgNAAgJAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgNAAIAAgOQgEAPgRAAQgKAAgGgFgAgOAOQAAAFACADQAEADAFAAQAIAAAFgFQAFgGAAgIIAAgCIgQAAQgOAAABAKg");
	this.shape_1379.setTransform(78.95,19.625);

	this.shape_1380 = new cjs.Shape();
	this.shape_1380.graphics.f("#000000").s().p("AARAhIAAglQAAgRgPAAQgIAAgFAGQgFAGAAAKIAAAgIgNAAIAAhAIANAAIAAAQQAGgRARAAQAKAAAHAGQAGAGAAANIAAAog");
	this.shape_1380.setTransform(71.975,19.575);

	this.shape_1381 = new cjs.Shape();
	this.shape_1381.graphics.f("#000000").s().p("AgFAvIAAhAIALAAIAABAgAgIgmQAAgIAIAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1381.setTransform(66.35,18.175);

	this.shape_1382 = new cjs.Shape();
	this.shape_1382.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAgBIAAgCQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_1382.setTransform(62.075,18.2);

	this.shape_1383 = new cjs.Shape();
	this.shape_1383.graphics.f("#000000").s().p("AgVAdQgGgFAAgKQAAgSAYAAIAPAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBIAAgDQAAgLgPAAQgMAAgKAFIAAgLQAMgGAMAAQAaAAAAAXIAAArIgMAAIAAgOQgFAPgRAAQgKAAgFgFgAgPAOQABAFADADQACADAHAAQAGAAAGgFQAFgGAAgIIAAgCIgQAAQgOAAAAAKg");
	this.shape_1383.setTransform(52.35,19.625);

	this.shape_1384 = new cjs.Shape();
	this.shape_1384.graphics.f("#000000").s().p("AgOAQIAAgcIgMAAIAAgKIAKAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgRIANAAIAAAUIAcAAIAAAKIgcAAIAAAaQAAARAOAAQAIAAAGgDIAAALQgIAEgJAAQgYAAAAgbg");
	this.shape_1384.setTransform(45.975,18.725);

	this.shape_1385 = new cjs.Shape();
	this.shape_1385.graphics.f("#000000").s().p("AgRAhIAAhAIAMAAIAAATQAFgUASAAIAAAOQgKAAgGAFQgGAGAAAKIAAAeg");
	this.shape_1385.setTransform(40.825,19.6);

	this.shape_1386 = new cjs.Shape();
	this.shape_1386.graphics.f("#000000").s().p("AgdAAQgBgPAKgJQAJgJANAAQAOAAAHAIQAIAHAAAOIAAAGIgwAAQABAMAFAFQAFAFALgBQANABALgGIAAAKQgLAGgPAAQggAAAAgigAATgGQAAgRgSAAQgPAAgDARIAkAAIAAAAg");
	this.shape_1386.setTransform(34.45,19.65);

	this.shape_1387 = new cjs.Shape();
	this.shape_1387.graphics.f("#000000").s().p("AgPAvIAAg1IgKAAIAAgLIAIAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAgBIAAgCQAAgLAHgHQAHgGALAAQAKAAAGADIAAALQgHgDgHAAQgOAAAAAOIAAAEIAZAAIAAALIgZAAIAAA1g");
	this.shape_1387.setTransform(28.275,18.2);

	this.shape_1388 = new cjs.Shape();
	this.shape_1388.graphics.f("#000000").s().p("AgdAhQgLgMAAgVQAAgVALgLQALgLASAAQAUAAAKALQALALgBAVQABAVgLAMQgKALgUgBQgSABgLgLgAgZAAQgBAfAaABQAbgBAAgfQAAgfgbABQgagBABAfg");
	this.shape_1388.setTransform(20.65,18.7);

	this.shape_1389 = new cjs.Shape();
	this.shape_1389.graphics.f("#000000").s().p("AAAAGIgJASIgJgHIAOgPIgUgCIADgLIATAIIgCgUIAJAAIgCAUIATgIIADALIgUACIAOAPIgJAHg");
	this.shape_1389.setTransform(13.05,16.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1389},{t:this.shape_1388},{t:this.shape_1387},{t:this.shape_1386},{t:this.shape_1385},{t:this.shape_1384},{t:this.shape_1383},{t:this.shape_1382},{t:this.shape_1381},{t:this.shape_1380},{t:this.shape_1379},{t:this.shape_1378},{t:this.shape_1377},{t:this.shape_1376},{t:this.shape_1375},{t:this.shape_1374},{t:this.shape_1373},{t:this.shape_1372},{t:this.shape_1371},{t:this.shape_1370},{t:this.shape_1369},{t:this.shape_1368},{t:this.shape_1367},{t:this.shape_1366},{t:this.shape_1365},{t:this.shape_1364},{t:this.shape_1363},{t:this.shape_1362},{t:this.shape_1361},{t:this.shape_1360},{t:this.shape_1359},{t:this.shape_1358},{t:this.shape_1357},{t:this.shape_1356},{t:this.shape_1355},{t:this.shape_1354},{t:this.shape_1353},{t:this.shape_1352},{t:this.shape_1351},{t:this.shape_1350},{t:this.shape_1349},{t:this.shape_1348},{t:this.shape_1347},{t:this.shape_1346},{t:this.shape_1345},{t:this.shape_1344},{t:this.shape_1343},{t:this.shape_1342},{t:this.shape_1341},{t:this.shape_1340},{t:this.shape_1339},{t:this.shape_1338},{t:this.shape_1337},{t:this.shape_1336},{t:this.shape_1335},{t:this.shape_1334},{t:this.shape_1333},{t:this.shape_1332},{t:this.shape_1331},{t:this.shape_1330},{t:this.shape_1329},{t:this.shape_1328},{t:this.shape_1327},{t:this.shape_1326},{t:this.shape_1325},{t:this.shape_1324},{t:this.shape_1323},{t:this.shape_1322},{t:this.shape_1321},{t:this.shape_1320},{t:this.shape_1319},{t:this.shape_1318},{t:this.shape_1317},{t:this.shape_1316},{t:this.shape_1315},{t:this.shape_1314},{t:this.shape_1313},{t:this.shape_1312},{t:this.shape_1311},{t:this.shape_1310},{t:this.shape_1309},{t:this.shape_1308},{t:this.shape_1307},{t:this.shape_1306},{t:this.shape_1305},{t:this.shape_1304},{t:this.shape_1303},{t:this.shape_1302},{t:this.shape_1301},{t:this.shape_1300},{t:this.shape_1299},{t:this.shape_1298},{t:this.shape_1297},{t:this.shape_1296},{t:this.shape_1295},{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1292},{t:this.shape_1291},{t:this.shape_1290},{t:this.shape_1289},{t:this.shape_1288},{t:this.shape_1287},{t:this.shape_1286},{t:this.shape_1285},{t:this.shape_1284},{t:this.shape_1283},{t:this.shape_1282},{t:this.shape_1281},{t:this.shape_1280},{t:this.shape_1279},{t:this.shape_1278},{t:this.shape_1277},{t:this.shape_1276},{t:this.shape_1275},{t:this.shape_1274},{t:this.shape_1273},{t:this.shape_1272},{t:this.shape_1271},{t:this.shape_1270},{t:this.shape_1269},{t:this.shape_1268},{t:this.shape_1267},{t:this.shape_1266},{t:this.shape_1265},{t:this.shape_1264},{t:this.shape_1263},{t:this.shape_1262},{t:this.shape_1261},{t:this.shape_1260},{t:this.shape_1259},{t:this.shape_1258},{t:this.shape_1257},{t:this.shape_1256},{t:this.shape_1255},{t:this.shape_1254},{t:this.shape_1253},{t:this.shape_1252},{t:this.shape_1251},{t:this.shape_1250},{t:this.shape_1249},{t:this.shape_1248},{t:this.shape_1247},{t:this.shape_1246},{t:this.shape_1245},{t:this.shape_1244},{t:this.shape_1243},{t:this.shape_1242},{t:this.shape_1241},{t:this.shape_1240},{t:this.shape_1239},{t:this.shape_1238},{t:this.shape_1237},{t:this.shape_1236},{t:this.shape_1235},{t:this.shape_1234},{t:this.shape_1233},{t:this.shape_1232},{t:this.shape_1231},{t:this.shape_1230},{t:this.shape_1229},{t:this.shape_1228},{t:this.shape_1227},{t:this.shape_1226},{t:this.shape_1225},{t:this.shape_1224},{t:this.shape_1223},{t:this.shape_1222},{t:this.shape_1221},{t:this.shape_1220},{t:this.shape_1219},{t:this.shape_1218},{t:this.shape_1217},{t:this.shape_1216},{t:this.shape_1215},{t:this.shape_1214},{t:this.shape_1213},{t:this.shape_1212},{t:this.shape_1211},{t:this.shape_1210},{t:this.shape_1209},{t:this.shape_1208},{t:this.shape_1207},{t:this.shape_1206},{t:this.shape_1205},{t:this.shape_1204},{t:this.shape_1203},{t:this.shape_1202},{t:this.shape_1201},{t:this.shape_1200},{t:this.shape_1199},{t:this.shape_1198},{t:this.shape_1197},{t:this.shape_1196},{t:this.shape_1195},{t:this.shape_1194},{t:this.shape_1193},{t:this.shape_1192},{t:this.shape_1191},{t:this.shape_1190},{t:this.shape_1189},{t:this.shape_1188},{t:this.shape_1187},{t:this.shape_1186},{t:this.shape_1185},{t:this.shape_1184},{t:this.shape_1183},{t:this.shape_1182},{t:this.shape_1181},{t:this.shape_1180},{t:this.shape_1179},{t:this.shape_1178},{t:this.shape_1177},{t:this.shape_1176},{t:this.shape_1175},{t:this.shape_1174},{t:this.shape_1173},{t:this.shape_1172},{t:this.shape_1171},{t:this.shape_1170},{t:this.shape_1169},{t:this.shape_1168},{t:this.shape_1167},{t:this.shape_1166},{t:this.shape_1165},{t:this.shape_1164},{t:this.shape_1163},{t:this.shape_1162},{t:this.shape_1161},{t:this.shape_1160},{t:this.shape_1159},{t:this.shape_1158},{t:this.shape_1157},{t:this.shape_1156},{t:this.shape_1155},{t:this.shape_1154},{t:this.shape_1153},{t:this.shape_1152},{t:this.shape_1151},{t:this.shape_1150},{t:this.shape_1149},{t:this.shape_1148},{t:this.shape_1147},{t:this.shape_1146},{t:this.shape_1145},{t:this.shape_1144},{t:this.shape_1143},{t:this.shape_1142},{t:this.shape_1141},{t:this.shape_1140},{t:this.shape_1139},{t:this.shape_1138},{t:this.shape_1137},{t:this.shape_1136},{t:this.shape_1135},{t:this.shape_1134},{t:this.shape_1133},{t:this.shape_1132},{t:this.shape_1131},{t:this.shape_1130},{t:this.shape_1129},{t:this.shape_1128},{t:this.shape_1127},{t:this.shape_1126},{t:this.shape_1125},{t:this.shape_1124},{t:this.shape_1123},{t:this.shape_1122},{t:this.shape_1121},{t:this.shape_1120},{t:this.shape_1119},{t:this.shape_1118},{t:this.shape_1117},{t:this.shape_1116},{t:this.shape_1115},{t:this.shape_1114},{t:this.shape_1113},{t:this.shape_1112},{t:this.shape_1111},{t:this.shape_1110},{t:this.shape_1109},{t:this.shape_1108},{t:this.shape_1107},{t:this.shape_1106},{t:this.shape_1105},{t:this.shape_1104},{t:this.shape_1103},{t:this.shape_1102},{t:this.shape_1101},{t:this.shape_1100},{t:this.shape_1099},{t:this.shape_1098},{t:this.shape_1097},{t:this.shape_1096},{t:this.shape_1095},{t:this.shape_1094},{t:this.shape_1093},{t:this.shape_1092},{t:this.shape_1091},{t:this.shape_1090},{t:this.shape_1089},{t:this.shape_1088},{t:this.shape_1087},{t:this.shape_1086},{t:this.shape_1085},{t:this.shape_1084},{t:this.shape_1083},{t:this.shape_1082},{t:this.shape_1081},{t:this.shape_1080},{t:this.shape_1079},{t:this.shape_1078},{t:this.shape_1077},{t:this.shape_1076},{t:this.shape_1075},{t:this.shape_1074},{t:this.shape_1073},{t:this.shape_1072},{t:this.shape_1071},{t:this.shape_1070},{t:this.shape_1069},{t:this.shape_1068},{t:this.shape_1067},{t:this.shape_1066},{t:this.shape_1065},{t:this.shape_1064},{t:this.shape_1063},{t:this.shape_1062},{t:this.shape_1061},{t:this.shape_1060},{t:this.shape_1059},{t:this.shape_1058},{t:this.shape_1057},{t:this.shape_1056},{t:this.shape_1055},{t:this.shape_1054},{t:this.shape_1053},{t:this.shape_1052},{t:this.shape_1051},{t:this.shape_1050},{t:this.shape_1049},{t:this.shape_1048},{t:this.shape_1047},{t:this.shape_1046},{t:this.shape_1045},{t:this.shape_1044},{t:this.shape_1043},{t:this.shape_1042},{t:this.shape_1041},{t:this.shape_1040},{t:this.shape_1039},{t:this.shape_1038},{t:this.shape_1037},{t:this.shape_1036},{t:this.shape_1035},{t:this.shape_1034},{t:this.shape_1033},{t:this.shape_1032},{t:this.shape_1031},{t:this.shape_1030},{t:this.shape_1029},{t:this.shape_1028},{t:this.shape_1027},{t:this.shape_1026},{t:this.shape_1025},{t:this.shape_1024},{t:this.shape_1023},{t:this.shape_1022},{t:this.shape_1021},{t:this.shape_1020},{t:this.shape_1019},{t:this.shape_1018},{t:this.shape_1017},{t:this.shape_1016},{t:this.shape_1015},{t:this.shape_1014},{t:this.shape_1013},{t:this.shape_1012},{t:this.shape_1011},{t:this.shape_1010},{t:this.shape_1009},{t:this.shape_1008},{t:this.shape_1007},{t:this.shape_1006},{t:this.shape_1005},{t:this.shape_1004},{t:this.shape_1003},{t:this.shape_1002},{t:this.shape_1001},{t:this.shape_1000},{t:this.shape_999},{t:this.shape_998},{t:this.shape_997},{t:this.shape_996},{t:this.shape_995},{t:this.shape_994},{t:this.shape_993},{t:this.shape_992},{t:this.shape_991},{t:this.shape_990},{t:this.shape_989},{t:this.shape_988},{t:this.shape_987},{t:this.shape_986},{t:this.shape_985},{t:this.shape_984},{t:this.shape_983},{t:this.shape_982},{t:this.shape_981},{t:this.shape_980},{t:this.shape_979},{t:this.shape_978},{t:this.shape_977},{t:this.shape_976},{t:this.shape_975},{t:this.shape_974},{t:this.shape_973},{t:this.shape_972},{t:this.shape_971},{t:this.shape_970},{t:this.shape_969},{t:this.shape_968},{t:this.shape_967},{t:this.shape_966},{t:this.shape_965},{t:this.shape_964},{t:this.shape_963},{t:this.shape_962},{t:this.shape_961},{t:this.shape_960},{t:this.shape_959},{t:this.shape_958},{t:this.shape_957},{t:this.shape_956},{t:this.shape_955},{t:this.shape_954},{t:this.shape_953},{t:this.shape_952},{t:this.shape_951},{t:this.shape_950},{t:this.shape_949},{t:this.shape_948},{t:this.shape_947},{t:this.shape_946},{t:this.shape_945},{t:this.shape_944},{t:this.shape_943},{t:this.shape_942},{t:this.shape_941},{t:this.shape_940},{t:this.shape_939},{t:this.shape_938},{t:this.shape_937},{t:this.shape_936},{t:this.shape_935},{t:this.shape_934},{t:this.shape_933},{t:this.shape_932},{t:this.shape_931},{t:this.shape_930},{t:this.shape_929},{t:this.shape_928},{t:this.shape_927},{t:this.shape_926},{t:this.shape_925},{t:this.shape_924},{t:this.shape_923},{t:this.shape_922},{t:this.shape_921},{t:this.shape_920},{t:this.shape_919},{t:this.shape_918},{t:this.shape_917},{t:this.shape_916},{t:this.shape_915},{t:this.shape_914},{t:this.shape_913},{t:this.shape_912},{t:this.shape_911},{t:this.shape_910},{t:this.shape_909},{t:this.shape_908},{t:this.shape_907},{t:this.shape_906},{t:this.shape_905},{t:this.shape_904},{t:this.shape_903},{t:this.shape_902},{t:this.shape_901},{t:this.shape_900},{t:this.shape_899},{t:this.shape_898},{t:this.shape_897},{t:this.shape_896},{t:this.shape_895},{t:this.shape_894},{t:this.shape_893},{t:this.shape_892},{t:this.shape_891},{t:this.shape_890},{t:this.shape_889},{t:this.shape_888},{t:this.shape_887},{t:this.shape_886},{t:this.shape_885},{t:this.shape_884},{t:this.shape_883},{t:this.shape_882},{t:this.shape_881},{t:this.shape_880},{t:this.shape_879},{t:this.shape_878},{t:this.shape_877},{t:this.shape_876},{t:this.shape_875},{t:this.shape_874},{t:this.shape_873},{t:this.shape_872},{t:this.shape_871},{t:this.shape_870},{t:this.shape_869},{t:this.shape_868},{t:this.shape_867},{t:this.shape_866},{t:this.shape_865},{t:this.shape_864},{t:this.shape_863},{t:this.shape_862},{t:this.shape_861},{t:this.shape_860},{t:this.shape_859},{t:this.shape_858},{t:this.shape_857},{t:this.shape_856},{t:this.shape_855},{t:this.shape_854},{t:this.shape_853},{t:this.shape_852},{t:this.shape_851},{t:this.shape_850},{t:this.shape_849},{t:this.shape_848},{t:this.shape_847},{t:this.shape_846},{t:this.shape_845},{t:this.shape_844},{t:this.shape_843},{t:this.shape_842},{t:this.shape_841},{t:this.shape_840},{t:this.shape_839},{t:this.shape_838},{t:this.shape_837},{t:this.shape_836},{t:this.shape_835},{t:this.shape_834},{t:this.shape_833},{t:this.shape_832},{t:this.shape_831},{t:this.shape_830},{t:this.shape_829},{t:this.shape_828},{t:this.shape_827},{t:this.shape_826},{t:this.shape_825},{t:this.shape_824},{t:this.shape_823},{t:this.shape_822},{t:this.shape_821},{t:this.shape_820},{t:this.shape_819},{t:this.shape_818},{t:this.shape_817},{t:this.shape_816},{t:this.shape_815},{t:this.shape_814},{t:this.shape_813},{t:this.shape_812},{t:this.shape_811},{t:this.shape_810},{t:this.shape_809},{t:this.shape_808},{t:this.shape_807},{t:this.shape_806},{t:this.shape_805},{t:this.shape_804},{t:this.shape_803},{t:this.shape_802},{t:this.shape_801},{t:this.shape_800},{t:this.shape_799},{t:this.shape_798},{t:this.shape_797},{t:this.shape_796},{t:this.shape_795},{t:this.shape_794},{t:this.shape_793},{t:this.shape_792},{t:this.shape_791},{t:this.shape_790},{t:this.shape_789},{t:this.shape_788},{t:this.shape_787},{t:this.shape_786},{t:this.shape_785},{t:this.shape_784},{t:this.shape_783},{t:this.shape_782},{t:this.shape_781},{t:this.shape_780},{t:this.shape_779},{t:this.shape_778},{t:this.shape_777},{t:this.shape_776},{t:this.shape_775},{t:this.shape_774},{t:this.shape_773},{t:this.shape_772},{t:this.shape_771},{t:this.shape_770},{t:this.shape_769},{t:this.shape_768},{t:this.shape_767},{t:this.shape_766},{t:this.shape_765},{t:this.shape_764},{t:this.shape_763},{t:this.shape_762},{t:this.shape_761},{t:this.shape_760},{t:this.shape_759},{t:this.shape_758},{t:this.shape_757},{t:this.shape_756},{t:this.shape_755},{t:this.shape_754},{t:this.shape_753},{t:this.shape_752},{t:this.shape_751},{t:this.shape_750},{t:this.shape_749},{t:this.shape_748},{t:this.shape_747},{t:this.shape_746},{t:this.shape_745},{t:this.shape_744},{t:this.shape_743},{t:this.shape_742},{t:this.shape_741},{t:this.shape_740},{t:this.shape_739},{t:this.shape_738},{t:this.shape_737},{t:this.shape_736},{t:this.shape_735},{t:this.shape_734},{t:this.shape_733},{t:this.shape_732},{t:this.shape_731},{t:this.shape_730},{t:this.shape_729},{t:this.shape_728},{t:this.shape_727},{t:this.shape_726},{t:this.shape_725},{t:this.shape_724},{t:this.shape_723},{t:this.shape_722},{t:this.shape_721},{t:this.shape_720},{t:this.shape_719},{t:this.shape_718},{t:this.shape_717},{t:this.shape_716},{t:this.shape_715},{t:this.shape_714},{t:this.shape_713},{t:this.shape_712},{t:this.shape_711},{t:this.shape_710},{t:this.shape_709},{t:this.shape_708},{t:this.shape_707},{t:this.shape_706},{t:this.shape_705},{t:this.shape_704},{t:this.shape_703},{t:this.shape_702},{t:this.shape_701},{t:this.shape_700},{t:this.shape_699},{t:this.shape_698},{t:this.shape_697},{t:this.shape_696},{t:this.shape_695},{t:this.shape_694},{t:this.shape_693},{t:this.shape_692},{t:this.shape_691},{t:this.shape_690},{t:this.shape_689},{t:this.shape_688},{t:this.shape_687},{t:this.shape_686},{t:this.shape_685},{t:this.shape_684},{t:this.shape_683},{t:this.shape_682},{t:this.shape_681},{t:this.shape_680},{t:this.shape_679},{t:this.shape_678},{t:this.shape_677},{t:this.shape_676},{t:this.shape_675},{t:this.shape_674},{t:this.shape_673},{t:this.shape_672},{t:this.shape_671},{t:this.shape_670},{t:this.shape_669},{t:this.shape_668},{t:this.shape_667},{t:this.shape_666},{t:this.shape_665},{t:this.shape_664},{t:this.shape_663},{t:this.shape_662},{t:this.shape_661},{t:this.shape_660},{t:this.shape_659},{t:this.shape_658},{t:this.shape_657},{t:this.shape_656},{t:this.shape_655},{t:this.shape_654},{t:this.shape_653},{t:this.shape_652},{t:this.shape_651},{t:this.shape_650},{t:this.shape_649},{t:this.shape_648},{t:this.shape_647},{t:this.shape_646},{t:this.shape_645},{t:this.shape_644},{t:this.shape_643},{t:this.shape_642},{t:this.shape_641},{t:this.shape_640},{t:this.shape_639},{t:this.shape_638},{t:this.shape_637},{t:this.shape_636},{t:this.shape_635},{t:this.shape_634},{t:this.shape_633},{t:this.shape_632},{t:this.shape_631},{t:this.shape_630},{t:this.shape_629},{t:this.shape_628},{t:this.shape_627},{t:this.shape_626},{t:this.shape_625},{t:this.shape_624},{t:this.shape_623},{t:this.shape_622},{t:this.shape_621},{t:this.shape_620},{t:this.shape_619},{t:this.shape_618},{t:this.shape_617},{t:this.shape_616},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613},{t:this.shape_612},{t:this.shape_611},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605},{t:this.shape_604},{t:this.shape_603},{t:this.shape_602},{t:this.shape_601},{t:this.shape_600},{t:this.shape_599},{t:this.shape_598},{t:this.shape_597},{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer_1
	this.shape_1390 = new cjs.Shape();
	this.shape_1390.graphics.f("rgba(255,255,255,0.698)").s().p("EhLxASwMAAAglfMCXjAAAMAAAAlfg");
	this.shape_1390.setTransform(490.05,125);

	this.timeline.addTween(cjs.Tween.get(this.shape_1390).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.legal, new cjs.Rectangle(5.1,5,970,350.6), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1
	this.instance = new lib.img1();
	this.instance.setTransform(245,68,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_1, new cjs.Rectangle(245,68,980,250), null);


(lib.hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A1PRgMAAAgi/MAqfAAAMAAAAi/g");
	this.shape.setTransform(136,112.025);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,272,224.1);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgjAqQgHgHAAgPQAAgNAJgHQAJgHARAAIAQAAIAFgBQAAgBAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBIAAgCQAAgFgFgDQgEgDgJAAQgJAAgJADQgJACgGADIAAgZIASgFQAJgCALAAQAUAAALAJQAKAIAAARIAAA/IgbAAIAAgSQgGAUgXAAQgOAAgIgIgAgNAMQgEADAAAFQAAAFADADQAEADAGAAQAEAAAFgDQAFgCACgEQADgFAAgHIAAgBIgSAAQgHAAgDADg");
	this.shape.setTransform(183.775,13.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgNA0QgKgKAAgUIAAgiIgQAAIAAgWIALAAIAEgBIABgEIAAgWIAbAAIAAAbIAkAAIAAAWIgkAAIAAAfQAAAKAEAEQAEAFAJAAQAKAAAJgEIAAAXIgLAEIgOABQgSAAgKgKg");
	this.shape_1.setTransform(174.15,12.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAxIAAhfIAbAAIAAAbQADgPAIgGQAJgIAMABIAAAeQgKAAgHACQgGACgEAEQgDAGAAAIIAAAsg");
	this.shape_2.setTransform(166.275,13.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AggAlQgOgMAAgZQABgPAGgMQAHgLALgGQALgFANAAQAVAAALAMQAMALgBAVIAAAMIhAAAQABAJAEAEQADAEAGACQAEACAKAAQAKAAAIgCQAKgCAFgDIAAAVQgFADgLADQgKACgLAAQgYAAgOgNgAAVgKQAAgTgSAAQgJAAgFAEQgEAGgCAJIAmAAIAAAAg");
	this.shape_3.setTransform(156.85,13.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgYBFIAAhJIgPAAIAAgWIAJAAIAFgBIABgEIAAgCQAAgKAEgIQAFgHAJgFQAIgFANAAIAOABIALADIAAAWIgKgCIgKAAQgIAAgFADQgEAFAAAHIAAADIAfAAIAAAWIgfAAIAABJg");
	this.shape_4.setTransform(147.7,11.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgaAsQgMgGgGgLQgGgKAAgRQAAgPAGgMQAGgLAMgGQALgFAPAAQAPAAAMAFQALAGAHALQAGAMAAAPQAAARgGAKQgHALgLAGQgMAGgPAAQgPAAgLgGgAgQgTQgGAHAAAMQABAMAFAHQAFAGALAAQAMAAAFgGQAGgGgBgNQAAgLgEgIQgGgGgMAAQgLAAgFAGg");
	this.shape_5.setTransform(137.55,13.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgkAoQgJgJAAgRIAAg+IAdAAIAAA2QAAAKAEAEQADAEAIAAQAJAAAFgGQAEgHAAgMIAAgvIAdAAIAABfIgcAAIAAgWQgHAYgYAAQgOAAgJgJg");
	this.shape_6.setTransform(121.275,13.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgOA0QgJgKAAgUIAAgiIgRAAIAAgWIAMAAIAEgBIABgEIAAgWIAbAAIAAAbIAkAAIAAAWIgkAAIAAAfQAAAKAFAEQADAFAJAAQAKAAAJgEIAAAXIgLAEIgOABQgSAAgLgKg");
	this.shape_7.setTransform(111,12.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgjAqQgHgHAAgPQAAgNAJgHQAJgHARAAIAQAAIAFgBQAAgBAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBIAAgCQAAgFgFgDQgEgDgJAAQgJAAgJADQgJACgGADIAAgZIASgFQAJgCALAAQAUAAALAJQAKAIAAARIAAA/IgbAAIAAgSQgGAUgXAAQgOAAgIgIgAgNAMQgEADAAAFQAAAFADADQAEADAGAAQAEAAAFgDQAFgCACgEQADgFAAgHIAAgBIgSAAQgHAAgDADg");
	this.shape_8.setTransform(96.425,13.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgOA0QgJgKAAgUIAAgiIgRAAIAAgWIAMAAIAEgBIABgEIAAgWIAbAAIAAAbIAkAAIAAAWIgkAAIAAAfQAAAKAFAEQADAFAJAAQALAAAIgEIAAAXIgMAEIgNABQgSAAgLgKg");
	this.shape_9.setTransform(86.8,12.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgNBGIAAhfIAbAAIAABfgAgRg0QAAgQARgBQAJAAAEAFQAFADAAAJQAAAHgFAFQgEAEgJAAQgRAAAAgQg");
	this.shape_10.setTransform(79.575,11.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgaAlQgNgNAAgYQAAgYANgNQANgMAXAAQAIAAAHACQAHABAHADIAAAYQgMgGgPgBQgMABgFAFQgIAHAAANQABAaAYAAQAJAAAGgCQAHgCAGgEIAAAYQgHADgGADQgHACgKAAQgXAAgNgNg");
	this.shape_11.setTransform(72.2,13.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgNBGIAAhfIAbAAIAABfgAgRg0QAAgQARgBQAJAAAEAFQAFADAAAJQAAAHgFAFQgEAEgJAAQgRAAAAgQg");
	this.shape_12.setTransform(64.875,11.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgNBCIAAiDIAbAAIAACDg");
	this.shape_13.setTransform(59.525,11.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgaAsQgMgGgGgLQgGgKAAgRQAAgPAGgMQAGgLAMgGQAMgFAOAAQAPAAAMAFQAMAGAFALQAHAMAAAPQAAARgHAKQgFALgMAGQgMAGgPAAQgOAAgMgGgAgQgTQgFAHAAAMQAAAMAEAHQAGAGALAAQALAAAGgGQAFgGABgNQAAgLgGgIQgFgGgMAAQgLAAgFAGg");
	this.shape_14.setTransform(51.2,13.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgbA8QgKgCgJgEIAAgbQAJAFAKADQAMADAMAAQAKAAAGgDQAHgEgBgGQAAgDgBgCQgBgCgEgCIgLgCIgQgDQgigGABgdQAAgLAFgJQAGgIALgFQAMgFAOAAQANAAAMACQALADAHAEIgCAaIgTgHQgLgDgLAAQgJAAgFAEQgFADgBAGQABAFADACQADACAJACIAQADQATADAIAHQAJAJAAAPQAAATgOAKQgOAKgXAAQgNAAgMgDg");
	this.shape_15.setTransform(39.85,12.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// border
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1.5,2,0,1).p("Av1jcIfrAAIAAG5I/rAAg");
	this.shape_16.setTransform(-0.05,-9.7,1.1,1,0,0,0,-101.4,-22.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-1,-10.7,225,46.2), null);


(lib.txt1c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// letters2c
	this.letters2c = new lib.letters2c();
	this.letters2c.name = "letters2c";

	this.timeline.addTween(cjs.Tween.get(this.letters2c).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1c, new cjs.Rectangle(0,8.1,273.3,44.5), null);


(lib.txt1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// letters2c
	this.letters2b = new lib.letters2bb();
	this.letters2b.name = "letters2b";

	this.timeline.addTween(cjs.Tween.get(this.letters2b).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1b, new cjs.Rectangle(0,-6.9,323.1,46.5), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// slash1
	this.slash1 = new lib.slash1();
	this.slash1.name = "slash1";
	this.slash1.setTransform(1,-54.45,1.8999,1.9001,0,0,0,4.2,5.9);

	this.timeline.addTween(cjs.Tween.get(this.slash1).wait(1));

	// slash1Guide
	this.slashGuide1 = new lib.slash1();
	this.slashGuide1.name = "slashGuide1";
	this.slashGuide1.setTransform(281.6,-55,1.9,1.9,0,0,0,4.7,5.6);

	this.timeline.addTween(cjs.Tween.get(this.slashGuide1).wait(1));

	// letters2
	this.letters2 = new lib.letters2();
	this.letters2.name = "letters2";
	this.letters2.setTransform(-11.8,108.75);

	this.timeline.addTween(cjs.Tween.get(this.letters2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-7,-77,298,40), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var img1 = this.img1;
		var cta = this.cta;
		var logo = this.logo;
		var logo2 = this.logo2;
		var legal = this.legal;
		
		var txt1 = this.txt1;
			var letters2 = txt1.letters2;
			var slash1 = txt1.slash1;
			var slash1Guide = txt1.slashGuide1;
		
		var txt2 = this.txt2;
			var letters2b = txt2.letters2b;
		
		var txt3 = this.txt3;
		//	var letters2c = txt3.letters2c;
		
		var offert = this.offert;
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		function getTime(){
			console.log(tl.duration());
		}
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat:-1, repeatDelay:7});
		
		var hit = this.hit;
		hit.addEventListener("mouseover", function() {
			tl.pause();
		});
		
		hit.addEventListener("mouseout", function() {
			tl.play();
		});
		
		tl
			.set([slash1Guide], { visible: false })
			.set([slash1], { alpha: 0 })
		
			.add("frame1")
			.from([img1, logo2], 1, {alpha: 0, ease: Power2.easeOut}, "frame1")
			.to([slash1], .5, { alpha:1, x:slash1Guide.x, y:slash1Guide.y, ease: Power0.easeNone}, "frame1+=1.5")
		    .from(txt1.letters2.children, .5/(txt1.letters2.children.length-1), {stagger:.5/(txt1.letters2.children.length-1), alpha:0, ease: Power0.easeNone}, "frame1+=1.5")
			.from(txt2, .75, { alpha: 0, x: "-=30", ease: Power2.easeOut}, "frame1+=2")
			.from(cta, .75, { alpha: 0, x: "-=30", ease: Power2.easeOut}, "frame1+=2.5")
		
			.add('frame2', '+=2.5')
			.to(txt2, .75, { alpha: 0, x: "+=30", ease: Power2.easeOut}, "frame2")
			.from(txt3, .5, { alpha: 0, x: "-=30", ease: Power2.easeOut}, "frame2+=0.5")
		
			.add('frame3', '+=2.5')
			.to(txt3, .5, { alpha: 0, x: "+=30", ease: Power2.easeOut}, "frame3")
			.from(offert, .75, { alpha: 0, x: "-=30", ease: Power2.easeOut}, "frame3+=0.5")
		
		
			.add("legal", "+=2.5")
			.to([offert, txt1, cta], .5, { alpha: 0, x: "+=30", ease: Power2.easeOut}, "legal")
			.from(legal, .5, {alpha:0, ease: Power2.easeOut}, "legal+=.5")
			.from(hit, .1, { y:"+="+h }, "legal+=1")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// hit
	this.hit = new lib.hit();
	this.hit.name = "hit";
	this.hit.setTransform(149.45,124.15,1,1.0444,0,0,0,136,111.7);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// logo2
	this.logo2 = new lib.logo2();
	this.logo2.name = "logo2";
	this.logo2.setTransform(490.75,220.95,0.75,0.75,0,0,0,34,30.4);

	this.timeline.addTween(cjs.Tween.get(this.logo2).wait(1));

	// legal
	this.legal = new lib.legal();
	this.legal.name = "legal";
	this.legal.setTransform(350,118,1,1,0,0,0,350,118);

	this.timeline.addTween(cjs.Tween.get(this.legal).wait(1));

	// offert
	this.offert = new lib.txt3a();
	this.offert.name = "offert";
	this.offert.setTransform(367.25,193.75,1.7999,1.7999,0,0,0,197.5,24.8);

	this.timeline.addTween(cjs.Tween.get(this.offert).wait(1));

	// txt3
	this.txt3 = new lib.txt1c();
	this.txt3.name = "txt3";
	this.txt3.setTransform(9.4,87.95,1.7249,1.7249,0,0,0,0.3,27.4);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(50.35,206.55,0.7507,0.75,0,0,0,38,8.8);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt2
	this.txt2 = new lib.txt1b();
	this.txt2.name = "txt2";
	this.txt2.setTransform(13.8,113.9,1.7249,1.7249,0,0,0,0.4,27.6);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(22.65,153.2,1.4699,1.4699,0,0,0,0.3,27.4);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(490,125,1,1,0,0,0,735,193);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(490,124.7,490,125.3);
// library properties:
lib.properties = {
	id: 'C24CD912A357430CB2AAC859A7EB09C3',
	width: 980,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"img1.jpg?1712302562182", id:"img1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C24CD912A357430CB2AAC859A7EB09C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;