(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgRAcQgIgJgBgSQABgSAIgKQAJgJAOAAQALAAAJAGIAAAGQgKgGgKAAQgKAAgHAHQgIAJAAAPQAAAPAIAIQAGAIALAAQAKAAAKgHIAAAGQgJAGgLAAQgOAAgJgJg");
	this.shape.setTransform(187.55,17.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAbAkIgIgVIgkAAIgJAVIgGAAIAdhHIAIAAIAcBHgAAQAJIgPgoIgQAoIAfAAg");
	this.shape_1.setTransform(180.65,17.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgEAkIgbhHIAHAAIAYBCIAZhCIAHAAIgcBHg");
	this.shape_2.setTransform(173.675,17.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgCAkIAAhCIgcAAIAAgFIA9AAIAAAFIgcAAIAABCg");
	this.shape_3.setTransform(166.675,17.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgaAQIgMAAIADgMIAHAAIAAgEIAAgDIgKAAIADgLIAJAAQADgPAKgIQALgJAOAAQAPAAALAGIAAAUQgKgIgNAAQgPAAgFAOIAXAAIAAALIgZAAIAAADIAAAEIAZAAIAAAMIgXAAQAEANAQAAQAMAAAMgIIAAATQgLAHgQAAQggAAgGgfg");
	this.shape_4.setTransform(155.55,16.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgcAjQgKgNAAgWQAAgVAKgMQAKgNASAAQATAAAKAMQAKANAAAVQAAAWgKANQgKAMgTAAQgSAAgKgMgAgRAAQAAAcARAAQASAAAAgcQAAgbgSAAQgRAAAAAbg");
	this.shape_5.setTransform(143.075,16.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgfAqIAAgTQALAFANAAQAXAAABgbQgDAGgGADQgGAEgIAAQgOAAgJgIQgIgGAAgOQAAgOAJgJQAKgJAQAAQASAAALAKQALAKAAAYQAAAWgKANQgLAOgVAAQgQAAgLgFgAgQgOQAAANAQAAQAHAAAEgDQAFgEAAgGQAAgHgFgEQgEgEgHAAQgQAAAAAPg");
	this.shape_6.setTransform(134.175,16.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgfAqIAAgTQALAFANAAQAXAAABgbQgDAGgGADQgGAEgIAAQgOAAgJgIQgIgGAAgOQAAgOAJgJQAKgJAQAAQASAAALAKQALAKAAAYQAAAWgKANQgLAOgVAAQgQAAgLgFgAgQgOQAAANAQAAQAHAAAEgDQAFgEAAgGQAAgHgFgEQgEgEgHAAQgQAAAAAPg");
	this.shape_7.setTransform(125.425,16.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgJAJQgEgDAAgGQAAgFAEgDQADgEAGAAQAGAAAEAEQAEADAAAFQAAAGgEADQgEAEgGAAQgGAAgDgEg");
	this.shape_8.setTransform(119.075,20.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAEAtIAAgRIguAAIAAgQIApg4IAaAAIAAA2IASAAIAAASIgSAAIAAARgAgTAKIAXAAIAAgjg");
	this.shape_9.setTransform(112.325,16.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AghAoIACgTQAOAHAOAAQAPAAAAgLQAAgJgOAAIgPAAIAAgQIAOAAQANAAAAgJQAAgKgQAAQgOAAgLAFIAAgTQAMgFAPAAQASAAAJAHQAJAHAAALQABAQgSAFQATADAAAQQAAANgJAHQgKAIgRAAQgQAAgPgHg");
	this.shape_10.setTransform(103.7,16.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgcAtIAAhZIA5AAIAAAHIgxAAIAAAhIAsAAIAAAGIgsAAIAAAkIAxAAIAAAHg");
	this.shape_11.setTransform(92.3,16.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgjAtIAAhZIAcAAQArAAAAAsQAAAWgMAMQgLALgUAAgAgbAmIAUAAQAjAAAAgmQAAglgjAAIgUAAg");
	this.shape_12.setTransform(83.675,16.725);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAZAtIgbgnIgYAAIAAAnIgIAAIAAhZIAiAAQAfAAAAAZQAAAWgZADIAdAngAgaAAIAaAAQAXAAAAgTQAAgSgYAAIgZAAg");
	this.shape_13.setTransform(71.475,16.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgDAtIAAhZIAHAAIAABZg");
	this.shape_14.setTransform(64.925,16.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgDAtIAAhSIgjAAIAAgHIBNAAIAAAHIgjAAIAABSg");
	this.shape_15.setTransform(58.725,16.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAZAtIgbgnIgYAAIAAAnIgIAAIAAhZIAiAAQAfAAAAAZQAAAWgZADIAdAngAgaAAIAaAAQAXAAAAgTQAAgSgYAAIgZAAg");
	this.shape_16.setTransform(50.325,16.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAiAtIgLgaIgtAAIgLAaIgIAAIAlhZIALAAIAjBZgAAUAMIgUgzIgTAzIAnAAg");
	this.shape_17.setTransform(41,16.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgfAtIAAhZIAhAAQAeAAAAAcQAAAOgIAGQgIAIgOAAIgZAAIAAAhgAgXAFIAYAAQAXAAAAgVQAAgVgXAAIgYAAg");
	this.shape_18.setTransform(32.6,16.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAhA8IgKgaIgtAAIgLAaIgIAAIAlhZIAKAAIAkBZgAAVAbIgVgzIgUAzIApAAgAgCgpIgPgSIAKAAIAMASg");
	this.shape_19.setTransform(20.15,15.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(13.7,5.2,180.20000000000002,23), null);


(lib.txt2a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape.setTransform(239.9,19.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgiAtQgKgNAAgZIAAhAIAKAAIAAA/QAAAVAHAKQAJAMASAAQATAAAJgLQAHgLAAgVIAAg/IAKAAIAABAQAAAZgKANQgLANgYAAQgXAAgLgNg");
	this.shape_1.setTransform(228.6,19.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAhBBIgKgQQgLAEgMAAQg0gBAAg6QAAg6A0AAQA1AAAAA6QAAAlgXAOIANAUgAgqgGQAAAyAqAAQAJgBAJgCIgRgZIAKAAIAOAVQASgKAAghQAAgxgrAAQgqgBAAAyg");
	this.shape_2.setTransform(216.325,19.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_3.setTransform(207.8,19.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAfA5IghgyIgfAAIAAAyIgKAAIAAhxIArAAQAnAAAAAgQAAAcggADIAlAygAghAAIAiAAQAbAAAAgYQAAgXgdAAIggAAg");
	this.shape_4.setTransform(200.65,19.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_5.setTransform(188.825,19.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgbAtQgOgQAAgcQAAgcAOgQQAOgPAVAAQARAAARAJIAAALQgRgLgQAAQgSAAgKANQgMANAAAYQAAAZAMAMQAKAMASgBQAQAAARgLIAAALQgQAKgSAAQgWAAgNgOg");
	this.shape_6.setTransform(178,19.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape_7.setTransform(167.75,19.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_8.setTransform(158.025,19.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgkBMIAAhxIBJAAIAAAJIg/AAIAAAoIA4AAIAAAJIg4AAIAAAuIA/AAIAAAJgAgIg0IAQgXIANAAIgUAXg");
	this.shape_9.setTransform(147.8,17.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_10.setTransform(132.375,19.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgJAAIAAhxIANAAIBHBnIAAhnIAJAAIAABxg");
	this.shape_11.setTransform(120.2,19.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_12.setTransform(108.75,19.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAxA5IAAhlIgvBlIgEAAIgvhlIAABlIgJAAIAAhxIAOAAIAsBiIAthiIAOAAIAABxg");
	this.shape_13.setTransform(95.775,19.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgkBMIAAhxIBJAAIAAAJIg/AAIAAAoIA5AAIAAAJIg5AAIAAAuIA/AAIAAAJgAgIg0IAQgXIANAAIgVAXg");
	this.shape_14.setTransform(83.15,17.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgpAxIAAgKQATALAVAAQAgAAAAgYQAAgJgFgEQgFgFgNgCIgVgEQgcgEAAgYQAAgOALgJQALgJATAAQAWAAAQAJIgBALQgRgLgUAAQgOAAgJAGQgHAHgBAKQAAAJAGAFQAFAEALACIAUAEQAQACAHAHQAIAGgBANQAAAPgMAJQgLAJgTAAQgYAAgQgKg");
	this.shape_15.setTransform(72.75,19.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAPAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_16.setTransform(61.2,19.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape_17.setTransform(49.75,19.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_18.setTransform(38.625,19.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAPAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_19.setTransform(26.45,19.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_20.setTransform(17.85,19.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2a, new cjs.Rectangle(13.7,5.2,233.4,28.099999999999998), null);


(lib.txt1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhGBuQgjgmAAhHQAAhHAjgmQAjglA8AAQArAAAkAVIAAAsQgjgZgoAAQgnABgYAZQgZAcAAA0QAAA2AZAbQAXAYAoAAQAmAAAngbIAAAsQgjAXguAAQg8AAgjgkg");
	this.shape.setTransform(346.225,35.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgVCOIAAkbIAsAAIAAEbg");
	this.shape_1.setTransform(327.5,35.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AA9COIhKhyIg4AAIAAByIgtAAIAAkbIBwAAQBsABAABUQAABFhJANIBSB0gAhFgIIBHAAQA6AAAAgvQAAgug+AAIhDAAg");
	this.shape_2.setTransform(308.625,35.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgWCOIAAjxIhjAAIAAgqIDzAAIAAAqIhkAAIAADxg");
	this.shape_3.setTransform(279.525,35.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhGBuQgjgmAAhHQAAhHAjgmQAjglA8AAQArAAAkAVIAAAsQgjgZgoAAQgnABgYAZQgZAcAAA0QAAA2AZAbQAXAYAoAAQAmAAAngbIAAAsQgjAXguAAQg8AAgjgkg");
	this.shape_4.setTransform(252.625,35.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhdCOIAAkbIC7AAIAAApIiOAAIAABPIB+AAIAAAlIh+AAIAABVICOAAIAAApg");
	this.shape_5.setTransform(227.425,35.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhZCOIAAkbIAtAAIAADxICGAAIAAAqg");
	this.shape_6.setTransform(203.525,35.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhdCOIAAkbIC7AAIAAApIiOAAIAABPIB+AAIAAAlIh+AAIAABVICOAAIAAApg");
	this.shape_7.setTransform(178.475,35.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("ABXCOIgZhHIh/AAIgaBHIgtAAIBrkbIA/AAIBnEbgAAxAfIgxiLIgyCLIBjAAg");
	this.shape_8.setTransform(140.025,35.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AA9COIhKhyIg4AAIAAByIgtAAIAAkbIBwAAQBsABAABUQAABFhJANIBSB0gAhFgIIBHAAQA6AAAAgvQAAgug+AAIhDAAg");
	this.shape_9.setTransform(112.475,35.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgWCOIAAjxIhjAAIAAgqIDzAAIAAAqIhkAAIAADxg");
	this.shape_10.setTransform(83.375,35.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhnB6IAAgrQApAaA4AAQBEAAAAgsQAAgQgKgJQgLgIgdgFIgtgJQhKgMAAg/QAAglAdgXQAdgYAzAAQA7AAAkAWIgCAqQgtgXgwAAQgdAAgRALQgQAMAAAUQAAARALAJQAKAHAWAEIAtAIQAqAHATARQATATAAAhQAAAqgfAWQgdAWg1AAQg5AAgpgYg");
	this.shape_11.setTransform(56.625,35.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("ABXCOIgZhHIh/AAIgaBHIgtAAIBrkbIA/AAIBnEbgAAxAfIgxiLIgyCLIBjAAg");
	this.shape_12.setTransform(29.425,35.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1b, new cjs.Rectangle(12.9,3.7,348.5,63.5), null);


(lib.txt1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape.setTransform(116.35,14.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_1.setTransform(106.025,14.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_2.setTransform(95.875,14.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape_3.setTransform(85.05,14.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgHA5IgqhxIALAAIAmBqIAnhqIALAAIgsBxg");
	this.shape_4.setTransform(73.725,14.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgiAtQgKgNAAgZIAAhAIAKAAIAAA/QAAAVAHAKQAJAMASAAQATAAAIgLQAIgLAAgVIAAg/IAKAAIAABAQAAAZgKANQgLANgYAAQgXAAgLgNg");
	this.shape_5.setTransform(61.8,14.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag0AAQAAg6A0AAQA1AAAAA6QAAA7g1AAQg0AAAAg7gAgqAAQAAAxAqAAQArABAAgyQAAgxgrAAQgqAAAAAxg");
	this.shape_6.setTransform(48.925,14.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgJAAIAAhxIANAAIBHBnIAAhnIAJAAIAABxg");
	this.shape_7.setTransform(35.5,14.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_8.setTransform(17.875,14.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_9.setTransform(7.225,14.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1a, new cjs.Rectangle(0,0,124.2,28.1), null);


(lib.slash = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7FF14").s().p("Ai+DgIC+m/IC/AAIi+G/g");
	this.shape.setTransform(307.275,28.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slash, new cjs.Rectangle(288.2,5.7,38.19999999999999,44.8), null);


(lib.logoBlack = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#040404").s().p("AjMDNQgNgCgHgHIgFgHQgBgEgBgFIgBgHIABgHQABgLAIgHQAHgGALgBIAIAAIAIAAQAHABAGACQAGADADAEQADAEACAEIACAJIAAALIgCAJIgEAGIgFAFIgIAEIgKACIgIAAIgIAAgAjMCaIgGACQgEADgCAGQgBAHABAGQAAAGAEADIAEADIAHACIAGAAIAHAAQAGgBADgDQADgDABgFIAAgGIAAgGQgBgJgFgDIgIgCIgKgBIgFABgAC0DMIAAg+IANAAIAAAxIAmAAIAAANgAAqDMIAAg+IA1AAIAAAMIgnAAIAAANIAkAAIAAALIgkABIAAANIAnAAIAAAMgAhXDMIAAg+IAUAAIARAAIAGAAIAEABIAFACIACACIADAEQADAEAAAHQAAAHgCAEQgBAFgEACQgDADgGABIgEABIgMAAIgNAAIgBATgAhICtIAMAAIAKgBIAEAAIABgBIACgBIABgDIAAgEIAAgEIgBgCIgCgCIgDgBIgNAAIgLAAgAgZBNQgPgDgPgGQgOgHgNgJQgYgSgPgaQgOgZgEgeIAAgJIAAgJIAAgEIACAAIAIABIAAAHIABAKIABAKQACASAJARQAHAPAMAPIAHAHIAIAHQAOAMAQAHQAQAIASADQAUADAUgDQAUgDAUgJIASgLQAIgGAIgIIALgMIAKgOIAEgIIAFgJIABgDIAFAAIAGAAIgBAEIgDAGIgEAHIgEAIQgIAMgJALQgJAKgLAIQgOALgQAHQgQAGgRADQgNACgNAAQgMAAgNgDgAA/gZIhrAAIguAAIALgGIAYgNIAdgPIAHgDIB9AOIB+AOIABAAIAAAAIgRAJgACMg2IgFgBIAAgFQAAgQgDgOQgEgPgGgOQgJgRgNgPQgNgOgQgKQgbgQgfgDQgdgCgdAMIgKAEIgIAEIgPAKIgMALIgLAMIgJAOIgFAKIgFAJIAAACIgFAAIgFAAIgBAAIAAgCIABgDQAJgVAOgRQAOgRASgNQAQgKARgGQARgGASgBIALAAIANAAIAOADIAOADQATAGARALQARALANAPQANAPAJATQAIASADAUIABAKIAAALIAAAGIAAACIgFAAgAhihLIh0gNIgLgBIgBAAIADgCIAFgDIAIgEICaAAIBrAAIAtAAIhFAlg");
	this.shape.setTransform(23.35,20.7,1,1,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logoBlack, new cjs.Rectangle(0,0,46.5,41.1), null);


(lib.logo_Opel_white_2023 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjMDNQgNgCgHgHIgFgHQgBgEgBgFIgBgHIABgHQABgLAIgHQAHgGALgBIAIAAIAIAAQAHABAGACQAGADADAEQADAEACAEIACAJIAAALIgCAJIgEAGIgFAFIgIAEIgKACIgIAAIgIAAgAjMCaIgGACQgEADgCAGQgBAHABAGQAAAGAEADIAEADIAHACIAGAAIAHAAQAGgBADgDQADgDABgFIAAgGIAAgGQgBgJgFgDIgIgCIgKgBIgFABgAC0DMIAAg+IANAAIAAAxIAmAAIAAANgAAqDMIAAg+IA1AAIAAAMIgnAAIAAANIAkAAIAAALIgkABIAAANIAnAAIAAAMgAhXDMIAAg+IAUAAIARAAIAGAAIAEABIAFACIACACIADAEQADAEAAAHQAAAHgCAEQgBAFgEACQgDADgGABIgEABIgMAAIgNAAIgBATgAhICtIAMAAIAKgBIAEAAIABgBIACgBIABgDIAAgEIAAgEIgBgCIgCgCIgDgBIgNAAIgLAAgAgZBNQgPgDgPgGQgOgHgNgJQgYgSgPgaQgOgZgEgeIAAgJIAAgJIAAgEIACAAIAIABIAAAHIABAKIABAKQACASAJARQAHAPAMAPIAHAHIAIAHQAOAMAQAHQAQAIASADQAUADAUgDQAUgDAUgJIASgLQAIgGAIgIIALgMIAKgOIAEgIIAFgJIABgDIAFAAIAGAAIgBAEIgDAGIgEAHIgEAIQgIAMgJALQgJAKgLAIQgOALgQAHQgQAGgRADQgNACgNAAQgMAAgNgDgAA/gZIhrAAIguAAIALgGIAYgNIAdgPIAHgDIB9AOIB+AOIABAAIAAAAIgRAJgACMg2IgFgBIAAgFQAAgQgDgOQgEgPgGgOQgJgRgNgPQgNgOgQgKQgbgQgfgDQgdgCgdAMIgKAEIgIAEIgPAKIgMALIgLAMIgJAOIgFAKIgFAJIAAACIgFAAIgFAAIgBAAIAAgCIABgDQAJgVAOgRQAOgRASgNQAQgKARgGQARgGASgBIALAAIANAAIAOADIAOADQATAGARALQARALANAPQANAPAJATQAIASADAUIABAKIAAALIAAAGIAAACIgFAAgAhihLIh0gNIgLgBIgBAAIADgCIAFgDIAIgEICaAAIBrAAIAtAAIhFAlg");
	this.shape.setTransform(23.35,20.7,1,1,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_Opel_white_2023, new cjs.Rectangle(0,0,47.2,41.5), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_1, new cjs.Rectangle(0,0,300,250), null);


(lib.ctaTxtBlack = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgPAPIAAgXIgMAAIAAgPIAIAAQABAAABAAQAAgBABAAQAAAAAAgBQABgBAAAAIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAANAMAAQAHAAAGgCIAAAQQgJADgIAAQgaAAAAgcg");
	this.shape.setTransform(101.15,13.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgZAaQgJgJAAgRQAAgQAJgIQAJgKAQABQAQgBAKAKQAJAIAAAQQAAARgJAJQgKAJgQgBQgQABgJgJgAgPABQAAARAPAAQAQAAAAgSQAAgQgQAAQgPgBAAASg");
	this.shape_1.setTransform(94.1,14.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgPAfIAAAOIgSAAIAAhbIATAAIAAAnQAFgOAPAAQAOAAAHAIQAIAIAAARQAAAQgIAKQgHAJgNgBQgRAAgFgPgAgOALIAAACQAAARAOAAQAPAAAAgSQAAgRgPAAQgOAAAAAQg");
	this.shape_2.setTransform(86.25,12.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgQAKgJQAJgIAOAAQAOgBAJAJQAHAHAAAPIAAAIIgrAAQAAAJAFACQAEAEAJAAQANAAAKgGIAAAPQgJAGgSgBQgPABgJgJgAAPgGQAAgOgOAAQgLAAgBAOIAaAAIAAAAg");
	this.shape_3.setTransform(78.35,14.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgbAqIAAgQQALAFANAAQARAAAAgQIAAgIQgFANgOAAQgNAAgHgIQgIgIAAgPQAAgRAIgJQAHgJAMAAQAQAAAFAQIAAgPIATAAIAAA8QAAAQgLAIQgKAIgPAAQgQAAgJgFgAgNgMQAAAPANABQAOgBAAgOIAAgBQAAgRgOAAQgNAAAAARg");
	this.shape_4.setTransform(70.525,15.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAMAiIAAglQAAgNgLAAQgMAAAAARIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAFAGQAGAHAAALIAAArg");
	this.shape_5.setTransform(62.925,13.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAVAqIgGgRIgfAAIgFARIgUAAIAdhTIAbAAIAbBTgAAKAIIgKgiIgKAiIAUAAg");
	this.shape_6.setTransform(54.475,13.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAgAiIAAglQAAgNgKAAQgMAAAAARIAAAhIgTAAIAAglQAAgNgKAAQgMAAAAARIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAPAAQAQAAADAQQAGgQAQAAQAKAAAFAGQAGAGAAAMIAAArg");
	this.shape_7.setTransform(40.95,13.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgYAcQgGgGAAgMIAAgrIATAAIAAAlQAAANALAAQAMAAAAgRIAAghIAUAAIAABBIgTAAIAAgOQgFAQgRAAQgJAAgGgGg");
	this.shape_8.setTransform(31.05,14.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgfAqIAAgOIAkgzIgkAAIAAgSIA+AAIAAANIglA0IAmAAIAAASg");
	this.shape_9.setTransform(23.475,13.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#F7FF15").ss(1,1,1).p("ApsiCITZAAIAAEFIzZAAg");
	this.shape_10.setTransform(62.075,13.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F7FF15").s().p("ApsCDIAAkFITZAAIAAEFg");
	this.shape_11.setTransform(62.075,13.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaTxtBlack, new cjs.Rectangle(-1,-1,126.2,28.2), null);


(lib.ctaTxt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AJtCDIzZAAIAAkFITZAAg");
	this.shape.setTransform(69.2478,14.7749,1.4901,1.1279);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgPAPIAAgXIgMAAIAAgPIAIAAQABAAABAAQAAgBABAAQAAAAAAgBQABgBAAAAIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAANALAAQAIAAAGgCIAAAQQgJADgIAAQgaAAAAgcg");
	this.shape_1.setTransform(145.45,14.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAMAiIAAglQAAgNgLAAQgMAAAAARIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAFAGQAGAHAAALIAAArg");
	this.shape_2.setTransform(138.575,15.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAHgEQAFgEAMgBIALAAQAFAAAAgCIAAgCQAAgIgNAAQgNABgJAFIAAgRQANgGANAAQAcAAAAAYIAAArIgSAAIAAgMQgFAOgQAAQgJgBgFgFgAgLAOQAAAHAIAAQAFAAAEgDQAFgEAAgHIAAgBIgNAAQgJAAAAAIg");
	this.shape_3.setTransform(130.95,15.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAMAiIAAglQAAgNgLAAQgMAAAAARIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAFAGQAGAHAAALIAAArg");
	this.shape_4.setTransform(123.825,15.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgQAKgJQAJgJAOAAQAOAAAJAJQAHAIAAAOIAAAJIgrAAQABAIAEADQAEACAJAAQANAAAKgEIAAAOQgKAFgQABQgQAAgJgJgAAPgGQgBgNgNAAQgLAAgBANIAaAAIAAAAg");
	this.shape_5.setTransform(116.25,15.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgPAPIAAgXIgMAAIAAgPIAIAAQABAAABAAQAAgBABAAQAAAAAAgBQABgBAAAAIAAgQIASAAIAAATIAZAAIAAAPIgZAAIAAAVQAAANALAAQAIAAAGgCIAAAQQgJADgIAAQgaAAAAgcg");
	this.shape_6.setTransform(109.35,14.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAMAiIAAglQAAgNgLAAQgMAAAAARIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAFAGQAGAHAAALIAAArg");
	this.shape_7.setTransform(102.475,15.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgJAwIAAhBIATAAIAABBgAgLgkQAAgLALAAQAMAAAAALQAAAMgMgBQgLABAAgMg");
	this.shape_8.setTransform(96.625,13.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgXAdQgGgFAAgKQAAgKAGgEQAHgEALgBIALAAQAFAAAAgCIAAgCQgBgIgMAAQgMABgKAFIAAgRQANgGANAAQAcAAAAAYIAAArIgSAAIAAgMQgFAOgPAAQgKgBgFgFgAgLAOQAAAHAIAAQAGAAADgDQAEgEABgHIAAgBIgNAAQgJAAAAAIg");
	this.shape_9.setTransform(91.1,15.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAfAiIAAglQABgNgKAAQgMAAAAARIAAAhIgTAAIAAglQAAgNgKAAQgLAAgBARIAAAhIgTAAIAAhBIATAAIAAAOQAEgQAQAAQAQAAAEAQQAFgQAQAAQAKAAAFAGQAGAGAAAMIAAArg");
	this.shape_10.setTransform(82,15.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgTAhIAAhAIASAAIAAASQAEgTARAAIAAAVQgKAAgFACQgFAEAAAJIAAAdg");
	this.shape_11.setTransform(70.425,15.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgVAaQgKgJAAgRQAAgQAKgJQAJgJAOAAQAOAAAJAJQAHAIAAAOIAAAJIgrAAQAAAIAFADQAEACAJAAQANAAAKgEIAAAOQgJAFgSABQgPAAgJgJgAAPgGQAAgNgOAAQgLAAgBANIAaAAIAAAAg");
	this.shape_12.setTransform(63.95,15.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgZAnQgJgJABgRQgBgQAJgKQAGgJAOAAQAOAAAGAOIAAgmIAUAAIAABbIgTAAIAAgPQgFARgQAAQgNgBgHgHgAgOANQAAARAOAAQAPAAAAgRIAAgBQAAgQgPgBQgOABAAARg");
	this.shape_13.setTransform(56,14.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAMAiIAAglQAAgNgLAAQgMAAAAARIAAAhIgTAAIAAhBIATAAIAAAOQAFgQAQAAQAKAAAFAGQAGAHAAALIAAArg");
	this.shape_14.setTransform(48.325,15.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgYAdQgFgFAAgKQAAgKAGgEQAHgEALgBIALAAQAFAAAAgCIAAgCQgBgIgMAAQgMABgKAFIAAgRQANgGANAAQAcAAAAAYIAAArIgSAAIAAgMQgFAOgPAAQgKgBgGgFgAgLAOQAAAHAIAAQAGAAADgDQAEgEABgHIAAgBIgNAAQgJAAAAAIg");
	this.shape_15.setTransform(40.7,15.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAfAiIAAglQABgNgLAAQgLAAAAARIAAAhIgTAAIAAglQAAgNgKAAQgLAAgBARIAAAhIgTAAIAAhBIATAAIAAAOQAEgQAQAAQAQAAAEAQQAFgQAQAAQAKAAAFAGQAGAGAAAMIAAArg");
	this.shape_16.setTransform(31.6,15.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAfAiIAAglQABgNgKAAQgMAAAAARIAAAhIgTAAIAAglQAAgNgKAAQgLAAgBARIAAAhIgTAAIAAhBIATAAIAAAOQAEgQAQAAQAQAAAEAQQAFgQAQAAQAKAAAFAGQAGAGAAAMIAAArg");
	this.shape_17.setTransform(19.9,15.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgYAaQgKgJAAgRQAAgQAKgJQAIgJAQAAQARAAAIAJQAKAJAAAQQAAARgKAJQgIAJgRAAQgQAAgIgJgAgOABQAAARAOAAQAPAAAAgSQAAgQgPgBQgOABAAARg");
	this.shape_18.setTransform(10,15.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgRAaQgJgJAAgRQAAgQAJgJQAIgJAPAAQALABAKAEIAAAQQgIgEgKAAQgRAAAAARQAAASARAAQAJAAAKgGIAAARQgKAFgMABQgPAAgIgJg");
	this.shape_19.setTransform(2.8,15.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAVA3IgGgRIgfAAIgFARIgUAAIAdhUIAbAAIAbBUgAAKAVIgKgiIgKAiIAUAAgAgHglIgPgRIAWAAIAKARg");
	this.shape_20.setTransform(-8.175,13.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaTxt, new cjs.Rectangle(-24.2,-1,187,31.6), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// slash1a
	this.slash1a = new lib.slash();
	this.slash1a.name = "slash1a";
	this.slash1a.setTransform(147.35,9.1,0.347,0.35,0,0,0,1.6,1.4);

	this.timeline.addTween(cjs.Tween.get(this.slash1a).wait(1));

	// txt2a
	this.txt2a = new lib.txt2a();
	this.txt2a.name = "txt2a";
	this.txt2a.setTransform(51.05,14.85,1,1,0,0,0,51.2,15.9);

	this.timeline.addTween(cjs.Tween.get(this.txt2a).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(1.5,4.2,385.6,88.8), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1b
	this.txt1b = new lib.txt1b();
	this.txt1b.name = "txt1b";
	this.txt1b.setTransform(181.75,48.7,1,1,0,0,0,195.2,25.7);

	this.timeline.addTween(cjs.Tween.get(this.txt1b).wait(1));

	// txt1a
	this.txt1a = new lib.txt1a();
	this.txt1a.name = "txt1a";
	this.txt1a.setTransform(51.2,28.5,1,1,0,0,0,51.2,15.9);

	this.timeline.addTween(cjs.Tween.get(this.txt1a).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-0.6,12.6,348.6,80.4), null);


(lib.logoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo_Opel_white_2023();
	this.instance.setTransform(23.2,20.5,1,1,0,0,0,23.2,20.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#040404").s().p("AjMDNQgNgCgHgHIgFgHQgBgEgBgFIgBgHIABgHQABgLAIgHQAHgGALgBIAIAAIAIAAQAHABAGACQAGADADAEQADAEACAEIACAJIAAALIgCAJIgEAGIgFAFIgIAEIgKACIgIAAIgIAAgAjMCaIgGACQgEADgCAGQgBAHABAGQAAAGAEADIAEADIAHACIAGAAIAHAAQAGgBADgDQADgDABgFIAAgGIAAgGQgBgJgFgDIgIgCIgKgBIgFABgAC0DMIAAg+IANAAIAAAxIAmAAIAAANgAAqDMIAAg+IA1AAIAAAMIgnAAIAAANIAkAAIAAALIgkABIAAANIAnAAIAAAMgAhXDMIAAg+IAUAAIARAAIAGAAIAEABIAFACIACACIADAEQADAEAAAHQAAAHgCAEQgBAFgEACQgDADgGABIgEABIgMAAIgNAAIgBATgAhICtIAMAAIAKgBIAEAAIABgBIACgBIABgDIAAgEIAAgEIgBgCIgCgCIgDgBIgNAAIgLAAgAgZBNQgPgDgPgGQgOgHgNgJQgYgSgPgaQgOgZgEgeIAAgJIAAgJIAAgEIACAAIAIABIAAAHIABAKIABAKQACASAJARQAHAPAMAPIAHAHIAIAHQAOAMAQAHQAQAIASADQAUADAUgDQAUgDAUgJIASgLQAIgGAIgIIALgMIAKgOIAEgIIAFgJIABgDIAFAAIAGAAIgBAEIgDAGIgEAHIgEAIQgIAMgJALQgJAKgLAIQgOALgQAHQgQAGgRADQgNACgNAAQgMAAgNgDgAA/gZIhrAAIguAAIALgGIAYgNIAdgPIAHgDIB9AOIB+AOIABAAIAAAAIgRAJgACMg2IgFgBIAAgFQAAgQgDgOQgEgPgGgOQgJgRgNgPQgNgOgQgKQgbgQgfgDQgdgCgdAMIgKAEIgIAEIgPAKIgMALIgLAMIgJAOIgFAKIgFAJIAAACIgFAAIgFAAIgBAAIAAgCIABgDQAJgVAOgRQAOgRASgNQAQgKARgGQARgGASgBIALAAIANAAIAOADIAOADQATAGARALQARALANAPQANAPAJATQAIASADAUIABAKIAAALIAAAGIAAACIgFAAgAhihLIh0gNIgLgBIgBAAIADgCIAFgDIAIgEICaAAIBrAAIAtAAIhFAlg");
	this.shape.setTransform(23.35,20.7,1,1,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logoWhite, new cjs.Rectangle(0,0,46.5,41.1), null);


(lib.logo_Opel_black_2023 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_black
	this.logoBlack = new lib.logoBlack();
	this.logoBlack.name = "logoBlack";
	this.logoBlack.setTransform(23.2,20.5,1,1,0,0,0,23.2,20.5);

	this.timeline.addTween(cjs.Tween.get(this.logoBlack).wait(1));

	// logo_white
	this.logoWhite = new lib.logoWhite();
	this.logoWhite.name = "logoWhite";
	this.logoWhite.setTransform(23.2,20.5,1,1,0,0,0,23.2,20.5);

	this.timeline.addTween(cjs.Tween.get(this.logoWhite).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_Opel_black_2023, new cjs.Rectangle(0,0,46.5,41.1), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AyuCWIAAkrMAlcAAAIhnErg");
	mask.setTransform(-120.35,14.05);

	// ctaTxtBlack
	this.ctaTxtBlack = new lib.ctaTxtBlack();
	this.ctaTxtBlack.name = "ctaTxtBlack";
	this.ctaTxtBlack.setTransform(62.1,13.1,1,1,0,0,0,62.1,13.1);

	var maskedShapeInstanceList = [this.ctaTxtBlack];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaTxtBlack).wait(1));

	// ctaTxt
	this.ctaTxt = new lib.ctaTxt();
	this.ctaTxt.name = "ctaTxt";
	this.ctaTxt.setTransform(82.5,13.1,1,1,0,0,0,62.1,13.1);

	this.timeline.addTween(cjs.Tween.get(this.ctaTxt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-3.3,-0.5,186,30.6), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var img1 = this.img1;
		var img1Guide = this.img1Guide;
		var img2 = this.img2;
		var img3 = this.img3;
		var img4 = this.img4;
		var img5 = this.img5;
		
		var txt1 = this.txt1;
			var txt1a= txt1.txt1a;
			var txt1b= txt1.txt1b;
			//var slash1a= txt1.slash1a;
			var slash1b= txt1.slash1b;
		var txt2 = this.txt2;
		var txt2a = txt2.txt2a;
			var slash1a = txt2.slash1a;
		var txt3 = this.txt3;
		var txt4 = this.txt4;
		var txt5 = this.txt5;
		var txt6 = this.txt6;
		
		
		var logoBox = this.logoBox;
			var logoWhite = logoBox.logoWhite;
			var logoBlack = logoBox.logoBlack;
		
		var cta = this.cta;
		var ctaBg = cta.ctaBg;
		var ctaTxtBlack = cta.ctaTxtBlack;
		var ctaHover = this.ctaHover;
		
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf, options) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf, options);
			}
		}
		
		var toMask = [txt2a];
		
		function makeTxtsMask(){
		
			for (var i = 0; i < toMask.length; i++) {
			 
				var toMaskVar = toMask[i]; 
				var areaMask = new createjs.Shape();
				areaMask.graphics.beginFill("#ccc").drawRect(0, 0, (toMaskVar.nominalBounds.width * toMaskVar.scaleX), (toMaskVar.nominalBounds.height * toMaskVar.scaleY));
					
					toMaskVar.mask = areaMask;
					toMaskVar.mask.regX = toMaskVar.regX * toMaskVar.scaleX;
					toMaskVar.mask.regY = toMaskVar.regY * toMaskVar.scaleY;
					toMaskVar.mask.x = toMask[i].x + toMaskVar.nominalBounds.x * toMaskVar.scaleX;
					toMaskVar.mask.y = toMask[i].y + toMaskVar.nominalBounds.y * toMaskVar.scaleY;
					
					//toMaskVar.parent.addChild(areaMask); // Also made visible
				
			}
			
		}
		
		makeTxtsMask();
		
		
		this.tl = tl = new TimelineMax({onStart:getTime, repeat:0, repeatDelay:0});
		this.tlBg = tlBg = new TimelineMax({paused:true, repeat:0, repeatDelay:0});
		
		
			tl
			//.set([], {visible:false})
			.set([legal_container], {alpha:1})
			.set([logoWhite], {alpha:0})
				
			.add("frame1")
			.from([logoBox], .5, {alpha:0 , ease: Power2.easeOut}, "frame1")
			.from([img1], .5, {onStart: Zoom, onStartParams:[3], ease: Power2.easeOut}, "frame1")
			.from([txt1], 1, {alpha:0,  ease: Power2.easeOut}, "frame1")
		
			.add("frame2", "frame1+=2")
			.from([slash1a], .5, {alpha:0, ease: Power2.easeInOut}, 1, "frame2")
			.staggerFrom([[txt2a.mask, slash1a]], 1, {cycle:{ x:["-="+(txt2a.nominalBounds.width)]}, ease: Power2.easeInOut}, 1, "frame2+=.2")
		
			.add("frame3", "frame2+=2.5")
			.from([txt3], 1, {alpha:0, ease: Power1.easeOut}, "frame3+=.5")
			
			.add("frame4", "frame3+=3.5")
			.to([txt3], .5, {alpha:0, ease: Power1.easeOut}, "frame4")
			.from([cta], .5, {alpha:0, ease: Power1.easeOut}, "frame4+=1")
			.from([legal_container], .5, {y:"+="+h, ease: Power4.easeInOut},"frame4+=1")
			.addCallback(autoShot,"+=1.5", [true])
		
			tlBg
			.add("frame1")
			.from([img1], 15, {scaleX:1.2, scaleY:1.2, ease: Power2.easeOut}, "frame1")
		
		
		
		function Zoom(t) {
			TweenMax.fromTo(this.target, t, {scaleX:1.1, scaleY:1.1, overwrite:0, rotation:0.001, rotationZ:0.001}, {scaleX:1, scaleY:1, ease:Power1.easeOut});
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logoBox = new lib.logo_Opel_black_2023();
	this.logoBox.name = "logoBox";
	this.logoBox.setTransform(150.9,227.45,0.8,0.8,0,0,0,24.2,21.5);

	this.timeline.addTween(cjs.Tween.get(this.logoBox).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(66.35,114,0.75,0.75,0,0,0,62.1,16.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt3
	this.txt3 = new lib.txt3();
	this.txt3.name = "txt3";
	this.txt3.setTransform(204.05,124.9,1,1,0,0,0,201.2,29.4);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(201.45,90.45,1,1,0,0,0,201.5,29.7);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(165.85,29.65,0.75,0.75,0,0,0,201.2,29.6);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(150,125.05,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-10.3,125.1,976.6999999999999,125);
// library properties:
lib.properties = {
	id: '90D64BED99C74B4B8A4EBEDF2253C157',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"img1.jpg", id:"img1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90D64BED99C74B4B8A4EBEDF2253C157'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;