(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._300x600_1 = function() {
	this.initialize(img._300x600_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1070,1010);


(lib._300x600_3 = function() {
	this.initialize(img._300x600_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,867,827);


(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1070,1010);


(lib.img2 = function() {
	this.initialize(img.img2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,581,557);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteTop = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgjmADcMAbNgiDMAsAAedMglJAeyg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteTop, new cjs.Rectangle(-227.8,-196,455.70000000000005,392), null);


(lib.txtGuide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("A4/jRIRr0nMAgTAbJIxpUog");
	this.shape.setTransform(159.95,152.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtGuide, new cjs.Rectangle(0,0,319.9,305.8), null);


(lib.txtBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5E5C57").s().p("EgZ2Ap0MgA9hVZMAyqApxIC9CZIi9CbMgvhAm0IiMByg");
	this.shape.setTransform(171.575,278.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtBg, new cjs.Rectangle(0,0,343.2,558), null);


(lib.txt4b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag1BDQgNgRAFgeIAJgyQAFgbAQgNQAQgOAYgBQAeAAAOASQAOASgFAeIgKAxQgEAbgQAPQgQAOgZgBQgeABgOgTgAgTg5QgKAJgEATIgJAzQgEAWAJAMQAJALAUAAQAQAAALgJQAKgKAEgSIAJgzQAEgWgJgLQgJgNgUAAQgQAAgLAKg");
	this.shape.setTransform(166.121,60.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkBTIAaiTIgyAAIADgSIB2AAIgEASIgwAAIgaCTg");
	this.shape_1.setTransform(152.85,60.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_2.setTransform(136.625,60.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_3.setTransform(122.55,60.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYBTIAcilIAVAAIgdClg");
	this.shape_4.setTransform(112,60.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAuBTIAWh5IhKBwIgMAAIgjhyIgWB7IgSAAIAdilIAQAAIAoCCIBWiCIAQAAIgdClg");
	this.shape_5.setTransform(98.175,60.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_6.setTransform(78.825,60.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_7.setTransform(64.575,60.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgYBTIAcilIAVAAIgdClg");
	this.shape_8.setTransform(52.95,60.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag7BTIAdilIBaAAIgDARIhHAAIgKA9IA9AAIgDAQIg9AAIgNBHg");
	this.shape_9.setTransform(44.025,60.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_10.setTransform(31.1,60.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_11.setTransform(16.4016,60.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AguBTIAdilIAUAAIgZCUIBFAAIgEARg");
	this.shape_12.setTransform(151.1,32.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_13.setTransform(139.55,32.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhABTIAdilIAvAAQAdAAANASQAOASgFAeIgIAsQgFAbgQAOQgRAOgaAAgAgpBCIAhAAQASAAALgKQALgJAEgUIAIgtQAEgWgJgMQgJgMgTAAIgdAAg");
	this.shape_14.setTransform(124.5526,32.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA+AAIgDAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_15.setTransform(106.15,32.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AglBTIAbiTIgyAAIADgSIB2AAIgDASIgyAAIgZCTg");
	this.shape_16.setTransform(93.6,32.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_17.setTransform(77.9516,32.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_18.setTransform(61.825,32.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AguBTIAdilIAUAAIgZCUIBFAAIgEARg");
	this.shape_19.setTransform(44,32.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_20.setTransform(32.45,32.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.9,17.4,284.3,58.50000000000001);


(lib.txt4a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyBWQgSgQAAgfIAAgGIAjAAIAAAGQAAAPAJAJQAIAIAQAAQAPAAAIgIQAKgHgBgNIAAgEQABgNgKgHQgIgHgPAAIgPAAIAAgcIAMAAQAOAAAHgGQAIgHAAgLIAAgFQAAgLgIgHQgHgGgNAAQgOAAgHAHQgIAGAAANIAAAHIgkAAIAAgHQAAgbASgQQASgQAeAAQAdAAASAPQARAOAAAZIAAAEQAAAOgGAKQgGAKgLAGQAOAFAIAMQAIALgBASIAAAEQAAAbgSAPQgTAPggAAQghAAgRgRg");
	this.shape.setTransform(112.15,17.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BXQgSgQAAgcIAAgHIAkAAIAAAHQAAAOAJAHQAJAHAQAAQARAAAIgGQAJgHAAgNQAAgLgHgHQgHgGgPgDIgRgEQgcgFgOgOQgPgPAAgXQAAgbASgQQATgQAgAAQAeAAASAQQASAPAAAbIAAAGIgkAAIAAgGQAAgMgIgHQgJgHgOAAQgPAAgIAGQgIAGAAAMQAAAKAHAHQAHAGAQADIAQADQAdAGAOAOQAOAPAAAYQAAAegSAPQgTAQgiAAQghAAgTgQg");
	this.shape_1.setTransform(89.975,17.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhHBkIAAjHIBFAAQAjAAATAUQAUAVgBAlIAAArQABAmgUAUQgTAUgjAAgAghBCIAfAAQARAAAKgKQAJgLAAgVIAAgvQAAgVgJgKQgKgLgRAAIgfAAg");
	this.shape_2.setTransform(72.35,17.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,183.4,36.1);


(lib.txt3Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4+jRIRp0nMAgUAbJIxpUog");
	mask.setTransform(61.3,30.15);

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3Container, new cjs.Rectangle(0,0,0,0), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBTIAAilIBjAAIAAAbIhEAAIAAAqIA5AAIAAAZIg5AAIAAAtIBEAAIAAAag");
	this.shape.setTransform(151.2,67.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBTIAAilIAfAAIAAClg");
	this.shape_1.setTransform(140.55,67.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA4BTIAAhjIgtBYIgVAAIgthYIAABjIgcAAIAAilIAZAAIA7B0IA5h0IAaAAIAAClg");
	this.shape_2.setTransform(126.55,67.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgtBFQgQgRAAgfIAAgpQAAgfAQgRQAQgQAdgBQAeABAQAQQARARAAAfIAAApQAAAfgRARQgQAQgeAAQgeAAgPgQgAgXgvQgHAIgBARIAAAsQABASAHAIQAJAJAOAAQAQAAAIgJQAHgIAAgSIAAgsQAAgRgHgIQgIgJgQAAQgOAAgJAJg");
	this.shape_3.setTransform(108.4,67.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAkBTIhEhsIAABsIgcAAIAAilIAZAAIBEBsIAAhsIAcAAIAAClg");
	this.shape_4.setTransform(92.5,67.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AguBFQgPgRAAgfIAAgpQAAgfAQgRQAQgQAdgBQAeABAQAQQAQARABAfIAAApQgBAfgQARQgQAQgeAAQgdAAgRgQgAgWgvQgJAIAAARIAAAsQAAASAJAIQAIAJAOAAQAQAAAHgJQAJgIgBgSIAAgsQABgRgJgIQgHgJgQAAQgOAAgIAJg");
	this.shape_5.setTransform(76.6,67.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgOBTIAAiJIgvAAIAAgcIB7AAIAAAcIguAAIAACJg");
	this.shape_6.setTransform(61.975,67.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgsBFQgQgRAAgdIAAhqIAfAAIAABrQAAAQAIAIQAHAIAOAAQAPAAAHgIQAIgIAAgQIAAhrIAfAAIAABqQAAAdgQARQgPAPgeAAQgdAAgPgPg");
	this.shape_7.setTransform(47.275,67.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAmBTIgLgiIg4AAIgLAiIgeAAIA4ilIAdAAIA5ClgAATAZIgThFIgVBFIAoAAg");
	this.shape_8.setTransform(31.7,67.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRAWIAEgJIAGgLIABgMIAAgXIAZAAIAAAVQgBAOgBAGQgCAFgIAMIgGAJg");
	this.shape_9.setTransform(20.1,62.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag7BTIAAilIA5AAQAdAAAQARQARARAAAfIAAAkQAAAfgRARQgQAQgdAAgAgcA3IAaAAQAPAAAIgIQAIgJAAgRIAAgoQAAgRgIgJQgIgJgPAAIgaAAg");
	this.shape_10.setTransform(10.025,67.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AA4BTIAAhjIgtBYIgVAAIgthYIAABjIgcAAIAAilIAaAAIA6B0IA5h0IAaAAIAAClg");
	this.shape_11.setTransform(167.85,41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAcBTIgshKIgRAUIAAA2IgfAAIAAilIAfAAIAABMIA7hMIAjAAIg4BGIA8Bfg");
	this.shape_12.setTransform(150.425,41.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgqBGQgQgQAAgdIAAgxQAAgdAQgQQAPgQAbAAQAcAAAQAQQAPAQAAAdIAAAxQAAAdgPAQQgPAPgdAAQgbAAgPgPgAgUgxQgGAIAAAQIAAA0QAAAPAGAIQAHAHANAAQAOAAAHgHQAHgIAAgPIAAg0QAAgQgHgIQgHgHgOgBQgNABgHAHg");
	this.shape_13.setTransform(134.475,41.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgqBGQgQgQAAgdIAAgxQAAgdAQgQQAPgQAbAAQAcAAAQAQQAPAQAAAdIAAAxQAAAdgPAQQgPAPgdAAQgbAAgPgPgAgUgxQgGAIAAAQIAAA0QAAAPAGAIQAHAHANAAQAOAAAHgHQAHgIAAgPIAAg0QAAgQgHgIQgHgHgOgBQgNABgHAHg");
	this.shape_14.setTransform(119.625,41.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAYBTIAAggIhNAAIAAgWIA5hvIAhAAIg4BqIArAAIAAgdIAeAAIAABYg");
	this.shape_15.setTransform(105.425,41.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAmBlIgMgjIg3AAIgLAjIgfAAIA5imIAdAAIA4CmgAATAqIgUhFIgUBFIAoAAgAgNhMIgbgYIAgAAIAVAYg");
	this.shape_16.setTransform(87.1,39.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgSAWIAGgJIAFgLIABgMIAAgXIAYAAIAAAVQAAAPgBAFQgCAFgIAMIgHAJg");
	this.shape_17.setTransform(75.5,36.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgsBFQgQgRAAgeIAAhpIAfAAIAABrQAAAQAIAIQAHAJAOgBQAPABAHgJQAIgHAAgRIAAhrIAfAAIAABpQAAAegQARQgPAPgeAAQgdAAgPgPg");
	this.shape_18.setTransform(64.925,41.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgOBpIAAgoQgXgEgMgQQgNgQAAgbIAAgpQAAgfARgRQAQgRAdAAQAeAAAQARQAQARAAAfIAAApQAAAbgMAQQgMAQgXAEIAAAogAgWhDQgJAJABARIAAAuQgBARAJAJQAHAJAPgBQAPABAJgJQAHgJABgRIAAguQgBgRgHgJQgJgIgPgBQgPABgHAIg");
	this.shape_19.setTransform(49.3,43.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgrBJQgPgOAAgXIAAgGIAdAAIAAAGQAAALAIAGQAIAHANgBQAOABAHgGQAHgGAAgKQAAgJgGgHQgGgFgMgCIgNgEQgYgEgMgLQgMgMAAgUQAAgWAPgOQAPgNAbAAQAZAAAPANQAPANAAAXIAAAEIgeAAIAAgEQAAgLgHgGQgHgFgMgBQgMAAgHAGQgGAFAAAJQAAAJAGAGQAGAEAMAEIAOACQAYAFALALQAMANAAAVQAAAYgPANQgQAMgcAAQgbAAgQgMg");
	this.shape_20.setTransform(34.425,41.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgsBFQgQgRAAgeIAAhpIAfAAIAABrQAAAQAIAIQAHAJAOgBQAPABAHgJQAIgHAAgRIAAhrIAfAAIAABpQAAAegQARQgPAPgeAAQgdAAgPgPg");
	this.shape_21.setTransform(19.275,41.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AghBTIAAgcIAOAAQALAAAHgGQAEgGAAgOIAAhvIAgAAIAABtQAAAegOANQgNANgbAAg");
	this.shape_22.setTransform(6.15,41.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(0,0,202.5,83.3), null);


(lib.txt1Line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai9AFIAAgJIF7AAIAAAJg");
	this.shape.setTransform(19,16.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1Line, new cjs.Rectangle(0,16.1,38,1), null);


(lib.txt1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag1BDQgNgRAFgeIAJgyQAFgbAQgNQAQgPAYAAQAeAAAOASQAOASgFAeIgKAxQgEAbgQAPQgQANgZAAQgeABgOgTgAgTg5QgKAKgEASIgJAzQgEAVAJANQAJALAUAAQAQAAALgJQAKgKAEgSIAJgzQAEgVgJgMQgJgNgUAAQgQAAgLAKg");
	this.shape.setTransform(336.471,41.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AglBTIAbiTIgyAAIADgSIB2AAIgDASIgxAAIgaCTg");
	this.shape_1.setTransform(323.2,41.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_2.setTransform(306.975,41.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA+AAIgDAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_3.setTransform(292.9,41.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYBTIAcilIAUAAIgcClg");
	this.shape_4.setTransform(282.35,41.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAuBTIAWh5IhKBwIgMAAIgjhyIgWB7IgSAAIAdilIAQAAIAoCCIBWiCIAQAAIgdClg");
	this.shape_5.setTransform(268.525,41.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_6.setTransform(249.175,41.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_7.setTransform(234.925,41.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXBTIAbilIAUAAIgcClg");
	this.shape_8.setTransform(223.3,41.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag7BTIAdilIBaAAIgDARIhHAAIgKA9IA9AAIgDAQIg9AAIgNBHg");
	this.shape_9.setTransform(214.375,41.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgJA4IA9AAIgDAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_10.setTransform(201.45,41.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_11.setTransform(186.7516,41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgtBTIAcilIATAAIgYCUIBEAAIgCARg");
	this.shape_12.setTransform(321.45,13.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgJA4IA9AAIgDAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_13.setTransform(309.9,13.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhABTIAdilIAvAAQAdAAANASQAOASgFAeIgIAsQgFAbgQAOQgRAOgaAAgAgpBCIAhAAQASAAALgKQALgJAEgUIAIgtQAEgWgJgMQgJgMgTAAIgdAAg");
	this.shape_14.setTransform(294.9026,13.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhIAAIgKA4IA9AAIgDAQIg9AAIgLA7IBJAAIgDARg");
	this.shape_15.setTransform(276.5,13.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AglBTIAbiTIgyAAIADgSIB2AAIgDASIgyAAIgZCTg");
	this.shape_16.setTransform(263.95,13.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_17.setTransform(248.3016,13.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_18.setTransform(232.175,13.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgtBTIAcilIATAAIgYCUIBEAAIgCARg");
	this.shape_19.setTransform(214.35,13.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA+AAIgDAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_20.setTransform(202.8,13.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(112.1,-1,299,58.5);


(lib.txt1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyBWQgSgQAAgfIAAgGIAjAAIAAAGQAAAPAJAJQAIAIAQAAQAPAAAIgIQAKgHgBgNIAAgEQABgNgKgHQgIgHgPAAIgPAAIAAgcIAMAAQAOAAAHgGQAIgHAAgLIAAgFQAAgLgIgHQgHgGgNAAQgOAAgHAHQgIAGAAANIAAAHIgkAAIAAgHQAAgbASgQQASgQAeAAQAdAAASAPQARAOAAAZIAAAEQAAAOgGAKQgGAKgLAGQAOAFAIAMQAIALgBASIAAAEQAAAbgSAPQgTAPggAAQghAAgRgRg");
	this.shape.setTransform(112.15,17.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BXQgSgQAAgcIAAgHIAkAAIAAAHQAAAOAJAHQAJAHAQAAQARAAAIgGQAJgHAAgNQAAgLgHgHQgHgGgPgDIgRgEQgcgFgOgOQgPgPAAgXQAAgbASgQQATgQAgAAQAeAAASAQQASAPAAAbIAAAGIgkAAIAAgGQAAgMgIgHQgJgHgOAAQgPAAgIAGQgIAGAAAMQAAAKAHAHQAHAGAQADIAQADQAdAGAOAOQAOAPAAAYQAAAegSAPQgTAQgiAAQghAAgTgQg");
	this.shape_1.setTransform(89.975,17.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhHBkIAAjHIBFAAQAjAAATAUQAUAVgBAlIAAArQABAmgUAUQgTAUgjAAgAghBCIAfAAQARAAAKgKQAJgLAAgVIAAgvQAAgVgJgKQgKgLgRAAIgfAAg");
	this.shape_2.setTransform(72.35,17.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,183.4,36.1);


(lib.mask2Guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("Egw7ABuMAvPgyoMAyoAvNMgvPAyog");
	this.shape.setTransform(313.175,313.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mask2Guide, new cjs.Rectangle(0,0,626.4,626.3), null);


(lib.mask1Guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhzTgC8MB2RhwWMBwWB2QMh2RBwWg");
	this.shape.setTransform(587.925,767.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,29.7,1475.9,1475.8999999999999);


(lib.ClipGroup_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As6ToIADhJIACgLQAIgtAegdQFglUBJhLQEVkaBUjYQAuh1AAhpQAAh/guiNQhMjqjrkrQisjcjwjsIWVRaIBVBLQAMALAJAOQANAWAAAVQAAArg0AnI5DTig");
	mask.setTransform(82.775,129.45);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#838382","#838382","#B7B7B6","#EBEBEB","#FFFFFF","#FAFAFA","#ECECEB","#D4D4D3","#B3B3B2","#9D9D9C","#9D9D9C"],[0,0.043,0.216,0.412,0.506,0.588,0.682,0.788,0.898,0.961,1],0,-129.4,0,129.5).s().p("As7UPMAAAgodIZ3AAMAAAAodg");
	this.shape.setTransform(82.775,129.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0,0,165.6,258.9), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("An0GPQgDgCAxgtQBIhCA1g4QDLjWBsjpQAphaAbgbQAkglBHgHQDQgTBegCIADAAQASAAAJAEQAJAEACAJQAFAPgeAWQhtBNjKCeIm1FcQjXCigMAAIAAgBg");
	mask.setTransform(58.1041,48.7588);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],-3.1,-36.4,3.1,35.1).s().p("ApAmLIQ0heIBNN1Iw0Beg");
	this.shape.setTransform(57.725,49.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(8,8.8,100.2,79.9), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ArIC0IhRhFQgVgVgJgXQgEgMAAgPQABgNADgJQAOghAigZIZDzhIAAAUQAAA7gFAfQgJAvgeAeQl7FyguAwQkUEbhVDbQguB2AABrQAAB/AuCMQBLDoDnEoQCrDbDuDpg");
	mask.setTransform(83.0475,129.025);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(61,61,61,0)","#3D3D3D","#000000","#000000"],[0,0.89,0.89,0.961,1],0,-129,0,129).s().p("As8UKMAAAgoTIZ5AAMAAAAoTg");
	this.shape.setTransform(82.925,129.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#E2E1E1","#E2E1E1","#DDDCDC","#CFCECE","#C6C6C6","#EAEAEA","#FFFFFF","#F9F9F9","#E9E9E9","#CECECE","#A8A8A8","#777777","#3D3D3D","rgba(61,61,61,0)","rgba(0,0,0,0)"],[0,0.039,0.118,0.212,0.251,0.4,0.506,0.549,0.604,0.671,0.737,0.812,0.89,0.89,1],0,-129,0,129).s().p("As8UKMAAAgoTIZ5AAMAAAAoTg");
	this.shape_1.setTransform(82.925,129.025);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0.3,0,165.6,258.1), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AEsRQQgzgshghZQiPiDi3jZQici2hPiQQhki3gBibQABiQBhifQBSiGCfiaQBahXD9jWQD/jXBSg5IgCACQi4CQj5D4QlfFfhUDIQg0B6AABhQAAB7ArB7QBdEMFDFoQCrC+DNC3Qg4grhDg7g");
	this.shape.setTransform(750.65,480.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(699.7,359.7,101.89999999999998,241.09999999999997), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgCM9QlCllhdkLQgrh8AAh6QAAhiA0h6QBUjIFgleQD6j5C2iPQgHAJgGAHQl7FyguAxQkTEahXDbQgtB3gBBrQABB+AtCMQBNDnDmEoQCpDZDuDrQjNi3irjAg");
	mask.setTransform(46.05,120.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(253,253,253,0)","#FDFDFD","#F5F5F5","#E7E7E7","#D4D4D3","#BBBBBA","#9D9D9C","#9D9D9C"],[0,0.655,0.655,0.737,0.804,0.863,0.914,0.961,1],0,117.4,0,-117.4).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape.setTransform(46.05,120.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#000000","#2D2D2D","#585858","#808080","#A3A3A3","#C0C0C0","#D7D7D7","#E9E9E9","#F6F6F6","#FDFDFD","#FFFFFF","#FDFDFD","rgba(253,253,253,0)","rgba(0,0,0,0)"],[0,0.039,0.063,0.086,0.114,0.141,0.173,0.208,0.251,0.298,0.361,0.506,0.655,0.655,1],0,117.4,0,-117.4).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape_1.setTransform(46.05,120.4);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,92.1,240.8), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Am9SkQFflUBKhLQETkaBVjXQAvh1gBhrQAAh+guiNQhNjqjqkrQisjcjvjrQDOC4CuDBQFGFsBeEMQAqB5AAB9QAABigyB3QhVDHlgFbQj4D2i5CPg");
	mask.setTransform(46.05,120.375);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(225,225,225,0)","#E1E1E1","#C9C9C9","#AAAAAA","#848484","#585858","#252525","#000000","#000000"],[0,0.694,0.694,0.745,0.792,0.843,0.886,0.933,0.961,1],0,117.4,0,-117.3).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape.setTransform(46.05,120.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#706F6F","#706F6F","#828181","#A3A3A3","#C0C0C0","#D7D7D7","#E9E9E9","#F6F6F6","#FDFDFD","#FFFFFF","#FCFCFC","#F2F2F2","#E1E1E1","rgba(225,225,225,0)","rgba(0,0,0,0)"],[0,0.039,0.055,0.09,0.125,0.165,0.212,0.267,0.341,0.506,0.58,0.639,0.694,0.694,1],0,117.4,0,-117.3).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape_1.setTransform(46.05,120.375);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,92.1,240.8), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhgNfQFxljBpkIQAziAAAh0QAAhygziAQigmTrmpJQCtB1COBzQDXCuClCpQFiFsAAEjQAAEkliFsQioCsjUCrQiSB2ipByQD1jAC3iwg");
	this.shape.setTransform(526.125,476.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("An7SzQC4iPD5j2QFflbBVjHQAzh5AAhgQAAh9grh5QhdkMlHlsQiujBjOi4QBfBLC3CoQCPCDC3DZQCbC2BQCQQBkC3AACbQAACQhhCdQhSCDigCaQhZBWj9DUQj+DVhSA5g");
	this.shape_1.setTransform(693.125,610.775);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(473.6,352.9,270.5,378.4), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRNfQFVljBgkJQAwiAAAhzQAAhxgwiBQiTmSqtpKQLmJKCgGSQAzCAAAByQAAB0gzB/QhpEJlxFjQi2Cwj2DAQDjjACoiwg");
	mask.setTransform(47.7,123.125);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(253,253,253,0)","#FDFDFD","#F5F5F5","#E7E7E7","#D3D3D3","#BABABA","#9B9B9B","#767676","#4A4A4A","#1B1B1B","#000000","#000000"],[0,0.62,0.62,0.682,0.729,0.773,0.812,0.851,0.882,0.914,0.945,0.961,1],0,120.1,0,-120).s().p("AncTPMAAAgmdIO5AAMAAAAmdg");
	this.shape.setTransform(47.7,123.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#000000","#131313","#444444","#707070","#979797","#B7B7B7","#D1D1D1","#E6E6E6","#F4F4F4","#FCFCFC","#FFFFFF","#FDFDFD","rgba(253,253,253,0)","rgba(0,0,0,0)"],[0,0.039,0.051,0.082,0.118,0.157,0.196,0.239,0.286,0.337,0.4,0.506,0.62,0.62,1],0,120.1,0,-120).s().p("AncTPMAAAgmdIO5AAMAAAAmdg");
	this.shape_1.setTransform(47.7,123.125);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,95.4,246.3), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAfbQAAgWABgkQADgoACgOQAEgTAKgTQALgUAPgPQFVlJBVhXQESkYBUjUQAuhzAAhoQAAh9guiKQhbkVk9lzQiqjJjbjOQgagbgIgbQgLAmgrAhI5cTyMAAAgqlIZcT0QAqAfAMAnQALgmArggIZcz0IgCAzQAABBgGAlQgJArggAeQlpFihABCQkSEYhVDYQguB0ABBpQgBB9AuCKQBbEWE9FzQCrDIDaDPQANALAKAQQAQAZAAAaQAAAegVAcQgPAVgXAQI5aT0gAIVhlQDqErBODqQAtCMABB/QAABrgvB1QhVDYkVEZQhJBLlgFUQgeAegIAvQgCALgCAlIgCA0IAAAUIZEzhQA0gnAAgtQAAgVgNgVQgJgPgMgLIhVhKI2WxZQDwDsCtDbgA6EJ7IZEzhQA0gmAAgtQAAgtg0gnI5EzhgAYOIlQjujqiqjbQjnknhNjoQguiLAAiAQAAhrAuh3QBWjbEUkaQAogpGBl6QAfgeAIgvQAFgeAAg7IABgVI5FTiQgiAYgOAiQgDAKAAANQgBAPAEAMQAJAWAVAVIBRBFIWSRWIAAAAg");
	this.shape.setTransform(637.95,545.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(469.6,339.7,336.79999999999995,412.50000000000006), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AGJFHIhphZIm1lcQjKiehthNQgegWAEgPQADgJAJgEQAJgEARAAIAEAAQBlACCNANQBGAHAkAmQAVAWAxBeIBhCcQB3CtBzBsIBkBjQBVBUgDACIAAABQgHAAhXhJg");
	mask.setTransform(55.9242,48.4557);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],3.2,-36.6,-3.1,35.2).s().p("AovGMIBNtyIQSBcIhONxg");
	this.shape.setTransform(56,48.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(7.2,8.5,97.5,79.9), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As7TjIAZgVIABAAQClhwCVh3QDWisCoisQFhlsAAkjQAAkjlhlsQiliqjZitQiNh0iuh1IgZgTIAAhSIZDThQA0AnAAAsQAAAtg0AnI5DThg");
	mask.setTransform(82.8,133.3);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#706F6F","#706F6F","#828181","#B1B1B1","#FDFDFD","#FFFFFF","#ECECEC","#BCBBBB","#6E6D6D","#5F5E5E","#5F5E5E"],[0,0.043,0.122,0.278,0.498,0.506,0.576,0.722,0.922,0.961,1],0,-133.3,0,133.3).s().p("As7U1MAAAgppIZ3AAMAAAAppg");
	this.shape.setTransform(82.8,133.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,165.6,266.6), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnvGPQgDgBCMh9IA/g7QBzhsB3itQA8hYAlhEQAyheAVgWQAjgmBGgHQCNgNBmgCIADAAQASAAAIAEQAJAEADAJQAEAPgeAWQheBCjXCrQk6D5h8BhIhCAyIhuBUQgkAcgGAAIAAgBg");
	mask.setTransform(56.7771,48.6098);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],-3.2,-36.5,3.1,35.2).s().p("Ao3mKIQihdIBNNzIwiBcg");
	this.shape.setTransform(56.825,48.825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(7.2,8.7,99.2,79.89999999999999), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnEziIAZAUQDjDACpCwQFUFjBhEIQAvCCAABxQAABygvCCQhhEIlUFjQipCwjjDAIgZAUg");
	mask.setTransform(45.325,125.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FAFAFA","#FAFAFA","#EBEBEB","#808285","#808285"],[0,0.02,0.471,0.961,1],0,-121.9,0,122).s().p("AnETjMAAAgnFIOJAAMAAAAnFg");
	this.shape.setTransform(45.325,125.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,90.7,250.2), null);


(lib.img4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600_3();
	this.instance.setTransform(0,0,0.8393,0.8987);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4, new cjs.Rectangle(0,0,727.7,743.2), null);


(lib.img2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.instance = new lib.img2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,581,557);


(lib.img1_zoom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();
	this.instance.setTransform(16.7,-116.55,1.0637,1.0637);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib._300x600_1();
	this.instance_1.setTransform(20.65,156.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_zoom, new cjs.Rectangle(16.7,-116.5,1138.2,1282.8), null);


(lib.ctaTxt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgbApQgJgKAAgSIAAgZQAAgSAKgKQAJgKARAAQASAAAKAKQAKAKAAASIAAAZQAAASgKAKQgKAKgSAAQgRAAgKgKgAgNgcQgFAFAAAKIAAAbQAAAKAFAFQAFAFAIAAQAKAAAEgFQAFgFAAgKIAAgbQAAgKgFgFQgEgGgKAAQgIAAgFAGg");
	this.shape.setTransform(133.05,9.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgcAyIAAhjIATAAIAABSIAmAAIAAARg");
	this.shape_1.setTransform(125.075,9.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAXAyIgHgVIghAAIgGAVIgTAAIAihjIARAAIAiBjgAAMAPIgMgpIgMApIAYAAg");
	this.shape_2.setTransform(116.35,9.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAPAyIgSglIgOAAIAAAlIgSAAIAAhjIAhAAQAQAAAIAIQAIAHAAAPIAAAEQgBALgDAFQgEAHgIADIAXAngAgRgBIAPAAQAGAAADgEQAEgDAAgGIAAgFQAAgHgEgEQgDgDgGAAIgPAAg");
	this.shape_3.setTransform(107.65,9.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AghAyIAAhjIAhAAQAOAAAIAHQAHAGABANIAAACQAAAHgDAFQgDAFgFADQAHABAEAHQAEAFAAAJIAAACQAAANgJAHQgHAHgPAAgAgPAjIASAAQAFAAAEgEQAEgDgBgGIAAgDQABgGgEgEQgEgDgFAAIgSAAgAgPgHIAPAAQAGAAACgDQADgCAAgGIAAgFQAAgEgDgEQgCgCgGAAIgPAAg");
	this.shape_4.setTransform(98.65,9.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgaA0QgKgLAAgRIAAg/IATAAIAAA/QAAAKAFAGQAEAEAIAAQAJAAAEgEQAFgGAAgKIAAg/IATAAIAAA/QAAARgKALQgJAJgSAAQgRAAgJgJgAgHguIAMgOIATAAIgQAOg");
	this.shape_5.setTransform(89.275,8.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgaAqQgJgKAAgSIAAgbQAAgSAJgKQAKgJAQAAQARAAAKAJQAJAKAAASIAAADIgTAAIAAgEQAAgKgEgFQgEgFgJAAQgIAAgEAFQgEAFAAAKIAAAdQAAAKAEAFQAEAEAIAAQAJAAAEgEQAEgFAAgKIAAgEIATAAIAAADQAAASgJAKQgKAJgRAAQgQAAgKgJg");
	this.shape_6.setTransform(80.125,9.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgZArQgKgIAAgOIAAgDIASAAIAAADQAAAHAFAEQAFAEAHAAQAIAAAFgEQAEgDAAgGQAAgGgDgDQgEgEgHgBIgIgCQgOgDgIgGQgHgHAAgMQAAgOAJgIQAKgHAPAAQAQAAAIAHQAJAIAAAOIAAACIgSAAIAAgCQAAgHgEgDQgFgEgGAAQgIAAgDADQgEADgBAGQABAFAEAEQADADAHABIAIACQAPADAGAGQAIAIgBAMQABAPgKAHQgJAIgRAAQgQAAgJgIg");
	this.shape_7.setTransform(71.35,9.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgdAyIAAhjIA7AAIAAAQIgpAAIAAAaIAiAAIAAAOIgiAAIAAAbIApAAIAAAQg");
	this.shape_8.setTransform(63.35,9.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgjAyIAAhjIAiAAQARAAAKAKQAKALAAASIAAAVQAAATgKAKQgKAKgRAAgAgQAhIAPAAQAJAAAEgFQAFgFAAgLIAAgXQAAgLgFgEQgEgGgJAAIgPAAg");
	this.shape_9.setTransform(54.675,9.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaTxt, new cjs.Rectangle(0,0,187.6,20.1), null);


(lib.ctaBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ap4DZQhpAAhLhAQhKg/AAhaQAAhZBKhAQBLg/BpgBITxAAQBpABBKA/QBLBAAABZQAABahLA/QhKBAhpAAg");
	this.shape.setTransform(88.725,21.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaBg, new cjs.Rectangle(0,0,177.5,43.5), null);


(lib.Cover_Right = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AJPQTIyhvIIhKg9IBKg7ITvwSMgAYAhSIAAAtg");
	this.shape.setTransform(74.9976,121.9951,1.1215,1.1215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cover_Right, new cjs.Rectangle(0,0,150,244), null);


(lib.Cover_Left = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AqEQTMgAYghSITwQSIBJA7IhJA9IyiPIIg2Atg");
	this.shape.setTransform(74.9976,121.9951,1.1215,1.1215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cover_Left, new cjs.Rectangle(0,0,150,244), null);


(lib.white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bQmMAAAghLMAu3AAAMAAAAhLg");
	this.shape.setTransform(150,106.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Cover_Right
	this.Cover_Right = new lib.Cover_Right();
	this.Cover_Right.name = "Cover_Right";
	this.Cover_Right.setTransform(150,88.8);

	this.timeline.addTween(cjs.Tween.get(this.Cover_Right).wait(1));

	// Cover_Left
	this.Cover_Left = new lib.Cover_Left();
	this.Cover_Left.name = "Cover_Left";
	this.Cover_Left.setTransform(0,88.8);

	this.timeline.addTween(cjs.Tween.get(this.Cover_Left).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,300,332.8), null);


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt4a
	this.txt4a = new lib.txt4a();
	this.txt4a.name = "txt4a";
	this.txt4a.setTransform(-173.6,-27.4);

	this.timeline.addTween(cjs.Tween.get(this.txt4a).wait(1));

	// txt4b
	this.txt4b = new lib.txt4b();
	this.txt4b.name = "txt4b";
	this.txt4b.setTransform(-173.45,8);

	this.timeline.addTween(cjs.Tween.get(this.txt4b).wait(1));

	// txt4Line
	this.txt4Line = new lib.txt1Line();
	this.txt4Line.name = "txt4Line";
	this.txt4Line.setTransform(-81.75,0.35,1.421,1,0,0,0,19.1,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txt4Line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(-224.3,-27.4,284.2,111.30000000000001), null);


(lib.txt2Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txtGuide
	this.txtGuide = new lib.txtGuide();
	this.txtGuide.name = "txtGuide";
	this.txtGuide.setTransform(-37.65,145.15,1,1,0,0,0,160,152.9);

	this.timeline.addTween(cjs.Tween.get(this.txtGuide).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4+jRIRp0nMAgUAbJIxpUog");
	mask.setTransform(61.3,30.15);

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(2.7,-13);

	var maskedShapeInstanceList = [this.txt2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2Container, new cjs.Rectangle(-197.6,-13,402.79999999999995,311.1), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1a
	this.txt1a = new lib.txt1a();
	this.txt1a.name = "txt1a";
	this.txt1a.setTransform(-178.35,-49.75);

	this.timeline.addTween(cjs.Tween.get(this.txt1a).wait(1));

	// txt1b
	this.txt1b = new lib.txt1b();
	this.txt1b.name = "txt1b";
	this.txt1b.setTransform(-85.8,29.25,1,1,0,0,0,262.4,26.9);

	this.timeline.addTween(cjs.Tween.get(this.txt1b).wait(1));

	// txt1Line
	this.txt1Line = new lib.txt1Line();
	this.txt1Line.name = "txt1Line";
	this.txt1Line.setTransform(-86.5,-23.95,1.421,1,0,0,0,19.1,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txt1Line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-236.1,-49.7,299,109.6), null);


(lib.logo_DS_vector = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(22.1,65,0.4799,0.4799,0,0,0,46.1,126.2);

	this.instance_1 = new lib.ClipGroup_1();
	this.instance_1.setTransform(53.1,85.15,0.4799,0.4799,0,0,0,57.6,49.8);

	this.instance_2 = new lib.ClipGroup_2();
	this.instance_2.setTransform(40.25,65.05,0.4799,0.4799,0,0,0,83.9,134.5);

	this.instance_3 = new lib.ClipGroup_3();
	this.instance_3.setTransform(107.45,85.15,0.4799,0.4799,0,0,0,56.7,49.7);

	this.instance_4 = new lib.ClipGroup_4();
	this.instance_4.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_5 = new lib.ClipGroup_5();
	this.instance_5.setTransform(24.5,65,0.4799,0.4799,0,0,0,48.6,124.2);

	this.instance_6 = new lib.ClipGroup_6();
	this.instance_6.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_7 = new lib.ClipGroup_7();
	this.instance_7.setTransform(104.8,129.55,0.4799,0.4799,0,0,0,47.1,121.2);

	this.instance_8 = new lib.ClipGroup_8();
	this.instance_8.setTransform(136.95,67,0.4799,0.4799,0,0,0,47,121.4);

	this.instance_9 = new lib.ClipGroup_9();
	this.instance_9.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_10 = new lib.ClipGroup_10();
	this.instance_10.setTransform(120.6,63.05,0.4799,0.4799,0,0,0,83.5,130.3);

	this.instance_11 = new lib.ClipGroup_11();
	this.instance_11.setTransform(133.35,152.3,0.4799,0.4799,0,0,0,58.6,50);

	this.instance_12 = new lib.ClipGroup_12();
	this.instance_12.setTransform(120.9,133.95,0.4799,0.4799,0,0,0,83.5,130.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-225.2,-163,612.0999999999999,612.1);


(lib.logo_black = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_DS_vector
	this.instance = new lib.logo_DS_vector("synched",0);
	this.instance.setTransform(203.7,143.3,1,1,0,0,0,80.8,143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// DS AUTOMOBILES
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AcjCpQgdgdABg7IA5AAQABAhAOAQQAOARAhAAQAfAAAOgNQAMgNAAgcQABgcgLgQQgLgPgagHIgjgLQgvgPgUgYQgWgZAAgwQAAguAbgbQAdgdA0ABQA7AAAcAaQAcAbAAA4Ig6AAQgBgegMgOQgMgOgeAAQgaAAgNAMQgMALAAAZQAAAbALANQAMAMAcAKIAhAKQAwAOAUAZQATAbAAAzQAAAzgeAcQgeAcg4AAQg9AAgegdgAHbCmQghghAAg7IAAiRQAAg7AhgiQAhghA7AAQA6AAAhAhQAhAiAAA7IAACRQAAA7ghAhQghAgg6AAQg7AAghgggAIFh+QgRASgBAjIAACUQABAiARASQARATAhAAQAgAAARgTQARgSAAgiIAAiUQAAgkgRgRQgRgTggABQghgBgRATgAkKCmQghghABg7IAAiRQgBg7AhgiQAighA6AAQA6AAAiAhQAgAiAAA7IAACRQAAA7ggAhQgiAgg6AAQg6AAgigggAjfh+QgSASAAAjIAACUQAAAiASASQARATAgAAQAgAAASgTQAQgSABgiIAAiUQgBgkgQgRQgSgTggABQgggBgRATgAt2CoQgeggAAg6IAAkOIA6AAIAAESQAAAiAQAQQAPAOAdAAQAfAAAOgOQAPgQABgiIAAkSIA5AAIAAEOQAAA6gdAgQgeAfg7gBQg5ABgfgfgA6eCpQgdgdAAg7IA6AAQAAAhAOAQQAPARAhAAQAeAAAPgNQANgNgBgcQAAgcgKgQQgLgPgagHIgjgLQgvgPgVgYQgUgZgBgwQAAguAbgbQAdgdA1ABQA6AAAcAaQAcAbAAA4Ig6AAQgBgegMgOQgMgOgfAAQgZAAgMAMQgNALAAAZQAAAbAMANQALAMAcAKIAiAKQAvAOATAZQAUAbAAAzQAAAzgeAcQgeAcg4AAQg9AAgegdgAYADBIAAmBIDBAAIAAA1IiHAAIAABtIB4AAIAAAzIh4AAIAAB4ICOAAIAAA0gAT3DBIAAmBIA6AAIAAFNICDAAIAAA0gARSDBIAAmBIA6AAIAAGBgAMTDBIAAmBIB4AAQAwAAAaAaQAZAZAAAxQAAAggKAWQgMAYgWAKQA2ARAABLQgBAygaAcQgcAbgzAAgANNCPIA+AAQAYAAANgPQAMgOAAgdQAAgegMgRQgNgRgXAAIg/AAgANNgcIA9AAQAVAAALgPQALgOAAgbQAAgbgMgPQgMgQgWAAIg6AAgAEjDBIAAkkIhGC5IgyAAIhHi6IAAElIg2AAIAAmBIBHAAIBRDaIBQjaIBEAAIAAGBgAn/DBIAAlNIheAAIAAg0ID3AAIAAA0IhfAAIAAFNgAwbDBIgZhqIhsAAIgZBqIg5AAIBfmBIBUAAIBhGBgAxAAlIgqi0IgqC0IBUAAgA/xDBIAAmBIBuAAQA7AAAhAhQAhAgAAA7IAACLQAAA6ghAgQghAgg7AAgA+4COIA0AAQAigBARgSQARgSAAgiIAAiMQAAgjgRgSQgRgSgiAAIg0AAg");
	this.shape.setTransform(203.35,246.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_black, new cjs.Rectangle(0,0.3,406.8,266.09999999999997), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo_black();
	this.instance.setTransform(0,-0.4,0.5688,0.5688,0,0,0,0,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-58.2,-92.6,348.2,348.2), null);


(lib.img2Guide2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.img2Guide2 = new lib.img2_1("synched",0);
	this.img2Guide2.name = "img2Guide2";
	this.img2Guide2.setTransform(183.5,179.65,1,1,0,0,0,339.3,477.2);

	this.timeline.addTween(cjs.Tween.get(this.img2Guide2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Guide2, new cjs.Rectangle(-155.8,-297.5,581,557), null);


(lib.img2Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EAZTAsBMgx/gpPIjHihICriOMA08gr7MgAOBZ4IABB5g");
	mask.setTransform(159.375,183.85);

	// img2
	this.img2 = new lib.img2_1();
	this.img2.name = "img2";
	this.img2.setTransform(157.35,175.85,0.6095,0.6095,0,0,0,297.6,287.8);

	var maskedShapeInstanceList = [this.img2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img2Guide2
	this.img2Guide2 = new lib.img2Guide2();
	this.img2Guide2.name = "img2Guide2";
	this.img2Guide2.setTransform(91.65,182.7,0.6075,0.6075,0,0,0,128.9,0.2);

	this.timeline.addTween(cjs.Tween.get(this.img2Guide2).wait(1));

	// msk (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EAZTAsCMgx/gpQIjHihICriOMA08gr6MgAOBZ4IABB3g");
	mask_1.setTransform(394.525,183);

	// imgGuide
	this.imgGuide = new lib.img2_1();
	this.imgGuide.name = "imgGuide";
	this.imgGuide.setTransform(549.1,178.55,0.6466,0.6466,0,0,0,313.4,282.1);

	var maskedShapeInstanceList = [this.imgGuide];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.imgGuide).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Container, new cjs.Rectangle(-81.2,-3.8,653.8000000000001,360.1), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1_zoom
	this.img1_zoom = new lib.img1_zoom();
	this.img1_zoom.name = "img1_zoom";
	this.img1_zoom.setTransform(160.65,334.8,0.5636,0.5636,0,0,0,494.7,540);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5D5C57").s().p("EgzBAOYIAA8vMBmDAAAIAAcvg");
	this.shape.setTransform(211.35,604.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.img1_zoom}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115.2,-35.2,653.1,731.5);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AwugHIQmwnIQ3Q3IwmQmg");
	mask.setTransform(107.075,99.1);

	// ctaTxt
	this.ctaTxt = new lib.ctaTxt();
	this.ctaTxt.name = "ctaTxt";
	this.ctaTxt.setTransform(107.15,97.7,1,1,0,0,0,93.8,10);

	var maskedShapeInstanceList = [this.ctaTxt];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaTxt).wait(1));

	// ctaBg
	this.ctaBg = new lib.ctaBg();
	this.ctaBg.name = "ctaBg";
	this.ctaBg.setTransform(106.5,98.25,1,1,0,0,0,88.7,21.8);

	var maskedShapeInstanceList = [this.ctaBg];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaBg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(13.4,76.5,187.5,43.5), null);


(lib.txt4Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AxpAAIRpxpIRqRpIxqRqg");
	mask.setTransform(214.025,212.775);

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(202.8,160,1,1,0,0,0,-93.5,0);

	var maskedShapeInstanceList = [this.txt4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4Container, new cjs.Rectangle(101.1,132.6,225.9,111.30000000000001), null);


(lib.txt1Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A84nYIQAzgMApxAiRIwATgg");
	mask.setTransform(212.925,209.125);

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(202.8,188,1,1,0,0,0,-93.5,0);

	var maskedShapeInstanceList = [this.txt1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1Container, new cjs.Rectangle(60.2,138.3,299,109.6), null);


(lib.logoContainer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// white
	this.white = new lib.white();
	this.white.name = "white";
	this.white.setTransform(-34.1,-59.6);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	// logo
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.setTransform(116,76.2,1,1,0,0,0,116,76.2);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logoContainer, new cjs.Rectangle(-58.2,-92.6,348.2,365.79999999999995), null);


(lib.logo_DS_WIP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_DS_vector
	this.instance = new lib.logo_DS_vector("synched",0);
	this.instance.setTransform(203.7,143.3,1,1,0,0,0,80.8,143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// DS AUTOMOBILES
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EA7eAFhQg8g9AAh9IB5AAQABBIAdAhQAeAiBEAAQBAAAAdgcQAcgbAAg5QAAg8gXgfQgWgfg3gQIhJgXQhigegqgzQgsg2AAhiQAAhgA4g5QA8g8BtAAQB5AAA7A3QA7A4AAB3Ih5AAQgChBgZgcQgagdg+AAQg2AAgaAYQgaAYAAAzQAAA3AYAdQAXAaA8ATIBFAVQBjAeAoA2QAqA4AABqQAABqg/A6Qg/A8h1AAQh/AAg+g9gAPdFZQhFhFAAh5IAAkxQAAh8BFhFQBEhGB7AAQB6AABEBGQBFBFAAB8IAAExQAAB5hFBFQhEBFh6AAQh7AAhEhFgAQ1kJQgkAnAABHIAAE3QAABIAkAmQAjAmBEAAQBDAAAkgmQAjgmAAhIIAAk3QAAhIgjgmQgkgmhDABQhEgBgjAmgAorFZQhFhFAAh5IAAkxQAAh8BFhFQBFhGB6AAQB6AABFBGQBEBFAAB8IAAExQAAB5hEBFQhFBFh6AAQh6AAhFhFgAnTkJQgkAnAABHIAAE3QAABIAkAmQAjAmBEAAQBDAAAkgmQAjgmAAhIIAAk3QAAhIgjgmQgkgmhDABQhEgBgjAmgA83FcQg+hAAAh6IAAozIB4AAIAAI8QAABGAhAhQAeAeA/AAQA/AAAegeQAgghAAhGIAAo8IB5AAIAAIzQAAB6g+BAQg/BCh5AAQh4AAhAhCgEg3LAFhQg8g9AAh9IB5AAQABBIAdAhQAeAiBEAAQBAAAAdgcQAcgbAAg5QAAg8gXgfQgWgfg3gQIhJgXQhigegqgzQgsg2AAhiQAAhgA4g5QA8g8BuAAQB5AAA6A3QA7A4AAB3Ih5AAQgChBgZgcQgagdg+AAQg2AAgaAYQgaAYAAAzQAAA3AYAdQAXAaA8ATIBFAVQBjAeAoA2QAqA4AABqQAABqg/A6Qg/A8h1AAQh/AAg+g9gEAyAAGSIAAsjIGTAAIAABuIkaAAIAADkID7AAIAABsIj7AAIAAD3IEnAAIAABugEApXAGSIAAsjIB5AAIAAK1IERAAIAABugEAkAAGSIAAsjIB5AAIAAMjgAZnGSIAAsjID6AAQBkAAA1A2QA1A1AABkQAABEgWAuQgXAygvAWQBxAjAACcQAABqg4A4Qg5A5hrAAgAbfEqICBAAQA0AAAagfQAbgeAAg7QAAhAgagjQgagjgyABIiEAAgAbfg7IB/AAQAtAAAXgeQAYgfAAg4QAAg5gaggQgZggguABIh6AAgAJeGSIAApjIiSGEIhoAAIiTmFIAAJkIhzAAIAAsjICUAAICpHHICnnHICOAAIAAMjgAwqGSIAAq2IjFAAIAAhtIIDAAIAABtIjGAAIAAK2gEgiPAGSIg0jdIjhAAIg0DdIh3AAIDFsjICxAAIDHMjgEgjbABLIhYl3IhZF3ICxAAgEhCNAGSIAAsjIDmAAQB6AABFBFQBFBEAAB5IAAEiQAAB4hFBEQhFBDh6AAgEhAWAEmIBtAAQBFAAAkgmQAkgmAAhHIAAkkQAAhIgkgmQgkgmhFAAIhtAAg");
	this.shape.setTransform(203.3718,246.5523,0.48,0.48);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_DS_WIP, new cjs.Rectangle(0,0.3,406.8,266.09999999999997), null);


(lib.img1Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask2Guide
	this.mask2Guide = new lib.mask2Guide();
	this.mask2Guide.name = "mask2Guide";
	this.mask2Guide.setTransform(-339.05,-285,1,1,0,0,0,313.2,313.1);

	this.timeline.addTween(cjs.Tween.get(this.mask2Guide).wait(1));

	// mask1Guide
	this.mask1Guide = new lib.mask1Guide();
	this.mask1Guide.name = "mask1Guide";
	this.mask1Guide.setTransform(734.65,323,0.4564,0.4564,0,0,0,593.2,764.6);

	this.timeline.addTween(cjs.Tween.get(this.mask1Guide).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egw7ABuMAvPgyoMAyoAvNMgvPAyog");
	mask.setTransform(114.125,106.275);

	// img1Guide
	this.img1Guide = new lib.img1_1();
	this.img1Guide.name = "img1Guide";
	this.img1Guide.setTransform(182.95,144.8,0.6249,0.6249,0,0,0,214.2,281.8);

	var maskedShapeInstanceList = [this.img1Guide];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1Guide).wait(1));

	// msk (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhgcgI1MBpShXnMBXnBpTMhpSBXmg");
	mask_1.setTransform(292.175,400.25);

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(364.35,314.75,1.1251,1.1251,0,0,0,330.8,287.9);

	var maskedShapeInstanceList = [this.img1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Container, new cjs.Rectangle(-652.2,-598.1,1721.3,1372.3000000000002), null);


(lib.logo_wraper2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo_DS_WIP();
	this.instance.setTransform(0,-0.15,0.28,0.28,0,0,0,0,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_wraper2, new cjs.Rectangle(-28.6,-45.6,171.29999999999998,171.4), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var logoContainer = this.logoContainer;	
				var logo = logoContainer.logo;
				var white = logoContainer.white;
			
			var img1Container = this.img1Container;
				var img1 = img1Container.img1;
					var img1_zoom = img1.img1_zoom;
				var img1Guide = img1Container.img1Guide;
				var img1Guide2 = img1Container.img1Guide2;
				var mask1Guide = img1Container.mask1Guide;
				var mask2Guide = img1Container.mask2Guide;
					
			var img2Container = this.img2Container;
				var img2 = img2Container.img2;
				var imgGuide = img2Container.imgGuide;
				var img2Guide2 = img2Container.img2Guide2;
			var img2ContainerGuide = this.img2ContainerGuide;
			
		/*	var img3Container = this.img3Container;
				var img3 = img3Container.img3;
				var img3Guide = img3Container.img3Guide; */
			
			var txt1Container = this.txt1Container;
				var txt1 = this.txt1Container.txt1;
					var txt1a = txt1.txt1a;
					var txt1b = txt1.txt1b;
					var txt1Line = txt1.txt1Line;
			
			var txt2Container = this.txt2Container;
				var txt2 = txt2Container.txt2;
				var txtGuide = txt2Container.txtGuide;
				
			var txt3Container = this.txt3Container;
				var txt3 = txt3Container.txt3;
				
			var txt4Container = this.txt4Container;
				var txt4 = this.txt4Container.txt4;
					var txt4a = txt4.txt4a;
					var txt4b = txt4.txt4b;
					var txt4Line = txt4.txt4Line;
					
			var img4 = this.img4;
			var LegalFrame2 = this.LegalFrame2;
			
		
				
			var whiteTop = this.whiteTop;	
			var logo2 = this.logo2;	
			var txtBg = this.txtBg;
			var cta = this.cta;
				var ctaTxt = cta.ctaTxt;
				var ctaBg = cta.ctaBg;
		
		
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf, options) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				//console.log(tf);
				//console.log(option);
				window.takeAutoShot(tf, options);
			}
		}
		
		/*********** dsLineScale **************/
		function dsLineScale(lineToScale, widestTxt){
			var childrenX = widestTxt.children[0].x;
			for (var i = 0; i < widestTxt.children.length; i++) {
				if ( widestTxt.children[i].x <= childrenX ){
				childrenX = widestTxt.children[i].x;
				var childrenXnext = widestTxt.children[i+1].x;		
				childrenX = childrenX-(childrenXnext - childrenX)/2;	
				}
			}	
			var lineWidth = Math.round((widestTxt.nominalBounds.width * widestTxt.scaleX - (childrenX * 2 * widestTxt.scaleX))/ 3.5);
			var lineScaleX = lineWidth / lineToScale.nominalBounds.width;
			lineToScale.scaleX = lineScaleX;
			console.log(lineWidth);
			}
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat: 0, repeatDelay:0});
		
		
		tl
			.set([img2Guide2], {visible: false})
			.to([img1Guide, img1Guide2, txtGuide], 0,{alpha: 0}, 0)
		
			.add("frame1")
			.from(white, {y:"-="+white.nominalBounds.height, duration: .75, ease:Power1.easeOut}, "frame1+=.75")
			.add(autoShot, "frame1+=.1")
		
			.add("frame2")
			.from(img1.mask, 1, {x: mask1Guide.x, y: mask1Guide.y, scaleX: mask1Guide.scaleX, scaleY: mask1Guide.scaleY, ease:Power2.easeOut},"frame2")
			.to(img1_zoom, 2, {scaleX: .5, scaleY: .5, x:"+=5"},"frame2+=.25")
			.from(txt1, .3, {alpha:0, ease: Power2.easeIn}, "frame2+=.10")
			.from(logo2, .7, {alpha:0, ease: Power2.easeIn}, "frame2+=.25")
			.add(autoShot)
		
			.add("frame3", "frame2+=2.5")
			.to(txt1.mask, 1, {y:"+="+w, ease:Power1.easeOut},"frame3")
			.from(txtBg, 1, { x:"-="+w, ease:Power1.easeOut},"frame3")
			.from(txt2.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeOut},"frame3+=1")
			.from(whiteTop, 1, {x:"+="+w, ease:Power1.easeOut},"frame3+=1")
			.to(img1.mask, 1, {x: img1Guide.mask.x, y: img1Guide.mask.y, ease:Power1.easeOut},"frame3+=1.1")
			.to(img1, 1, {x: img1Guide.x, y: img1Guide.y, scaleX: img1Guide.scaleX, scaleY: img1Guide.scaleY, ease:Power1.easeOut},"frame3+=1.1")
			.from(img2.mask, .5, { x: imgGuide.mask.x, y: imgGuide.mask.y, scaleX: imgGuide.mask.scaleX, scaleY: imgGuide.mask.scaleY, ease:Power1.easeOut},"frame3")
			.from(img2, 1, {x: imgGuide.x, y: imgGuide.y, scaleX: imgGuide.scaleX, scaleY: imgGuide.scaleY, ease:Power1.easeOut},"frame3+=1")
			.to(img2, 5, {x: img2Guide2.x, y: img2Guide2.y, scaleX: img2Guide2.scaleX, scaleY: img2Guide2.scaleY, ease:Power1.easeOut})
			.add(autoShot)
		
			.add("frame4", "frame3+=4")
			.to(txt2.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeIn},"frame4+=2")
			//.from(txt3.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeIn},"frame4+=.5")
			/*.from(img3.mask, 1, { x: imgGuide.mask.x, y: imgGuide.mask.y, scaleX: imgGuide.mask.scaleX, scaleY: imgGuide.mask.scaleY, ease:Power1.easeOut},"frame4+=.5")
			.from(img3, 1, {x: img3Guide.x, y: img3Guide.y, scaleX: img3Guide.scaleX, scaleY: img3Guide.scaleY, ease:Power1.easeOut}, "frame4+=.5")
			.from(img3, 5, {onStart: moveInDirection, onStartParams:[img3, 180, 3.5, w/1.4]},"frame4+=1.5")*/
			.add(autoShot, "frame4+=3")
		
			.add("frame5", "frame4+=3")
			.to([img2.mask, whiteTop], 1, {x:"+="+w, ease:Power1.easeIn},"frame5")
			.to(txtBg, 1, { x:"-="+txtBg.nominalBounds.width, ease:Power1.easeIn},"frame5")
			.to(img1.mask, 1, {x: mask2Guide.x, y: mask2Guide.y, ease:Power2.easeOut},"frame5")
			.from(img4, {alpha:0, ease:Linear.easeOut}, "frame5+=.3")
			.from(img4, 1.5, {y: "+=10", scaleX: 1.05, scaleY: 1.05, ease:Linear.easeOut}, "frame5+=.4")
			.from(txt4.mask, 1, {scaleX: 0, scaleY: 0, ease:Power1.easeInOut},"frame5+=.5")
			.from(ctaBg.mask, 1, {scaleX: 0, scaleY: 0, ease:Power1.easeInOut},"frame5+=.5")
			.from(txt4b, 1, {alpha:0, ease:Linear.easeOut},"frame5+=.5")
			.from(ctaTxt, .3, {alpha:0, ease:Power1.easeIn},"frame5+=.7")
			.add(autoShot)
			
			.add("frame6", "frame5+=5")
			.from(LegalFrame2, 1, {alpha:0, ease:Linear.easeOut}, "frame6")
			.call(autoShot, [true] ,"+=1")
		
		
		/*function moveInDirection(target, directionInDegrees, t, distance) {
		    var directionInRadians = directionInDegrees * (Math.PI / 180);
		
		    var defaultDistanceX = target.nominalBounds.width * target.scaleX - w;
		    var defaultDistanceY = target.nominalBounds.height * target.scaleY - h;
		
		    var distanceX = distance || defaultDistanceX;
		    var distanceY = distance || defaultDistanceY;
		
		    var xMove = distanceX * Math.cos(directionInRadians);
		    var yMove = distanceY * Math.sin(directionInRadians);
		
		    gsap.to(target, {x: `+=${xMove}`, y: `+=${yMove}`, duration: t, ease:Power1.easeInOut});
		}*/
		
		
		function ZoomIn(target, scale, t) {
			gsap.fromTo(target, {scaleX:0.9, scaleY:0.9} , {scaleX:scale, scaleY:scale, ease:Power2.easeOut, overwrite:0, rotation:0.001, delay:0, duration: t})
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo2
	this.logo2 = new lib.logo_wraper2();
	this.logo2.name = "logo2";
	this.logo2.setTransform(78.95,19.45,1.25,1.25,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.logo2).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(149.6,536.9,1,1,0,0,0,106.7,96);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt4
	this.txt4Container = new lib.txt4Container();
	this.txt4Container.name = "txt4Container";
	this.txt4Container.setTransform(150.1,448.75,1,1,0,0,0,214.5,197.3);

	this.timeline.addTween(cjs.Tween.get(this.txt4Container).wait(1));

	// txt3
	this.txt3Container = new lib.txt3Container();
	this.txt3Container.name = "txt3Container";
	this.txt3Container.setTransform(8.45,512.05);

	this.timeline.addTween(cjs.Tween.get(this.txt3Container).wait(1));

	// txt2
	this.txt2Container = new lib.txt2Container();
	this.txt2Container.name = "txt2Container";
	this.txt2Container.setTransform(8.45,509);

	this.timeline.addTween(cjs.Tween.get(this.txt2Container).wait(1));

	// txtBg
	this.txtBg = new lib.txtBg();
	this.txtBg.name = "txtBg";
	this.txtBg.setTransform(-32.05,325.5);

	this.timeline.addTween(cjs.Tween.get(this.txtBg).wait(1));

	// img2
	this.img2Container = new lib.img2Container();
	this.img2Container.name = "img2Container";
	this.img2Container.setTransform(0,0,1.7634,1.7634);

	this.timeline.addTween(cjs.Tween.get(this.img2Container).wait(1));

	// whiteTop
	this.whiteTop = new lib.whiteTop();
	this.whiteTop.name = "whiteTop";
	this.whiteTop.setTransform(445.6,-25.7,1.4692,1.4692,0.8676,0,0,0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.whiteTop).wait(1));

	// txt1
	this.txt1Container = new lib.txt1Container();
	this.txt1Container.name = "txt1Container";
	this.txt1Container.setTransform(149,504.75,1,1,0,0,0,208.6,210.1);

	this.timeline.addTween(cjs.Tween.get(this.txt1Container).wait(1));

	// img4
	this.img4 = new lib.img4();
	this.img4.name = "img4";
	this.img4.setTransform(150.45,182.15,1,1,0,0,0,225.2,268.6);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// img1
	this.img1Container = new lib.img1Container();
	this.img1Container.name = "img1Container";

	this.timeline.addTween(cjs.Tween.get(this.img1Container).wait(1));

	// logo
	this.logoContainer = new lib.logoContainer();
	this.logoContainer.name = "logoContainer";
	this.logoContainer.setTransform(34,135.5);

	this.timeline.addTween(cjs.Tween.get(this.logoContainer).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-502.2,-298.1,1775.6000000000001,1315.7);
// library properties:
lib.properties = {
	id: '10544D5684BA4F528969206F0477CF68',
	width: 300,
	height: 600,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"_300x600_1.jpg", id:"_300x600_1"},
		{src:"_300x600_3.jpg", id:"_300x600_3"},
		{src:"img1.jpg", id:"img1"},
		{src:"img2.jpg", id:"img2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['10544D5684BA4F528969206F0477CF68'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;