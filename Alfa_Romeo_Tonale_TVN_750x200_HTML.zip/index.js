(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.F1 = function() {
	this.initialize(img.F1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1500,400);


(lib.F2 = function() {
	this.initialize(img.F2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,750,200);


(lib.F3 = function() {
	this.initialize(img.F3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,750,200);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,482,482);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.logo_guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-212.7,-212.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_guide, new cjs.Rectangle(-212.7,-212.7,482,482), null);


(lib.logo_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.instance = new lib.logo();
	this.instance.setTransform(-217.4,-217.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-217.4,-217.4,482,482), null);


(lib.img3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.F3();
	this.instance.setTransform(-149.5,-299.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3, new cjs.Rectangle(-149.5,-299.9,750,199.99999999999997), null);


(lib.img2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.F2();
	this.instance.setTransform(-150,-299.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2, new cjs.Rectangle(-150,-299.9,750,199.99999999999997), null);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.F1();
	this.instance.setTransform(-149.5,-300.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1, new cjs.Rectangle(-149.5,-300.9,1500,400), null);


(lib.flash = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Livello_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","#FFFFFF","rgba(255,255,255,0)"],[0,0.792,1],-150.9,0,151,0).s().p("AuhGzIyItlMAvLAAAISINlg");
	this.shape.setTransform(208.975,43.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.flash, new cjs.Rectangle(0,0,418,87), null);


(lib.F5_txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAmArIAAhDIgBAAIgdBDIgPAAIgehEIgBAAIAABEIgSAAIAAhVIAeAAIAaA8IAAAAIAbg8IAeAAIAABVg");
	this.shape.setTransform(102.65,1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAbArIgUghIgkAAIAAAhIgTAAIAAhVIBAAAQAQAAAIAGQAHAHAAANQAAALgFAFQgFAGgKABIAAABIAWAjgAgdgEIArAAQAGAAADgDQADgCAAgGQAAgGgDgCQgDgDgGAAIgrAAg");
	this.shape_1.setTransform(90.7,1.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_2.setTransform(83.025,1.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgpArIAAhVIBTAAIAAAQIhAAAIAAAVIA+AAIAAAOIg+AAIAAAig");
	this.shape_3.setTransform(76.4,1.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAiArIgIgSIgzAAIgIASIgVAAIArhVIAXAAIArBVgAASAKIgSgjIAAAAIgRAjIAjAAg");
	this.shape_4.setTransform(61.475,1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqArIAAhVIATAAIAABFIBCAAIAAAQg");
	this.shape_5.setTransform(51,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgwArIAAhVIAzAAQAWAAAMAKQAMALAAAVQAAAWgMAKQgMALgWAAgAgdAbIAdAAQAcAAAAgbQAAgbgcAAIgdAAg");
	this.shape_6.setTransform(40.375,1.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgqArIAAhVIBTAAIAAAPIhAAAIAAATIA+AAIAAAOIg+AAIAAAWIBCAAIAAAPg");
	this.shape_7.setTransform(25.5,1.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_8.setTransform(18.475,1.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgaAoQgMgFgGgKQgHgKAAgPQAAgOAHgKQAGgKAMgFQANgFAOAAQAQAAALAEQALAEAGAIQAHAIAAAKIgXAAQAAgIgIgFQgGgFgOAAQgOAAgIAHQgJAIAAANQAAAOAJAIQAIAHAOAAQANAAAIgFQAHgGAAgJIAXAAQAAALgHAIQgFAJgMAEQgLAEgQAAQgOAAgNgFg");
	this.shape_9.setTransform(10.85,1.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAaArIg2g+IgBAAIAAA+IgSAAIAAhVIAWAAIA2A9IABAAIAAg9IASAAIAABVg");
	this.shape_10.setTransform(-0.575,1.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgpArIAAhVIBSAAIAAAPIhAAAIAAATIA+AAIAAAOIg+AAIAAAWIBBAAIAAAPg");
	this.shape_11.setTransform(-11.25,1.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAnArIAAhDIgBAAIgfBDIgOAAIgfhEIAAAAIAABEIgSAAIAAhVIAeAAIAaA8IAAAAIAag8IAfAAIAABVg");
	this.shape_12.setTransform(-23.05,1.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAiArIgIgSIgzAAIgIASIgVAAIArhVIAXAAIArBVgAASAKIgSgjIAAAAIgRAjIAjAAg");
	this.shape_13.setTransform(-35.375,1.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAaArIg2g+IgBAAIAAA+IgSAAIAAhVIAWAAIA2A9IABAAIAAg9IASAAIAABVg");
	this.shape_14.setTransform(-46.725,1.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgmAiQgPgMgBgWQABgVAPgMQAOgLAYAAQAZAAAOALQAQAMgBAVQABAWgQAMQgOALgZAAQgYAAgOgLgAgYgVQgIAHgBAOQABAOAIAIQAJAHAPAAQAQAAAJgHQAIgIABgOQgBgOgIgHQgJgHgQAAQgPAAgJAHg");
	this.shape_15.setTransform(-58.45,1.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AguArIAAhVIA/AAQAbAAAAAWQAAAHgCAEQgDAFgFABIAAABQAGACAEAEQADAFAAAJQAAANgHAGQgHAGgPAAgAgcAcIApAAQAHAAADgDQAEgCAAgGQAAgGgEgDQgDgDgHAAIgpAAgAgcgHIAoAAQAGAAADgDQADgCAAgFQAAgGgDgCQgDgCgGAAIgoAAg");
	this.shape_16.setTransform(-69.775,1.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAiArIgIgSIgzAAIgIASIgVAAIArhVIAXAAIArBVgAASAKIgSgjIAAAAIgRAjIAjAAg");
	this.shape_17.setTransform(-81.125,1.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AATArIgSg+IgBAAIgSA+IgXAAIgchVIAVAAIATA+IAAAAIAUg+IAUAAIATA+IABAAIATg+IAUAAIgcBVg");
	this.shape_18.setTransform(-98.025,1.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKAKIAAgSIAVAAIAAASg");
	this.shape_19.setTransform(-111.175,4.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgjAmQgMgHgBgRIAVAAQABAKAHADQAHAEAMAAQAbAAAAgNQAAgFgEgCQgDgCgGgBIgggDQgNgCgHgEQgHgFAAgMQAAgaAtAAQAVAAAMAGQAMAHABAPIgWAAQAAgIgHgDQgGgDgMAAQgXAAAAALQAAAEADACQAEACAHABIAfADQANABAHAGQAIAFAAAMQAAAPgNAHQgMAGgYAAQgXAAgMgHg");
	this.shape_20.setTransform(-118.475,1.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgqArIAAhVIBTAAIAAAPIhAAAIAAATIA+AAIAAAOIg+AAIAAAWIBCAAIAAAPg");
	this.shape_21.setTransform(-128.65,1.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgIArIAAhVIARAAIAABVg");
	this.shape_22.setTransform(-135.675,1.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAmArIAAhDIgBAAIgdBDIgPAAIgehEIgBAAIAABEIgSAAIAAhVIAeAAIAaA8IAAAAIAbg8IAeAAIAABVg");
	this.shape_23.setTransform(-144.15,1.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgYArIAhhVIAQAAIghBVg");
	this.shape_24.setTransform(-153.6,1.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgmAiQgPgMgBgWQABgVAPgMQAOgLAYAAQAZAAAOALQAQAMgBAVQABAWgQAMQgOALgZAAQgYAAgOgLgAgYgVQgIAHgBAOQABAOAIAIQAJAHAPAAQAQAAAJgHQAIgIABgOQgBgOgIgHQgJgHgQAAQgPAAgJAHg");
	this.shape_25.setTransform(-162.4,1.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgIArIAAhFIgnAAIAAgQIBfAAIAAAQIgmAAIAABFg");
	this.shape_26.setTransform(-173.6,1.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgmAAIAAgQIBfAAIAAAQIgmAAIAABFg");
	this.shape_27.setTransform(-184.05,1.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgqArIAAhVIBTAAIAAAPIhAAAIAAATIA+AAIAAAOIg+AAIAAAWIBCAAIAAAPg");
	this.shape_28.setTransform(-194.25,1.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAaArIg2g+IgBAAIAAA+IgSAAIAAhVIAWAAIA2A9IABAAIAAg9IASAAIAABVg");
	this.shape_29.setTransform(-205.125,1.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AglArIAAgVIgJAEIAAgQIAJgFIAAgvIATAAIAAAmIAigSIAAAQIgiASIAAAPIBBAAIAAAQg");
	this.shape_30.setTransform(-220.225,1.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgsArIAAgPIA8g2Ig5AAIAAgQIBWAAIAAAPIg8A2IA8AAIAAAQg");
	this.shape_31.setTransform(-230.225,1.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgnA2QgPgEgGgIQgHgJAAgMIAoAAQACAGAGADQAGADANAAQAPAAAGgEQAHgEAAgIQAAgJgHgEQgGgDgPAAQgRAAgIAEIgnAAIAEg+IB4AAIAAAYIhYAAIgBARIABAAIAOgFQAIgCAMAAQAXAAANAEQAOAEAGAJQAGAIAAAOQAAAPgGAJQgHAJgPAEQgPAFgZAAQgYAAgPgEg");
	this.shape_32.setTransform(-248.425,0.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AABA4IAAhCIgmAAIAAgYIAIAAQARAAAIgFQAHgGADgKIAgAAIAABvg");
	this.shape_33.setTransform(-260.475,0.05);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgoA3QgPgEgGgIQgHgJgBgPIApAAQABAJAHADQAHADANABQAPgBAHgCQAHgDAAgGQAAgHgFgEQgFgCgLAAIgZAAIAAgVIAaAAQAJAAAFgDQAEgDAAgGQAAgGgHgDQgHgCgNAAQgMAAgGAEQgHACgBAIIgnAAQABgOAHgJQAHgIAOgDQAOgEAWgBQAXABAPADQAOADAHAHQAHAHAAAMQAAAKgFAHQgEAFgJACIAAABQALABAFAHQAGAFAAAMQAAANgHAIQgHAIgPADQgPAEgaAAQgZAAgPgFg");
	this.shape_34.setTransform(-271.975,0.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AABA4IAAhCIgmAAIAAgYIAIAAQARAAAIgFQAHgGADgKIAgAAIAABvg");
	this.shape_35.setTransform(-283.975,0.05);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgwArIAAhVIAzAAQAWAAAMAKQAMALAAAVQAAAWgMAKQgMALgWAAgAgdAbIAdAAQAcAAAAgbQAAgbgcAAIgdAAg");
	this.shape_36.setTransform(-297.525,1.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgmAiQgPgMgBgWQABgVAPgMQAOgLAYAAQAZAAAPALQAOAMAAAVQAAAWgOAMQgPALgZAAQgYAAgOgLgAgXgVQgJAHAAAOQAAAOAJAIQAIAHAPAAQAQAAAJgHQAJgIAAgOQAAgOgJgHQgJgHgQAAQgPAAgIAHg");
	this.shape_37.setTransform(-309.35,1.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F5_txt2, new cjs.Rectangle(-319.6,-9,433.1,20), null);


(lib.F3_txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJA1IAAhpIATAAIAABpg");
	this.shape.setTransform(21.475,9.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAiA1Igqg4IgfAYIAAAgIgTAAIAAhpIATAAIAAA0IA/g0IAcAAIguAlIA1BEg");
	this.shape_1.setTransform(13.05,9.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAVBDQgGgDAAgIQAAgDADgEQACgFAGgDIAHgFIhTAAIAAhpIBjAAIAAAQIhQAAIAAAaIBOAAIAAAQIhOAAIAAAfIBSAAIAAAQIgMgBIgGABIASAAQgJAFgEAEQgEAEAAAFQAAABAAAAQABABAAAAQAAABABAAQAAABABAAIAGABIAIgBIAAALIgMABQgMABgGgEgAAhAkIAGgBIAMABg");
	this.shape_2.setTransform(-0.175,11.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAkA1IgagrIgwAAIAAArIgUAAIAAhpIBNAAQAUgBAJAIQAJAHAAARQAAAYgaAFIAAAAIAcAtgAgmgFIA4AAQAJgBAEgDQAEgEAAgIQAAgHgEgEQgEgEgJAAIg4AAg");
	this.shape_3.setTransform(-13.025,9.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag6A1IAAhpIA8AAQA5AAAAA0QAAA1g5AAgAgmAmIAlAAQASAAAKgKQAKgJAAgTQAAgSgKgKQgKgIgSgBIglAAg");
	this.shape_4.setTransform(-31.775,9.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AghAyQgOgGgJgNQgIgMAAgTQAAgRAIgNQAJgMAOgHQAOgGATAAQATAAAPAGQAPAHAIAMQAIANAAARQAAATgIAMQgIANgPAGQgPAGgTAAQgTAAgOgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAUAAAMgKQAMgKAAgUQAAgTgMgKQgMgKgUAAQgTAAgMAKg");
	this.shape_5.setTransform(-46.2,9.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag4A1IAAhpIBMAAQASgBAKAIQAIAHABARQgBASgIAGQgKAIgSAAIg4AAIAAAqgAgkgEIA0AAQALAAAEgEQAFgEgBgIQABgJgFgDQgEgFgLAAIg0AAg");
	this.shape_6.setTransform(-64.8,9.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpAsQgPgLAAgWIAAhBIATAAIAABBQAAAOAKAHQAKAHARAAQASAAAKgHQAKgHAAgOIAAhBIATAAIAABBQAAAWgPALQgQALgaAAQgZAAgQgLg");
	this.shape_7.setTransform(-78.675,9.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAjA1Igrg4IgeAYIAAAgIgUAAIAAhpIAUAAIAAA0IA/g0IAbAAIguAlIA1BEg");
	this.shape_8.setTransform(-91.85,9.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag3A1IAAhpIBKAAQASAAAIAGQAIAHAAAOQAAARgMAFIAAAAQAHADAFAFQADAGAAAMQABAQgKAHQgIAIgTgBgAgkAmIA1AAQAJAAAFgEQAEgEABgIQgBgJgEgEQgFgEgJAAIg1AAgAgkgJIA0AAQAIAAAEgDQAEgEAAgHQAAgHgEgDQgEgEgIAAIg0AAg");
	this.shape_9.setTransform(13.8,-8.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpAsQgPgLAAgWIAAhBIATAAIAABBQAAAOAKAHQAKAHARAAQASAAAKgHQAKgHAAgOIAAhBIATAAIAABBQAAAWgPALQgQALgaAAQgZAAgQgLg");
	this.shape_10.setTransform(-0.075,-8.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgyA1IAAhpIATAAIAABZIBSAAIAAAQg");
	this.shape_11.setTransform(-13.025,-8.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAaA1IgahRIAAAAIgaBRIgWAAIgjhpIAUAAIAaBSIABAAIAahSIAVAAIAbBSIAAAAIAahSIAUAAIgjBpg");
	this.shape_12.setTransform(-33.125,-8.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AghBBQgPgHgIgMQgIgNAAgSQAAgSAIgMQAIgNAPgGQAOgHATAAQATAAAPAHQAPAGAIANQAIAMAAASQAAASgIANQgIAMgPAHQgPAGgTAAQgTAAgOgGgAgfgOQgMAKAAATQAAATAMAKQAMAKATAAQAVAAALgKQAMgKAAgTQAAgTgMgKQgLgKgVAAQgTAAgMAKgAgIguIANgYIAbAAIgYAYg");
	this.shape_13.setTransform(-49.15,-10.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAxA1IAAhWIgBAAIgnBWIgQAAIgphYIgBAAIAABYIgSAAIAAhpIAgAAIAjBQIABAAIAkhQIAfAAIAABpg");
	this.shape_14.setTransform(-64.5,-8.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAsA1IgLgXIhBAAIgMAXIgVAAIA3hpIAVAAIA3BpgAAZANIgZgvIAAAAIgYAvIAxAAg");
	this.shape_15.setTransform(-79.375,-8.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag2A1IAAgPIBQhKIhLAAIAAgQIBnAAIAAAPIhPBKIBPAAIAAAQg");
	this.shape_16.setTransform(-92.65,-8.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F3_txt1, new cjs.Rectangle(-101,-17,148.1,37), null);


(lib.F2_txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AASA0IAAgaIhJAAIAAgPIBFg+IAWAAIAAA+IAUAAIAAAPIgUAAIAAAagAggALIAAAAIAyAAIAAgtIAAAAg");
	this.shape.setTransform(43.875,17.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAmA1IgmgqIglAqIgZAAIAyg3IgugzIAZAAIAhAmIAjgmIAYAAIguAzIAyA3g");
	this.shape_1.setTransform(31.375,17.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AASA0IAAgaIhJAAIAAgPIBFg+IAWAAIAAA+IAUAAIAAAPIgUAAIAAAagAggALIAAAAIAyAAIAAgtIAAAAg");
	this.shape_2.setTransform(18.775,17.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAxA1IAAhWIAAAAIgpBWIgPAAIgohYIgBAAIAABYIgTAAIAAhqIAfAAIAkBQIAAAAIAkhQIAgAAIAABqg");
	this.shape_3.setTransform(-0.2,17.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgyA1IAAhqIBjAAIAAARIhQAAIAAAaIBOAAIAAAQIhOAAIAAAfIBSAAIAAAQg");
	this.shape_4.setTransform(-14.325,17.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag6A1IAAhqIA8AAQA5AAAAA1QAAA1g5AAgAgmAmIAlAAQASAAAKgKQAKgJAAgTQAAgSgKgKQgKgIgSgBIglAAg");
	this.shape_5.setTransform(-27.325,17.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAVBDQgGgDAAgIQAAgDADgEQACgFAGgDIAHgFIhTAAIAAhqIBjAAIAAARIhQAAIAAAaIBOAAIAAARIhOAAIAAAeIBSAAIAAAQIgMgBIgGABIASAAQgJAEgEAFQgEAEAAAFQAAABAAAAQABABAAAAQAAABABAAQAAABABAAIAGABIAIgBIAAAMIgMAAQgMAAgGgDgAAzAkgAAhAkIAGgBIAMABg");
	this.shape_6.setTransform(-40.525,19.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag4A1IAAhqIBMAAQASAAAKAIQAIAHABASQgBARgIAGQgKAIgSAAIg4AAIAAAqgAgkgEIA0AAQALAAAEgEQAFgDgBgJQABgJgFgDQgEgFgLAAIg0AAg");
	this.shape_7.setTransform(-53.2,17.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAsA1IgLgXIhBAAIgMAXIgVAAIA3hqIAVAAIA3BqgAAZAOIgZgxIAAAAIgYAxIAxAAg");
	this.shape_8.setTransform(-66.925,17.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAkA1IhJhSIgBAAIAABSIgSAAIAAhqIAWAAIBJBSIAAAAIAAhSIASAAIAABqg");
	this.shape_9.setTransform(-80.775,17.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag1A1IAAgPIBPhKIhLAAIAAgRIBoAAIAAAQIhQBJIBQAAIAAARg");
	this.shape_10.setTransform(-99.15,17.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAxA1IAAhWIAAAAIgpBWIgPAAIgohYIgBAAIAABYIgTAAIAAhqIAfAAIAkBQIAAAAIAkhQIAgAAIAABqg");
	this.shape_11.setTransform(41.2,-0.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAjA1Igrg4IgeAYIAAAgIgUAAIAAhqIAUAAIAAA1IA/g1IAbAAIguAmIA1BEg");
	this.shape_12.setTransform(26.95,-0.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgpApQgPgOAAgbQAAgZAPgOQAOgOAbAAQAcAAAOAOQAPAOAAAZQAAAbgPAOQgOAOgcgBQgbABgOgOgAgkAAQgBAnAlAAQAmAAAAgnQAAgmgmAAQglAAABAmg");
	this.shape_13.setTransform(8.3,-0.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgoAvQgNgHAAgQQAAgLAFgHQAFgGAJgBIAAgBQgIgCgFgGQgFgGAAgJQAAgPAOgGQAMgIAaABQAbgBANAIQANAGAAAPQAAAJgGAGQgEAGgIACIAAABQAJABAFAGQAFAHAAALQAAAQgNAHQgNAHgcAAQgbAAgNgHgAgZAJQgHAEgBAKQABAJAHAEQAIADARAAQASAAAHgDQAIgEAAgJQAAgHgEgEQgDgEgHgBQgHgBgMAAQgRgBgIAEgAgYgjQgHAEAAAHQAAAIAHAFQAJADAPAAQAQAAAIgDQAIgFAAgIQAAgHgIgEQgIgEgQABQgPgBgJAEg");
	this.shape_14.setTransform(-4.35,-0.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgzA1IAAgDQAAgQAJgJQAJgJAPgHIAcgLQALgEAFgEQAFgFAAgGQAAgJgIgDQgGgEgOAAQggAAgBAYIgUAAQAAgVAPgJQAPgJAXAAQAXAAANAHQAMAHAAARQAAAJgDAGQgFAGgGADQgGAEgKADIggAOQgIADgEAEQgFAEgBADIBRAAIAAAPg");
	this.shape_15.setTransform(-16.65,-0.525);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AghAyQgPgGgIgNQgIgMAAgTQAAgRAIgNQAIgMAPgHQAPgGASAAQAUAAAOAGQAOAHAJAMQAIANAAARQAAATgIAMQgJANgOAGQgOAGgUAAQgSAAgPgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAVAAALgKQAMgKAAgUQAAgTgMgKQgLgKgVAAQgTAAgMAKg");
	this.shape_16.setTransform(-34.8,-0.575);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag6A1IAAhqIA8AAQA5AAAAA1QAAA1g5AAgAgmAmIAlAAQASAAAKgKQAKgJAAgTQAAgSgKgKQgKgIgSgBIglAAg");
	this.shape_17.setTransform(-48.725,-0.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgeAyQgPgGgIgNQgIgMAAgTQAAgRAIgNQAIgMAPgHQAOgGARAAQATAAANAFQANAFAHAKQAIAJAAANIgWAAQAAgMgLgHQgJgHgSAAQgSAAgLAKQgMALAAASQAAAUAMAKQALAKASAAQATAAAJgHQAKgIABgMIAWAAQAAANgIAKQgIAKgNAFQgNAFgTAAQgRAAgOgGg");
	this.shape_18.setTransform(-67.8,-0.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AghAyQgOgGgJgNQgIgMAAgTQAAgRAIgNQAJgMAOgHQAOgGATAAQATAAAPAGQAOAHAJAMQAIANAAARQAAATgIAMQgJANgOAGQgPAGgTAAQgTAAgOgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAUAAAMgKQAMgKAAgUQAAgTgMgKQgMgKgUAAQgTAAgMAKg");
	this.shape_19.setTransform(-82.1,-0.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAxA1IAAhWIgBAAIgnBWIgQAAIgphYIgBAAIAABYIgSAAIAAhqIAgAAIAjBQIABAAIAkhQIAfAAIAABqg");
	this.shape_20.setTransform(-97.45,-0.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F2_txt1, new cjs.Rectangle(-107.5,-9,170.1,37), null);


(lib.F1_txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJA2Ig1hqIAWAAIAoBTIAAAAIAqhTIAVAAIg2Bqg");
	this.shape.setTransform(32.1,17.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgpAsQgPgLAAgWIAAhBIATAAIAABBQAAAOAKAHQAKAHARAAQASAAAKgHQAKgHAAgOIAAhBIATAAIAABBQAAAWgPALQgQALgaAAQgZAAgQgLg");
	this.shape_1.setTransform(18.625,17.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgqAwQgOgJgBgVIAVAAQABANAJAFQAKAFAQAAQASAAAJgFQAJgEAAgJQAAgHgEgDQgFgDgIgBIgngEQgQgCgJgFQgIgHAAgOQAAgQAOgIQAOgIAYAAQA2AAABAjIgVAAQAAgLgJgEQgJgEgQAAQgfAAAAAPQAAAGAFADQAEADAJABIAnADQAQACAIAGQAJAHAAAPQAAASgPAIQgPAIgcAAQgbAAgPgIg");
	this.shape_2.setTransform(5.175,17.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgIA2IAAgoIg1hCIAXAAIAmAxIAngxIAYAAIg1BBIAAApg");
	this.shape_3.setTransform(-12.5,17.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAaA2IgahSIAAAAIgaBSIgWAAIgjhqIAUAAIAaBSIABAAIAahSIAVAAIAbBSIAAAAIAahSIAUAAIgjBqg");
	this.shape_4.setTransform(-27.675,17.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AghAyQgOgGgJgNQgIgMAAgTQAAgRAIgNQAJgMAOgHQAPgGASAAQAUAAAOAGQAOAHAJAMQAIANAAARQAAATgIAMQgJANgOAGQgOAGgUAAQgSAAgPgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAVAAALgKQAMgKAAgUQAAgTgMgKQgLgKgVAAQgTAAgMAKg");
	this.shape_5.setTransform(-43.7,17.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgIA2IAAhaIgyAAIAAgQIB0AAIAAAQIgwAAIAABag");
	this.shape_6.setTransform(-57.4,17.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAkA2IgagsIgwAAIAAAsIgUAAIAAhqIBNAAQAUAAAJAHQAJAIAAAQQAAAZgaAEIAAABIAcAtgAgmgGIA4AAQAJAAAEgDQAEgEAAgIQAAgIgEgDQgEgEgJAAIg4AAg");
	this.shape_7.setTransform(-70.325,17.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AghAyQgPgGgIgNQgIgMAAgTQAAgRAIgNQAIgMAPgHQAPgGASAAQAUAAAOAGQAOAHAJAMQAIANAAARQAAATgIAMQgJANgOAGQgOAGgUAAQgSAAgPgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAVAAALgKQAMgKAAgUQAAgTgMgKQgLgKgVAAQgTAAgMAKg");
	this.shape_8.setTransform(-84.75,17.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag4A2IAAhqIBMAAQASAAAKAHQAJAIgBAQQABASgJAGQgKAHgSABIg4AAIAAArgAgkgEIA1AAQAJAAAFgEQAFgDAAgJQAAgJgFgDQgFgEgJAAIg1AAg");
	this.shape_9.setTransform(-98.35,17.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqAwQgOgJgBgVIAVAAQABANAJAFQAKAFAQAAQASAAAJgFQAJgEAAgJQAAgHgEgDQgFgDgIgBIgngEQgQgCgJgFQgIgHAAgOQAAgQAOgIQAOgIAYAAQA2AAABAjIgVAAQAAgLgJgEQgJgEgQAAQgfAAAAAPQAAAGAFADQAEADAJABIAnADQAQACAIAGQAJAHAAAPQAAASgPAIQgPAIgcAAQgbAAgPgIg");
	this.shape_10.setTransform(-111.725,17.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgyA2IAAhqIBjAAIAAAQIhQAAIAAAbIBOAAIAAAOIhOAAIAAAgIBSAAIAAARg");
	this.shape_11.setTransform(89.075,-0.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgyA2IAAhqIATAAIAABZIBSAAIAAARg");
	this.shape_12.setTransform(76.725,-0.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAsA2IgLgZIhBAAIgMAZIgVAAIA3hqIAVAAIA3BqgAAZANIgZgvIAAAAIgYAvIAxAAg");
	this.shape_13.setTransform(63.525,-0.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAkA2IhJhTIgBAAIAABTIgSAAIAAhqIAWAAIBJBRIAAAAIAAhRIASAAIAABqg");
	this.shape_14.setTransform(49.675,-0.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AghAyQgPgGgIgNQgIgMAAgTQAAgRAIgNQAIgMAPgHQAPgGASAAQAUAAAOAGQAOAHAJAMQAIANAAARQAAATgIAMQgJANgOAGQgOAGgUAAQgSAAgPgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAVAAALgKQAMgKAAgUQAAgTgMgKQgLgKgVAAQgTAAgMAKg");
	this.shape_15.setTransform(35.4,-0.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgIA2IAAhaIgyAAIAAgQIB0AAIAAAQIgwAAIAABag");
	this.shape_16.setTransform(21.7,-0.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AghAyQgOgGgJgNQgIgMAAgTQAAgRAIgNQAJgMAOgHQAOgGATAAQATAAAPAGQAOAHAJAMQAIANAAARQAAATgIAMQgJANgOAGQgPAGgTAAQgTAAgOgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAUAAAMgKQAMgKAAgUQAAgTgMgKQgMgKgUAAQgTAAgMAKg");
	this.shape_17.setTransform(2.95,-0.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgyA2IAAhqIBjAAIAAAQIhQAAIAAAbIBOAAIAAAOIhOAAIAAAgIBSAAIAAARg");
	this.shape_18.setTransform(-10.425,-0.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAxA2IAAhXIAAAAIgpBXIgPAAIgphZIAAAAIAABZIgTAAIAAhqIAfAAIAkBQIAAAAIAkhQIAgAAIAABqg");
	this.shape_19.setTransform(-24.85,-0.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AghAyQgPgGgIgNQgIgMAAgTQAAgRAIgNQAIgMAPgHQAPgGASAAQAUAAAOAGQAOAHAJAMQAIANAAARQAAATgIAMQgJANgOAGQgOAGgUAAQgSAAgPgGgAgfgdQgMAKAAATQAAAUAMAKQAMAKATAAQAVAAALgKQAMgKAAgUQAAgTgMgKQgLgKgVAAQgTAAgMAKg");
	this.shape_20.setTransform(-40.2,-0.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAkA2IgagsIgwAAIAAAsIgUAAIAAhqIBNAAQAUAAAJAHQAJAIAAAQQAAAZgaAEIAAABIAcAtgAgmgGIA4AAQAJAAAEgDQAEgEAAgIQAAgIgEgDQgEgEgJAAIg4AAg");
	this.shape_21.setTransform(-53.975,-0.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAsA2IgLgZIhBAAIgMAZIgVAAIA3hqIAVAAIA3BqgAAZANIgZgvIAAAAIgYAvIAxAAg");
	this.shape_22.setTransform(-72.925,-0.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgxA2IAAhqIBjAAIAAAQIhQAAIAAAeIBOAAIAAAOIhOAAIAAAug");
	this.shape_23.setTransform(-85.675,-0.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgyA2IAAhqIATAAIAABZIBSAAIAAARg");
	this.shape_24.setTransform(-97.925,-0.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAsA2IgLgZIhBAAIgMAZIgVAAIA3hqIAVAAIA3BqgAAZANIgZgvIAAAAIgYAvIAxAAg");
	this.shape_25.setTransform(-111.125,-0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.F1_txt1, new cjs.Rectangle(-120,-9.1,218.1,37), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgvA8IAAgNIBFhAIhAAAIAAgPIBZAAIAAAOIhFBAIBGAAIAAAOgAgEgnIAKgUIAYAAIgVAUg");
	this.shape.setTransform(36.55,-1.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgyAvIAAhdIA0AAQAxABAAAtQAAAvgxAAgAghAgIAgAAQAQABAIgJQAJgHAAgRQAAgQgJgHQgIgJgQAAIggAAg");
	this.shape_1.setTransform(25.325,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAXAvIgXhHIAAAAIgWBHIgTAAIgfhdIASAAIAXBIIAAAAIAXhIIARAAIAYBIIAAAAIAXhIIARAAIgfBdg");
	this.shape_2.setTransform(11.6,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAnAvIgKgVIg5AAIgKAVIgTAAIAwhdIATAAIAwBdgAAWAMIgWgqIAAAAIgVAqIArAAg");
	this.shape_3.setTransform(-1.9,0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAfAvIgWgmIgqAAIAAAmIgRAAIAAhdIBDAAQARAAAHAHQAIAHAAAOQAAAVgWAEIAAAAIAYAogAghgFIAxAAQAHAAAEgCQAEgEAAgHQAAgGgEgEQgEgDgHAAIgxAAg");
	this.shape_4.setTransform(-13.475,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgwAvIAAhdIBAAAQASABAHAGQAIAHAAAPQAAAOgIAGQgHAHgSAAIgwAAIAAAlgAgggDIAuAAQAIAAAFgDQADgEAAgHQAAgHgDgEQgEgDgJgBIguAAg");
	this.shape_5.setTransform(-25.1,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgkApQgNgIAAgSIASAAQABALAIAFQAIAEAOAAQAPAAAIgEQAIgEAAgHQAAgHgDgCQgEgDgIgBIghgDQgOgCgIgEQgHgGAAgMQAAgOAMgHQAMgHAWAAQAuAAABAfIgSAAQAAgKgIgEQgIgDgNAAQgbAAAAANQAAAGADACQAEACAIABIAiADQANACAIAFQAHAFAAAOQAAAQgNAHQgNAHgYAAQgXAAgNgIg");
	this.shape_6.setTransform(-36.725,0.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bgr
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AsfCWIAAkrIY/AAIAAErg");

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-80,-15,160,30), null);


(lib.black = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A3bN9IAA75MAu3AAAIAAb5g");
	this.shape.setTransform(0.8,-183.85,1,1.1201,0,0,0,0.5,-89.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.black, new cjs.Rectangle(-149.7,-183.6,300,200), null);


(lib.ALFAROMEOSTELVIOF5_txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag6A5IAAhxIBzAAIAAAXIhVAAIAAAVIBSAAIAAAVIhSAAIAAAZIBXAAIAAAXg");
	this.shape.setTransform(110.875,-2.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag6A5IAAhxIAeAAIAABYIBXAAIAAAZg");
	this.shape_1.setTransform(97.3,-2.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAsA5IgLgVIhCAAIgKAVIghAAIA6hxIAlAAIA6BxgAAWANIgWgsIAAAAIgVAsIArAAg");
	this.shape_2.setTransform(82.525,-2.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAgA5IhEhOIgBAAIAABOIgcAAIAAhxIAjAAIBDBMIABAAIAAhMIAdAAIAABxg");
	this.shape_3.setTransform(66.95,-2.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag3AtQgTgPAAgeQAAgdATgPQAUgPAjgBQAjABAUAPQAUAPAAAdQAAAegUAPQgUAPgjAAQgjAAgUgPgAgegaQgLAKAAAQQAAASALAJQAKAJAUAAQAUAAALgJQALgJAAgSQAAgQgLgKQgLgJgUAAQgUAAgKAJg");
	this.shape_4.setTransform(51.025,-2.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOA5IAAhZIgzAAIAAgYICDAAIAAAYIgzAAIAABZg");
	this.shape_5.setTransform(35.675,-2.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag3AtQgTgPAAgeQAAgdATgPQAUgPAjgBQAjABAUAPQAUAPAAAdQAAAegUAPQgUAPgjAAQgjAAgUgPgAgegaQgLAKAAAQQAAASALAJQAKAJAUAAQAUAAALgJQALgJAAgSQAAgQgLgKQgLgJgUAAQgUAAgKAJg");
	this.shape_6.setTransform(14.775,-2.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag6A5IAAhxIBzAAIAAAXIhVAAIAAAVIBSAAIAAAVIhSAAIAAAZIBXAAIAAAXg");
	this.shape_7.setTransform(-0.175,-2.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAyA5IAAhVIAAAAIgmBVIgYAAIglhWIgBAAIAABWIgdAAIAAhxIAwAAIAfBKIAAAAIAghKIAwAAIAABxg");
	this.shape_8.setTransform(-16.3,-2.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag3AtQgTgPAAgeQAAgdATgPQAUgPAjgBQAjABAUAPQAUAPAAAdQAAAegUAPQgUAPgjAAQgjAAgUgPgAgegaQgLAKAAAQQAAASALAJQAKAJAUAAQAUAAALgJQALgJAAgSQAAgQgLgKQgLgJgUAAQgUAAgKAJg");
	this.shape_9.setTransform(-33.575,-2.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAhA5IgYgoIgvAAIAAAoIgdAAIAAhxIBaAAQAWAAALAIQAJAKABASQgBAPgGAGQgHAIgMACIAAABIAcAtgAgmgGIA3AAQAIAAAEgCQADgEAAgGQAAgHgDgEQgEgDgIAAIg3AAg");
	this.shape_10.setTransform(-49.05,-2.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAsA5IgLgVIhCAAIgKAVIghAAIA6hxIAlAAIA6BxgAAWANIgWgsIAAAAIgVAsIArAAg");
	this.shape_11.setTransform(-70.375,-2.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag6A5IAAhxIB0AAIAAAYIhVAAIAAAZIBSAAIAAAVIhSAAIAAArg");
	this.shape_12.setTransform(-84.75,-2.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag6A5IAAhxIAeAAIAABYIBXAAIAAAZg");
	this.shape_13.setTransform(-98.25,-2.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAsA5IgLgVIhCAAIgKAVIghAAIA6hxIAlAAIA6BxgAAWANIgWgsIAAAAIgVAsIArAAg");
	this.shape_14.setTransform(-113.025,-2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ALFAROMEOSTELVIOF5_txt1, null, null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {F2_txt1:0};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var img1 = this.img1;
		var logo = this.logo;
		var logo_guide = this.logo_guide;
		var F1_txt1 = this.F1_txt1;
		var img2 = this.img2;
		var F2_txt1 = this.F2_txt1;
		var img3 = this.img3;
		var F3_txt1 = this.F3_txt1;
		var img4 = this.img4;
		var F4_txt1 = this.F4_txt1;
		var black = this.black;
		var F5_txt1 = this.F5_txt1;
		var F5_txt2 = this.F5_txt2;
		var cta = this.cta;
		var cta2 = this.cta2;
		var flash = this.flash;
		
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
		    console.log(tl.duration());
		}
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat: 0, repeatDelay:0});
		
		
			tl	
		
		
			.add("frame1")
			.set(logo_guide, {visible: false})
			.from ([img1], {duration: 3, scale:.8,  ease: "circ.out"}, "frame1")
			.from ([F1_txt1], {duration: .75, x:"+=100", alpha:0, ease: Power2.easeOut}, "frame1+=1")
			.from (cta, {duration: .75, y:"+=100", alpha:0, ease: Power2.easeOut}, "frame1+=1.3")
		
			.add("frame2", "frame1+=4")
			.from ([img2], {duration:.75, alpha:0, scale:1.4,  ease: "circ.out"}, "frame2")
			.from ([F2_txt1], {duration: .75, x:"+=100", alpha:0, ease: Power2.easeOut}, "frame2+=.5")
		
			.add("frame3", "frame2+=3")
			.from ([img3], {duration:.75, alpha:0, scale:1.4,  ease: "circ.out"}, "frame3")
			.from ([F3_txt1], {duration: .75, x:"+=100", alpha:0, ease: Power2.easeOut}, "frame3+=.5")
		
			.add("frame4", "frame3+=3")
			.to(cta,{duration: .01, alpha:0, alpha:0, ease: Power2.easeOut}, "frame4")
			.from(cta2,{duration: .75, y:"+=100", alpha:0, alpha:0, ease: Power2.easeOut}, "frame4")
			.from ([black], {duration:.5, alpha:0, ease: "circ.out"}, "frame4")
			.to ([logo], {duration: .5, x: logo_guide.x, y: logo_guide.y, scaleX: logo_guide.scaleX, scaleY: logo_guide.scaleY, ease: Power1.easeInOut}, "frame4+=.5")
			.from ([F5_txt1], {duration: .5, alpha:0, ease: Power1.easeOut}, "frame4+=.5")
			.from ([F5_txt2], {duration: .5, y:"+=100", alpha:0, ease: Power1.easeOut}, "frame4+=1")
			.to ([flash], {duration: 1, x:"+=500", ease:Linear, repeat: 2}, "frame4+=1.2")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AOTNoIAAjwIUAAAIAADwg");
	mask.setTransform(219.5054,87.2308);

	// flash
	this.flash = new lib.flash();
	this.flash.name = "flash";
	this.flash.setTransform(280.4,185.7,0.509,0.5436,0,0,0,419.4,89);

	var maskedShapeInstanceList = [this.flash];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.flash).wait(1));

	// cta2
	this.cta2 = new lib.cta();
	this.cta2.name = "cta2";
	this.cta2.setTransform(375.1,163.05,0.8,0.8,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.cta2).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(74.1,173.05,0.8,0.8,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// logo
	this.logo = new lib.logo_1();
	this.logo.name = "logo";
	this.logo.setTransform(29.55,29.3,0.09,0.09,0,0,0,0.6,0);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// F5_txt2
	this.F5_txt2 = new lib.F5_txt2();
	this.F5_txt2.name = "F5_txt2";
	this.F5_txt2.setTransform(494.4,122.55,1.1576,1.1576,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.F5_txt2).wait(1));

	// F5_txt1
	this.F5_txt1 = new lib.ALFAROMEOSTELVIOF5_txt1();
	this.F5_txt1.name = "F5_txt1";
	this.F5_txt1.setTransform(377,100.75,1.1576,1.1576,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.F5_txt1).wait(1));

	// black
	this.black = new lib.black();
	this.black.name = "black";
	this.black.setTransform(375.25,67.55,2.5,1,0,0,0,0.4,-116.1);

	this.timeline.addTween(cjs.Tween.get(this.black).wait(1));

	// F3_txt1
	this.F3_txt1 = new lib.F3_txt1();
	this.F3_txt1.name = "F3_txt1";
	this.F3_txt1.setTransform(132.3,98.3,1.2,1.2,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.F3_txt1).wait(1));

	// img3
	this.img3 = new lib.img3();
	this.img3.name = "img3";
	this.img3.setTransform(375.95,101,1,1,0,0,0,226,-199);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// F2_txt1
	this.F2_txt1 = new lib.F2_txt1();
	this.F2_txt1.name = "F2_txt1";
	this.F2_txt1.setTransform(112.85,100.35,1.2,1.2,0,0,0,-22.1,9.8);

	this.timeline.addTween(cjs.Tween.get(this.F2_txt1).wait(1));

	// img2
	this.img2 = new lib.img2();
	this.img2.name = "img2";
	this.img2.setTransform(375,100.95,1,1,0,0,0,225,-199);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// F1_txt1
	this.F1_txt1 = new lib.F1_txt1();
	this.F1_txt1.name = "F1_txt1";
	this.F1_txt1.setTransform(143.15,101.15,1.2,1.2,0,0,0,-10.2,10.3);

	this.timeline.addTween(cjs.Tween.get(this.F1_txt1).wait(1));

	// img1
	this.img1 = new lib.img1();
	this.img1.name = "img1";
	this.img1.setTransform(374.25,99.55,0.5,0.5,0,0,0,599,-101.8);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	// logo_guide
	this.logo_guide = new lib.logo_guide();
	this.logo_guide.name = "logo_guide";
	this.logo_guide.setTransform(375.15,41.45,0.12,0.12,0,0,0,29.6,30.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_guide).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(375,100,375.5,100.1);
// library properties:
lib.properties = {
	id: '01CFA39BDC1945B6927CEAE655CA6F42',
	width: 750,
	height: 200,
	fps: 60,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"F1.jpg?1712655465063", id:"F1"},
		{src:"F2.jpg?1712655465063", id:"F2"},
		{src:"F3.jpg?1712655465063", id:"F3"},
		{src:"logo.png?1712655465063", id:"logo"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['01CFA39BDC1945B6927CEAE655CA6F42'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;