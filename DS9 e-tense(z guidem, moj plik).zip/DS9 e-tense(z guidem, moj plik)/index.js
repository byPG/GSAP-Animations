(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[537,0,300,600],[0,0,535,600],[415,602,128,128],[253,602,160,196],[0,602,251,251]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._1 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.eco = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.logomind706SP = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtline = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.7,1,1).p("AjbAAIG3AA");
	this.shape.setTransform(22,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtline, new cjs.Rectangle(-1,-1,46,2), null);


(lib.txt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgkA3QgNgNAAgZIAAggQAAgZANgOQANgNAXAAQAYAAANANQANAOAAAZIAAAgQAAAZgNANQgNANgYAAQgXAAgNgNgAgSgmQgGAHAAAOIAAAkQAAANAGAHQAGAHAMAAQANAAAFgHQAHgHAAgNIAAgkQAAgOgHgHQgFgHgNAAQgMAAgGAHg");
	this.shape.setTransform(136.15,10.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLBDIgsiFIAaAAIAeBiIAfhiIAYAAIgsCFg");
	this.shape_1.setTransform(123.825,10.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLBDIAAiFIAXAAIAACFg");
	this.shape_2.setTransform(114.875,10.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLBDIAAhuIglAAIAAgXIBhAAIAAAXIglAAIAABug");
	this.shape_3.setTransform(106.525,10.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLBDIAAiFIAXAAIAACFg");
	this.shape_4.setTransform(98.175,10.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgjA3QgNgOAAgXIAAhVIAZAAIAABWQAAANAGAHQAGAGALAAQAMAAAGgGQAGgHAAgNIAAhWIAZAAIAABVQAAAXgNAOQgMANgYgBQgXABgMgNg");
	this.shape_5.setTransform(89,10.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgLBDIAAhuIglAAIAAgXIBhAAIAAAXIglAAIAABug");
	this.shape_6.setTransform(77.225,10.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAdBDIg2hXIAABXIgXAAIAAiFIAUAAIA2BXIAAhXIAXAAIAACFg");
	this.shape_7.setTransform(65.275,10.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLBDIAAiFIAXAAIAACFg");
	this.shape_8.setTransform(55.875,10.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AglBCIAAiEIAYAAIAABuIAzAAIAAAWg");
	this.shape_9.setTransform(172.95,-11.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAeBCIgJgbIgsAAIgJAbIgYAAIAtiEIAXAAIAtCEgAAPAUIgPg3IgRA3IAgAAg");
	this.shape_10.setTransform(161.3,-11.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgjA4QgMgNAAgYIAAgkQAAgYAMgNQANgNAWgBQAXABANANQAMANAAAYIAAADIgZAAIAAgFQAAgMgGgIQgFgGgMAAQgKAAgGAGQgGAIAAAMIAAAnQAAANAGAGQAGAHAKAAQAMAAAFgHQAGgGAAgNIAAgGIAZAAIAAAFQAAAYgMANQgNAMgXAAQgWAAgNgMg");
	this.shape_11.setTransform(149.225,-11.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgkA3QgNgOAAgYIAAggQAAgaANgNQANgOAXAAQAYAAANAOQANANAAAaIAAAgQAAAYgNAOQgNANgYAAQgXAAgNgNgAgSgmQgGAHAAAOIAAAkQAAANAGAHQAHAHALAAQAMAAAHgHQAGgHAAgNIAAgkQAAgOgGgHQgHgHgMAAQgLAAgHAHg");
	this.shape_12.setTransform(137,-11.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgLBCIgsiEIAaAAIAeBhIAfhhIAYAAIgsCEg");
	this.shape_13.setTransform(124.675,-11.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgnBCIAAiEIBOAAIAAAWIg2AAIAAAhIAuAAIAAAVIguAAIAAAjIA3AAIAAAVg");
	this.shape_14.setTransform(110.2,-11.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgLBCIAAhtIglAAIAAgXIBhAAIAAAXIglAAIAABtg");
	this.shape_15.setTransform(99.075,-11.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAdBCIg2hWIAABWIgXAAIAAiEIAUAAIA2BWIAAhWIAXAAIAACEg");
	this.shape_16.setTransform(87.125,-11.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgnBCIAAiEIBPAAIAAAWIg2AAIAAAhIAtAAIAAAVIgtAAIAAAjIA2AAIAAAVg");
	this.shape_17.setTransform(75.7,-11.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgLBCIAAhtIglAAIAAgXIBhAAIAAAXIglAAIAABtg");
	this.shape_18.setTransform(64.575,-11.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgiA6QgMgLAAgSIAAgFIAXAAIAAAFQAAAJAHAEQAGAGAKgBQALAAAGgEQAGgEAAgJQAAgHgFgEQgFgGgKgBIgKgCQgTgEgKgJQgJgJAAgRQAAgRAMgLQAMgLAVAAQAVAAALALQAMAKAAASIAAAEIgYAAIAAgEQAAgIgGgFQgFgFgJAAQgKABgFAEQgGAEAAAHQAAAIAFADQAFAFAKACIALACQASAEAKAJQAJAKAAARQABATgMAKQgNAKgXAAQgVAAgNgKg");
	this.shape_19.setTransform(53.4,-11.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgLBCIAAiEIAXAAIAACEg");
	this.shape_20.setTransform(44.725,-11.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgiA6QgMgLAAgSIAAgFIAYAAIAAAFQAAAJAFAEQAHAGAKgBQALAAAGgEQAGgEAAgJQAAgHgFgEQgFgGgJgBIgLgCQgTgEgKgJQgJgJAAgRQAAgRAMgLQAMgLAVAAQAVAAAMALQALAKAAASIAAAEIgYAAIAAgEQAAgIgFgFQgGgFgJAAQgKABgGAEQgFAEAAAHQAAAIAFADQAFAFAKACIAKACQAUAEAJAJQAKAKgBARQAAATgMAKQgMAKgXAAQgVAAgNgKg");
	this.shape_21.setTransform(36.15,-11.05);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAfBCIgJgbIgtAAIgIAbIgZAAIAtiEIAXAAIAtCEgAAPAUIgPg3IgRA3IAgAAg");
	this.shape_22.setTransform(24.2,-11.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(16,-23.4,163.5,46.8), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBDIAAhuIglAAIAAgXIBhAAIAAAXIglAAIAABug");
	this.shape.setTransform(193.025,33.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdBDIg2hXIAABXIgXAAIAAiFIAUAAIA2BXIAAhXIAXAAIAACFg");
	this.shape_1.setTransform(181.075,33.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnBDIAAiFIBPAAIAAAWIg2AAIAAAhIAtAAIAAAVIgtAAIAAAjIA2AAIAAAWg");
	this.shape_2.setTransform(169.65,33.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAsBDIAAhQIgjBHIgRAAIgjhHIAABQIgXAAIAAiFIAUAAIAuBdIAvhdIAUAAIAACFg");
	this.shape_3.setTransform(155.675,33.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAdBDIg2hXIAABXIgXAAIAAiFIAUAAIA2BXIAAhXIAXAAIAACFg");
	this.shape_4.setTransform(140.875,33.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgLBDIAAiFIAXAAIAACFg");
	this.shape_5.setTransform(131.475,33.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAeBDIgJgcIgsAAIgJAcIgYAAIAtiFIAXAAIAtCFgAAPAUIgPg4IgRA4IAgAAg");
	this.shape_6.setTransform(122.45,33.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgLBDIAAhuIglAAIAAgXIBhAAIAAAXIglAAIAABug");
	this.shape_7.setTransform(110.775,33.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgkA3QgNgNAAgZIAAggQAAgZANgOQANgNAXAAQAYAAANANQANAOAAAZIAAAgQAAAZgNANQgNANgYAAQgXAAgNgNgAgSgmQgGAHAAAOIAAAkQAAANAGAHQAGAHAMAAQAMAAAHgHQAGgHAAgNIAAgkQAAgOgGgHQgHgHgMAAQgMAAgGAHg");
	this.shape_8.setTransform(99.1,33.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgmBDIAAiFIBNAAIAAAWIg1AAIAAAoIAuAAIAAAUIguAAIAAAzg");
	this.shape_9.setTransform(88.325,33.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAdBDIg2hXIAABXIgXAAIAAiFIAUAAIA2BXIAAhXIAXAAIAACFg");
	this.shape_10.setTransform(76.275,33.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLBDIAAiFIAXAAIAACFg");
	this.shape_11.setTransform(66.875,33.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgnBDIAAiFIBPAAIAAAWIg2AAIAAAhIAtAAIAAAVIgtAAIAAAjIA2AAIAAAWg");
	this.shape_12.setTransform(55.6,33.75);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgvBDIAAiFIAuAAQAXAAANAOQANANAAAaIAAAcQAAAYgNAOQgNAOgXAAgAgWAsIAVAAQALAAAGgHQAHgHAAgOIAAgfQAAgOgHgHQgGgHgLAAIgVAAg");
	this.shape_13.setTransform(44.075,33.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAdBCIg2hWIAABWIgXAAIAAiEIAUAAIA2BWIAAhWIAXAAIAACEg");
	this.shape_14.setTransform(200.525,12.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgkBEQgNgOAAgYIAAghQAAgZANgNQANgOAXAAQAYAAANAOQANANAAAZIAAAhQAAAYgNAOQgNANgYAAQgXAAgNgNgAgSgZQgGAHAAAOIAAAjQAAAOAGAHQAGAHAMAAQANAAAFgHQAHgHAAgOIAAgjQAAgOgHgHQgFgHgNAAQgMAAgGAHgAgKg+IARgSIAZAAIgVASg");
	this.shape_15.setTransform(187.8,11.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgLBCIAAiEIAXAAIAACEg");
	this.shape_16.setTransform(178.725,12.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgjA4QgMgNAAgYIAAgkQAAgYAMgNQANgNAWgBQAXABANANQAMANAAAYIAAADIgZAAIAAgFQAAgMgGgIQgFgGgMAAQgKAAgGAGQgGAIAAAMIAAAnQAAANAGAGQAGAHAKAAQAMAAAFgHQAGgGAAgNIAAgGIAZAAIAAAFQAAAYgMANQgNAMgXAAQgWAAgNgMg");
	this.shape_17.setTransform(169.975,12.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAeBCIgJgbIgsAAIgJAbIgYAAIAtiEIAXAAIAtCEgAAPAUIgPg3IgRA3IAgAAg");
	this.shape_18.setTransform(157.8,12.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAVBCIgZgwIgTAAIAAAwIgZAAIAAiEIAuAAQAUABALAJQALALAAATIAAAGQAAAOgGAHQgFAJgKAEIAeA0gAgXgCIAVAAQAIABAEgFQAFgFAAgJIAAgGQAAgJgFgFQgEgEgIAAIgVAAg");
	this.shape_19.setTransform(146.225,12.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgnBCIAAiEIBPAAIAAAWIg2AAIAAAhIAtAAIAAAVIgtAAIAAAjIA2AAIAAAVg");
	this.shape_20.setTransform(134.8,12.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAdBCIg2hWIAABWIgXAAIAAiEIAUAAIA2BWIAAhWIAXAAIAACEg");
	this.shape_21.setTransform(122.675,12.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgnBCIAAiEIBOAAIAAAWIg1AAIAAAhIAtAAIAAAVIgtAAIAAAjIA2AAIAAAVg");
	this.shape_22.setTransform(111.25,12.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgjA4QgNgNAAgZIAAgiQAAgZANgNQANgNAXgBQAXABAMALQANAMAAAWIAAAAIgZAAIAAgCQAAgKgGgGQgGgFgLAAQgMAAgGAHQgGAGAAAOIAAAmQAAAOAGAGQAGAHALAAQAMAAAGgGQAGgGAAgMIAAgGIgUAAIAAgTIAtAAIAAAXQAAAXgNAMQgMAMgYAAQgXAAgMgMg");
	this.shape_23.setTransform(99.525,12.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAeBCIgJgbIgsAAIgJAbIgYAAIAtiEIAXAAIAtCEgAAPAUIgPg3IgRA3IAgAAg");
	this.shape_24.setTransform(83.75,12.35);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgLBCIgsiEIAaAAIAeBhIAfhhIAYAAIgsCEg");
	this.shape_25.setTransform(71.425,12.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgnBCIAAiEIBPAAIAAAWIg3AAIAAAhIAuAAIAAAVIguAAIAAAjIA3AAIAAAVg");
	this.shape_26.setTransform(60.45,12.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgjA3QgNgNAAgYIAAhVIAZAAIAABWQAAANAGAGQAGAHALAAQAMAAAGgHQAGgGAAgNIAAhWIAZAAIAABVQAAAYgNANQgMAMgYAAQgXAAgMgMg");
	this.shape_27.setTransform(48.5,12.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAdBCIg2hWIAABWIgXAAIAAiEIAUAAIA2BWIAAhWIAXAAIAACEg");
	this.shape_28.setTransform(35.725,12.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(0,0,236.2,46.8), null);


(lib.txt1txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape.setTransform(135.725,43.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_1.setTransform(128.625,43.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZAtQgKgKAAgSIAAghQAAgSAKgKQAJgKAQAAQARAAAKAKQAJAKAAASIAAAEIgNAAIAAgEQAAgNgFgHQgHgGgLAAQgLAAgFAGQgHAHABANIAAAhQgBANAHAHQAFAGALAAQALAAAHgGQAFgHAAgNIAAgDIANAAIAAADQAAASgJAKQgKAKgRAAQgQAAgJgKg");
	this.shape_2.setTransform(121.6,43.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAbA1IgzhRIAABRIgLAAIAAhpIAKAAIAyBRIAAhRIAMAAIAABpg");
	this.shape_3.setTransform(111.45,43.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_4.setTransform(101.325,43.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaAtQgKgKAAgSIAAggQAAgTAKgKQAKgKARAAQAQAAAKAJQAJAJAAARIAAABIgMAAIAAgBQAAgLgGgGQgGgGgLAAQgMAAgGAHQgGAGAAANIAAAiQAAANAGAGQAGAHALAAQAMAAAGgGQAGgHAAgMIAAgIIgUAAIAAgLIAhAAIAAASQAAASgKAJQgKAKgRAAQgRAAgJgKg");
	this.shape_5.setTransform(91.575,43.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_6.setTransform(82.825,43.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_7.setTransform(74.725,43.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_8.setTransform(66.425,43.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_9.setTransform(53.675,43.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_10.setTransform(45.325,43.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_11.setTransform(33.725,43.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQARAAAKAKQAJAKAAATIAAAbQAAATgJAKQgKAKgRAAgAgVAqIAUAAQALAAAHgHQAFgHABgNIAAgcQgBgOgFgHQgHgHgLAAIgUAAg");
	this.shape_12.setTransform(24.35,43.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAoBgIgqhMIgoAAIAABMIgWAAIAAi/IA+AAQAZAAAOANQAPAOAAAaIAAAKQAAAUgIAMQgKAMgQAFIAvBPgAgqABIAoAAQAOAAAIgHQAJgKAAgPIAAgLQAAgRgJgIQgIgIgOAAIgoAAg");
	this.shape_13.setTransform(132.9,17);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag1BgIAAi/IBrAAIAAAUIhUAAIAABBIBHAAIAAASIhHAAIAABFIBUAAIAAATg");
	this.shape_14.setTransform(116.35,17);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag/BgIAAi/IA8AAQAggBARAUQASASAAAjIAAAwQAAAigSATQgRASggAAgAgoBMIAlAAQAVAAAMgNQALgNAAgYIAAgzQAAgYgLgNQgMgMgVgBIglAAg");
	this.shape_15.setTransform(99.225,17);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgwBQQgTgSABgiIAAg3QgBgiATgTQARgSAfAAQAgAAASASQASATAAAiIAAA3QAAAigSATQgSASggAAQgfAAgRgTgAghhBQgLANAAAYIAAA5QAAAYALANQAMANAVAAQAWAAAMgNQALgNAAgYIAAg5QAAgYgLgNQgMgNgWAAQgVAAgMANg");
	this.shape_16.setTransform(80.7,17.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag6BgIAAi/IA8AAQAbAAAPANQAPAOAAAaIAAAQQAAAagPANQgPANgbAAIglAAIAABGgAgjAHIAlAAQAQAAAJgIQAJgIAAgRIAAgQQAAgQgJgJQgJgIgQAAIglAAg");
	this.shape_17.setTransform(63.925,17);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgzBgIAAi/IAXAAIAACrIBQAAIAAAUg");
	this.shape_18.setTransform(42.475,17);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag1BgIAAi/IBrAAIAAAUIhUAAIAABBIBHAAIAAASIhHAAIAABFIBUAAIAAATg");
	this.shape_19.setTransform(27.25,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1txt, new cjs.Rectangle(0,0,159.9,54.2), null);


(lib.offer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape.setTransform(102.125,428.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_1.setTransform(93.825,428.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_2.setTransform(87.225,433.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_3.setTransform(80.675,428.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_4.setTransform(72.375,428.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_5.setTransform(64.375,428.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_6.setTransform(57.725,428.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghA1IAAhpIAiAAQANAAAHAHQAIAGAAANIAAAEQAAAHgDAGQgEAFgFADQAHABAFAHQAFAGAAAKIAAADQgBANgHAHQgJAHgOAAgAgVArIAYAAQAIAAAGgFQAEgEAAgJIAAgDQAAgJgEgFQgFgEgJAAIgYAAgAgVgFIAWAAQAHAAAEgEQAFgFAAgHIAAgFQAAgHgFgFQgEgEgHAAIgWAAg");
	this.shape_7.setTransform(51.15,428.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_8.setTransform(41.225,428.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAnA1IAAhNIgjBHIgHAAIgjhHIAABNIgMAAIAAhpIAKAAIAoBTIAohTIALAAIAABpg");
	this.shape_9.setTransform(29.65,428.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_10.setTransform(18.025,428.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_11.setTransform(8.725,428.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgaAsQgKgJAAgTIAAhFIANAAIAABGQAAANAGAHQAHAFAKAAQAMAAAGgFQAGgHAAgNIAAhGIAMAAIAABFQAAATgJAJQgKAKgRAAQgRAAgJgKg");
	this.shape_12.setTransform(-0.65,428.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_13.setTransform(-10.475,428.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_14.setTransform(-19.825,428.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQARAAAJAKQAKAKAAATIAAAbQAAATgKAKQgJAKgRAAgAgVAqIAUAAQALAAAGgHQAGgHABgNIAAgcQgBgOgGgHQgGgHgLAAIgUAAg");
	this.shape_15.setTransform(-29.1,428.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_16.setTransform(-42.6,428.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_17.setTransform(-51.575,428.775);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_18.setTransform(119.475,411.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_19.setTransform(111.175,411.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_20.setTransform(103.175,411.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_21.setTransform(93.925,411.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgaAtQgKgKAAgSIAAggQAAgTAKgKQAKgKARAAQAQAAAKAJQAJAJAAARIAAABIgMAAIAAgBQAAgLgGgGQgGgGgLAAQgMAAgGAHQgGAGAAANIAAAiQAAANAGAGQAGAHALAAQAMAAAGgGQAGgHAAgMIAAgIIgUAAIAAgLIAhAAIAAASQAAASgKAJQgKAKgRAAQgRAAgJgKg");
	this.shape_22.setTransform(84.275,411.675);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_23.setTransform(75.625,411.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_24.setTransform(67.625,411.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_25.setTransform(55.425,411.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_26.setTransform(47.125,411.675);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIALAAIAyBRIAAhRIAMAAIAABpg");
	this.shape_27.setTransform(37.35,411.675);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_28.setTransform(27.125,411.675);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_29.setTransform(19.975,411.675);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgZAtQgKgKAAgSIAAghQAAgSAKgKQAJgKAQAAQASAAAIAKQAKAKAAASIAAAEIgNAAIAAgEQABgNgHgHQgFgGgMAAQgLAAgFAGQgHAHABANIAAAhQgBANAHAHQAFAGALAAQAMAAAFgGQAHgHgBgNIAAgDIANAAIAAADQAAASgJAKQgKAKgRAAQgQAAgJgKg");
	this.shape_30.setTransform(13.05,411.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_31.setTransform(6.025,411.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQARAAAJAKQAKAKAAATIAAAbQAAATgKAKQgJAKgRAAgAgWAqIAVAAQALAAAGgHQAHgHAAgNIAAgcQAAgOgHgHQgGgHgLAAIgVAAg");
	this.shape_32.setTransform(-0.9,411.675);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_33.setTransform(-11.2,411.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_34.setTransform(-21.425,411.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgaAtQgJgKAAgSIAAghQAAgSAJgKQAKgKAQAAQASAAAJAKQAJAKAAASIAAAEIgMAAIAAgEQgBgNgFgHQgHgGgLAAQgKAAgHAGQgFAHgBANIAAAhQABANAFAHQAHAGAKAAQALAAAHgGQAFgHABgNIAAgDIAMAAIAAADQAAASgJAKQgJAKgSAAQgQAAgKgKg");
	this.shape_35.setTransform(-31.1,411.675);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAWA1IgXgqIgWAAIAAAqIgMAAIAAhpIAiAAQAOAAAHAIQAJAHgBAOIAAAGQAAALgEAGQgFAHgJACIAaAsgAgXABIAWAAQAHAAAFgEQAFgFAAgJIAAgGQAAgJgFgEQgFgFgHAAIgWAAg");
	this.shape_36.setTransform(-43.35,411.675);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_37.setTransform(-52.275,411.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgFA1IgkhpIAOAAIAbBXIAdhXIANAAIgkBpg");
	this.shape_38.setTransform(-61.6,411.675);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAJAWIgJgQIgJAQIgEAHIgIgFIAFgHIANgOIgSgDIgIgDIACgIIAIACIARAIIgBgTIAAgIIAIAAIAAAIIgCATIAQgIIAJgCIADAIIgIADIgSADIAMAOIAFAHIgIAFg");
	this.shape_39.setTransform(-69.95,409.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_40.setTransform(71.025,377.475);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AggA2IAAgIQAAgNAEgHQAFgJANgGIAMgHQAJgEAEgGQAEgGAAgHIAAgDQAAgJgFgFQgFgGgJAAQgJABgFAFQgFAGgBAKIAAAFIgLAAIAAgGQgBgPAJgIQAJgJAOAAQAPAAAIAIQAJAJAAANIAAADQAAAMgHAIQgFAIgNAGIgMAHQgIAFgDAEQgEAGAAAHIA1AAIAAALg");
	this.shape_41.setTransform(62.35,377.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_42.setTransform(53.225,377.475);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AggA2IAAgIQAAgNAEgHQAFgJAMgGIANgHQAJgEAEgGQAEgGAAgHIAAgDQAAgJgFgFQgFgGgJAAQgJABgFAFQgGAGAAAKIAAAFIgLAAIAAgGQAAgPAIgIQAJgJAOAAQAOAAAJAIQAIAJAAANIAAADQABAMgHAIQgFAIgNAGIgMAHQgIAFgDAEQgDAGgBAHIA1AAIAAALg");
	this.shape_43.setTransform(44.2,377.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgiBDIA4iFIANAAIg4CFg");
	this.shape_44.setTransform(35.9,378.175);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_45.setTransform(27.975,377.475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAJA1IAAhbIgYAQIgGgJIAggVIALAAIAABpg");
	this.shape_46.setTransform(19.45,377.475);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgiBDIA4iFIANAAIg4CFg");
	this.shape_47.setTransform(12.85,378.175);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAJA1IAAhbIgYAQIgGgJIAggVIAKAAIAABpg");
	this.shape_48.setTransform(5.95,377.475);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_49.setTransform(-1.225,377.475);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_50.setTransform(-12.275,377.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_51.setTransform(-20.475,377.475);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_52.setTransform(119.775,360.375);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_53.setTransform(110.625,360.375);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_54.setTransform(101.775,360.375);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_55.setTransform(92.425,360.375);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AAYA1IAAgwIgvAAIAAAwIgNAAIAAhpIANAAIAAAuIAvAAIAAguIAMAAIAABpg");
	this.shape_56.setTransform(82.4,360.375);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_57.setTransform(70.225,360.375);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgZAtQgKgKAAgSIAAghQAAgSAKgKQAJgKAQAAQASAAAJAKQAJAKAAASIAAAEIgNAAIAAgEQAAgNgFgHQgHgGgLAAQgLAAgFAGQgHAHAAANIAAAhQAAANAHAHQAFAGALAAQALAAAHgGQAFgHAAgNIAAgDIANAAIAAADQAAASgJAKQgJAKgSAAQgQAAgJgKg");
	this.shape_58.setTransform(60.95,360.375);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgLAAIAAhpIAJAAIAzBRIAAhRIALAAIAABpg");
	this.shape_59.setTransform(50.9,360.375);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_60.setTransform(40.875,360.375);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_61.setTransform(30.85,360.375);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_62.setTransform(23.425,360.375);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIA5AAIAAALIgtAAIAAAnIAnAAIAAAKIgnAAIAAAtg");
	this.shape_63.setTransform(17.7,360.375);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_64.setTransform(5.475,360.375);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_65.setTransform(-1.275,360.375);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_66.setTransform(-7.825,360.375);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AAbA1IgzhRIAABRIgLAAIAAhpIAKAAIAyBRIAAhRIAMAAIAABpg");
	this.shape_67.setTransform(-17.35,360.375);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_68.setTransform(-27.375,360.375);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_69.setTransform(-35.625,360.375);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_70.setTransform(-43.525,360.375);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_71.setTransform(-51.725,360.375);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_72.setTransform(-60.625,360.375);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_73.setTransform(-69.475,360.375);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_74.setTransform(84.95,343.275);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_75.setTransform(74.725,343.275);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgaAtQgJgKAAgSIAAghQAAgSAJgKQAKgKAQAAQASAAAIAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgFgGgMAAQgKAAgHAGQgFAHAAANIAAAhQAAANAFAHQAHAGAKAAQAMAAAFgGQAHgHAAgNIAAgDIAMAAIAAADQAAASgJAKQgKAKgRAAQgQAAgKgKg");
	this.shape_76.setTransform(65.05,343.275);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_77.setTransform(52.025,343.275);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQARAAAKAKQAJAKAAATIAAAbQAAATgJAKQgKAKgRAAgAgVAqIAUAAQALAAAHgHQAFgHABgNIAAgcQgBgOgFgHQgHgHgLAAIgUAAg");
	this.shape_78.setTransform(42.35,343.275);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAbA1IgzhRIAABRIgLAAIAAhpIAKAAIAyBRIAAhRIAMAAIAABpg");
	this.shape_79.setTransform(32.05,343.275);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_80.setTransform(22.025,343.275);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_81.setTransform(15.025,343.275);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgZAtQgKgKAAgSIAAghQAAgSAKgKQAJgKAQAAQASAAAIAKQAKAKAAASIAAAEIgNAAIAAgEQABgNgHgHQgFgGgMAAQgLAAgFAGQgHAHABANIAAAhQgBANAHAHQAFAGALAAQAMAAAFgGQAHgHgBgNIAAgDIANAAIAAADQAAASgJAKQgKAKgRAAQgQAAgJgKg");
	this.shape_82.setTransform(8.1,343.275);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAbA1IgzhRIAABRIgLAAIAAhpIAKAAIAyBRIAAhRIAMAAIAABpg");
	this.shape_83.setTransform(-1.95,343.275);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_84.setTransform(-11.975,343.275);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_85.setTransform(-22,343.275);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_86.setTransform(-29.425,343.275);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIA5AAIAAALIgtAAIAAAnIAnAAIAAAKIgnAAIAAAtg");
	this.shape_87.setTransform(-35.15,343.275);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_88.setTransform(125.675,313.65);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgTAtQgJgKAAgSIgOAAIAAgKIAOAAIAAgNIgOAAIAAgKIAOAAQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgGgHgLAAQgLAAgGAHQgGAHAAANIAdAAIAAAKIgdAAIAAANIAZAAIAAAKIgZAAQAAANAGAHQAGAHALAAQALAAAGgHQAHgHAAgNIAAgDIAMAAIAAADQAAASgKAKQgJAKgRAAQgRAAgJgKg");
	this.shape_89.setTransform(118.325,309.075);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgJA1IAAgNQAAgJADgJQADgKAJgPIALgWQAEgIAAgIIgqAAIAAAPIgLAAIAAgaIBBAAIAAAKQAAAIgCAJQgEAIgIAQQgKAPgDAJQgDAIAAAJIAAANg");
	this.shape_90.setTransform(109.35,309.075);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AAUA1IAAgXIgzAAIAAgJIAmhJIAMAAIgkBHIAlAAIAAgWIAMAAIAAA4g");
	this.shape_91.setTransform(101.2,309.075);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgIAOIAEgHIADgGIAAgHIAAgMIAKAAIAAALIgBAKIgEAJIgEAHg");
	this.shape_92.setTransform(94.95,314.95);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_93.setTransform(88.775,309.075);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_94.setTransform(79.575,309.075);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_95.setTransform(70.025,309.075);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_96.setTransform(63.225,313.65);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AggA2IAAgIQAAgNAEgHQAFgJAMgGIANgHQAJgEAEgGQAEgGAAgHIAAgDQAAgJgFgFQgFgGgJAAQgJABgFAFQgFAGgBAKIAAAFIgLAAIAAgGQgBgPAJgIQAJgJAOAAQAPAAAIAIQAJAJAAANIAAADQAAAMgHAIQgFAIgNAGIgMAHQgIAFgDAEQgEAGAAAHIA1AAIAAALg");
	this.shape_97.setTransform(56.95,309);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgJA1IAAgNQAAgJADgJQADgKAJgPIAMgWQADgIAAgIIgqAAIAAAPIgLAAIAAgaIBBAAIAAAKQAAAIgDAJQgDAIgIAQQgKAPgDAJQgDAIAAAJIAAANg");
	this.shape_98.setTransform(48.7,309.075);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgGApIAAgPIANAAIAAAPgAgGgZIAAgPIANAAIAAAPg");
	this.shape_99.setTransform(39.625,310.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_100.setTransform(33.075,309.075);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_101.setTransform(23.525,309.075);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgjA1IAAgJIA2hVIg0AAIAAgLIBDAAIAAAJIg2BVIA4AAIAAALg");
	this.shape_102.setTransform(14.225,309.075);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_103.setTransform(5.125,309.075);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_104.setTransform(-3.125,309.075);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_105.setTransform(-11.675,309.075);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_106.setTransform(-24.475,309.075);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_107.setTransform(-35.925,309.075);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_108.setTransform(-45.175,309.075);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_109.setTransform(-54.325,309.075);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_110.setTransform(-63.625,309.075);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_111.setTransform(-72.925,309.075);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_112.setTransform(110.325,291.975);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_113.setTransform(103.175,291.975);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgaAtQgJgKAAgSIAAghQAAgSAJgKQAKgKAQAAQASAAAJAKQAJAKAAASIAAAEIgMAAIAAgEQgBgNgFgHQgHgGgLAAQgKAAgHAGQgFAHgBANIAAAhQABANAFAHQAHAGAKAAQALAAAHgGQAFgHABgNIAAgDIAMAAIAAADQAAASgJAKQgJAKgSAAQgQAAgKgKg");
	this.shape_114.setTransform(96.25,291.975);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_115.setTransform(87.675,291.975);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AAWA1IgXgqIgWAAIAAAqIgMAAIAAhpIAiAAQAOAAAHAIQAIAHAAAOIAAAGQABALgFAGQgFAHgJACIAaAsgAgXABIAWAAQAIAAAEgEQAFgFAAgJIAAgGQAAgJgFgEQgEgFgIAAIgWAAg");
	this.shape_116.setTransform(78.9,291.975);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_117.setTransform(69.625,291.975);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_118.setTransform(59.575,296.55);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgTAtQgJgKAAgSIgOAAIAAgKIAOAAIAAgNIgOAAIAAgKIAOAAQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgGgHgLAAQgLAAgGAHQgGAHAAANIAdAAIAAAKIgdAAIAAANIAZAAIAAAKIgZAAQAAANAGAHQAGAHALAAQALAAAGgHQAHgHAAgNIAAgDIAMAAIAAADQAAASgKAKQgJAKgRAAQgRAAgJgKg");
	this.shape_119.setTransform(52.225,291.975);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AAUA1IAAgXIgzAAIAAgJIAlhJIAOAAIglBHIAlAAIAAgWIAMAAIAAA4g");
	this.shape_120.setTransform(42.85,291.975);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AggA2IAAgIQAAgNAEgHQAFgJAMgGIANgHQAJgEAEgGQAEgGAAgHIAAgDQAAgJgFgFQgFgGgJAAQgJABgFAFQgGAGAAAKIAAAFIgMAAIAAgGQABgPAIgIQAJgJAOAAQAOAAAJAIQAIAJAAANIAAADQABAMgHAIQgFAIgNAGIgMAHQgIAFgDAEQgDAGgBAHIA1AAIAAALg");
	this.shape_121.setTransform(34.75,291.9);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgIAOIADgHIAEgGIAAgHIAAgMIAKAAIAAALIAAAKIgFAJIgEAHg");
	this.shape_122.setTransform(28,297.85);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AAJA1IAAhbIgYAQIgGgJIAggVIAKAAIAABpg");
	this.shape_123.setTransform(22.6,291.975);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AghA2IAAgIQAAgNAGgHQAEgJANgGIAMgHQAJgEAEgGQAEgGAAgHIAAgDQAAgJgFgFQgFgGgJAAQgJABgFAFQgGAGABAKIAAAFIgNAAIAAgGQAAgPAJgIQAIgJAPAAQAPAAAIAIQAJAJgBANIAAADQAAAMgFAIQgGAIgNAGIgMAHQgIAFgDAEQgEAGAAAHIA2AAIAAALg");
	this.shape_124.setTransform(15.7,291.9);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_125.setTransform(6.825,291.975);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_126.setTransform(0.025,296.55);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AAJA1IAAhbIgYAQIgGgJIAggVIAKAAIAABpg");
	this.shape_127.setTransform(-5.75,291.975);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_128.setTransform(-12.925,291.975);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgGApIAAgPIANAAIAAAPgAgGgZIAAgPIANAAIAAAPg");
	this.shape_129.setTransform(-26.125,293.2);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AAWA1IgXgqIgWAAIAAAqIgMAAIAAhpIAiAAQAOAAAHAIQAJAHgBAOIAAAGQABALgFAGQgFAHgJACIAaAsgAgXABIAWAAQAHAAAFgEQAFgFAAgJIAAgGQAAgJgFgEQgFgFgHAAIgWAAg");
	this.shape_130.setTransform(-32.35,291.975);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_131.setTransform(-41.625,291.975);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgFA1IgkhpIANAAIAdBXIAdhXIAMAAIglBpg");
	this.shape_132.setTransform(-51.2,291.975);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_133.setTransform(-60.025,291.975);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_134.setTransform(121.075,279.45);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_135.setTransform(114.525,274.875);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_136.setTransform(106.225,274.875);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_137.setTransform(96.45,274.875);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_138.setTransform(86.225,274.875);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_139.setTransform(79.075,274.875);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgaAtQgJgKAAgSIAAghQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgFgGgMAAQgKAAgHAGQgFAHAAANIAAAhQAAANAFAHQAHAGAKAAQAMAAAFgGQAHgHAAgNIAAgDIAMAAIAAADQAAASgJAKQgKAKgRAAQgQAAgKgKg");
	this.shape_140.setTransform(72.15,274.875);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_141.setTransform(65.125,274.875);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQARAAAJAKQAKAKAAATIAAAbQAAATgKAKQgJAKgRAAgAgVAqIAUAAQALAAAGgHQAGgHABgNIAAgcQgBgOgGgHQgGgHgLAAIgUAAg");
	this.shape_142.setTransform(58.2,274.875);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AAbA1IgzhRIAABRIgLAAIAAhpIAKAAIAyBRIAAhRIAMAAIAABpg");
	this.shape_143.setTransform(47.9,274.875);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_144.setTransform(37.675,274.875);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgZAtQgKgKAAgSIAAghQAAgSAKgKQAJgKAQAAQARAAAKAKQAJAKAAASIAAAEIgNAAIAAgEQAAgNgFgHQgHgGgLAAQgLAAgFAGQgHAHAAANIAAAhQAAANAHAHQAFAGALAAQALAAAHgGQAFgHAAgNIAAgDIANAAIAAADQAAASgJAKQgKAKgRAAQgQAAgJgKg");
	this.shape_145.setTransform(28,274.875);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_146.setTransform(14.975,274.875);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQAQAAAKAKQAKAKAAATIAAAbQAAATgKAKQgKAKgQAAgAgVAqIAUAAQALAAAGgHQAHgHAAgNIAAgcQAAgOgHgHQgGgHgLAAIgUAAg");
	this.shape_147.setTransform(5.3,274.875);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AAbA1IgzhRIAABRIgLAAIAAhpIAJAAIAzBRIAAhRIALAAIAABpg");
	this.shape_148.setTransform(-5,274.875);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_149.setTransform(-13.975,274.875);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_150.setTransform(-20.725,274.875);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_151.setTransform(-26.375,274.875);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_152.setTransform(-34.925,274.875);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AAnA1IAAhNIgjBHIgHAAIgjhHIAABNIgLAAIAAhpIAJAAIAoBTIAohTIAKAAIAABpg");
	this.shape_153.setTransform(-46.35,274.875);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgaAsQgKgJAAgTIAAhFIANAAIAABGQAAANAHAHQAFAFALAAQAMAAAGgFQAGgHAAgNIAAhGIANAAIAABFQAAATgKAJQgKAKgRAAQgQAAgKgKg");
	this.shape_154.setTransform(-58.05,274.95);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgaAtQgJgKAAgSIAAghQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgFgGgMAAQgKAAgHAGQgFAHAAANIAAAhQAAANAFAHQAHAGAKAAQAMAAAFgGQAHgHAAgNIAAgDIAMAAIAAADQAAASgJAKQgKAKgRAAQgQAAgKgKg");
	this.shape_155.setTransform(-67.8,274.875);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_156.setTransform(107.825,262.35);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AgTAtQgJgKAAgSIgOAAIAAgKIAOAAIAAgNIgOAAIAAgKIAOAAQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgGgHgLAAQgLAAgGAHQgGAHAAANIAdAAIAAAKIgdAAIAAANIAZAAIAAAKIgZAAQAAANAGAHQAGAHALAAQALAAAGgHQAHgHAAgNIAAgDIAMAAIAAADQAAASgKAKQgJAKgRAAQgRAAgJgKg");
	this.shape_157.setTransform(100.475,257.775);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AAUA1IAAgXIgzAAIAAgJIAlhJIAOAAIglBHIAlAAIAAgWIAMAAIAAA4g");
	this.shape_158.setTransform(91.1,257.775);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_159.setTransform(82.475,257.775);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AgIAOIAEgHIADgGIABgHIAAgMIAJAAIAAALIgBAKIgEAJIgEAHg");
	this.shape_160.setTransform(75.3,263.65);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_161.setTransform(69.125,257.775);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_162.setTransform(59.825,257.775);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AAUA1IAAgXIgzAAIAAgJIAmhJIAMAAIgkBHIAlAAIAAgWIAMAAIAAA4g");
	this.shape_163.setTransform(51.1,257.775);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_164.setTransform(45.225,262.35);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_165.setTransform(38.425,257.775);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AgYAuQgJgJAAgOIAAgBIAMAAIAAABQAAAKAGAFQAGAFAJAAQAKAAAFgFQAHgHgBgKIAAgGQABgLgHgEQgFgGgKAAQgHAAgFADQgFADgEAGIgKgCIAFg5IA3AAIAAALIgtAAIgDAhQAEgEAFgBQAGgCAGAAQAOAAAJAJQAJAHAAAPIAAAGQAAAPgJAKQgJAIgQAAQgPAAgJgIg");
	this.shape_166.setTransform(29.35,257.85);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AgGApIAAgPIANAAIAAAPgAgGgZIAAgPIANAAIAAAPg");
	this.shape_167.setTransform(19.625,259);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_168.setTransform(12.625,257.775);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQAQAAAKAKQAKAKAAATIAAAbQAAATgKAKQgKAKgQAAgAgVAqIAUAAQALAAAGgHQAHgHAAgNIAAgcQAAgOgHgHQgGgHgLAAIgUAAg");
	this.shape_169.setTransform(2.95,257.775);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_170.setTransform(-6.925,257.775);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQAQAAALAKQAJAKAAATIAAAbQAAATgJAKQgLAKgQAAgAgWAqIAVAAQALAAAHgHQAFgHAAgNIAAgcQAAgOgFgHQgHgHgLAAIgVAAg");
	this.shape_171.setTransform(-16.45,257.775);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("AgaAsQgJgJAAgTIAAhFIAMAAIAABGQAAANAGAHQAHAFAKAAQAMAAAGgFQAGgHAAgNIAAhGIAMAAIAABFQAAATgJAJQgJAKgSAAQgRAAgJgKg");
	this.shape_172.setTransform(-26.6,257.85);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_173.setTransform(-35.375,257.775);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQAQAAAKAKQAKAKAAATIAAAbQAAATgKAKQgKAKgQAAgAgVAqIAUAAQALAAAGgHQAHgHAAgNIAAgcQAAgOgHgHQgGgHgLAAIgUAAg");
	this.shape_174.setTransform(-44.65,257.775);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_175.setTransform(-54.525,257.775);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_176.setTransform(104.875,240.675);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_177.setTransform(95.625,240.675);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_178.setTransform(86.475,240.675);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_179.setTransform(77.175,240.675);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_180.setTransform(67.875,240.675);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_181.setTransform(56.625,240.675);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_182.setTransform(47.725,240.675);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFFFFF").s().p("AAWA1IgXgqIgWAAIAAAqIgMAAIAAhpIAiAAQAOAAAHAIQAJAHgBAOIAAAGQABALgFAGQgFAHgJACIAaAsgAgXABIAWAAQAHAAAFgEQAFgFAAgJIAAgGQAAgJgFgEQgFgFgHAAIgWAAg");
	this.shape_183.setTransform(39.2,240.675);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_184.setTransform(29.025,240.675);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_185.setTransform(19.975,240.675);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#FFFFFF").s().p("AAnA1IAAhNIgjBHIgHAAIgjhHIAABNIgLAAIAAhpIAJAAIAoBTIAohTIAKAAIAABpg");
	this.shape_186.setTransform(8.55,240.675);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_187.setTransform(-0.275,240.675);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_188.setTransform(-7.725,245.25);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_189.setTransform(-14.275,240.675);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_190.setTransform(-22.575,240.675);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_191.setTransform(-31.675,240.675);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_192.setTransform(-39.975,240.675);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FFFFFF").s().p("AAnA1IAAhNIgjBHIgHAAIgjhHIAABNIgLAAIAAhpIAKAAIAnBTIAphTIAKAAIAABpg");
	this.shape_193.setTransform(-51.15,240.675);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_194.setTransform(96.725,223.575);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_195.setTransform(87.425,223.575);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_196.setTransform(74.825,223.575);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FFFFFF").s().p("AgjA1IAAgJIA2hVIg0AAIAAgLIBDAAIAAAJIg2BVIA4AAIAAALg");
	this.shape_197.setTransform(65.525,223.575);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_198.setTransform(56.425,223.575);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_199.setTransform(48.175,223.575);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_200.setTransform(39.625,223.575);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_201.setTransform(29.575,228.15);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FFFFFF").s().p("AgTAtQgJgKAAgSIgOAAIAAgKIAOAAIAAgNIgOAAIAAgKIAOAAQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgGgHgLAAQgLAAgGAHQgGAHAAANIAdAAIAAAKIgdAAIAAANIAZAAIAAAKIgZAAQAAANAGAHQAGAHALAAQALAAAGgHQAHgHAAgNIAAgDIAMAAIAAADQAAASgKAKQgJAKgRAAQgRAAgJgKg");
	this.shape_202.setTransform(22.225,223.575);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_203.setTransform(12.625,223.575);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FFFFFF").s().p("AgXAvQgJgJAAgOIAAgBIAMAAIAAABQAAAKAGAFQAFAFAJAAQALAAAGgGQAFgHAAgLIAAgSQgEAFgGADQgGACgHAAQgPAAgJgIQgJgIAAgOIAAgEQAAgPAKgIQAJgJAPAAQAQAAAJAJQAKAJAAAPIAAAnQAAASgJAJQgJAKgRAAQgOAAgJgIgAgPglQgGAFAAAKIAAADQAAALAGAFQAFAEAKAAQALAAAGgEQAFgFAAgLIAAgDQAAgKgGgFQgFgGgLAAQgKAAgFAGg");
	this.shape_204.setTransform(3.475,223.575);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FFFFFF").s().p("AgIAOIAEgHIADgGIAAgHIAAgMIAKAAIAAALIgBAKIgEAJIgEAHg");
	this.shape_205.setTransform(-3.45,229.45);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#FFFFFF").s().p("AgYAuQgJgJAAgPIAAAAIAMAAIAAAAQAAALAGAFQAFAFAKAAQAKAAAGgFQAFgHAAgKIAAgGQAAgLgFgEQgGgGgKAAQgGAAgGADQgFADgDAGIgKgCIADg5IA3AAIAAALIgtAAIgCAhQAFgEAFgBQAFgCAGAAQAPAAAIAJQAJAHAAAPIAAAGQAAAPgJAKQgJAIgQAAQgPAAgJgIg");
	this.shape_206.setTransform(-9.4,223.65);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_207.setTransform(-18.425,223.575);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_208.setTransform(-27.375,223.575);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_209.setTransform(-34.175,228.15);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#FFFFFF").s().p("AAJA1IAAhbIgYAQIgGgJIAggVIAKAAIAABpg");
	this.shape_210.setTransform(-39.95,223.575);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#FFFFFF").s().p("AAUA1IAAgXIgzAAIAAgJIAlhJIAOAAIglBHIAlAAIAAgWIAMAAIAAA4g");
	this.shape_211.setTransform(-46.9,223.575);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#FFFFFF").s().p("AgGApIAAgPIANAAIAAAPgAgGgZIAAgPIANAAIAAAPg");
	this.shape_212.setTransform(98.125,207.7);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_213.setTransform(92.375,206.475);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_214.setTransform(83.475,206.475);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#FFFFFF").s().p("AAWA1IgXgqIgWAAIAAAqIgMAAIAAhpIAiAAQAOAAAIAIQAHAHAAAOIAAAGQABALgFAGQgFAHgJACIAaAsgAgXABIAWAAQAHAAAFgEQAFgFAAgJIAAgGQAAgJgFgEQgFgFgHAAIgWAAg");
	this.shape_215.setTransform(74.95,206.475);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_216.setTransform(64.775,206.475);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIAgAAQAPAAAIAIQAIAHAAAOIAAAJQAAAOgIAHQgIAIgPAAIgUAAIAAAmgAgTAEIAUAAQAJAAAFgEQAFgFAAgJIAAgJQAAgJgFgEQgFgFgJAAIgUAAg");
	this.shape_217.setTransform(55.725,206.475);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#FFFFFF").s().p("AAnA1IAAhNIgjBHIgHAAIgjhHIAABNIgMAAIAAhpIAKAAIAoBTIAohTIAKAAIAABpg");
	this.shape_218.setTransform(44.3,206.475);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_219.setTransform(35.475,206.475);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_220.setTransform(28.025,211.05);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FFFFFF").s().p("AgTAtQgJgKAAgSIgOAAIAAgKIAOAAIAAgNIgOAAIAAgKIAOAAQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgGgHgLAAQgLAAgGAHQgGAHAAANIAdAAIAAAKIgdAAIAAANIAZAAIAAAKIgZAAQAAANAGAHQAGAHALAAQALAAAGgHQAHgHAAgNIAAgDIAMAAIAAADQAAASgKAKQgJAKgRAAQgRAAgJgKg");
	this.shape_221.setTransform(20.675,206.475);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#FFFFFF").s().p("AAUA1IAAgXIgzAAIAAgJIAmhJIAMAAIgkBHIAlAAIAAgWIAMAAIAAA4g");
	this.shape_222.setTransform(11.3,206.475);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#FFFFFF").s().p("AAUA1IAAgXIgzAAIAAgJIAlhJIAOAAIglBHIAlAAIAAgWIAMAAIAAA4g");
	this.shape_223.setTransform(3.15,206.475);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#FFFFFF").s().p("AgIAOIADgHIAEgGIABgHIAAgMIAJAAIAAALIgBAKIgFAJIgDAHg");
	this.shape_224.setTransform(-3.1,212.35);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FFFFFF").s().p("AgJA1IAAgNQAAgJADgJQADgKAJgPIALgWQAEgIAAgIIgqAAIAAAPIgLAAIAAgaIBBAAIAAAKQAAAIgCAJQgDAIgKAQQgJAPgDAJQgDAIAAAJIAAANg");
	this.shape_225.setTransform(-8.65,206.475);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_226.setTransform(-17.025,206.475);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#FFFFFF").s().p("AgYAuQgJgJAAgOIAAgBIAMAAIAAABQAAAKAGAFQAGAFAJAAQAKAAAFgFQAHgHAAgKIAAgGQAAgLgHgEQgFgGgKAAQgGAAgGADQgFADgEAGIgKgCIAEg5IA4AAIAAALIgtAAIgDAhQAEgEAFgBQAGgCAGAAQAOAAAJAJQAJAHAAAPIAAAGQAAAPgJAKQgJAIgQAAQgPAAgJgIg");
	this.shape_227.setTransform(-26.1,206.55);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_228.setTransform(-32.625,211.05);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#FFFFFF").s().p("AAJA1IAAhbIgYAQIgGgJIAggVIAKAAIAABpg");
	this.shape_229.setTransform(-38.4,206.475);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#FFFFFF").s().p("AghA2IAAgIQABgNAEgHQAFgJANgGIAMgHQAJgEAEgGQAEgGAAgHIAAgDQAAgJgFgFQgFgGgJAAQgJABgFAFQgFAGAAAKIAAAEIgMAAIAAgFQgBgPAJgIQAJgJAOAAQAPAAAIAIQAJAJAAANIAAADQgBAMgGAIQgFAIgNAGIgMAHQgIAFgDAEQgDAGgBAHIA2AAIAAALg");
	this.shape_230.setTransform(-45.3,206.4);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#FFFFFF").s().p("AgGApIAAgPIANAAIAAAPgAgGgZIAAgPIANAAIAAAPg");
	this.shape_231.setTransform(120.225,190.6);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_232.setTransform(113.425,189.375);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQARAAAKAKQAJAKAAATIAAAbQAAATgJAKQgKAKgRAAgAgWAqIAVAAQALAAAHgHQAFgHAAgNIAAgcQAAgOgFgHQgHgHgLAAIgVAAg");
	this.shape_233.setTransform(103.9,189.375);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_234.setTransform(94.025,189.375);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#FFFFFF").s().p("AAWA1IgXgqIgWAAIAAAqIgMAAIAAhpIAiAAQAOAAAHAIQAJAHgBAOIAAAGQAAALgEAGQgFAHgJACIAaAsgAgXABIAWAAQAHAAAFgEQAFgFAAgJIAAgGQAAgJgFgEQgFgFgHAAIgWAAg");
	this.shape_235.setTransform(85,189.375);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_236.setTransform(75.475,189.375);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_237.setTransform(65.95,189.375);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_238.setTransform(56.975,189.375);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#FFFFFF").s().p("AgJAKIAAgUIATAAIAAAUg");
	this.shape_239.setTransform(47.1,193.65);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#FFFFFF").s().p("AATAxQgFgGAAgJIAAgNQAAgJAFgGQAFgFAKgBQAKABAFAFQAFAGAAAJIAAANQAAAJgFAGQgFAFgKAAQgKAAgFgFgAAdAPQgCACAAAEIAAAOQAAADACACQACADADAAQAEAAABgDQACgCAAgDIAAgOQAAgEgCgCQgBgCgEAAQgDAAgCACgAglA1IA8hpIAPAAIg8BpgAgwgFQgFgFAAgKIAAgNQAAgKAFgFQAFgFAKAAQAKAAAFAFQAFAFAAAKIAAANQAAAKgFAFQgFAFgKAAQgKAAgFgFgAgmgnQgCACAAAEIAAAOQAAADACACQACACADABQADgBACgCQACgCAAgDIAAgOQAAgEgCgCQgCgCgDAAQgDAAgCACg");
	this.shape_240.setTransform(38.925,189.4);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#FFFFFF").s().p("AgaAuQgKgJAAgQIAAgDIATAAIAAADQAAAIAFAEQAEAFAIAAQAIAAAFgEQAEgEAAgHIAAgCQAAgHgEgEQgFgEgIAAIgIAAIAAgOIAHAAQAHAAAEgDQAEgEAAgGIAAgCQAAgGgEgEQgEgDgGAAQgIAAgEADQgEAEAAAGIAAAEIgTAAIAAgDQAAgPAJgIQAKgJAQAAQAPAAAJAIQAKAHAAAOIAAACQAAAHgEAGQgDAFgGAEQAIABAEAHQAEAGAAAJIAAACQAAAPgKAIQgKAIgRAAQgRAAgJgJg");
	this.shape_241.setTransform(28.375,189.375);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#FFFFFF").s().p("AAPA1IAAgUIgxAAIAAgPIAlhGIAUAAIgjBDIAbAAIAAgSIATAAIAAA4g");
	this.shape_242.setTransform(19.6,189.375);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#FFFFFF").s().p("AgLAOIADgGIAEgIIABgGIAAgPIAPAAIAAANIgBANIgGALIgFAGg");
	this.shape_243.setTransform(13.125,195);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgBIATAAIAAABQAAAHAEAEQAEAEAHAAQAIAAAFgFQAEgEAAgJIAAgOQgDAEgGABQgFACgFAAQgQAAgJgJQgJgHAAgPIAAgCQAAgQAKgJQAJgJARAAQASAAAJAKQAKAJAAARIAAAkQAAASgKAJQgJAKgSAAQgPAAgKgJgAgMghQgFAEAAAJIAAABQAAAJAFAEQAEAEAIAAQAJAAAEgEQAFgEAAgJIAAgBQAAgJgFgEQgEgEgJAAQgIAAgEAEg");
	this.shape_244.setTransform(6.725,189.375);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#FFFFFF").s().p("AgKApIAAgVIAVAAIAAAVgAgKgTIAAgVIAVAAIAAAVg");
	this.shape_245.setTransform(-2.7,190.575);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#FFFFFF").s().p("AgfA1IAAhpIA/AAIAAARIgrAAIAAAbIAkAAIAAAQIgkAAIAAAcIArAAIAAARg");
	this.shape_246.setTransform(-8.725,189.375);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#FFFFFF").s().p("AAYA1IgHgWIgjAAIgHAWIgUAAIAkhpIASAAIAkBpgAANAQIgNgsIgNAsIAaAAg");
	this.shape_247.setTransform(-18.2,189.375);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#FFFFFF").s().p("AgJA1IAAhXIgdAAIAAgSIBNAAIAAASIgdAAIAABXg");
	this.shape_248.setTransform(-27.525,189.375);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_249.setTransform(-37.125,193.95);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#FFFFFF").s().p("AATAxQgFgFAAgJIAAgOQAAgJAFgFQAFgGAJAAQAJAAAEAGQAFAEAAAKIAAAOQAAAJgFAFQgEAFgJAAQgJABgFgGgAAaANQgCADAAAEIAAAPQAAAFACADQACACAFAAQAEAAACgCQADgDAAgFIAAgPQAAgEgDgDQgCgCgEgBQgFABgCACgAgjA1IA9hpIAKAAIg9BpgAgugGQgEgEAAgKIAAgOQAAgJAEgFQAFgFAJAAQAJAAAFAEQAFAGAAAJIAAAOQAAAKgFAEQgFAGgJAAQgJAAgFgGgAgngqQgCADAAAFIAAAPQAAAFACACQADADAEAAQAEAAADgDQACgCAAgFIAAgPQAAgFgCgDQgDgCgEAAQgEAAgDACg");
	this.shape_250.setTransform(-45.125,189.4);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#FFFFFF").s().p("AgYAuQgJgJAAgPIAAAAIAMAAIAAAAQAAALAGAFQAGAFAJAAQAKAAAFgFQAHgHAAgKIAAgGQAAgLgHgEQgFgGgKAAQgGAAgGADQgFADgEAGIgJgCIADg5IA4AAIAAALIguAAIgCAhQAFgEAEgBQAGgCAGAAQAOAAAJAJQAJAHAAAPIAAAGQAAAPgJAKQgJAIgQAAQgPAAgJgIg");
	this.shape_251.setTransform(-55.45,189.45);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#FFFFFF").s().p("AgIAOIADgHIAEgGIABgHIAAgMIAJAAIAAALIAAAKIgGAJIgDAHg");
	this.shape_252.setTransform(-62.35,195.25);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#FFFFFF").s().p("AgJA1IAAgNQAAgJADgJQADgKAJgPIALgWQADgIAAgIIgpAAIAAAPIgMAAIAAgaIBDAAIAAAKQAAAIgEAJQgCAIgKAQQgJAPgDAJQgDAIAAAJIAAANg");
	this.shape_253.setTransform(-67.9,189.375);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#FFFFFF").s().p("AgGApIAAgPIANAAIAAAPgAgGgZIAAgPIANAAIAAAPg");
	this.shape_254.setTransform(109.825,173.5);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIALAAIAyBRIAAhRIAMAAIAABpg");
	this.shape_255.setTransform(102.6,172.275);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_256.setTransform(95.175,172.275);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_257.setTransform(88.625,172.275);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_258.setTransform(79.075,176.85);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#FFFFFF").s().p("AgTAtQgJgKAAgSIgOAAIAAgKIAOAAIAAgNIgOAAIAAgKIAOAAQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgGgHgLAAQgLAAgGAHQgGAHAAANIAdAAIAAAKIgdAAIAAANIAZAAIAAAKIgZAAQAAANAGAHQAGAHALAAQALAAAGgHQAHgHAAgNIAAgDIAMAAIAAADQAAASgKAKQgJAKgRAAQgRAAgJgKg");
	this.shape_259.setTransform(71.725,172.275);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#FFFFFF").s().p("AgXAvQgJgJAAgOIAAgBIAMAAIAAABQAAAKAGAFQAFAFAJAAQALAAAGgGQAFgHAAgLIAAgSQgEAFgGADQgGACgHAAQgPAAgJgIQgJgIAAgOIAAgEQAAgPAKgIQAJgJAPAAQAQAAAJAJQAKAJAAAPIAAAnQAAASgJAJQgJAKgRAAQgOAAgJgIgAgPglQgGAFAAAKIAAADQAAALAGAFQAFAEAKAAQALAAAGgEQAFgFAAgLIAAgDQAAgKgGgFQgFgGgLAAQgKAAgFAGg");
	this.shape_260.setTransform(61.925,172.275);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_261.setTransform(52.625,172.275);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#FFFFFF").s().p("AgIAOIAEgHIADgGIAAgHIAAgMIAKAAIAAALIgBAKIgEAJIgEAHg");
	this.shape_262.setTransform(45.45,178.15);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#FFFFFF").s().p("AgZAtQgJgJAAgSIAAgjQAAgRAJgKQAJgKAQAAQARAAAJAKQAJAKAAARIAAAjQAAASgJAJQgJAKgRAAQgQAAgJgKgAgQgkQgFAHAAAMIAAAkQAAAMAFAGQAGAGAKAAQALAAAGgGQAFgGAAgMIAAgkQAAgMgFgHQgGgGgLAAQgKAAgGAGg");
	this.shape_263.setTransform(39.025,172.275);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_264.setTransform(29.725,172.275);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_265.setTransform(20.775,172.275);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_266.setTransform(13.975,176.85);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#FFFFFF").s().p("AgYAuQgKgJAAgPIAAgnQAAgSAJgJQAJgKAQAAQAPAAAJAIQAJAJAAAOIAAABIgMAAIAAgBQAAgJgGgGQgFgFgKAAQgKAAgGAGQgFAHAAALIAAASQAEgFAGgDQAGgCAHAAQAPAAAJAIQAJAIAAAOIAAAEQAAAPgKAIQgJAJgQAAQgPAAgJgJgAgQAEQgFAGAAAKIAAADQAAAKAGAGQAFAFAKAAQAKAAAGgFQAGgGAAgKIAAgDQAAgKgGgGQgGgEgKAAQgKAAgGAEg");
	this.shape_267.setTransform(7.425,172.275);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_268.setTransform(-1.875,172.275);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#FFFFFF").s().p("AgGApIAAgPIANAAIAAAPgAgGgZIAAgPIANAAIAAAPg");
	this.shape_269.setTransform(-11.525,173.5);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_270.setTransform(-18.325,172.275);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_271.setTransform(-27.475,172.275);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_272.setTransform(-36.775,172.275);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#FFFFFF").s().p("AgaAsQgKgJAAgTIAAhFIANAAIAABGQAAANAHAHQAFAFALAAQAMAAAGgFQAGgHAAgNIAAhGIANAAIAABFQAAATgKAJQgKAKgRAAQgQAAgKgKg");
	this.shape_273.setTransform(-46.8,172.35);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#FFFFFF").s().p("AgaAtQgJgKAAgSIAAghQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgFgGgMAAQgKAAgHAGQgFAHAAANIAAAhQAAANAFAHQAHAGAKAAQAMAAAFgGQAHgHAAgNIAAgDIAMAAIAAADQAAASgJAKQgKAKgRAAQgQAAgKgKg");
	this.shape_274.setTransform(-56.55,172.275);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_275.setTransform(100.975,155.175);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#FFFFFF").s().p("AAnA1IAAhNIgjBHIgHAAIgjhHIAABNIgLAAIAAhpIAKAAIAnBTIAohTIAKAAIAABpg");
	this.shape_276.setTransform(89.55,155.175);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#FFFFFF").s().p("AgFA1IAAhpIALAAIAABpg");
	this.shape_277.setTransform(80.725,155.175);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_278.setTransform(74.175,155.175);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_279.setTransform(66.425,155.175);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#FFFFFF").s().p("AgaA3QgJgJAAgTIAAhGIAMAAIAABHQAAAMAHAHQAFAGALAAQAMAAAGgGQAGgHAAgMIAAhHIANAAIAABGQAAATgKAJQgJAJgSAAQgQAAgKgJgAgFgyIANgNIANAAIgPANg");
	this.shape_280.setTransform(56.9,154.2);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#FFFFFF").s().p("AgGAHIAAgNIANAAIAAANg");
	this.shape_281.setTransform(46.625,159.75);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_282.setTransform(40.075,155.175);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_283.setTransform(30.725,155.175);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#FFFFFF").s().p("AgFA1IAAheIggAAIAAgLIBLAAIAAALIggAAIAABeg");
	this.shape_284.setTransform(21.575,155.175);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape_285.setTransform(12.275,155.175);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#FFFFFF").s().p("AgaAsQgKgJAAgTIAAhFIANAAIAABGQAAANAHAHQAFAFALAAQAMAAAGgFQAGgHAAgNIAAhGIANAAIAABFQAAATgKAJQgKAKgRAAQgQAAgKgKg");
	this.shape_286.setTransform(2.25,155.25);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#FFFFFF").s().p("AgaAtQgJgKAAgSIAAghQAAgSAJgKQAKgKAQAAQARAAAJAKQAKAKAAASIAAAEIgMAAIAAgEQAAgNgHgHQgFgGgMAAQgKAAgHAGQgFAHAAANIAAAhQAAANAFAHQAHAGAKAAQAMAAAFgGQAHgHAAgNIAAgDIAMAAIAAADQAAASgJAKQgKAKgRAAQgQAAgKgKg");
	this.shape_287.setTransform(-7.5,155.175);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#FFFFFF").s().p("AgYAuQgJgJAAgOIAAgBIAMAAIAAABQAAAKAGAFQAGAFAJAAQAKAAAGgFQAFgHAAgKIAAgGQAAgLgFgEQgGgGgKAAQgHAAgFADQgFADgDAGIgLgCIAFg5IA2AAIAAALIgtAAIgCAhQAFgEAFgBQAFgCAGAAQAPAAAIAJQAJAHAAAPIAAAGQAAAPgJAKQgJAIgQAAQgPAAgJgIg");
	this.shape_288.setTransform(-19.85,155.25);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#FFFFFF").s().p("AgYAuQgKgIAAgPIAAgDIANAAIAAADQAAAKAFAFQAGAGAKAAQALAAAFgFQAGgFAAgJIAAgDQAAgJgGgEQgGgFgKAAIgIAAIAAgKIAHAAQAJAAAFgEQAGgFAAgIIAAgCQAAgJgFgEQgGgFgIAAQgJAAgGAFQgFAFAAAJIAAAEIgMAAIAAgEQAAgOAJgIQAIgIAPAAQAOAAAJAIQAIAHAAANIAAACQAAAIgDAGQgEAGgIADQAJABAFAHQAFAGAAAKIAAADQAAANgJAIQgKAIgQAAQgPAAgJgJg");
	this.shape_289.setTransform(-28.875,155.175);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#FFFFFF").s().p("AAaA1IgyhRIAABRIgMAAIAAhpIAKAAIAzBRIAAhRIALAAIAABpg");
	this.shape_290.setTransform(-41.7,155.175);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_291.setTransform(-50.675,155.175);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#FFFFFF").s().p("AALAiIgLgXIgLAXIgHAJIgPgLIAHgJIASgTIgZgDIgLgDIAFgTIAMAFIAWALIgDgaIAAgLIASAAIAAALIgFAbIAYgMIAKgFIAHATIgLADIgaADIASATIAHAJIgPALg");
	this.shape_292.setTransform(88.4,112.5);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#FFFFFF").s().p("AglBAQgOgMAAgVIAAgEIAaAAIAAAEQAAALAHAFQAHAGALAAQAMAAAHgFQAGgFAAgKQAAgIgFgFQgFgFgLgCIgMgCQgVgEgKgKQgLgLAAgRQAAgUANgMQAOgLAXAAQAXAAANALQANALAAAUIAAAEIgbAAIAAgEQAAgJgGgFQgGgFgKAAQgLAAgGAEQgGAFAAAIQAAAIAFAFQAGAEALADIAMACQAVAEAKAKQAKALAAASQAAAWgNALQgOALgZAAQgYAAgNgLg");
	this.shape_293.setTransform(77.025,115.475);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#FFFFFF").s().p("AgrBJIAAiRIBXAAIAAAYIg7AAIAAAlIAxAAIAAAWIgxAAIAAAnIA7AAIAAAXg");
	this.shape_294.setTransform(65.25,115.475);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#FFFFFF").s().p("AAwBJIAAhXIgnBOIgRAAIgnhOIAABXIgZAAIAAiRIAVAAIA0BmIAzhmIAVAAIAACRg");
	this.shape_295.setTransform(49.9,115.475);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#FFFFFF").s().p("AgpBJIAAiRIAbAAIAAB5IA4AAIAAAYg");
	this.shape_296.setTransform(32.05,115.475);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#FFFFFF").s().p("AAiBJIgLgeIgwAAIgKAeIgbAAIAyiRIAZAAIAyCRgAARAWIgRg9IgTA9IAkAAg");
	this.shape_297.setTransform(19.225,115.475);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#FFFFFF").s().p("AgcA/QgOgNgBgYIgRAAIAAgRIAQAAIAAgQIgQAAIAAgRIARAAQABgYANgNQAOgNAXAAQAaAAAOAOQANAOAAAbIAAAEIgaAAIAAgGQAAgOgHgIQgGgHgOAAQgLAAgHAHQgGAGgBANIAhAAIAAARIghAAIAAAQIAcAAIAAARIgcAAQABAMAGAHQAHAGALAAQAOAAAGgHQAHgHAAgPIAAgGIAaAAIAAAFQAAAagNAOQgOAOgaAAQgXAAgNgMg");
	this.shape_298.setTransform(1.225,115.475);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#FFFFFF").s().p("AgjA+QgOgMAAgWIAAAAIAaAAIAAAAQAAALAHAGQAFAGALAAQALAAAGgGQAFgGAAgMIAAgGQAAgLgFgGQgHgGgKAAQgHAAgGADQgGADgEAGIgWgFIAGhOIBSAAIAAAXIg8AAIgDAiQAFgEAHgCQAGgBAGAAQAWAAAMAMQALALAAAVIAAAGQAAAXgMAMQgNAMgYAAQgXAAgMgMg");
	this.shape_299.setTransform(-11.85,115.575);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#FFFFFF").s().p("AgiBAQgNgMAAgVIAAgBIAaAAIAAACQAAAKAGAFQAFAFALAAQALAAAGgGQAHgHAAgLIAAgTQgGAEgIADQgGACgIAAQgWAAgMgMQgNgLAAgUIAAgDQAAgVAOgNQANgMAXAAQAZAAANAMQANANAAAYIAAAxQAAAZgNANQgNANgYAAQgXAAgMgLgAgRguQgGAGgBAMIAAACQABALAGAGQAGAGALAAQAMAAAGgGQAHgGAAgLIAAgCQAAgMgHgGQgGgGgMAAQgLAAgGAGg");
	this.shape_300.setTransform(-24.45,115.475);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#FFFFFF").s().p("AglA/QgNgMAAgWIAAgFIAaAAIAAAFQAAALAGAGQAHAGALAAQALAAAGgFQAHgGAAgJIAAgDQAAgKgHgFQgGgFgLAAIgLAAIAAgUIAKAAQAJAAAGgFQAFgFAAgIIAAgDQAAgJgFgFQgGgEgJAAQgKAAgGAFQgFAFgBAJIAAAFIgZAAIAAgFQAAgUAMgMQAOgLAWAAQAVAAANAKQANALgBASIAAADQABAKgFAIQgFAHgIAFQALADAFAIQAGAJAAANIAAADQAAATgOALQgNALgYAAQgYAAgNgMg");
	this.shape_301.setTransform(-36.85,115.475);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#FFFFFF").s().p("Ag3BkIAAjHIBvAAIAAAVIhYAAIAABDIBKAAIAAATIhKAAIAABHIBYAAIAAAVg");
	this.shape_302.setTransform(107.3,87.525);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#FFFFFF").s().p("AgwBXQgRgQAAgcIAAgFIAWAAIAAAFQAAATAMAKQALAKAVAAQAUAAAKgJQAMgJAAgQQAAgPgJgJQgJgKgUgDIgOgDQgbgGgOgMQgNgOAAgXQgBgZASgPQARgPAdAAQAcAAARAPQARAPAAAbIAAAFIgYAAIAAgFQAAgRgKgKQgKgJgTAAQgSAAgLAJQgLAIAAAQQAAANAKAJQAIAJATADIAPADQAcAGAOANQANAOAAAXQAAAcgRAPQgSAPgeAAQgfAAgSgQg");
	this.shape_303.setTransform(90.3,87.525);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#FFFFFF").s().p("AAyBkIhgiaIAACaIgWAAIAAjHIATAAIBgCaIAAiaIAWAAIAADHg");
	this.shape_304.setTransform(71.925,87.525);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#FFFFFF").s().p("Ag3BkIAAjHIBuAAIAAAVIhWAAIAABDIBJAAIAAATIhJAAIAABHIBXAAIAAAVg");
	this.shape_305.setTransform(55.05,87.525);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#FFFFFF").s().p("AgKBkIAAixIg8AAIAAgWICNAAIAAAWIg8AAIAACxg");
	this.shape_306.setTransform(38.4,87.525);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#FFFFFF").s().p("AgbAJIAAgSIA3AAIAAASg");
	this.shape_307.setTransform(26.525,88);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#FFFFFF").s().p("Ag3BkIAAjHIBvAAIAAAVIhXAAIAABDIBJAAIAAATIhJAAIAABHIBXAAIAAAVg");
	this.shape_308.setTransform(15.65,87.525);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#FFFFFF").s().p("AgsBXQgQgPAAgbIAAgBIAWAAIAAABQAAASAKAKQALAJARAAQAUAAALgMQALgLAAgWIAAghQgIAJgLAFQgMAFgNAAQgcAAgRgQQgRgPAAgbIAAgGQAAgdASgQQARgQAdAAQAfAAARARQARAQAAAdIAABKQAAAhgRASQgQASgfAAQgdAAgQgQgAgehHQgLAKAAATIAAAGQAAATALAKQALAJATAAQAUAAALgJQALgKAAgTIAAgGQAAgTgLgKQgLgKgUAAQgTAAgLAKg");
	this.shape_309.setTransform(-13.925,87.525);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#FFFFFF").s().p("AgwBXQgRgQAAgcIAAgFIAXAAIAAAFQAAATALAKQALAKAVAAQATAAALgJQAMgJAAgQQAAgPgKgJQgIgKgUgDIgPgDQgbgGgNgMQgOgOAAgXQAAgZARgPQARgPAdAAQAdAAAQAPQASAPgBAbIAAAFIgWAAIAAgFQAAgRgLgKQgLgJgSAAQgTAAgKAJQgKAIAAAQQAAANAJAJQAJAJASADIAQADQAbAGANANQAOAOAAAXQAAAcgRAPQgSAPgeAAQgfAAgSgQg");
	this.shape_310.setTransform(-36.9,87.525);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#FFFFFF").s().p("AhBBkIAAjHIA+AAQAgAAATAUQASATAAAjIAAAzQAAAjgSAUQgTATggAAgAgpBPIAmAAQAWAAALgOQAMgNAAgZIAAg1QAAgZgMgNQgLgNgWAAIgmAAg");
	this.shape_311.setTransform(-54.35,87.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.offer, new cjs.Rectangle(-79.5,70,209.5,369.6), null);


(lib.logo_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AcjCpQgdgdAAg7IA6AAQAAAhAOAQQAPARAhAAQAeAAAPgNQANgNAAgcQgBgcgKgQQgLgPgagHIgjgLQgvgPgVgYQgUgZgBgwQAAguAbgbQAdgdA1ABQA5AAAdAaQAcAbAAA4Ig6AAQgBgegMgOQgNgOgeAAQgZAAgMAMQgNALAAAZQAAAbAMANQALAMAcAKIAiAKQAvAOATAZQAUAbAAAzQAAAzgeAcQgfAcg3AAQg9AAgegdgAHbCmQghghAAg7IAAiRQAAg7AhgiQAgghA7AAQA7AAAhAhQAhAiAAA7IAACRQAAA7ghAhQghAgg7AAQg7AAgggggAIFh+QgSASABAjIAACUQgBAiASASQARATAgAAQAhAAARgTQARgSAAgiIAAiUQAAgkgRgRQgRgTghABQgggBgRATgAkKCmQggghgBg7IAAiRQABg7AggiQAhghA7AAQA7AAAgAhQAiAiAAA7IAACRQAAA7giAhQggAgg7AAQg7AAghgggAjfh+QgSASAAAjIAACUQAAAiASASQAQATAhAAQAgAAASgTQAQgSAAgiIAAiUQAAgkgQgRQgSgTggABQghgBgQATgAt2CoQgdggAAg6IAAkOIA5AAIAAESQAAAiAQAQQAPAOAeAAQAeAAAPgOQAOgQAAgiIAAkSIA7AAIAAEOQgBA6gdAgQgeAeg6AAQg6AAgfgegA6eCpQgcgdgBg7IA6AAQABAhANAQQAPARAhAAQAeAAAOgNQAOgNAAgcQAAgcgLgQQgLgPgagHIgjgLQgvgPgVgYQgVgZABgwQAAguAbgbQAcgdA1ABQA6AAAbAaQAdAbAAA4Ig6AAQgBgegMgOQgNgOgdAAQgaAAgMAMQgNALAAAZQAAAbALANQALAMAdAKIAiAKQAvAOATAZQAUAbAAAzQAAAzgeAcQgeAcg4AAQg+AAgdgdgAYADBIAAmBIDCAAIAAA1IiIAAIAABtIB4AAIAAAzIh4AAIAAB4ICOAAIAAA0gAT3DBIAAmBIA5AAIAAFNICEAAIAAA0gARSDBIAAmBIA6AAIAAGBgAMTDBIAAmBIB4AAQAwAAAZAaQAaAZAAAxQAAAggLAWQgLAYgXAKQA2ARAABLQAAAygaAcQgcAbgyAAgANMCPIA+AAQAZAAANgPQANgOAAgdQAAgegNgRQgMgRgYAAIhAAAgANMgcIA9AAQAWAAALgPQALgOAAgbQABgbgNgPQgMgQgWAAIg7AAgAEjDBIAAkkIhGC5IgyAAIhGi6IAAElIg3AAIAAmBIBGAAIBRDaIBRjaIBEAAIAAGBgAn/DBIAAlNIhfAAIAAg0ID4AAIAAA0IhfAAIAAFNgAwaDBIgZhqIhtAAIgZBqIg5AAIBfmBIBVAAIBfGBgAw/AkIgqizIgrCzIBVAAgA/xDBIAAmBIBvAAQA6AAAhAhQAhAgAAA7IAACLQAAA6ghAgQghAgg6AAgA+4COIA1AAQAggBASgSQARgSAAgiIAAiMQAAgjgRgSQgSgSggAAIg1AAg");
	this.shape.setTransform(0,246.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// logo
	this.instance = new lib.logo();
	this.instance.setTransform(-80,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-203.4,0,406.8,266.4), null);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnVAFIAAgJIOrAAIAAAJg");
	this.shape.setTransform(47,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,94,1);


(lib.img2guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._2();
	this.instance.setTransform(413,74);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2guide, new cjs.Rectangle(413,74,535,600), null);


(lib.img2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img2
	this.instance = new lib._2();
	this.instance.setTransform(72,68);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2, new cjs.Rectangle(72,68,535,600), null);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1
	this.instance = new lib._1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1, new cjs.Rectangle(0,0,300,600), null);


(lib.euroSquare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrAAIAsgrIArAsIgsArg");
	this.shape.setTransform(4.425,4.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.euroSquare, new cjs.Rectangle(0,0,8.9,8.9), null);


(lib.euro2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A2ICEMAsZgEiIgtBsMgr0ADRg");
	this.shape.setTransform(-184.1348,-90.24,1.6719,1.6719);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgogAJ5MBPngUNIBdBeMhRHATLg");
	this.shape_1.setTransform(8.8814,-194.8566,1.6719,1.6719);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EggNANzMBAbgcBIhACbMg/aAaCg");
	this.shape_2.setTransform(-86.5818,-256.59,1.6719,1.6719);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Eg0KAgqMBoVhBvIgJCwMhoGA/bg");
	this.shape_3.setTransform(117.1343,-477.1919,1.6719,1.6719);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A3eTEMAudgmIIAgB4MgtLAkRg");
	this.shape_4.setTransform(33.3323,-556.1037,1.6719,1.6719);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AiJAZICjiOIBwAJIkQDig");
	this.shape_5.setTransform(-239.0136,-318.7832,1.6719,1.6719);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AjsC4IHZmjIgRBgInCF3g");
	this.shape_6.setTransform(-339.6178,-241.2507,1.6719,1.6719);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AifBsIEQjxIAvAJIk1ECg");
	this.shape_7.setTransform(-426.9725,-162.6733,1.6719,1.6719);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AkbDxIHRo1IBmAiIoaJng");
	this.shape_8.setTransform(-241.396,-418.1335,1.6719,1.6719);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AlMFLIJUrWIBJAVIqiMCg");
	this.shape_9.setTransform(-361.2266,-277.4047,1.6719,1.6719);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ah8CMID5kvIAAA6IjrENg");
	this.shape_10.setTransform(-447.9125,-182.7356,1.6719,1.6719);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AqXP8MATtggxIBCBjMgUUAgIg");
	this.shape_11.setTransform(-299.3678,-470.6716,1.6719,1.6719);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhkBxICnkdIAiAnIjAEyg");
	this.shape_12.setTransform(-432.4896,-252.7447,1.6719,1.6719);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AEes4IBOBQIqaYTIg9AOg");
	this.shape_13.setTransform(-393.9533,-446.2625,1.6719,1.6719);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgOgXIANgIIAQA0IgLALg");
	this.shape_14.setTransform(-563.3544,-87.0634,1.6719,1.6719);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AClIhIldwHIAdg+IFURHIgTACg");
	this.shape_15.setTransform(-602.6013,-205.7655,1.6719,1.6719);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWgQIAJgOIAkAzIgLAKg");
	this.shape_16.setTransform(-570.836,-81.1283,1.6719,1.6719);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABzC8IkBlZIAQggIENF7g");
	this.shape_17.setTransform(-619.1528,-147.3758,1.6719,1.6719);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ahoh7IAkgWICtDzIgIAwg");
	this.shape_18.setTransform(-671.3566,-214.5845,1.6719,1.6719);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ah0hEIAIgUIDhCnIgKAKg");
	this.shape_19.setTransform(-592.1522,-85.6424,1.6719,1.6719);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhFglIAagPIBxBUIgMAVg");
	this.shape_20.setTransform(-642.0572,-119.4975,1.6719,1.6719);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhSgUIAGguICfB2IgqAPg");
	this.shape_21.setTransform(-709.0988,-171.2416,1.6719,1.6719);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhJgKIgOgYICvA6IgLALg");
	this.shape_22.setTransform(-592.8628,-71.0972,1.6719,1.6719);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AjcgMIGrAFIAOAOImoAGg");
	this.shape_23.setTransform(-623.834,-56.8028,1.6719,1.6719);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AiLAfIEMhTIALAMIkTBdg");
	this.shape_24.setTransform(-602.8103,-40.7947,1.6719,1.6719);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ah7BNIDtinIAKAKIjoCsg");
	this.shape_25.setTransform(-594.5346,-28.1722,1.6719,1.6719);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AjnB3IG1k1IApANInuFwg");
	this.shape_26.setTransform(-730.206,73.7277,1.6719,1.6719);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AiYCyIEomNIAJAKIkwGug");
	this.shape_27.setTransform(-594.4092,-1.1716,1.6719,1.6719);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AlLGIIJxtIIAmAAIp3OBg");
	this.shape_28.setTransform(-691.7951,134.0818,1.6719,1.6719);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("ADxrZIALALIm2WGIhCAig");
	this.shape_29.setTransform(-605.0673,90.0283,1.6719,1.6719);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgHmZIAPgPIAKM9IgjAUg");
	this.shape_30.setTransform(-555.5803,46.7271,1.6719,1.6719);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ABRE+IjHqCIALgLIDiKfg");
	this.shape_31.setTransform(-528.3708,24.4078,1.6719,1.6719);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("ABACXIjhk+IBXAVIDsE6g");
	this.shape_32.setTransform(-351.8224,222.8576,1.6719,1.6719);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AhIhEIAPgpICCCvIgTAsg");
	this.shape_33.setTransform(-438.7173,104.6989,1.6719,1.6719);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("Ajzk5IALgJIHcJ/IglAGg");
	this.shape_34.setTransform(-501.4956,16.6755,1.6719,1.6719);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("Eg5KgoqIAKgKMByLBQNIjpBcg");
	this.shape_35.setTransform(75.0034,394.3904,1.6719,1.6719);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("Eg82gTyIALgLMB5iAlfIipCcg");
	this.shape_36.setTransform(120.4362,165.2202,1.6719,1.6719);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Egp8AAJIgPgOMBTBgApIBWBdg");
	this.shape_37.setTransform(-71.7859,-55.8832,1.6719,1.6719);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("A3aHqMAu2gPdIgFBGMgumAOhg");
	this.shape_38.setTransform(-279.8906,-146.6234,1.6719,1.6719);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AnNE8IO/rTIAABvIvjLAg");
	this.shape_39.setTransform(-242.0648,-285.346,1.6719,1.6719);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AoDFgIOpq6IBegPIv+LTg");
	this.shape_40.setTransform(-449.7934,-129.5287,1.6719,1.6719);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AkHEpIHLqQIBEBQIncJ/g");
	this.shape_41.setTransform(-264.4259,-456.0847,1.6719,1.6719);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AjnEgIGvpoIAhBMImyJFg");
	this.shape_42.setTransform(-364.2359,-319.5773,1.6719,1.6719);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AhmBpIC0j+IAYArIi9EAg");
	this.shape_43.setTransform(-427.4322,-230.1746,1.6719,1.6719);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AjuFBIHMqLIASAgInUJ1g");
	this.shape_44.setTransform(-501.2448,-129.7794,1.6719,1.6719);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgtBrIBDjZIAYgIIhQDtg");
	this.shape_45.setTransform(-539.4886,-100.2711,1.6719,1.6719);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgMiLIAZgPIgDEjIgSASg");
	this.shape_46.setTransform(-554.4518,-143.2379,1.6719,1.6719);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgHgaIAPgHIAAA0IgPAPg");
	this.shape_47.setTransform(-553.3651,-94.9212,1.6719,1.6719);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AiAgDICEh9IB9CEIiEB9g");
	this.shape_48.setTransform(-555.0369,-56.2176,1.6719,1.6719);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.euro2, new cjs.Rectangle(-771.6,-831.2,1543.3000000000002,1662.5), null);


(lib.euro1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnfNUINC6xIB8AAIuIa7g");
	this.shape.setTransform(-195.3915,-358.7566,1.6719,1.6719);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA5GFIiEsJIAqAWIBtLxIgSACg");
	this.shape_1.setTransform(-420.3821,-86.4524,1.6719,1.6719);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAKCsIg9ljIA1AXIAyFYg");
	this.shape_2.setTransform(-437.1843,-194.7889,1.6719,1.6719);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABkDTIjemnIAoAKIDNGfg");
	this.shape_3.setTransform(-448.3021,-56.5261,1.6719,1.6719);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAcBdIhei1IAtgEIBYC5g");
	this.shape_4.setTransform(-489.806,-138.4473,1.6719,1.6719);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhLgsIAJgcICOCRIgfAAg");
	this.shape_5.setTransform(-468.6152,-33.5381,1.6719,1.6719);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AghgLIAGgiIA9A+IgHAeg");
	this.shape_6.setTransform(-494.6126,-57.9054,1.6719,1.6719);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AidiCIAZgkIEiEqIgLAjg");
	this.shape_7.setTransform(-533.7342,-96.0656,1.6719,1.6719);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgggJIAWgLIArAWIgCATg");
	this.shape_8.setTransform(-456.4106,9.0944,1.6719,1.6719);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhAgRIAegRIBjAzIgWASg");
	this.shape_9.setTransform(-507.9039,-17.739,1.6719,1.6719);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiZgMIArgTIECArIAGATg");
	this.shape_10.setTransform(-479.6913,23.347,1.6719,1.6719);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhQACICVgWIAMARIiOAYg");
	this.shape_11.setTransform(-468.1972,47.6725,1.6719,1.6719);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag7ASIBngyIAQAMIhoA1g");
	this.shape_12.setTransform(-459.1274,66.8571,1.6719,1.6719);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiBAcIDOhlIA2AQIj7CDg");
	this.shape_13.setTransform(-591.0371,136.1557,1.6719,1.6719);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgxAZIBQhOIATAHIhhBkg");
	this.shape_14.setTransform(-447.1318,84.9968,1.6719,1.6719);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AmNFNILprWIAWgBQAUgCAHgCIsEMdg");
	this.shape_15.setTransform(-571.6436,211.8074,1.6719,1.6719);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AlnKbIK701IAVAAIqQU1g");
	this.shape_16.setTransform(-484.874,198.5161,1.6719,1.6719);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AA/moIAUgHIhyMWIgzBJg");
	this.shape_17.setTransform(-421.9703,164.1594,1.6719,1.6719);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgujhIAQgMIBNHCIgaAZg");
	this.shape_18.setTransform(-385.7746,131.4745,1.6719,1.6719);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AApCfIiVkvIAeghIC7Fjg");
	this.shape_19.setTransform(-286.4661,258.3686,1.6719,1.6719);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AiTj+IAMgRIEbIcIgkADg");
	this.shape_20.setTransform(-351.794,131.5163,1.6719,1.6719);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ah+h0IBOgLICvCpIgPBWg");
	this.shape_21.setTransform(-143.8147,300.0815,1.6719,1.6719);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Aith6IAAg4IFbFRIg2AUg");
	this.shape_22.setTransform(-227.4076,207.3769,1.6719,1.6719);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AjcjMIAHgTIGxGnIgVAYg");
	this.shape_23.setTransform(-324.9607,113.2512,1.6719,1.6719);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("EgnbgUSIAAgUMBNxAmPIBGC/g");
	this.shape_24.setTransform(71.0611,282.2344,1.6719,1.6719);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("EgjcgF0IgGgTMBGGAKmIA/Bpg");
	this.shape_25.setTransform(34.4892,110.6598,1.6719,1.6719);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("EgkkAGDMBJJgMWIhBBtMhH8AK6g");
	this.shape_26.setTransform(45.1473,-36.8818,1.6719,1.6719);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("A7gOUMA3BgczIgtB2Mg2DAbJg");
	this.shape_27.setTransform(-57.4213,-141.6238,1.6719,1.6719);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("ArGLZIV+3GIAPByI04Vpg");
	this.shape_28.setTransform(0.1743,-374.8064,1.6719,1.6719);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AmGF2ILrsEIAjBBIrvLcg");
	this.shape_29.setTransform(-191.3791,-172.7204,1.6719,1.6719);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AkwEmIJEpRIAdAYIpNI/g");
	this.shape_30.setTransform(-311.2096,-51.3852,1.6719,1.6719);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAEgnIAngPIg0BlIghAHg");
	this.shape_31.setTransform(-348.0323,-64.0077,1.6719,1.6719);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgwBKIBDiJIAegKIhMCTg");
	this.shape_32.setTransform(-368.1365,-24.4264,1.6719,1.6719);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgDgnIATgEIgNBMIgSALg");
	this.shape_33.setTransform(-391.1663,-17.0285,1.6719,1.6719);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgdhyIAwAmIALCiIglAdg");
	this.shape_34.setTransform(-418.1668,-188.0179,1.6719,1.6719);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("ABTGUIjBrsIAkg+IC5Mtg");
	this.shape_35.setTransform(-447.1736,-160.5158,1.6719,1.6719);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AhQiFIAYgnICJFYIgcABg");
	this.shape_36.setTransform(-462.1368,-115.2084,1.6719,1.6719);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgngfIAag2IA1CEIgbAng");
	this.shape_37.setTransform(-483.8709,-165.9911,1.6719,1.6719);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgugoIAWgUIBHB3IgdACg");
	this.shape_38.setTransform(-474.0488,-85.1567,1.6719,1.6719);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AhPhoIAtgFIBzC/IgYAcg");
	this.shape_39.setTransform(-505.9395,-133.2227,1.6719,1.6719);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AALAkIg3g+IAegJIA7BHg");
	this.shape_40.setTransform(-489.4717,-68.4799,1.6719,1.6719);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AiRicIA3gDIDsEcIgLAjg");
	this.shape_41.setTransform(-527.3811,-108.521,1.6719,1.6719);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("ABKBrIjPirIgFg5IEVDzg");
	this.shape_42.setTransform(-539.5857,-86.0345,1.6719,1.6719);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Ai1BEIFBi/IArAOIltDpg");
	this.shape_43.setTransform(-581.5493,150.6591,1.6719,1.6719);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AlRDlIJ7oRIAoAHIqhJSg");
	this.shape_44.setTransform(-579.2505,193.5841,1.6719,1.6719);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("Al+GcILZtCIAjACIq2NLg");
	this.shape_45.setTransform(-555.5937,217.0319,1.6719,1.6719);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AEzn1IASAWIowO4IhZAdg");
	this.shape_46.setTransform(-523.7448,233.0818,1.6719,1.6719);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AjNHAIGFuNIAWATIlkOIg");
	this.shape_47.setTransform(-484.874,236.3419,1.6719,1.6719);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("ABHlGIAXAPIh5IoIhCBWg");
	this.shape_48.setTransform(-446.2123,220.6682,1.6719,1.6719);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AABiTIAZAMIgPECIgkAYg");
	this.shape_49.setTransform(-413.9454,194.2946,1.6719,1.6719);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgUhkIAaAHIAPCiIgbAgg");
	this.shape_50.setTransform(-389.5362,187.022,1.6719,1.6719);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAPB5IhVjTIAdgnIBwECg");
	this.shape_51.setTransform(-304.6058,265.5994,1.6719,1.6719);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgohIIAbgBIA2B9IgYAWg");
	this.shape_52.setTransform(-345.4409,173.5218,1.6719,1.6719);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AhdiTIA3AKICFDQIgMBOg");
	this.shape_53.setTransform(-275.2228,248.3793,1.6719,1.6719);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgJAqIgmhAIATglIBMB3g");
	this.shape_54.setTransform(-296.7062,204.3258,1.6719,1.6719);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("Agrg1IAbgFIA8BdIgUAYg");
	this.shape_55.setTransform(-326.2146,161.2754,1.6719,1.6719);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AiWh2IA/gUIDuENIhYAIg");
	this.shape_56.setTransform(-164.7965,311.7428,1.6719,1.6719);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AhGhFIAlgJIBoB1IgSAog");
	this.shape_57.setTransform(-276.226,185.9771,1.6719,1.6719);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("Ag/gzIAagKIBlBxIggAKg");
	this.shape_58.setTransform(-305.7343,149.1126,1.6719,1.6719);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AoDm3IAYgOIPvM9IgKBOg");
	this.shape_59.setTransform(-215.0777,199.5192,1.6719,1.6719);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("A0rsEIAWgSMApAAYUIiBAZg");
	this.shape_60.setTransform(-67.4107,238.6825,1.6719,1.6719);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("EglxgPKIASgUMBLRAeQIiZAtg");
	this.shape_61.setTransform(125.4801,253.3113,1.6719,1.6719);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("EgqhgKYIAQgYMBTSATKIBhCXg");
	this.shape_62.setTransform(183.0757,182.508,1.6719,1.6719);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("EgocgC9IAMgZMBP7AFQQgCABAZAuIAbAug");
	this.shape_63.setTransform(164.6017,82.4472,1.6719,1.6719);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.euro1, new cjs.Rectangle(-638.1,-502.8,1276.2,1005.7), null);


(lib.ecoLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.eco();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ecoLogo, new cjs.Rectangle(0,0,128,128), null);


(lib.ds9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgzBdQgSgSgBgdIAAgCIAnAAIAAADQAAANAIAIQAIAHAPABQARAAAJgKQAJgJAAgRIAAgcQgIAHgKAEQgLADgMAAQgeAAgTgRQgSgRAAgdIAAgEQAAgfAUgTQATgSAiAAQAkABATASQATASAAAiIAABKQAAAjgTAUQgTASgjABQghgBgTgQgAgahDQgJAIAAARIAAAEQAAAQAJAJQAKAIAQAAQARAAAJgIQAKgJAAgQIAAgEQAAgRgKgIQgJgJgRAAQgQAAgKAJg");
	this.shape.setTransform(60.7,18.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag3BdQgUgSAAgdIAAgHIAnAAIAAAHQAAAPAJAHQAKAJARgBQASAAAJgHQAJgHAAgOQABgLgJgHQgHgIgPgDIgSgEQgfgFgPgPQgPgQAAgZQAAgdATgRQAUgQAigBQAgABAUAQQASAQABAdIAAAGIgnAAIAAgGQAAgNgJgIQgJgHgPAAQgQAAgJAHQgIAGAAAMQAAAMAIAHQAHAHARACIARAEQAeAGAQAPQAPAQAAAbQAAAegUARQgUARgkAAQgjAAgUgRg");
	this.shape_1.setTransform(36.95,18.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhLBqIAAjTIBIAAQAmgBAVAWQAUAVAAAoIAAAvQAAAogUAVQgVAVgmAAgAgkBGIAhAAQATAAAKgLQAKgLAAgWIAAgyQAAgXgKgLQgKgLgTAAIghAAg");
	this.shape_2.setTransform(18.225,18.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ds9, new cjs.Rectangle(0,0,78.1,38.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgZArQgJgIAAgOIAAgDIASAAIAAADQgBAHAFAEQAFAEAHAAQAIAAAFgEQAEgDAAgGQAAgGgEgDQgDgEgHgBIgIgCQgPgDgGgGQgIgHAAgMQAAgOAKgIQAIgHAQAAQAPAAAJAHQAJAIAAAOIAAACIgSAAIAAgCQAAgHgEgDQgEgEgHAAQgHAAgFADQgDADAAAGQAAAFADAEQAEADAIABIAHACQAOADAIAGQAGAIABAMQgBAPgIAHQgKAIgRAAQgQAAgJgIg");
	this.shape.setTransform(119.9,13.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAXA8IgHgUIghAAIgGAUIgTAAIAihjIARAAIAiBjgAAMAZIgMgpIgMApIAYAAgAgIgtIANgOIATAAIgQAOg");
	this.shape_1.setTransform(110.95,12.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAhAyIAAg8IgbA1IgMAAIgag1IAAA8IgRAAIAAhjIAPAAIAiBGIAjhGIAPAAIAABjg");
	this.shape_2.setTransform(100.1,13.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAyIAAhjIA6AAIAAARIgnAAIAAAZIAhAAIAAAOIghAAIAAAbIAoAAIAAAQg");
	this.shape_3.setTransform(87.6,13.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAPAyIgSglIgOAAIAAAlIgSAAIAAhjIAhAAQAQAAAHAIQAJAIAAAOIAAAFQgBAKgDAFQgEAHgIADIAXAngAgRgBIAPAAQAGAAADgDQAEgEAAgGIAAgGQAAgGgEgEQgDgDgGAAIgPAAg");
	this.shape_4.setTransform(79.3,13.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AghAyIAAhjIAhAAQAOAAAIAHQAHAHABAMIAAACQAAAHgDAFQgDAFgFACQAHADAEAFQAEAGAAAJIAAACQAAANgJAHQgHAHgPAAgAgPAiIASAAQAFAAAEgDQAEgDgBgGIAAgDQABgHgEgDQgEgDgFAAIgSAAgAgPgHIAPAAQAGAAACgDQADgDAAgFIAAgFQAAgEgDgEQgCgCgGAAIgPAAg");
	this.shape_5.setTransform(70.3,13.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgaApQgKgKAAgSIAAg/IATAAIAABAQAAAKAFAFQAEAFAIAAQAJAAAEgFQAFgFAAgKIAAhAIATAAIAAA/QAAASgKAKQgJAKgSAAQgRAAgJgKg");
	this.shape_6.setTransform(60.925,13.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgaAqQgJgKAAgSIAAgbQAAgSAJgKQAKgJAQAAQARAAAKAJQAJAKAAASIAAADIgTAAIAAgEQAAgKgEgFQgEgFgJAAQgIAAgEAFQgEAFAAAKIAAAdQAAAKAEAFQAEAEAIAAQAJAAAEgEQAEgFAAgKIAAgEIATAAIAAADQAAASgJAKQgKAJgRAAQgQAAgKgJg");
	this.shape_7.setTransform(51.775,13.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgZArQgKgIAAgOIAAgDIASAAIAAADQAAAHAFAEQAFAEAHAAQAIAAAFgEQAEgDAAgGQAAgGgDgDQgEgEgHgBIgIgCQgOgDgIgGQgHgHAAgMQAAgOAJgIQAKgHAPAAQAQAAAIAHQAJAIAAAOIAAACIgSAAIAAgCQAAgHgEgDQgEgEgHAAQgIAAgDADQgEADgBAGQABAFAEAEQADADAHABIAIACQAPADAGAGQAIAIgBAMQABAPgKAHQgJAIgRAAQgQAAgJgIg");
	this.shape_8.setTransform(43,13.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdAyIAAhjIA7AAIAAARIgpAAIAAAZIAiAAIAAAOIgiAAIAAAbIApAAIAAAQg");
	this.shape_9.setTransform(35,13.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgjAyIAAhjIAiAAQARAAAKAKQAKALAAASIAAAWQAAASgKAKQgKAKgRAAgAgQAhIAPAAQAJAAAEgFQAFgFAAgLIAAgXQAAgLgFgEQgEgGgJAAIgPAAg");
	this.shape_10.setTransform(26.325,13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// ctaBgc
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ArXCLIAAkVIWvAAIAAEVg");
	this.shape_11.setTransform(72.75,13.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,145.5,27.8), null);


(lib.cargaLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logomind706SP();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cargaLogo, new cjs.Rectangle(0,0,251,251), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ds
	this.ds9 = new lib.ds9();
	this.ds9.name = "ds9";
	this.ds9.setTransform(30.8,18.9,1,1,0,0,0,39,19.1);

	this.timeline.addTween(cjs.Tween.get(this.ds9).wait(1));

	// line
	this.txtline = new lib.txtline();
	this.txtline.name = "txtline";
	this.txtline.setTransform(31.8,40,1,1,0,0,0,22,0);

	this.timeline.addTween(cjs.Tween.get(this.txtline).wait(1));

	// txt
	this.txt1txt = new lib.txt1txt();
	this.txt1txt.name = "txt1txt";
	this.txt1txt.setTransform(32.15,71.15,1,1,0,0,0,80,27.1);

	this.timeline.addTween(cjs.Tween.get(this.txt1txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-47.8,-0.2,159.89999999999998,98.4), null);


(lib.frameWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// line6
	this.line6 = new lib.line();
	this.line6.name = "line6";
	this.line6.setTransform(257,558,1.3775,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.line6).wait(1));

	// line5
	this.line5 = new lib.line();
	this.line5.name = "line5";
	this.line5.setTransform(0,558,1.3776,1);

	this.timeline.addTween(cjs.Tween.get(this.line5).wait(1));

	// line4
	this.line4 = new lib.line();
	this.line4.name = "line4";
	this.line4.setTransform(257,0,5.9361,1,90);

	this.timeline.addTween(cjs.Tween.get(this.line4).wait(1));

	// line3
	this.line3 = new lib.line();
	this.line3.name = "line3";
	this.line3.setTransform(0.3,-1,5.9572,1,90,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.line3).wait(1));

	// line2
	this.line2 = new lib.line();
	this.line2.name = "line2";
	this.line2.setTransform(203.85,-0.25,0.5638,1,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line2).wait(1));

	// line1
	this.line1 = new lib.line();
	this.line1.name = "line1";
	this.line1.setTransform(52.2,0,0.5638,1,180);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.8,-1,257.8,560);


(lib.euroAll = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// euro2
	this.euro2 = new lib.euro2();
	this.euro2.name = "euro2";
	this.euro2.setTransform(194.35,164.6,0.5184,0.5184,0,0,0,-547.3,-48.2);

	this.timeline.addTween(cjs.Tween.get(this.euro2).wait(1));

	// euro1
	this.euro1 = new lib.euro1();
	this.euro1.name = "euro1";
	this.euro1.setTransform(194.45,164.6,0.6269,0.6268,0,0,0,-395.4,39.7);

	this.timeline.addTween(cjs.Tween.get(this.euro1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.euroAll, new cjs.Rectangle(42.3,-241.3,835.8000000000001,861.8), null);


(lib.europa = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// euroSquare
	this.euroSquare = new lib.euroSquare();
	this.euroSquare.name = "euroSquare";
	this.euroSquare.setTransform(49,167.45,1,1,-1.0002,0,0,4.4,4.5);

	this.timeline.addTween(cjs.Tween.get(this.euroSquare).wait(1));

	// mask_car (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("APee7MhCoAAAMAAAgmKMAjtAAAIAA8GMAvuAAAIAAaPQHFBBFSFTQGjGiABJQQgBJQmjGjQmiGjpQAAQnnAAlxkbgAH3ZCQAbA3AwASQAJADAJACQASAJAWAAQAOgBAMgEQANAAAMgFQAPgEANgJIANgKIALgIQASgOAIgTQAFgKACgLIAJgQQAIgQAGgSIAHgKIABgEIAVgGQAtgLBYgQQBbgPArgLQAcgIARgHQAMgGAJgGQAVgEAQgMQAkAAAhgJIAwgOQAdgKAUgDQASgDAlgDIAOgCIAFAJQANAQAUAJQATAJAUgBIAIgBQARACARgFQAYgHAPgRQAQgSAGgYIAAgCQAKgPAEgTQADgNgBgNIAAgKIABgBQAGgMAEgPIABgHQAXgRAOggQAMgeABgyQACg8gNg8QgIgogRgbIgFgHQgEgKgGgJQgPgVgVgLQgPgIgVgFIgmgKQgzgOhKgyQg1gkgSgKQgTgKgUgIQgLgBgKgGIgPgCQgwgIhSgFQhngHhWgEQgLABgOAAIh1ABIgagBIgIgBIgPACIgWgBQg7gCg/ADIgEABIgBgBQgMgDgKACQgMgBgKADQgNgCgMAFIgFAAQhLAJgjAMQgWAHgLALIgGAGIgBAAIgFAFIgDABIgtAcIgfASQgTAKgMAJIgWASIgXASQgHAGgbAPQgWAMgLAKIgDADQgLgEgLAAQgOAAgMAHQgMAHgIALQgHAMgBAOQgBAOAGANIABACIhBAaIgLABQgTADglAJIgoAIQgZAFgQAFQgUAGgPAJQgIABgJAEIgKACQgOAEgKAKIgCACQgVAGgQAIIgLAHQgLAGgKAIIgIAJIAAAAQgSAHgMAOIgFADQgJAFgMAMQgHAIgFAHQgHAHgHAIQgMAQgDATIgFAKIgBAFQgEAIgBAIQgFAMgCAPIAAAGQgRAjAEAlIABAHQgFAPAEAPIABABIABALIgBADQgDAHAAALQAAAMADAIIADAJIgBAIQAAATAJAOQABAKAEAIQAGANAMAIQAHAFAHADIAMAIQAUALAnAJQBsAYA9AMQBcASBMAIQBQAICeAEQBXACArgFQAVgDAPgGIAGgBQAQgEALgLIACgCIATgGIATgIIADAFg");
	mask.setTransform(-93.3,125.725);

	// euroAll
	this.euroAll = new lib.euroAll();
	this.euroAll.name = "euroAll";
	this.euroAll.setTransform(49,167.8,0.3453,0.3453,-0.4963,0,0,190.3,161.6);

	var maskedShapeInstanceList = [this.euroAll];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.euroAll).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.europa, new cjs.Rectangle(-1.9,26.8,236.20000000000002,299.4), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var logo = this.logo;
		var logoDSmin = this.logoDSmin;
		var ecoLogo = this.ecoLogo;
		var cargaLogo = this.cargaLogo;
		
		var frameWhite = this.frameWhite;
		
		var txt1 = this.txt1;
		var txtds9 = txt1.ds9;
		var txtds9line = txt1.txtline;
		var txt1txt = txt1.txt1txt;
		
		var txt2 = this.txt2;
		var txt3 = this.txt3;
		var offer = this.offer;
		
		var img1 = this.img1;
		var img2 = this.img2;
		var img2guide = this.img2guide;
		
		var cta = this.cta;
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		var europa = this.europa;
		var euro1 = europa.euroAll.euro1;
		var euro2 = europa.euroAll.euro2;
		var euroAll = europa.euroAll;
		var euroSquare = europa.euroSquare;
		
		//MASK - START 
		var toMask = [euro1];
		
		function makeMask(){
		
			for (var i = 0; i < toMask.length; i++) {
			 
				var toMaskVar = toMask[i]; 
				var areaMask = new createjs.Shape();
			
				//MASKA KÓŁKO
				 areaMask.graphics.beginStroke("1px solid #ffffff").arc((toMaskVar.nominalBounds.width * toMaskVar.scaleX)/2, (toMaskVar.nominalBounds.height * toMaskVar.scaleY)/2, toMaskVar.nominalBounds.width * toMaskVar.scaleX, 0, 2 * Math.PI);
					toMaskVar.mask = areaMask;
					toMaskVar.mask.regX = toMaskVar.regX * toMaskVar.scaleX;
					toMaskVar.mask.regY = toMaskVar.regY * toMaskVar.scaleY;
					toMaskVar.mask.x = toMask[i].x + toMaskVar.nominalBounds.x * toMaskVar.scaleX;
					toMaskVar.mask.y = toMask[i].y + toMaskVar.nominalBounds.y * toMaskVar.scaleY;
					
					//toMaskVar.parent.addChild(areaMask); // Also made visible
			}
			
		}
		makeMask();
		//MASK - START END
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf);
			}
		
		}
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat:0, repeatDelay:0, ease: Power2.easeOut});
		this.euroTl = euroTl = gsap.timeline({paused:true, repeat:0, repeatDelay:0});
		this.imgTl = imgTl = gsap.timeline({paused:true, repeat:0, repeatDelay:0}); //timeline dla drugiego zdjęcia
		
		
		
		euroTl
			.add("europe")
			.from([euroAll], {duration: 3, rotation:"10"}, "europe")
			.from([euroSquare], {duration: .5, scaleX:110, scaleY:110, x:"+=20", y: "+=40"}, "europe+=.3")
			.from(euro1, {duration: 2, scaleX:2.5, scaleY:2.5, ease: Power2.easeOut}, "europe+=.4")
			.from(euro1.mask, {duration: 3, scaleX:.1, scaleY:.1, alpha: 0}, "europe+=.3")
			.from(euro2, {duration: 2, scaleX:2.5, scaleY:2.5, ease: Power2.easeOut}, "europe+=1")
		
		imgTl
			.to([img2], 10, {x:img2guide.x, ease: Power2.easeOut}, "frame2")
		
		
		tl
			.add("frame1")
			.add(function(){euroTl.play(0)}, "frame1")
			.from(txtds9, {duration: 1.5, alpha:0, ease: Power2.easeOut}, "frame1+=1")
			.from(txtds9line, {duration: 1.5, alpha:0, ease: Power2.easeOut}, "frame1+=1.2")
			.from(txt1txt, {duration: 1.5, alpha:0, ease: Power2.easeOut}, "frame1+=1.5")
			.to([img1, txt1, europa, frameWhite, logo], {duration:0.5, alpha:0, ease: Power2.easeOut}, "frame1+=5")
			.add(autoShot)
		
			.add("frame2") 
			.add(function(){imgTl.play(0)})
			.to([logo, frameWhite], {duration:2, alpha:1}, "frame2")
			//.from(img2, {duration:2, alpha:0}, "frame2")
			.from(txt2, {duration: 1, alpha:0}, "frame2+=.5")
			.to(txt2, {duration: 1, alpha:0}, "frame2+=4.5")
			.from(txt3, {duration: 1, alpha:0}, "frame2+=5.5")
			.to([img2, img2guide, frameWhite, logo, txt3], {duration:0.5, alpha:0, ease: Power2.easeOut})
			.add(autoShot)
		
			.add("frame3")
			.from([logoDSmin, ecoLogo, cargaLogo, offer, cta], {duration:1, alpha:0}, "frame3")
			.call(autoShot, [true],"+=0")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// europa
	this.europa = new lib.europa();
	this.europa.name = "europa";
	this.europa.setTransform(233.75,288,1.0783,1.0781,0,0,0,49,167.1);

	this.timeline.addTween(cjs.Tween.get(this.europa).wait(1));

	// logo
	this.logo = new lib.logo_1();
	this.logo.name = "logo";
	this.logo.setTransform(174.25,43,0.3,0.3,0,0,0,80.9,98.7);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// frameWhite
	this.frameWhite = new lib.frameWhite();
	this.frameWhite.name = "frameWhite";
	this.frameWhite.setTransform(21,21);

	this.timeline.addTween(cjs.Tween.get(this.frameWhite).wait(1));

	// logoDSmin
	this.logoDSmin = new lib.logo_1();
	this.logoDSmin.name = "logoDSmin";
	this.logoDSmin.setTransform(41.4,28.6,0.17,0.1699,0,0,0,0.6,133.9);

	this.timeline.addTween(cjs.Tween.get(this.logoDSmin).wait(1));

	// ecoLogo
	this.ecoLogo = new lib.ecoLogo();
	this.ecoLogo.name = "ecoLogo";
	this.ecoLogo.setTransform(223.4,28.75,0.35,0.35,0,0,0,64.2,64.2);

	this.timeline.addTween(cjs.Tween.get(this.ecoLogo).wait(1));

	// cargaLogo
	this.cargaLogo = new lib.cargaLogo();
	this.cargaLogo.name = "cargaLogo";
	this.cargaLogo.setTransform(272.45,27.75,0.22,0.22,0,0,0,126.2,126.2);

	this.timeline.addTween(cjs.Tween.get(this.cargaLogo).wait(1));

	// offer
	this.offer = new lib.offer();
	this.offer.name = "offer";
	this.offer.setTransform(475.65,146.7,1,1,0,0,0,350.9,101.5);

	this.timeline.addTween(cjs.Tween.get(this.offer).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(150.05,539.7,1,1,0,0,0,72.8,13.9);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(149.1,148.7,1,1,0,0,0,31.4,18.2);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// img1
	this.img1 = new lib.img1();
	this.img1.name = "img1";
	this.img1.setTransform(490,125,1,1,0,0,0,490,125);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	// txt3
	this.txt3 = new lib.txt3();
	this.txt3.name = "txt3";
	this.txt3.setTransform(150,539.85,1,1,0,0,0,97.7,0);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(150,516.45,1,1,0,0,0,118.1,0);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// img2
	this.img2 = new lib.img2();
	this.img2.name = "img2";
	this.img2.setTransform(267.9,353,1,1,0,0,0,339.9,421);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img2guide
	this.img2guide = new lib.img2guide();
	this.img2guide.name = "img2guide";
	this.img2guide.setTransform(32.5,300,1,1,0,0,0,680.5,374);

	this.timeline.addTween(cjs.Tween.get(this.img2guide).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-122.9,299.5,657.9,300.5);
// library properties:
lib.properties = {
	id: '00F0F05ED14546088A2FEAF3F984DC27',
	width: 300,
	height: 600,
	fps: 60,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['00F0F05ED14546088A2FEAF3F984DC27'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;