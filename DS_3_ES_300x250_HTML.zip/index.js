(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._300x250_3 = function() {
	this.initialize(img._300x250_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1119,720);


(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1070,1010);


(lib.img2 = function() {
	this.initialize(img.img2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,581,557);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteTop = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgjmADcMAbNgiDMAsAAedMglJAeyg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteTop, new cjs.Rectangle(-227.8,-196,455.70000000000005,392), null);


(lib.whiteEnd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgaHgp2MBBvA1jMhPPAeKg");
	this.shape.setTransform(253.575,267.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteEnd, new cjs.Rectangle(0,0,507.2,535.8), null);


(lib.txtGuide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("A4/jRIRr0nMAgTAbJIxpUog");
	this.shape.setTransform(159.95,152.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtGuide, new cjs.Rectangle(0,0,319.9,305.8), null);


(lib.txtBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5E5C57").s().p("EgZ2Ap0MgA9hVZMAyqApxIC9CZIi9CbMgvhAm0IiMByg");
	this.shape.setTransform(171.575,278.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtBg, new cjs.Rectangle(0,0,343.2,558), null);


(lib.txt4b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag1BDQgNgRAFgeIAJgyQAFgbAQgNQAQgOAYgBQAeAAAOASQAOASgFAeIgKAxQgEAbgQAPQgQAOgZgBQgeABgOgTgAgTg5QgKAJgEATIgJAzQgEAWAJAMQAJALAUAAQAQAAALgJQAKgKAEgSIAJgzQAEgWgJgLQgJgNgUAAQgQAAgLAKg");
	this.shape.setTransform(149.471,74.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgkBTIAaiTIgyAAIADgSIB2AAIgEASIgwAAIgaCTg");
	this.shape_1.setTransform(136.2,74.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_2.setTransform(119.975,74.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_3.setTransform(105.9,74.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgYBTIAcilIAVAAIgdClg");
	this.shape_4.setTransform(95.35,74.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAuBTIAWh5IhKBwIgMAAIgjhyIgWB7IgSAAIAdilIAQAAIAoCCIBWiCIAQAAIgdClg");
	this.shape_5.setTransform(81.525,74.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_6.setTransform(62.175,74.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_7.setTransform(47.925,74.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgYBTIAcilIAVAAIgdClg");
	this.shape_8.setTransform(36.3,74.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag7BTIAdilIBaAAIgDARIhHAAIgKA9IA9AAIgDAQIg9AAIgNBHg");
	this.shape_9.setTransform(27.375,74.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_10.setTransform(14.45,74.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_11.setTransform(-0.2484,74.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AguBTIAeilIATAAIgZCUIBFAAIgEARg");
	this.shape_12.setTransform(118.35,47.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_13.setTransform(106.8,47.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhABTIAdilIAvAAQAdAAANASQAOASgFAeIgIAsQgFAbgQAOQgRAOgaAAgAgpBCIAhAAQASAAALgKQALgJAEgUIAIgtQAEgWgJgMQgJgMgTAAIgdAAg");
	this.shape_14.setTransform(91.8026,47.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_15.setTransform(73.4,47.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AglBTIAbiTIgyAAIADgSIB2AAIgEASIgwAAIgaCTg");
	this.shape_16.setTransform(60.85,47.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_17.setTransform(45.2016,47.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_18.setTransform(29.075,47.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AguBTIAeilIATAAIgZCUIBFAAIgEARg");
	this.shape_19.setTransform(11.25,47.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_20.setTransform(-0.3,47.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.7,32.2,243.7,58.5);


(lib.txt4a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgyBWQgTgQABgfIAAgGIAjAAIAAAGQAAAPAJAJQAIAIAQAAQAPAAAIgIQAKgHAAgNIAAgEQAAgNgKgHQgIgHgPAAIgPAAIAAgcIAMAAQANAAAIgGQAIgHAAgLIAAgFQAAgLgIgHQgIgGgMAAQgNAAgIAHQgIAGAAANIAAAHIgjAAIAAgHQAAgbARgQQARgQAfAAQAdAAARAPQASAOAAAZIAAAEQAAAOgGAKQgGAKgLAGQAOAFAIAMQAHALAAASIAAAEQAAAbgSAPQgSAPghAAQggAAgSgRg");
	this.shape.setTransform(42.65,49.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag0BXQgSgQAAgcIAAgHIAkAAIAAAHQAAAOAJAHQAJAHAQAAQARAAAIgGQAJgHAAgNQAAgLgHgHQgHgGgPgDIgRgEQgcgFgOgOQgPgPAAgXQAAgbASgQQATgQAgAAQAeAAASAQQASAPAAAbIAAAGIgkAAIAAgGQAAgMgIgHQgJgHgOAAQgPAAgIAGQgIAGAAAMQAAAKAHAHQAHAGAQADIAQADQAdAGAOAOQAOAPAAAYQAAAegSAPQgTAQgiAAQghAAgTgQg");
	this.shape_1.setTransform(20.475,49.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhHBkIAAjHIBFAAQAjAAAUAUQASAVAAAlIAAArQAAAmgSAUQgUAUgjAAgAghBCIAfAAQASAAAJgKQAKgLAAgVIAAgvQAAgVgKgKQgJgLgSAAIgfAAg");
	this.shape_2.setTransform(2.85,49.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,32.2,71.2,36.099999999999994);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBTIAAilIBjAAIAAAbIhEAAIAAAqIA5AAIAAAZIg5AAIAAAtIBEAAIAAAag");
	this.shape.setTransform(151.2,67.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBTIAAilIAfAAIAAClg");
	this.shape_1.setTransform(140.55,67.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA4BTIAAhjIgtBYIgVAAIgthYIAABjIgcAAIAAilIAZAAIA7B0IA5h0IAaAAIAAClg");
	this.shape_2.setTransform(126.55,67.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgtBFQgQgRAAgfIAAgpQAAgfAQgRQAQgQAdgBQAeABAQAQQARARAAAfIAAApQAAAfgRARQgQAQgeAAQgeAAgPgQgAgXgvQgHAIgBARIAAAsQABASAHAIQAJAJAOAAQAQAAAIgJQAHgIAAgSIAAgsQAAgRgHgIQgIgJgQAAQgOAAgJAJg");
	this.shape_3.setTransform(108.4,67.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAkBTIhEhsIAABsIgcAAIAAilIAZAAIBEBsIAAhsIAcAAIAAClg");
	this.shape_4.setTransform(92.5,67.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AguBFQgPgRAAgfIAAgpQAAgfAQgRQAQgQAdgBQAeABAQAQQAQARABAfIAAApQgBAfgQARQgQAQgeAAQgdAAgRgQgAgWgvQgJAIAAARIAAAsQAAASAJAIQAIAJAOAAQAQAAAHgJQAJgIgBgSIAAgsQABgRgJgIQgHgJgQAAQgOAAgIAJg");
	this.shape_5.setTransform(76.6,67.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgOBTIAAiJIgvAAIAAgcIB7AAIAAAcIguAAIAACJg");
	this.shape_6.setTransform(61.975,67.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgsBFQgQgRAAgdIAAhqIAfAAIAABrQAAAQAIAIQAHAIAOAAQAPAAAHgIQAIgIAAgQIAAhrIAfAAIAABqQAAAdgQARQgPAPgeAAQgdAAgPgPg");
	this.shape_7.setTransform(47.275,67.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAmBTIgLgiIg4AAIgLAiIgeAAIA4ilIAdAAIA5ClgAATAZIgThFIgVBFIAoAAg");
	this.shape_8.setTransform(31.7,67.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRAWIAEgJIAGgLIABgMIAAgXIAZAAIAAAVQgBAOgBAGQgCAFgIAMIgGAJg");
	this.shape_9.setTransform(20.1,62.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag7BTIAAilIA5AAQAdAAAQARQARARAAAfIAAAkQAAAfgRARQgQAQgdAAgAgcA3IAaAAQAPAAAIgIQAIgJAAgRIAAgoQAAgRgIgJQgIgJgPAAIgaAAg");
	this.shape_10.setTransform(10.025,67.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AA4BTIAAhjIgtBYIgVAAIgthYIAABjIgcAAIAAilIAaAAIA6B0IA5h0IAaAAIAAClg");
	this.shape_11.setTransform(167.85,41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAcBTIgshKIgRAUIAAA2IgfAAIAAilIAfAAIAABMIA7hMIAjAAIg4BGIA8Bfg");
	this.shape_12.setTransform(150.425,41.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgqBGQgQgQAAgdIAAgxQAAgdAQgQQAPgQAbAAQAcAAAQAQQAPAQAAAdIAAAxQAAAdgPAQQgPAPgdAAQgbAAgPgPgAgUgxQgGAIAAAQIAAA0QAAAPAGAIQAHAHANAAQAOAAAHgHQAHgIAAgPIAAg0QAAgQgHgIQgHgHgOgBQgNABgHAHg");
	this.shape_13.setTransform(134.475,41.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgqBGQgQgQAAgdIAAgxQAAgdAQgQQAPgQAbAAQAcAAAQAQQAPAQAAAdIAAAxQAAAdgPAQQgPAPgdAAQgbAAgPgPgAgUgxQgGAIAAAQIAAA0QAAAPAGAIQAHAHANAAQAOAAAHgHQAHgIAAgPIAAg0QAAgQgHgIQgHgHgOgBQgNABgHAHg");
	this.shape_14.setTransform(119.625,41.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAYBTIAAggIhNAAIAAgWIA5hvIAhAAIg4BqIArAAIAAgdIAeAAIAABYg");
	this.shape_15.setTransform(105.425,41.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAmBlIgMgjIg3AAIgLAjIgfAAIA5imIAdAAIA4CmgAATAqIgUhFIgUBFIAoAAgAgNhMIgbgYIAgAAIAVAYg");
	this.shape_16.setTransform(87.1,39.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgSAWIAGgJIAFgLIABgMIAAgXIAYAAIAAAVQAAAPgBAFQgCAFgIAMIgHAJg");
	this.shape_17.setTransform(75.5,36.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgsBFQgQgRAAgeIAAhpIAfAAIAABrQAAAQAIAIQAHAJAOgBQAPABAHgJQAIgHAAgRIAAhrIAfAAIAABpQAAAegQARQgPAPgeAAQgdAAgPgPg");
	this.shape_18.setTransform(64.925,41.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgOBpIAAgoQgXgEgMgQQgNgQAAgbIAAgpQAAgfARgRQAQgRAdAAQAeAAAQARQAQARAAAfIAAApQAAAbgMAQQgMAQgXAEIAAAogAgWhDQgJAJABARIAAAuQgBARAJAJQAHAJAPgBQAPABAJgJQAHgJABgRIAAguQgBgRgHgJQgJgIgPgBQgPABgHAIg");
	this.shape_19.setTransform(49.3,43.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgrBJQgPgOAAgXIAAgGIAdAAIAAAGQAAALAIAGQAIAHANgBQAOABAHgGQAHgGAAgKQAAgJgGgHQgGgFgMgCIgNgEQgYgEgMgLQgMgMAAgUQAAgWAPgOQAPgNAbAAQAZAAAPANQAPANAAAXIAAAEIgeAAIAAgEQAAgLgHgGQgHgFgMgBQgMAAgHAGQgGAFAAAJQAAAJAGAGQAGAEAMAEIAOACQAYAFALALQAMANAAAVQAAAYgPANQgQAMgcAAQgbAAgQgMg");
	this.shape_20.setTransform(34.425,41.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgsBFQgQgRAAgeIAAhpIAfAAIAABrQAAAQAIAIQAHAJAOgBQAPABAHgJQAIgHAAgRIAAhrIAfAAIAABpQAAAegQARQgPAPgeAAQgdAAgPgPg");
	this.shape_21.setTransform(19.275,41.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AghBTIAAgcIAOAAQALAAAHgGQAEgGAAgOIAAhvIAgAAIAABtQAAAegOANQgNANgbAAg");
	this.shape_22.setTransform(6.15,41.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(0,0,202.5,83.3), null);


(lib.txt1Line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ai9AFIAAgJIF7AAIAAAJg");
	this.shape.setTransform(19,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1Line, new cjs.Rectangle(0,0,38,1), null);


(lib.txt1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag1BDQgNgRAFgeIAJgxQAFgbAQgPQAQgOAYAAQAeABAOARQAOARgFAfIgKAxQgEAbgQAPQgQANgZAAQgeABgOgTgAgTg5QgKAKgEASIgJAzQgEAVAJANQAJAMAUgBQAQABALgKQAKgKAEgSIAJgzQAEgWgJgLQgJgNgUAAQgQAAgLAKg");
	this.shape.setTransform(187.721,42.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgkBTIAaiTIgyAAIADgSIB2AAIgEASIgwAAIgaCTg");
	this.shape_1.setTransform(174.45,42.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_2.setTransform(158.225,42.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_3.setTransform(144.15,42.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgYBTIAcilIAVAAIgdClg");
	this.shape_4.setTransform(133.6,42.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAuBTIAWh5IhKBwIgMAAIgjhyIgWB7IgSAAIAdilIAQAAIAoCCIBWiCIAQAAIgdClg");
	this.shape_5.setTransform(119.775,42.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_6.setTransform(100.425,42.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_7.setTransform(86.175,42.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgYBTIAcilIAVAAIgdClg");
	this.shape_8.setTransform(74.55,42.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag7BTIAdilIBaAAIgDARIhHAAIgKA9IA9AAIgDAQIg9AAIgNBHg");
	this.shape_9.setTransform(65.625,42.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_10.setTransform(52.7,42.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_11.setTransform(38.0016,42.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AguBTIAeilIATAAIgZCUIBFAAIgEARg");
	this.shape_12.setTransform(156.6,14.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_13.setTransform(145.05,14.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhABTIAdilIAvAAQAdAAANASQAOASgFAeIgIAsQgFAbgQAOQgRAOgaAAgAgpBCIAhAAQASAAALgKQALgJAEgUIAIgtQAEgWgJgMQgJgMgTAAIgdAAg");
	this.shape_14.setTransform(130.0526,14.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_15.setTransform(111.65,14.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AglBTIAbiTIgyAAIADgSIB2AAIgDASIgxAAIgaCTg");
	this.shape_16.setTransform(99.1,14.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_17.setTransform(83.4516,14.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_18.setTransform(67.325,14.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AguBTIAeilIATAAIgZCUIBFAAIgEARg");
	this.shape_19.setTransform(49.5,14.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_20.setTransform(37.95,14.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(28.5,0,177.8,58.5);


(lib.txt1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgyBWQgSgQAAgfIAAgGIAjAAIAAAGQAAAPAJAJQAIAIAQAAQAPAAAIgIQAKgHgBgNIAAgEQABgNgKgHQgIgHgPAAIgPAAIAAgcIAMAAQAOAAAHgGQAIgHAAgLIAAgFQAAgLgIgHQgHgGgNAAQgOAAgHAHQgIAGAAANIAAAHIgkAAIAAgHQAAgbASgQQASgQAeAAQAdAAASAPQARAOAAAZIAAAEQAAAOgGAKQgGAKgLAGQAOAFAIAMQAIALgBASIAAAEQAAAbgSAPQgTAPggAAQghAAgRgRg");
	this.shape.setTransform(51.4,17.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag0BXQgSgQAAgcIAAgHIAkAAIAAAHQAAAOAJAHQAJAHAQAAQARAAAIgGQAJgHAAgNQAAgLgHgHQgHgGgPgDIgRgEQgcgFgOgOQgPgPAAgXQAAgbASgQQATgQAgAAQAeAAASAQQASAPAAAbIAAAGIgkAAIAAgGQAAgMgIgHQgJgHgOAAQgPAAgIAGQgIAGAAAMQAAAKAHAHQAHAGAQADIAQADQAdAGAOAOQAOAPAAAYQAAAegSAPQgTAQgiAAQghAAgTgQg");
	this.shape_1.setTransform(29.225,17.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhHBkIAAjHIBFAAQAjAAATAUQAUAVgBAlIAAArQABAmgUAUQgTAUgjAAgAghBCIAfAAQARAAAKgKQAJgLAAgVIAAgvQAAgVgJgKQgKgLgRAAIgfAAg");
	this.shape_2.setTransform(11.6,17.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,183.4,36.1);


(lib.mask1Guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EghRgAJMAhbgZ8MAhIAZ8MghbAaPg");
	this.shape.setTransform(213,167);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mask1Guide, new cjs.Rectangle(0,0,426,334), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As6ToIADhJIACgLQAIgtAegdQFglUBJhLQEVkaBUjYQAuh1AAhpQAAh/guiNQhMjqjrkrQisjcjwjsIWVRaIBVBLQAMALAJAOQANAWAAAVQAAArg0AnI5DTig");
	mask.setTransform(82.775,129.45);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#838382","#838382","#B7B7B6","#EBEBEB","#FFFFFF","#FAFAFA","#ECECEB","#D4D4D3","#B3B3B2","#9D9D9C","#9D9D9C"],[0,0.043,0.216,0.412,0.506,0.588,0.682,0.788,0.898,0.961,1],0,-129.4,0,129.5).s().p("As7UPMAAAgodIZ3AAMAAAAodg");
	this.shape.setTransform(82.775,129.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0,0,165.6,258.9), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("An0GPQgDgCAxgtQBIhCA1g4QDLjWBsjpQAphaAbgbQAkglBHgHQDQgTBegCIADAAQASAAAJAEQAJAEACAJQAFAPgeAWQhtBNjKCeIm1FcQjXCigMAAIAAgBg");
	mask.setTransform(58.1041,48.7588);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],-3.1,-36.4,3.1,35.1).s().p("ApAmLIQ0heIBNN1Iw0Beg");
	this.shape.setTransform(57.725,49.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(8,8.8,100.2,79.9), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ArIC0IhRhFQgVgVgJgXQgEgMAAgPQABgNADgJQAOghAigZIZDzhIAAAUQAAA7gFAfQgJAvgeAeQl7FyguAwQkUEbhVDbQguB2AABrQAAB/AuCMQBLDoDnEoQCrDbDuDpg");
	mask.setTransform(83.0475,129.025);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(61,61,61,0)","#3D3D3D","#000000","#000000"],[0,0.89,0.89,0.961,1],0,-129,0,129).s().p("As8UKMAAAgoTIZ5AAMAAAAoTg");
	this.shape.setTransform(82.925,129.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#E2E1E1","#E2E1E1","#DDDCDC","#CFCECE","#C6C6C6","#EAEAEA","#FFFFFF","#F9F9F9","#E9E9E9","#CECECE","#A8A8A8","#777777","#3D3D3D","rgba(61,61,61,0)","rgba(0,0,0,0)"],[0,0.039,0.118,0.212,0.251,0.4,0.506,0.549,0.604,0.671,0.737,0.812,0.89,0.89,1],0,-129,0,129).s().p("As8UKMAAAgoTIZ5AAMAAAAoTg");
	this.shape_1.setTransform(82.925,129.025);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0.3,0,165.6,258.1), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AEsRQQgzgshghZQiPiDi3jZQici2hPiQQhki3gBibQABiQBhifQBSiGCfiaQBahXD9jWQD/jXBSg5IgCACQi4CQj5D4QlfFfhUDIQg0B6AABhQAAB7ArB7QBdEMFDFoQCrC+DNC3Qg4grhDg7g");
	this.shape.setTransform(750.65,480.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(699.7,359.7,101.89999999999998,241.09999999999997), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgCM9QlCllhdkLQgrh8AAh6QAAhiA0h6QBUjIFgleQD6j5C2iPQgHAJgGAHQl7FyguAxQkTEahXDbQgtB3gBBrQABB+AtCMQBNDnDmEoQCpDZDuDrQjNi3irjAg");
	mask.setTransform(46.05,120.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(253,253,253,0)","#FDFDFD","#F5F5F5","#E7E7E7","#D4D4D3","#BBBBBA","#9D9D9C","#9D9D9C"],[0,0.655,0.655,0.737,0.804,0.863,0.914,0.961,1],0,117.4,0,-117.4).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape.setTransform(46.05,120.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#000000","#2D2D2D","#585858","#808080","#A3A3A3","#C0C0C0","#D7D7D7","#E9E9E9","#F6F6F6","#FDFDFD","#FFFFFF","#FDFDFD","rgba(253,253,253,0)","rgba(0,0,0,0)"],[0,0.039,0.063,0.086,0.114,0.141,0.173,0.208,0.251,0.298,0.361,0.506,0.655,0.655,1],0,117.4,0,-117.4).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape_1.setTransform(46.05,120.4);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,92.1,240.8), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Am9SkQFflUBKhLQETkaBVjXQAvh1gBhrQAAh+guiNQhNjqjqkrQisjcjvjrQDOC4CuDBQFGFsBeEMQAqB5AAB9QAABigyB3QhVDHlgFbQj4D2i5CPg");
	mask.setTransform(46.05,120.375);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(225,225,225,0)","#E1E1E1","#C9C9C9","#AAAAAA","#848484","#585858","#252525","#000000","#000000"],[0,0.694,0.694,0.745,0.792,0.843,0.886,0.933,0.961,1],0,117.4,0,-117.3).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape.setTransform(46.05,120.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#706F6F","#706F6F","#828181","#A3A3A3","#C0C0C0","#D7D7D7","#E9E9E9","#F6F6F6","#FDFDFD","#FFFFFF","#FCFCFC","#F2F2F2","#E1E1E1","rgba(225,225,225,0)","rgba(0,0,0,0)"],[0,0.039,0.055,0.09,0.125,0.165,0.212,0.267,0.341,0.506,0.58,0.639,0.694,0.694,1],0,117.4,0,-117.3).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape_1.setTransform(46.05,120.375);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,92.1,240.8), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhgNfQFxljBpkIQAziAAAh0QAAhygziAQigmTrmpJQCtB1COBzQDXCuClCpQFiFsAAEjQAAEkliFsQioCsjUCrQiSB2ipByQD1jAC3iwg");
	this.shape.setTransform(526.125,476.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("An7SzQC4iPD5j2QFflbBVjHQAzh5AAhgQAAh9grh5QhdkMlHlsQiujBjOi4QBfBLC3CoQCPCDC3DZQCbC2BQCQQBkC3AACbQAACQhhCdQhSCDigCaQhZBWj9DUQj+DVhSA5g");
	this.shape_1.setTransform(693.125,610.775);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(473.6,352.9,270.5,378.4), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRNfQFVljBgkJQAwiAAAhzQAAhxgwiBQiTmSqtpKQLmJKCgGSQAzCAAAByQAAB0gzB/QhpEJlxFjQi2Cwj2DAQDjjACoiwg");
	mask.setTransform(47.7,123.125);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(253,253,253,0)","#FDFDFD","#F5F5F5","#E7E7E7","#D3D3D3","#BABABA","#9B9B9B","#767676","#4A4A4A","#1B1B1B","#000000","#000000"],[0,0.62,0.62,0.682,0.729,0.773,0.812,0.851,0.882,0.914,0.945,0.961,1],0,120.1,0,-120).s().p("AncTPMAAAgmdIO5AAMAAAAmdg");
	this.shape.setTransform(47.7,123.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#000000","#131313","#444444","#707070","#979797","#B7B7B7","#D1D1D1","#E6E6E6","#F4F4F4","#FCFCFC","#FFFFFF","#FDFDFD","rgba(253,253,253,0)","rgba(0,0,0,0)"],[0,0.039,0.051,0.082,0.118,0.157,0.196,0.239,0.286,0.337,0.4,0.506,0.62,0.62,1],0,120.1,0,-120).s().p("AncTPMAAAgmdIO5AAMAAAAmdg");
	this.shape_1.setTransform(47.7,123.125);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,95.4,246.3), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAfbQAAgWABgkQADgoACgOQAEgTAKgTQALgUAPgPQFVlJBVhXQESkYBUjUQAuhzAAhoQAAh9guiKQhbkVk9lzQiqjJjbjOQgagbgIgbQgLAmgrAhI5cTyMAAAgqlIZcT0QAqAfAMAnQALgmArggIZcz0IgCAzQAABBgGAlQgJArggAeQlpFihABCQkSEYhVDYQguB0ABBpQgBB9AuCKQBbEWE9FzQCrDIDaDPQANALAKAQQAQAZAAAaQAAAegVAcQgPAVgXAQI5aT0gAIVhlQDqErBODqQAtCMABB/QAABrgvB1QhVDYkVEZQhJBLlgFUQgeAegIAvQgCALgCAlIgCA0IAAAUIZEzhQA0gnAAgtQAAgVgNgVQgJgPgMgLIhVhKI2WxZQDwDsCtDbgA6EJ7IZEzhQA0gmAAgtQAAgtg0gnI5EzhgAYOIlQjujqiqjbQjnknhNjoQguiLAAiAQAAhrAuh3QBWjbEUkaQAogpGBl6QAfgeAIgvQAFgeAAg7IABgVI5FTiQgiAYgOAiQgDAKAAANQgBAPAEAMQAJAWAVAVIBRBFIWSRWIAAAAg");
	this.shape.setTransform(637.95,545.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(469.6,339.7,336.79999999999995,412.50000000000006), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AGJFHIhphZIm1lcQjKiehthNQgegWAEgPQADgJAJgEQAJgEARAAIAEAAQBlACCNANQBGAHAkAmQAVAWAxBeIBhCcQB3CtBzBsIBkBjQBVBUgDACIAAABQgHAAhXhJg");
	mask.setTransform(55.9242,48.4557);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],3.2,-36.6,-3.1,35.2).s().p("AovGMIBNtyIQSBcIhONxg");
	this.shape.setTransform(56,48.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(7.2,8.5,97.5,79.9), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As7TjIAZgVIABAAQClhwCVh3QDWisCoisQFhlsAAkjQAAkjlhlsQiliqjZitQiNh0iuh1IgZgTIAAhSIZDThQA0AnAAAsQAAAtg0AnI5DThg");
	mask.setTransform(82.8,133.3);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#706F6F","#706F6F","#828181","#B1B1B1","#FDFDFD","#FFFFFF","#ECECEC","#BCBBBB","#6E6D6D","#5F5E5E","#5F5E5E"],[0,0.043,0.122,0.278,0.498,0.506,0.576,0.722,0.922,0.961,1],0,-133.3,0,133.3).s().p("As7U1MAAAgppIZ3AAMAAAAppg");
	this.shape.setTransform(82.8,133.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,165.6,266.6), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnvGPQgDgBCMh9IA/g7QBzhsB3itQA8hYAlhEQAyheAVgWQAjgmBGgHQCNgNBmgCIADAAQASAAAIAEQAJAEADAJQAEAPgeAWQheBCjXCrQk6D5h8BhIhCAyIhuBUQgkAcgGAAIAAgBg");
	mask.setTransform(56.7771,48.6098);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],-3.2,-36.5,3.1,35.2).s().p("Ao3mKIQihdIBNNzIwiBcg");
	this.shape.setTransform(56.825,48.825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(7.2,8.7,99.2,79.89999999999999), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnEziIAZAUQDjDACpCwQFUFjBhEIQAvCCAABxQAABygvCCQhhEIlUFjQipCwjjDAIgZAUg");
	mask.setTransform(45.325,125.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FAFAFA","#FAFAFA","#EBEBEB","#808285","#808285"],[0,0.02,0.471,0.961,1],0,-121.9,0,122).s().p("AnETjMAAAgnFIOJAAMAAAAnFg");
	this.shape.setTransform(45.325,125.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,90.7,250.2), null);


(lib.img4Guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x250_3();
	this.instance.setTransform(-335,-184.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Guide, new cjs.Rectangle(-335,-184.4,1119,720), null);


(lib.img4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x250_3();
	this.instance.setTransform(-287.1,-184.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4, new cjs.Rectangle(-287.1,-184.7,1119,720), null);


(lib.img2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.instance = new lib.img2();
	this.instance.setTransform(66.2,-3.65,0.5023,0.5023);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(66.2,-3.6,291.90000000000003,279.8);


(lib.img1_zoom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();
	this.instance.setTransform(0.05,0.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2B2B").s().p("EiIiBnwMAAAjPeMERGAAAMAAADPeg");
	this.shape.setTransform(873.75,668.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_zoom, new cjs.Rectangle(-0.2,0.1,1747.9,1332.8000000000002), null);


(lib.ctaTxt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbApQgJgKAAgSIAAgZQAAgSAKgKQAJgKARAAQASAAAKAKQAKAKAAASIAAAZQAAASgKAKQgKAKgSAAQgRAAgKgKgAgNgcQgFAFAAAKIAAAbQAAAKAFAFQAFAFAIAAQAKAAAEgFQAFgFAAgKIAAgbQAAgKgFgFQgEgGgKAAQgIAAgFAGg");
	this.shape.setTransform(133.05,9.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcAyIAAhjIATAAIAABSIAmAAIAAARg");
	this.shape_1.setTransform(125.075,9.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXAyIgHgVIghAAIgGAVIgTAAIAihjIARAAIAiBjgAAMAPIgMgpIgMApIAYAAg");
	this.shape_2.setTransform(116.35,9.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAPAyIgSglIgOAAIAAAlIgSAAIAAhjIAhAAQAQAAAIAIQAIAHAAAPIAAAEQgBALgDAFQgEAHgIADIAXAngAgRgBIAPAAQAGAAADgEQAEgDAAgGIAAgFQAAgHgEgEQgDgDgGAAIgPAAg");
	this.shape_3.setTransform(107.65,9.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghAyIAAhjIAhAAQAOAAAIAHQAHAGABANIAAACQAAAHgDAFQgDAFgFADQAHABAEAHQAEAFAAAJIAAACQAAANgJAHQgHAHgPAAgAgPAjIASAAQAFAAAEgEQAEgDgBgGIAAgDQABgGgEgEQgEgDgFAAIgSAAgAgPgHIAPAAQAGAAACgDQADgCAAgGIAAgFQAAgEgDgEQgCgCgGAAIgPAAg");
	this.shape_4.setTransform(98.65,9.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaA0QgKgLAAgRIAAg/IATAAIAAA/QAAAKAFAGQAEAEAIAAQAJAAAEgEQAFgGAAgKIAAg/IATAAIAAA/QAAARgKALQgJAJgSAAQgRAAgJgJgAgHguIAMgOIATAAIgQAOg");
	this.shape_5.setTransform(89.275,8.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAqQgJgKAAgSIAAgbQAAgSAJgKQAKgJAQAAQARAAAKAJQAJAKAAASIAAADIgTAAIAAgEQAAgKgEgFQgEgFgJAAQgIAAgEAFQgEAFAAAKIAAAdQAAAKAEAFQAEAEAIAAQAJAAAEgEQAEgFAAgKIAAgEIATAAIAAADQAAASgJAKQgKAJgRAAQgQAAgKgJg");
	this.shape_6.setTransform(80.125,9.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZArQgKgIAAgOIAAgDIASAAIAAADQAAAHAFAEQAFAEAHAAQAIAAAFgEQAEgDAAgGQAAgGgDgDQgEgEgHgBIgIgCQgOgDgIgGQgHgHAAgMQAAgOAJgIQAKgHAPAAQAQAAAIAHQAJAIAAAOIAAACIgSAAIAAgCQAAgHgEgDQgFgEgGAAQgIAAgDADQgEADgBAGQABAFAEAEQADADAHABIAIACQAPADAGAGQAIAIgBAMQABAPgKAHQgJAIgRAAQgQAAgJgIg");
	this.shape_7.setTransform(71.35,9.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdAyIAAhjIA7AAIAAAQIgpAAIAAAaIAiAAIAAAOIgiAAIAAAbIApAAIAAAQg");
	this.shape_8.setTransform(63.35,9.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgjAyIAAhjIAiAAQARAAAKAKQAKALAAASIAAAVQAAATgKAKQgKAKgRAAgAgQAhIAPAAQAJAAAEgFQAFgFAAgLIAAgXQAAgLgFgEQgEgGgJAAIgPAAg");
	this.shape_9.setTransform(54.675,9.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaTxt, new cjs.Rectangle(0,0,187.6,20.1), null);


(lib.ctaBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ap4DZQhpAAhLhAQhKg/AAhaQAAhZBKhAQBLg/BpgBITxAAQBpABBKA/QBLBAAABZQAABahLA/QhKBAhpAAg");
	this.shape.setTransform(88.725,21.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaBg, new cjs.Rectangle(0,0,177.5,43.5), null);


(lib.Cover_Right = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AJPQTIyhvIIhKg9IBKg7ITvwSMgAYAhSIAAAtg");
	this.shape.setTransform(74.9976,121.9951,1.1215,1.1215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cover_Right, new cjs.Rectangle(0,0,150,244), null);


(lib.Cover_Left = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AqEQTMgAYghSITwQSIBJA7IhJA9IyiPIIg2Atg");
	this.shape.setTransform(74.9976,121.9951,1.1215,1.1215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cover_Left, new cjs.Rectangle(0,0,150,244), null);


(lib.white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bQmMAAAghLMAu3AAAMAAAAhLg");
	this.shape.setTransform(150,106.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Cover_Right
	this.Cover_Right = new lib.Cover_Right();
	this.Cover_Right.name = "Cover_Right";
	this.Cover_Right.setTransform(150,88.8);

	this.timeline.addTween(cjs.Tween.get(this.Cover_Right).wait(1));

	// Cover_Left
	this.Cover_Left = new lib.Cover_Left();
	this.Cover_Left.name = "Cover_Left";
	this.Cover_Left.setTransform(0,88.8);

	this.timeline.addTween(cjs.Tween.get(this.Cover_Left).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,300,332.8), null);


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt4a
	this.txt4a = new lib.txt4a();
	this.txt4a.name = "txt4a";
	this.txt4a.setTransform(-151.9,10.1,1,1,0,0,0,28.3,49.8);

	this.timeline.addTween(cjs.Tween.get(this.txt4a).wait(1));

	// txt4b
	this.txt4b = new lib.txt4b();
	this.txt4b.name = "txt4b";
	this.txt4b.setTransform(-64.2,71.1,1,1,0,0,0,114,62.9);

	this.timeline.addTween(cjs.Tween.get(this.txt4b).wait(1));

	// txt4Line
	this.txt4Line = new lib.txt1Line();
	this.txt4Line.name = "txt4Line";
	this.txt4Line.setTransform(-163.8,32.8,1,1,0,0,0,19.1,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txt4Line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(-188.9,-7.5,244.7,106.4), null);


(lib.txt2Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txtGuide
	this.txtGuide = new lib.txtGuide();
	this.txtGuide.name = "txtGuide";
	this.txtGuide.setTransform(-37.65,145.15,1,1,0,0,0,160,152.9);

	this.timeline.addTween(cjs.Tween.get(this.txtGuide).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4+jRIRp0nMAgUAbJIxpUog");
	mask.setTransform(61.3,30.15);

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(2.4,1.4);

	var maskedShapeInstanceList = [this.txt2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2Container, new cjs.Rectangle(-197.6,-7.7,402.5,305.8), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1a
	this.txt1a = new lib.txt1a();
	this.txt1a.name = "txt1a";
	this.txt1a.setTransform(0.15,15.6);

	this.timeline.addTween(cjs.Tween.get(this.txt1a).wait(1));

	// txt1b
	this.txt1b = new lib.txt1b();
	this.txt1b.name = "txt1b";
	this.txt1b.setTransform(-26.65,61.8);

	this.timeline.addTween(cjs.Tween.get(this.txt1b).wait(1));

	// txt1Line
	this.txt1Line = new lib.txt1Line();
	this.txt1Line.name = "txt1Line";
	this.txt1Line.setTransform(5.15,56.45,1.421,1,0,0,0,0.1,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txt1Line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(0.2,15.6,183.3,104.7), null);


(lib.logo_DS_vector = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(22.1,65,0.4799,0.4799,0,0,0,46.1,126.2);

	this.instance_1 = new lib.ClipGroup_1();
	this.instance_1.setTransform(53.1,85.15,0.4799,0.4799,0,0,0,57.6,49.8);

	this.instance_2 = new lib.ClipGroup_2();
	this.instance_2.setTransform(40.25,65.05,0.4799,0.4799,0,0,0,83.9,134.5);

	this.instance_3 = new lib.ClipGroup_3();
	this.instance_3.setTransform(107.45,85.15,0.4799,0.4799,0,0,0,56.7,49.7);

	this.instance_4 = new lib.ClipGroup_4();
	this.instance_4.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_5 = new lib.ClipGroup_5();
	this.instance_5.setTransform(24.5,65,0.4799,0.4799,0,0,0,48.6,124.2);

	this.instance_6 = new lib.ClipGroup_6();
	this.instance_6.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_7 = new lib.ClipGroup_7();
	this.instance_7.setTransform(104.8,129.55,0.4799,0.4799,0,0,0,47.1,121.2);

	this.instance_8 = new lib.ClipGroup_8();
	this.instance_8.setTransform(136.95,67,0.4799,0.4799,0,0,0,47,121.4);

	this.instance_9 = new lib.ClipGroup_9();
	this.instance_9.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_10 = new lib.ClipGroup_10();
	this.instance_10.setTransform(120.6,63.05,0.4799,0.4799,0,0,0,83.5,130.3);

	this.instance_11 = new lib.ClipGroup_11();
	this.instance_11.setTransform(133.35,152.3,0.4799,0.4799,0,0,0,58.6,50);

	this.instance_12 = new lib.ClipGroup_12();
	this.instance_12.setTransform(120.9,133.95,0.4799,0.4799,0,0,0,83.5,130.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-225.2,-163,612.0999999999999,612.1);


(lib.logo_black = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_DS_vector
	this.instance = new lib.logo_DS_vector("synched",0);
	this.instance.setTransform(203.7,143.3,1,1,0,0,0,80.8,143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// DS AUTOMOBILES
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AcjCpQgdgdABg7IA5AAQABAhAOAQQAOARAhAAQAfAAAOgNQAMgNAAgcQABgcgLgQQgLgPgagHIgjgLQgvgPgUgYQgWgZAAgwQAAguAbgbQAdgdA0ABQA7AAAcAaQAcAbAAA4Ig6AAQgBgegMgOQgMgOgeAAQgaAAgNAMQgMALAAAZQAAAbALANQAMAMAcAKIAhAKQAwAOAUAZQATAbAAAzQAAAzgeAcQgeAcg4AAQg9AAgegdgAHbCmQghghAAg7IAAiRQAAg7AhgiQAhghA7AAQA6AAAhAhQAhAiAAA7IAACRQAAA7ghAhQghAgg6AAQg7AAghgggAIFh+QgRASgBAjIAACUQABAiARASQARATAhAAQAgAAARgTQARgSAAgiIAAiUQAAgkgRgRQgRgTggABQghgBgRATgAkKCmQghghABg7IAAiRQgBg7AhgiQAighA6AAQA6AAAiAhQAgAiAAA7IAACRQAAA7ggAhQgiAgg6AAQg6AAgigggAjfh+QgSASAAAjIAACUQAAAiASASQARATAgAAQAgAAASgTQAQgSABgiIAAiUQgBgkgQgRQgSgTggABQgggBgRATgAt2CoQgeggAAg6IAAkOIA6AAIAAESQAAAiAQAQQAPAOAdAAQAfAAAOgOQAPgQABgiIAAkSIA5AAIAAEOQAAA6gdAgQgeAfg7gBQg5ABgfgfgA6eCpQgdgdAAg7IA6AAQAAAhAOAQQAPARAhAAQAeAAAPgNQANgNgBgcQAAgcgKgQQgLgPgagHIgjgLQgvgPgVgYQgUgZgBgwQAAguAbgbQAdgdA1ABQA6AAAcAaQAcAbAAA4Ig6AAQgBgegMgOQgMgOgfAAQgZAAgMAMQgNALAAAZQAAAbAMANQALAMAcAKIAiAKQAvAOATAZQAUAbAAAzQAAAzgeAcQgeAcg4AAQg9AAgegdgAYADBIAAmBIDBAAIAAA1IiHAAIAABtIB4AAIAAAzIh4AAIAAB4ICOAAIAAA0gAT3DBIAAmBIA6AAIAAFNICDAAIAAA0gARSDBIAAmBIA6AAIAAGBgAMTDBIAAmBIB4AAQAwAAAaAaQAZAZAAAxQAAAggKAWQgMAYgWAKQA2ARAABLQgBAygaAcQgcAbgzAAgANNCPIA+AAQAYAAANgPQAMgOAAgdQAAgegMgRQgNgRgXAAIg/AAgANNgcIA9AAQAVAAALgPQALgOAAgbQAAgbgMgPQgMgQgWAAIg6AAgAEjDBIAAkkIhGC5IgyAAIhHi6IAAElIg2AAIAAmBIBHAAIBRDaIBQjaIBEAAIAAGBgAn/DBIAAlNIheAAIAAg0ID3AAIAAA0IhfAAIAAFNgAwbDBIgZhqIhsAAIgZBqIg5AAIBfmBIBUAAIBhGBgAxAAlIgqi0IgqC0IBUAAgA/xDBIAAmBIBuAAQA7AAAhAhQAhAgAAA7IAACLQAAA6ghAgQghAgg7AAgA+4COIA0AAQAigBARgSQARgSAAgiIAAiMQAAgjgRgSQgRgSgiAAIg0AAg");
	this.shape.setTransform(203.35,246.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_black, new cjs.Rectangle(0,0.3,406.8,266.09999999999997), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo_black();
	this.instance.setTransform(0,-0.4,0.5688,0.5688,0,0,0,0,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-58.2,-92.6,348.2,348.2), null);


(lib.img2Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("APOcnIAAAAIAAAAgAK8ZJQoom71oxEMAmpgdxQADAHiFckIiFcjQgBgEkRjag");
	mask.setTransform(181.7273,83.2);

	// img2
	this.img2 = new lib.img2_1();
	this.img2.name = "img2";
	this.img2.setTransform(99.95,81.25,0.6075,0.6075,0,0,0,155.2,140.9);

	var maskedShapeInstanceList = [this.img2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// msk (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("APOcnIAAAAIAAAAgAK8ZIQoom51oxEMAmpgdyQADAHiFckIiFcjQgBgEkRjbg");
	mask_1.setTransform(313.9273,188.3);

	// imgGuide
	this.imgGuide = new lib.img2_1();
	this.imgGuide.name = "imgGuide";
	this.imgGuide.setTransform(163,148.5,0.2065,0.2065,0,0,0,0.8,0.5);

	var maskedShapeInstanceList = [this.imgGuide];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.imgGuide).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Container, new cjs.Rectangle(58,-6.5,178.8,211.9), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1_zoom
	this.img1_zoom = new lib.img1_zoom();
	this.img1_zoom.name = "img1_zoom";
	this.img1_zoom.setTransform(358.6,676.2,1.019,1.019,0,0,0,368.1,675.5);

	this.timeline.addTween(cjs.Tween.get(this.img1_zoom).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.7,-12,1781.1000000000001,1358.1);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AwugHIQmwnIQ3Q3IwmQmg");
	mask.setTransform(107.075,99.1);

	// ctaTxt
	this.ctaTxt = new lib.ctaTxt();
	this.ctaTxt.name = "ctaTxt";
	this.ctaTxt.setTransform(107.15,97.7,1,1,0,0,0,93.8,10);

	var maskedShapeInstanceList = [this.ctaTxt];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaTxt).wait(1));

	// ctaBg
	this.ctaBg = new lib.ctaBg();
	this.ctaBg.name = "ctaBg";
	this.ctaBg.setTransform(106.5,98.25,1,1,0,0,0,88.7,21.8);

	var maskedShapeInstanceList = [this.ctaBg];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaBg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-93.7,-21.7,294.6,141.7), null);


(lib.txt4Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txtGuideEnd
	this.txtGuideEnd = new lib.txtGuide();
	this.txtGuideEnd.name = "txtGuideEnd";
	this.txtGuideEnd.setTransform(86.3,321.75,1,1,0,0,0,160,152.9);

	this.timeline.addTween(cjs.Tween.get(this.txtGuideEnd).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4/jRIRr0nMAgUAbJIxrUog");
	mask.setTransform(176.45,215.55);

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(246.2,179.25,1,1,0,0,0,-63.7,44.9);

	var maskedShapeInstanceList = [this.txt4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4Container, new cjs.Rectangle(-73.7,126.9,410.09999999999997,347.79999999999995), null);


(lib.txt1Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4/jRIRr0nMAgUAbJIxrUog");
	mask.setTransform(177.45,189.8);

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(115.35,107.8);

	var maskedShapeInstanceList = [this.txt1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1Container, new cjs.Rectangle(115.5,123.4,183.39999999999998,104.69999999999999), null);


(lib.logoContainer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// white
	this.white = new lib.white();
	this.white.name = "white";
	this.white.setTransform(-34.1,-59.6);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	// logo
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.setTransform(116,76.2,1,1,0,0,0,116,76.2);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logoContainer, new cjs.Rectangle(-58.2,-92.6,348.2,365.79999999999995), null);


(lib.logo_DS_WIP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_DS_vector
	this.instance = new lib.logo_DS_vector("synched",0);
	this.instance.setTransform(203.7,143.3,1,1,0,0,0,80.8,143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// DS AUTOMOBILES
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EA7eAFhQg8g9AAh9IB5AAQABBIAdAhQAeAiBEAAQBAAAAdgcQAcgbAAg5QAAg8gXgfQgWgfg3gQIhJgXQhigegqgzQgsg2AAhiQAAhgA4g5QA8g8BtAAQB5AAA7A3QA7A4AAB3Ih5AAQgChBgZgcQgagdg+AAQg2AAgaAYQgaAYAAAzQAAA3AYAdQAXAaA8ATIBFAVQBjAeAoA2QAqA4AABqQAABqg/A6Qg/A8h1AAQh/AAg+g9gAPdFZQhFhFAAh5IAAkxQAAh8BFhFQBEhGB7AAQB6AABEBGQBFBFAAB8IAAExQAAB5hFBFQhEBFh6AAQh7AAhEhFgAQ1kJQgkAnAABHIAAE3QAABIAkAmQAjAmBEAAQBDAAAkgmQAjgmAAhIIAAk3QAAhIgjgmQgkgmhDABQhEgBgjAmgAorFZQhFhFAAh5IAAkxQAAh8BFhFQBFhGB6AAQB6AABFBGQBEBFAAB8IAAExQAAB5hEBFQhFBFh6AAQh6AAhFhFgAnTkJQgkAnAABHIAAE3QAABIAkAmQAjAmBEAAQBDAAAkgmQAjgmAAhIIAAk3QAAhIgjgmQgkgmhDABQhEgBgjAmgA83FcQg+hAAAh6IAAozIB4AAIAAI8QAABGAhAhQAeAeA/AAQA/AAAegeQAgghAAhGIAAo8IB5AAIAAIzQAAB6g+BAQg/BCh5AAQh4AAhAhCgEg3LAFhQg8g9AAh9IB5AAQABBIAdAhQAeAiBEAAQBAAAAdgcQAcgbAAg5QAAg8gXgfQgWgfg3gQIhJgXQhigegqgzQgsg2AAhiQAAhgA4g5QA8g8BuAAQB5AAA6A3QA7A4AAB3Ih5AAQgChBgZgcQgagdg+AAQg2AAgaAYQgaAYAAAzQAAA3AYAdQAXAaA8ATIBFAVQBjAeAoA2QAqA4AABqQAABqg/A6Qg/A8h1AAQh/AAg+g9gEAyAAGSIAAsjIGTAAIAABuIkaAAIAADkID7AAIAABsIj7AAIAAD3IEnAAIAABugEApXAGSIAAsjIB5AAIAAK1IERAAIAABugEAkAAGSIAAsjIB5AAIAAMjgAZnGSIAAsjID6AAQBkAAA1A2QA1A1AABkQAABEgWAuQgXAygvAWQBxAjAACcQAABqg4A4Qg5A5hrAAgAbfEqICBAAQA0AAAagfQAbgeAAg7QAAhAgagjQgagjgyABIiEAAgAbfg7IB/AAQAtAAAXgeQAYgfAAg4QAAg5gaggQgZggguABIh6AAgAJeGSIAApjIiSGEIhoAAIiTmFIAAJkIhzAAIAAsjICUAAICpHHICnnHICOAAIAAMjgAwqGSIAAq2IjFAAIAAhtIIDAAIAABtIjGAAIAAK2gEgiPAGSIg0jdIjhAAIg0DdIh3AAIDFsjICxAAIDHMjgEgjbABLIhYl3IhZF3ICxAAgEhCNAGSIAAsjIDmAAQB6AABFBFQBFBEAAB5IAAEiQAAB4hFBEQhFBDh6AAgEhAWAEmIBtAAQBFAAAkgmQAkgmAAhHIAAkkQAAhIgkgmQgkgmhFAAIhtAAg");
	this.shape.setTransform(203.3718,246.5523,0.48,0.48);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_DS_WIP, new cjs.Rectangle(0,0.3,406.8,266.09999999999997), null);


(lib.img1Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask1Guide
	this.mask1Guide = new lib.mask1Guide();
	this.mask1Guide.name = "mask1Guide";
	this.mask1Guide.setTransform(261.8,-261.55,1.5551,1.5551,0,0,0,213,167);

	this.timeline.addTween(cjs.Tween.get(this.mask1Guide).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EBOLCIDMiafh/eIponyIITm2MCjmiHtMgArEVvIADFyg");
	mask.setTransform(11.15,350.05);

	// img1Guide2
	this.img1Guide2 = new lib.img1_1();
	this.img1Guide2.name = "img1Guide2";
	this.img1Guide2.setTransform(-0.6,-6.6,0.404,0.404);

	var maskedShapeInstanceList = [this.img1Guide2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1Guide2).wait(1));

	// msk (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EgzvgAPMAz/goVMAzgAoVMgz/Ao0g");
	mask_1.setTransform(106.425,-96.375);

	// img1Guide
	this.img1Guide = new lib.img1_1();
	this.img1Guide.name = "img1Guide";
	this.img1Guide.setTransform(210.35,112.3,0.2395,0.2395,0,0,0,889.3,686);

	var maskedShapeInstanceList = [this.img1Guide];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1Guide).wait(1));

	// msk (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EgzvgAPMAz/goVMAzgAoVMgz/Ao0g");
	mask_2.setTransform(261.775,24.225);

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(359.6,141.75,0.4135,0.4135,0,0,0,863.1,628);

	var maskedShapeInstanceList = [this.img1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Container, new cjs.Rectangle(-69.4,-521.2,662.4,1058.5), null);


(lib.logo_wraper2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo_DS_WIP();
	this.instance.setTransform(0,-0.15,0.28,0.28,0,0,0,0,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_wraper2, new cjs.Rectangle(-28.6,-45.6,171.29999999999998,171.4), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var logoContainer = this.logoContainer;	
				var logo = logoContainer.logo;
				var white = logoContainer.white;
			
			var img1Container = this.img1Container;
				var img1 = img1Container.img1;
					var img1_zoom = img1.img1_zoom;
				var img1_2 = img1Container.img1_2;
				var img1_2Guide = img1Container.img1_2Guide;
				
				var img1Guide = img1Container.img1Guide;
				var img1Guide2 = img1Container.img1Guide2;
				var mask1Guide = img1Container.mask1Guide;
					
			var img2Container = this.img2Container;
				var img2 = img2Container.img2;
				var imgGuide = img2Container.imgGuide;
			var img2ContainerGuide = this.img2ContainerGuide;
			
			
			var txt1Container = this.txt1Container;
				var txt1 = this.txt1Container.txt1;
					var txt1a = txt1.txt1a;
					var txt1b = txt1.txt1b;
					var txt1Line = txt1.txt1Line;
			
			var txt2Container = this.txt2Container;
				var txt2 = txt2Container.txt2;
				var txtGuide = txt2Container.txtGuide;
				
				
			var txt4Container = this.txt4Container;
				var txt4 = this.txt4Container.txt4;
					var txt4a = txt4.txt4a;
					var txt4b = txt4.txt4b;
					var txt4Line = txt4.txt4Line;
					var txtGuideEnd = txt4Container.txtGuideEnd;
			
				var img4 = this.img4;
				var img4Guide = this.img4Guide;
				
			var LegalFrame2 = this.LegalFrame2;
				
			var whiteTop = this.whiteTop;	
			var logo2 = this.logo2;	
			var txtBg = this.txtBg;
			var cta = this.cta;
				var ctaTxt = cta.ctaTxt;
				var ctaBg = cta.ctaBg;
		
			var whiteEnd = this.whiteEnd;
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf, options) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				//console.log(tf);
				//console.log(option);
				window.takeAutoShot(tf, options);
			}
		}
		
		/*********** dsLineScale **************/
		function dsLineScale(lineToScale, widestTxt){
			var childrenX = widestTxt.children[0].x;
			for (var i = 0; i < widestTxt.children.length; i++) {
				if ( widestTxt.children[i].x <= childrenX ){
				childrenX = widestTxt.children[i].x;
				var childrenXnext = widestTxt.children[i+1].x;		
				childrenX = childrenX-(childrenXnext - childrenX)/2;	
				}
			}	
			var lineWidth = Math.round((widestTxt.nominalBounds.width * widestTxt.scaleX - (childrenX * 2 * widestTxt.scaleX))/ 3.5);
			var lineScaleX = lineWidth / lineToScale.nominalBounds.width;
			lineToScale.scaleX = lineScaleX;
			console.log(lineWidth);
			}
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat: 0, repeatDelay:0});
		
		tl
			.to([img1Guide, img1_2Guide, img1Guide2, img4Guide, txtGuide, txtGuideEnd], 0,{alpha: 0}, 0)
		
			.add("frame1")
			.from(white, {y:"-="+white.nominalBounds.height, duration: .75, ease:Power1.easeOut}, "frame1+=.75")
			.add(autoShot, "frame1+=.1")
		
			.add("frame2")
			.from(img1.mask, 1, {x: mask1Guide.x, y: mask1Guide.y,/* scaleX: mask1Guide.scaleX, scaleY: mask1Guide.scaleY,*/ ease:Power2.easeOut},"frame2")
			.from(img1_zoom, 2, {scaleX: 1.05, scaleY: 1.05},"frame2+=.25")
			.from(logo2, .7, {alpha:0, ease: Power2.easeIn}, "frame2+=.25")
			.from(txt1.mask, .5, {x:"-="+w, ease:Power1.easeOut},"frame2")
			.add(autoShot)
		
			.add("frame3", "frame2+=2.5")
			.from(txtBg, 1, { x:"-="+w, ease:Power1.easeOut},"frame3")
			.from(txt2.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeOut},"frame3+=.4")
			.from(whiteTop, 1, {x:"+="+w, ease:Power1.easeOut},"frame3+=.55")
			.to(img1, 1, {x: img1Guide.x, y: img1Guide.y, scaleX: img1Guide.scaleX, scaleY: img1Guide.scaleY, ease:Power1.easeOut},"frame3+=.55")
			.from(img2.mask, 1, { x: imgGuide.mask.x, y: imgGuide.mask.y, scaleX: imgGuide.mask.scaleX, scaleY: imgGuide.mask.scaleY, ease:Power1.easeOut},"frame3+=.5")
			.to(img2, 2, {scaleX: .5, scaleY: .5, x:"-=20", y:"-=7", ease:Power1.easeOut},"frame3+=1")
			.to(img1.mask, 1, {x: img1Guide.mask.x, y: img1Guide.mask.y, ease:Power1.easeOut},"frame3+=2")
			.add(autoShot)
		
			.add("frame4", "frame3+=3")
			.to(txt1, .1, {alpha:0},"frame4")
			//.to(txt2, .5, {alpha:0, ease:Power2.easeOut},"frame4+=.5")
			/*.from(txt3.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeIn},"frame4+=1")
			.from(img3.mask, 1, { x: imgGuide.mask.x, y: imgGuide.mask.y, scaleX: imgGuide.mask.scaleX, scaleY: imgGuide.mask.scaleY, ease:Power1.easeOut},"frame4+=.5")
			.from(img3, 1, {x: img3Guide.x, y: img3Guide.y, scaleX: img3Guide.scaleX, scaleY: img3Guide.scaleY, ease:Power1.easeOut}, "frame4+=.5")
			.from(img3, 5, {onStart: moveInDirection, onStartParams:[img3, 180, 4.5, w/1.4]},"frame4+=1.5")*/
			.add(autoShot, "frame4+=3")
		
			.add("frame5", "frame4+=1")
			.from(img1_2, .1, {alpha:0},"frame5")
			.to([img2.mask, whiteTop], .7, {x:"+="+w, ease:Power1.easeIn},"frame5")
			.to([txtBg,txt2], .7, { x:"-="+txtBg.nominalBounds.width, ease:Power1.easeIn},"frame5")
			.to(img1.mask, .7, {y:"-="+h, ease:Power1.easeOut},"frame5")
			.to(img1, .7, {x: img1Guide2.x, y: img1Guide2.y, scaleX: img1Guide2.scaleX, scaleY: img1Guide2.scaleY, ease:Power1.easeInOut},"frame5")
			.from(img4, .3, {alpha:0, ease:Linear.easeOut}, "frame5+=.3")
			.to(img4, 1, {scaleX: .45 , scaleY: .45, ease:Linear.easeOut}, "frame5+=.5")
			.from(whiteEnd, .5, { x:"-="+w, ease:Power1.easeOut},"frame5+=2")
			.to(img4, .5, {x: img4Guide.x, y: img4Guide.y, scaleX: img4Guide.scaleX, scaleY: img4Guide.scaleY, ease:Power1.easeOut}, "frame5+=2")
			.from(txt4.mask, .5, {x: txtGuideEnd.x, y: txtGuideEnd.y, scaleX: txtGuideEnd.scaleX, scaleY: txtGuideEnd.scaleY, ease:Linear.easeOut},"frame5+=2.2")
			.from(ctaBg.mask, 1, {scaleX: 0, scaleY: 0, ease:Power1.easeInOut},"frame5+=2.8")
			.from(ctaTxt, .3, {alpha:0, ease:Power1.easeIn},"frame5+=3.5")
			.call(autoShot, [true] ,"+=1")
		
		
		
		function moveInDirection(target, directionInDegrees, t, distance) {
		    var directionInRadians = directionInDegrees * (Math.PI / 180);
		
		    var defaultDistanceX = target.nominalBounds.width * target.scaleX - w;
		    var defaultDistanceY = target.nominalBounds.height * target.scaleY - h;
		
		    var distanceX = distance || defaultDistanceX;
		    var distanceY = distance || defaultDistanceY;
		
		    var xMove = distanceX * Math.cos(directionInRadians);
		    var yMove = distanceY * Math.sin(directionInRadians);
		
		    gsap.to(target, {x: `+=${xMove}`, y: `+=${yMove}`, duration: t, ease:Power1.easeInOut});
		}
		
		
		function ZoomIn(target, scale, t) {
			gsap.fromTo(target, {scaleX:0.9, scaleY:0.9} , {scaleX:scale, scaleY:scale, ease:Power2.easeOut, overwrite:0, rotation:0.001, delay:0, duration: t})
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo2
	this.logo2 = new lib.logo_wraper2();
	this.logo2.name = "logo2";
	this.logo2.setTransform(104.45,11.95,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.logo2).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(68.25,221.3,0.65,0.65,0,0,0,108.1,96.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt4
	this.txt4Container = new lib.txt4Container();
	this.txt4Container.name = "txt4Container";
	this.txt4Container.setTransform(98.5,161.65,0.7321,0.7321,0,0,0,240.1,180.6);

	this.timeline.addTween(cjs.Tween.get(this.txt4Container).wait(1));

	// txt2
	this.txt2Container = new lib.txt2Container();
	this.txt2Container.name = "txt2Container";
	this.txt2Container.setTransform(6.3,182.4,0.7664,0.7664);

	this.timeline.addTween(cjs.Tween.get(this.txt2Container).wait(1));

	// txtBg
	this.txtBg = new lib.txtBg();
	this.txtBg.name = "txtBg";
	this.txtBg.setTransform(-24.9,58.35,0.9999,0.9999,-1.288,0,0,-0.4,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtBg).wait(1));

	// txt1
	this.txt1Container = new lib.txt1Container();
	this.txt1Container.name = "txt1Container";
	this.txt1Container.setTransform(76.3,201.3,0.766,0.766,0,0,0,207.4,176.4);

	this.timeline.addTween(cjs.Tween.get(this.txt1Container).wait(1));

	// img2
	this.img2Container = new lib.img2Container();
	this.img2Container.name = "img2Container";
	this.img2Container.setTransform(0,0,1.7634,1.7634);

	this.timeline.addTween(cjs.Tween.get(this.img2Container).wait(1));

	// whiteTop
	this.whiteTop = new lib.whiteTop();
	this.whiteTop.name = "whiteTop";
	this.whiteTop.setTransform(322.6,-196.85,1.4692,1.4692,0.8676,0,0,0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.whiteTop).wait(1));

	// img1
	this.img1Container = new lib.img1Container();
	this.img1Container.name = "img1Container";
	this.img1Container.setTransform(159.9,291,1,1,0,0,0,159.9,291);

	this.timeline.addTween(cjs.Tween.get(this.img1Container).wait(1));

	// whiteEnd
	this.whiteEnd = new lib.whiteEnd();
	this.whiteEnd.name = "whiteEnd";
	this.whiteEnd.setTransform(62.85,220.75,1,1,0,0,0,253.6,267.9);

	this.timeline.addTween(cjs.Tween.get(this.whiteEnd).wait(1));

	// img4Guide
	this.img4Guide = new lib.img4Guide();
	this.img4Guide.name = "img4Guide";
	this.img4Guide.setTransform(211.6,128.4,0.4,0.4,0,0,0,217.2,139.8);

	this.timeline.addTween(cjs.Tween.get(this.img4Guide).wait(1));

	// img4
	this.img4 = new lib.img4();
	this.img4.name = "img4";
	this.img4.setTransform(149.35,143.8,0.4,0.4,0,0,0,272.5,175.4);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// logo
	this.logoContainer = new lib.logoContainer();
	this.logoContainer.name = "logoContainer";
	this.logoContainer.setTransform(67.8,67.25,0.7099,0.7099,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.logoContainer).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-389,-432.3,1160.8,1689.7);
// library properties:
lib.properties = {
	id: '10544D5684BA4F528969206F0477CF68',
	width: 300,
	height: 250,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"_300x250_3.jpg", id:"_300x250_3"},
		{src:"img1.jpg", id:"img1"},
		{src:"img2.jpg", id:"img2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['10544D5684BA4F528969206F0477CF68'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;