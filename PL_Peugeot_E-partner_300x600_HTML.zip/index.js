(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_1", frames: [[0,0,393,404],[395,0,31,37]]},
		{name:"index_atlas_NP_1", frames: [[0,0,600,1200],[602,0,600,1200],[1204,0,600,1200],[1806,0,600,1200]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bitmap1 = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.icon = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.img1 = function() {
	this.initialize(ss["index_atlas_NP_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.img2 = function() {
	this.initialize(ss["index_atlas_NP_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.img3 = function() {
	this.initialize(ss["index_atlas_NP_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.img4 = function() {
	this.initialize(ss["index_atlas_NP_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt1_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAsBYIghg4IgEAAIg5AAIAAA4IgYAAIAAivIBRAAQAlAAAPANQAQAOAAAhQAAAZgJANQgJANgUAFIAkA7gAgyAJIA5AAQAYAAAJgHQAKgHAAgWQAAgWgKgIQgJgHgYAAIg5AAg");
	this.shape.setTransform(98.475,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBZQgVgWAAgwQAAgwAVgVQAVgWAtAAQAuAAAVAWQAVAVAAAwQAAAwgVAWQgVAVguAAQgtAAgVgVgAgwghQgOAPAAAlQAAAlAOAPQAPAQAhAAQAiAAAOgQQAPgPAAglQAAglgPgPQgOgQgiAAQghAAgPAQgAgMhPIAZgeIAaAAIgcAeg");
	this.shape_1.setTransform(78.05,14.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhJBYIAAivIBUAAQAeAAAOAKQAOALAAAZQAAAjgbAGQAgAGAAAjQAAAbgPAKQgPAKgiAAgAgwBBIA6AAQAVAAAJgFQAJgGAAgQQAAgQgJgGQgIgFgTAAIg9AAgAgwgLIA7AAQASAAAHgGQAIgFAAgQQAAgPgIgGQgHgFgTAAIg6AAg");
	this.shape_2.setTransform(58.775,16.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMBYIAAhFIhIhqIAdAAIA3BTIA4hTIAdAAIhJBqIAABFg");
	this.shape_3.setTransform(40.05,16.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAtBYIgriZIgDAAIgrCZIgsAAIgxivIAaAAIArCZIAEAAIAqiZIAtAAIAqCZIAFAAIAqiZIAaAAIgxCvg");
	this.shape_4.setTransform(16.625,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1_5, new cjs.Rectangle(0,0,133.2,33.6), null);


(lib.txt1_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBYIAAhFIhIhqIAdAAIA2BTIA3hTIAdAAIhIBqIAABFg");
	this.shape.setTransform(89.6,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAsBYIghg4IgEAAIg5AAIAAA4IgYAAIAAivIBRAAQAlAAAPANQAQAOAAAhQAAAZgJANQgJANgUAFIAkA7gAgyAJIA5AAQAYAAAJgHQAKgHAAgWQAAgWgKgIQgJgHgYAAIg5AAg");
	this.shape_1.setTransform(71.675,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhJBYIAAivIBUAAQAeAAAOAKQAOALAAAZQAAAjgbAGQAgAGAAAjQAAAbgPAKQgPAKgiAAgAgwBBIA6AAQAVAAAJgFQAJgGAAgQQAAgQgJgGQgIgFgTAAIg9AAgAgwgLIA7AAQASAAAHgGQAIgFAAgQQAAgPgIgGQgHgFgTAAIg6AAg");
	this.shape_2.setTransform(52.675,16.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhCBGQgVgWAAgwQAAgvAVgWQAVgWAtAAQAuAAAVAWQAVAWAAAvQAAAwgVAWQgVAWguAAQgtAAgVgWgAgwg0QgOAQAAAkQAAAlAOAQQAPAPAhAAQAiAAAPgPQAOgQAAglQAAgkgOgQQgPgPgiAAQghAAgPAPg");
	this.shape_3.setTransform(32.4,16.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhPBYIAAivIBJAAQAtAAAUAVQAVAVAAAtQAAAvgVAVQgUAUgtAAgAg2BBIAwAAQAhAAAOgPQAOgPAAgjQAAgigOgPQgOgPghAAIgwAAg");
	this.shape_4.setTransform(12.525,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1_4, new cjs.Rectangle(0,0,121.5,33.6), null);


(lib.txt1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCBGQgVgWAAgwQAAgvAVgWQAVgWAtAAQAuAAAVAWQAVAWAAAvQAAAwgVAWQgVAWguAAQgtAAgVgWgAgvg0QgPAQAAAkQAAAlAPAQQAOAPAhAAQAiAAAOgPQAPgQAAglQAAgkgPgQQgOgPgiAAQghAAgOAPg");
	this.shape.setTransform(29.75,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLBYIAAiYIhDAAIAAgXICdAAIAAAXIhDAAIAACYg");
	this.shape_1.setTransform(10.725,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1_3, new cjs.Rectangle(0,0,53,33.6), null);


(lib.txt1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBYIAAiYIhDAAIAAgXICdAAIAAAXIhDAAIAACYg");
	this.shape.setTransform(124.575,16.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBGQgVgWAAgwQAAgvAVgWQAVgWAtAAQAuAAAVAWQAVAWAAAvQAAAwgVAWQgVAWguAAQgtAAgVgWgAgwg0QgOAQAAAkQAAAlAOAQQAPAPAhAAQAiAAAOgPQAPgQAAglQAAgkgPgQQgOgPgiAAQghAAgPAPg");
	this.shape_1.setTransform(105.5,16.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABYIAAivICBAAIAAAXIhoAAIAAA1IBgAAIAAAWIhgAAIAAA2IBoAAIAAAXg");
	this.shape_2.setTransform(86.95,16.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhABGQgVgWAAgwQAAgvAVgWQAUgWAtAAQAkAAAUAOQAUANAHAdIgaAAQgFgRgPgIQgNgHgYAAQghAAgOAPQgOAQAAAkQAAAlAOAQQAPAPAiAAQAeAAAOgKQAOgLAAgZIAAgFIg9AAIAAgWIBWAAIAAAcQAABFhTAAQguAAgVgWg");
	this.shape_3.setTransform(67.875,16.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag7BKQgSgQAAgmIAAhtIAZAAIAABtQAAAZAMALQAMAKAcAAQAeAAALgKQANgLAAgZIAAhtIAYAAIAABtQAAAmgSAQQgSAQgqAAQgpAAgSgQg");
	this.shape_4.setTransform(47.775,17);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag/BYIAAivICAAAIAAAXIhoAAIAAA1IBgAAIAAAWIhgAAIAAA2IBoAAIAAAXg");
	this.shape_5.setTransform(29.55,16.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKBYIAAivIBRAAQAlAAAPANQAQAOAAAiQAAAhgQAOQgPAOglAAIg5AAIAAA1gAgyAMIA5AAQAYAAAJgIQAKgHAAgXQAAgWgKgIQgJgIgYAAIg5AAg");
	this.shape_6.setTransform(12.075,16.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1_2, new cjs.Rectangle(0,0,183,33.6), null);


(lib.txt1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBYIAAhFIhIhqIAcAAIA3BTIA3hTIAeAAIhJBqIAABFg");
	this.shape.setTransform(255.85,-66.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhMBYIAAgWIBziCIhsAAIAAgXICLAAIAAAXIhzCBIB6AAIAAAXg");
	this.shape_1.setTransform(238.5,-66.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9BGQgVgWAAgwQAAgvAVgWQAUgWArAAQAiAAAUAOQAUANAHAdIgaAAQgGgRgNgIQgNgHgXAAQggAAgNAPQgOAQAAAkQAAAlAOAQQANAPAgAAQAsAAALggIAaAAQgHAdgUANQgUAOgiAAQgrAAgUgWg");
	this.shape_2.setTransform(220.425,-66.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAtBYIgriZIgDAAIgrCZIgsAAIgxivIAaAAIArCZIAEAAIAqiZIAtAAIAqCZIAFAAIAqiZIAaAAIgxCvg");
	this.shape_3.setTransform(195.975,-66.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA/BYIgTgyIhXAAIgTAyIgaAAIBFivIAnAAIBFCvgAAjAPIgghSIgFAAIggBSIBFAAg");
	this.shape_4.setTransform(171.825,-66.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgLBYIAAiYIhDAAIAAgXICdAAIAAAXIhDAAIAACYg");
	this.shape_5.setTransform(153.625,-66.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhFBTIAAgZQAhAKAhAAQAcAAALgGQALgGAAgPQAAgPgJgGQgJgFgdgFQgrgEgNgKQgPgKAAgbQAAgaARgLQASgNAnAAQAdAAAfAIIAAAYQghgIgbAAQgdAAgKAGQgJAFAAAOQAAAOAIAFQAJAFAdAFQAqAEAPAKQAOALAAAcQAAAcgSAMQgRAMgoAAQgiAAgggJg");
	this.shape_6.setTransform(135.95,-66.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhCBGQgVgWAAgwQAAgvAVgWQAVgWAtAAQAuAAAVAWQAVAWAAAvQAAAwgVAWQgVAWguAAQgtAAgVgWgAgwg0QgOAQAAAkQAAAlAOAQQAPAPAhAAQAiAAAOgPQAPgQAAglQAAgkgPgQQgOgPgiAAQghAAgPAPg");
	this.shape_7.setTransform(116.4,-66.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhPBYIAAivIBJAAQAtAAAUAVQAVAVAAAtQAAAvgVAVQgUAUgtAAgAg2BBIAwAAQAhAAAOgPQAOgPAAgjQAAgigOgPQgOgPghAAIgwAAg");
	this.shape_8.setTransform(96.525,-66.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1_1, new cjs.Rectangle(84,-83,198,33.6), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bitmap1();
	this.instance.setTransform(0,0,0.75,0.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,294.8,303), null);


(lib.img4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img4();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4_1, new cjs.Rectangle(0,0,300,600), null);


(lib.img3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img3();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3_1, new cjs.Rectangle(0,0,600,1200), null);


(lib.img2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2_1, new cjs.Rectangle(0,0,600,1200), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();
	this.instance.setTransform(300,598);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_1, new cjs.Rectangle(300,598,600,1200), null);


(lib.headline = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// subtext
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAwIAAgmIgog5IAPAAIAeAuIAfguIAPAAIgoA5IAAAmg");
	this.shape.setTransform(190.8,34.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAaAwIg3hNIAABNIgNAAIAAhfIARAAIA3BNIAAhNIANAAIAABfg");
	this.shape_1.setTransform(180.3,34.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpAwIAAgMIA+hGIg6AAIAAgNIBLAAIAAANIg+BGIBCAAIAAAMg");
	this.shape_2.setTransform(169.95,34.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghAmQgLgMAAgaQAAgZALgMQALgMAXAAQASAAAMAHQALAHADAQIgOAAQgDgJgHgFQgIgDgMAAQgQAAgIAIQgHAJAAATQAAAUAHAIQAIAJAQAAQAZAAAFgSIAOAAQgDAQgLAIQgMAHgSAAQgXAAgLgMg");
	this.shape_3.setTransform(160.1,34.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgFAwIAAgmIgog5IAPAAIAeAuIAfguIAPAAIgoA5IAAAmg");
	this.shape_4.setTransform(149.95,34.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAYAwIgSgeIgCAAIgfAAIAAAeIgNAAIAAhfIAsAAQAUAAAIAHQAJAHAAASQAAAPgFAGQgFAHgKADIATAggAgbAFIAfAAQANAAAFgEQAGgDgBgNQABgLgGgFQgFgEgNABIgfAAg");
	this.shape_5.setTransform(140.2,34.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGAwIAAhSIgkAAIAAgNIBVAAIAAANIgkAAIAABSg");
	this.shape_6.setTransform(130,34.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAWAwIgwgvIAAAvIgNAAIAAhfIANAAIAAApIAwgpIARAAIgzAtIA0Ayg");
	this.shape_7.setTransform(120.95,34.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgiAwIAAhfIBFAAIAAANIg4AAIAAAcIA0AAIAAAMIg0AAIAAAeIA4AAIAAAMg");
	this.shape_8.setTransform(111.125,34.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgfAwIAAhfIANAAIAABTIAyAAIAAAMg");
	this.shape_9.setTransform(102.6,34.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgiAwIAAhfIBFAAIAAANIg4AAIAAAcIA0AAIAAAMIg0AAIAAAeIA4AAIAAAMg");
	this.shape_10.setTransform(93.575,34.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgGAwIAAhfIAMAAIAABfg");
	this.shape_11.setTransform(83,34.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAZAwIg2hNIAABNIgNAAIAAhfIARAAIA3BNIAAhNIANAAIAABfg");
	this.shape_12.setTransform(75.25,34.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgYAwIAAgmIgOAHIAAgOIAOgFIAAgtIANAAIAAAnIAYgMIAAANIgYALIAAAgIAyAAIAAAMg");
	this.shape_13.setTransform(65.25,34.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgiAwIAAhfIBFAAIAAANIg4AAIAAAcIA0AAIAAAMIg0AAIAAAeIA4AAIAAAMg");
	this.shape_14.setTransform(56.925,34.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgoAwIAAhfIAsAAQAUAAAIAHQAJAIAAASQAAASgJAHQgIAIgUgBIgfAAIAAAegAgbAGIAfAAQANAAAFgEQAGgEgBgMQABgMgGgFQgFgEgNABIgfAAg");
	this.shape_15.setTransform(47.4,34.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAZAwIgYhTIgBAAIgYBTIgYAAIgahfIAOAAIAXBTIADAAIAXhTIAXAAIAXBTIADAAIAXhTIAOAAIgaBfg");
	this.shape_16.setTransform(30.325,34.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// headline
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAbBIIgUgnIgoAAIAAAnIgjAAIAAiPIBMAAQAhAAAOAMQAOAMAAAcQAAAmgbAJIAaAsgAghAEIApAAQAOAAAFgEQAHgFgBgNQABgOgHgFQgFgFgOAAIgpAAg");
	this.shape_17.setTransform(214.55,14.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag6BIIAAiPIB1AAIAAAeIhSAAIAAAaIBLAAIAAAeIhLAAIAAAbIBSAAIAAAeg");
	this.shape_18.setTransform(198.9,14.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAdBIIhChfIAABfIgjAAIAAiPIArAAIBDBhIAAhhIAjAAIAACPg");
	this.shape_19.setTransform(182.325,14.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgRBIIAAhxIg0AAIAAgeICLAAIAAAeIg0AAIAABxg");
	this.shape_20.setTransform(165.9,14.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAcBIIgVgnIgoAAIAAAnIgjAAIAAiPIBNAAQAgAAAOAMQAOAMAAAcQAAAmgbAJIAZAsgAghAEIApAAQAOAAAGgEQAFgFAAgNQAAgOgFgFQgGgFgOAAIgpAAg");
	this.shape_21.setTransform(150.4,14.125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAsBIIgLggIhAAAIgMAgIgmAAIA2iPIA3AAIA1CPgAAWAJIgUgzIgEAAIgTAzIArAAg");
	this.shape_22.setTransform(133.35,14.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhEBIIAAiPIBMAAQAhAAAOAMQAOAMAAAdQAAAbgOANQgOAMghAAIgpAAIAAAmgAghAFIApAAQAOAAAGgFQAFgEAAgOQAAgOgFgFQgGgFgOAAIgpAAg");
	this.shape_23.setTransform(117.45,14.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgdAOIAAgbIA7AAIAAAbg");
	this.shape_24.setTransform(105.475,16.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ag7BIIAAiPIB3AAIAAAeIhUAAIAAAaIBNAAIAAAeIhNAAIAAAbIBUAAIAAAeg");
	this.shape_25.setTransform(95,14.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgQBIIAAg4Ig9hXIApAAIAlA4IAmg4IAnAAIg8BXIAAA4g");
	this.shape_26.setTransform(74,14.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAaBIIgYhxIgDAAIgZBxIg7AAIgjiPIAlAAIAbByIADAAIAYhyIA7AAIAXByIADAAIAbhyIAmAAIgjCPg");
	this.shape_27.setTransform(53.45,14.125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag7A5QgSgSAAgnQAAgnASgRQASgSApAAQAqAAASASQASARAAAnQAAAngSASQgSASgqAAQgpAAgSgSgAghghQgJAJAAAYQAAAYAJAKQAKAKAXAAQAYAAAKgKQAJgKAAgYQAAgYgJgJQgKgKgYAAQgXAAgKAKg");
	this.shape_28.setTransform(32.175,14.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAdBIIhChfIAABfIgjAAIAAiPIArAAIBDBhIAAhhIAjAAIAACPg");
	this.shape_29.setTransform(14.475,14.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.headline, new cjs.Rectangle(0,0,228.1,44.2), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.instance = new lib.icon();
	this.instance.setTransform(41,9,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgzBFIAAgXIBAhAIg9AAIAAgYIBhAAIAAAYIhABAIBDAAIAAAXgAgMgxIAQgTIAdAAIgUATg");
	this.shape.setTransform(161.3,19.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag3A4IAAhvIAzAAQAfAAAPANQAOAOAAAcQAAAegOANQgOANggAAgAgcAgIAYAAQASAAAHgHQAHgIAAgRQAAgRgHgHQgHgIgSABIgYAAg");
	this.shape_1.setTransform(149.325,20.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAUA4IgThYIgBAAIgUBYIguAAIgbhvIAdAAIAVBYIACAAIAShYIAuAAIASBYIADAAIAUhYIAeAAIgcBvg");
	this.shape_2.setTransform(132.7,20.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAiA4IgIgZIgyAAIgJAZIgdAAIAphvIArAAIAqBvgAARAHIgPgoIgEAAIgOAoIAhAAg");
	this.shape_3.setTransform(116.3,20.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAVA4IgPgeIggAAIAAAeIgbAAIAAhvIA8AAQAZAAALAJQALAKAAAVQAAAdgVAIIAUAigAgaADIAgAAQALAAAEgDQAFgDAAgLQAAgLgFgEQgEgEgLAAIggAAg");
	this.shape_4.setTransform(103.55,20.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag1A4IAAhvIA7AAQAaAAALAKQALAJAAAWQAAAVgLAKQgLAJgaAAIggAAIAAAegAgaAEIAgAAQALgBAEgDQAFgDAAgLQAAgLgFgEQgEgEgLAAIggAAg");
	this.shape_5.setTransform(91.1,20.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgxA0IAAgYQAeAGASABQAOAAAFgCQAFgCAAgHQAAgGgEgCQgFgDgPgCQgcgCgKgHQgLgGAAgSQAAgTAMgHQAMgJAbAAQAWAAAWAEIAAAZQgZgGgSAAQgPAAgEACQgFACAAAGQAAAGAEACIAUAEQAcACAKAHQALAHAAASQAAATgMAJQgMAIgcABQgYAAgYgHg");
	this.shape_6.setTransform(78.475,20.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bgc
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AwZDIIAAmPMAgzAAAIAAGPg");
	this.shape_7.setTransform(105,20);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,210,40), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1_5
	this.txt1_5 = new lib.txt1_5();
	this.txt1_5.name = "txt1_5";
	this.txt1_5.setTransform(163,200,1,1,0,0,0,66.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt1_5).wait(1));

	// txt1_4
	this.txt1_4 = new lib.txt1_4();
	this.txt1_4.name = "txt1_4";
	this.txt1_4.setTransform(201.2,173.8,1,1,0,0,0,60.8,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt1_4).wait(1));

	// txt1_3
	this.txt1_3 = new lib.txt1_3();
	this.txt1_3.name = "txt1_3";
	this.txt1_3.setTransform(144.75,173.3,1,1,0,0,0,48.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt1_3).wait(1));

	// txt1_2
	this.txt1_2 = new lib.txt1_2();
	this.txt1_2.name = "txt1_2";
	this.txt1_2.setTransform(185.9,147.3,1,1,0,0,0,91.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt1_2).wait(1));

	// txt1_1
	this.txt1_1 = new lib.txt1_1();
	this.txt1_1.name = "txt1_1";
	this.txt1_1.setTransform(52.9,203.3,1,1,0,0,0,42.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.txt1_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(94.4,103.5,197.99999999999997,113.30000000000001), null);


(lib.group2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.setTransform(150,87,0.35,0.35,0,0,0,147.8,152.2);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// headline
	this.headline = new lib.headline();
	this.headline.name = "headline";
	this.headline.setTransform(151.05,163.5,1.15,1.15,0,0,0,115.4,22.2);

	this.timeline.addTween(cjs.Tween.get(this.headline).wait(1));

	// offer
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAwA+IAAhkIglBJIgUAAIgmhJIAABkIgRAAIAAh7IAZAAIAnBNIABAAIAnhNIAZAAIAAB7g");
	this.shape.setTransform(274.425,473.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAfA+IgXgoIgDAAIgoAAIAAAoIgRAAIAAh7IA5AAQAZAAAMAKQALAJAAAXQAAASgHAJQgGAJgOADIAZAqgAgjAGIAoAAQAQAAAHgFQAHgFAAgPQAAgPgHgFQgHgGgQAAIgoAAg");
	this.shape_1.setTransform(259.8,473.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgIA+IAAh7IAQAAIAAB7g");
	this.shape_2.setTransform(250.1,473.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgrA+IAAh7IBXAAIAAAQIhGAAIAAAoIBBAAIAAAPIhBAAIAAA0g");
	this.shape_3.setTransform(242.225,473.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAsA+IgOgjIg8AAIgNAjIgSAAIAwh7IAbAAIAwB7gAAYALIgWg6IgDAAIgXA6IAwAAg");
	this.shape_4.setTransform(224.775,473.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgoA+IAAh7IARAAIAABrIBAAAIAAAQg");
	this.shape_5.setTransform(213.4,473.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag3A+IAAh7IAzAAQAfAAAOAPQAPAPAAAfQAAAhgPAOQgOAPgfAAgAgmAuIAiAAQAXAAAKgLQAJgKAAgZQAAgYgJgKQgKgLgXAAIgiAAg");
	this.shape_6.setTransform(200.875,473.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARBHQgJgIAAgSQAAgSAJgIQAJgHAUAAQAVAAAJAHQAJAIAAASQAAASgJAIQgJAHgVAAQgUAAgJgHgAAlAjQgCACgBAIQABAHACADQADAEAGAAQAHAAADgEQACgCAAgIQAAgIgCgCQgDgDgHAAQgGAAgDADgAhMBLIB4iVIAhAAIh3CVgAhLgSQgJgJAAgRQAAgSAJgIQAKgHATAAQAVAAAJAHQAJAIAAASQAAARgJAJQgJAHgVAAQgTAAgKgHgAg3g2QgCACAAAIQAAAHACADQADAEAGAAQAIAAACgEQACgDAAgHQAAgIgCgCQgCgDgIAAQgGAAgDADg");
	this.shape_7.setTransform(179,472.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AALBLIAAhyIgqAVIgPgbIA6gdIAjAAIAACVg");
	this.shape_8.setTransform(163.45,472.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgwA7QgPgSAAgpQAAgoAPgSQAPgTAhAAQAiAAAPATQAPASAAAoQAAApgPASQgPATgiAAQghAAgPgTgAgVglQgGAKAAAbQAAAcAGAKQAGAKAPAAQAQAAAGgKQAGgKAAgcQAAgbgGgKQgGgKgQAAQgPAAgGAKg");
	this.shape_9.setTransform(151.475,472.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALBLIAAhyIgqAVIgPgbIA6gdIAjAAIAACVg");
	this.shape_10.setTransform(137.8,472.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgtASQAAgtArAAQAOAAASAHIAAgqIAQAAIAAB7IgLAAIgDgGQgUAIgOAAQgrAAAAgtgAgVgFQgHAGAAARQAAAQAHAHQAHAHAPAAQAOAAAPgHIAAgvQgOgGgPAAQgPAAgHAHg");
	this.shape_11.setTransform(121.675,473.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgjAjQgMgLAAgYQAAgXAMgLQAMgLAXAAQAYAAAMALQAMALAAAXQAAAYgMALQgMAKgYAAQgXAAgMgKgAgWgWQgIAHAAAPQAAAQAIAIQAHAGAPABQAQgBAIgGQAHgIAAgQQAAgPgHgHQgIgIgQABQgPgBgHAIg");
	this.shape_12.setTransform(110.375,475.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgsAxQgPgPAAgiQAAghAPgPQAOgPAfAAQAZAAANAJQAPAJAEAVIgSAAQgDgMgKgGQgKgFgQAAQgXAAgKALQgKALAAAZQAAAaAKALQAKALAYAAQAVAAAJgIQALgHAAgRIAAgEIgrAAIAAgPIA8AAIAAATQAAAwg6AAQggAAgOgPg");
	this.shape_13.setTransform(93,473.575);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAhA+IhGhjIAABjIgRAAIAAh7IAVAAIBHBkIAAhkIASAAIAAB7g");
	this.shape_14.setTransform(78.6,473.575);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgIA+IAAh7IAQAAIAAB7g");
	this.shape_15.setTransform(68.65,473.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgwA6IAAgRQAXAGAXAAQAUAAAHgEQAIgEAAgKQAAgLgHgEQgGgEgUgDQgegDgJgGQgLgIABgSQgBgSAMgJQANgIAbAAQAVAAAVAFIAAARQgXgFgTAAQgTAAgIADQgHAEAAAKQAAAKAGADQAGAEAVADQAdADALAHQAKAIAAATQAAATgNAJQgMAIgcAAQgYAAgWgGg");
	this.shape_16.setTransform(59.75,473.575);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAsA+IgOgjIg8AAIgNAjIgSAAIAwh7IAbAAIAwB7gAAYALIgWg6IgDAAIgXA6IAwAAg");
	this.shape_17.setTransform(46.675,473.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgsA+IAAh7IBZAAIAAAQIhIAAIAAAmIBDAAIAAAPIhDAAIAAAmIBIAAIAAAQg");
	this.shape_18.setTransform(34.275,473.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgoA+IAAh7IARAAIAABrIBAAAIAAAQg");
	this.shape_19.setTransform(23.3,473.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(150.15,542.15,0.85,0.8496,0,0,0,105.1,20.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// img4
	this.instance = new lib.img4_1();
	this.instance.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.group2, new cjs.Rectangle(0,0,300,600), null);


(lib.group1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(309.8,662.1,1.5999,1.5999,0,0,0,193.5,160.2);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(149.15,300,0.5,0.5,0,0,0,300,600);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.group1, new cjs.Rectangle(149.2,299,318.8,600), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var group1 = this.group1;
			var img1 = group1.img1;
			var txt1 = group1.txt1;
			var txt1_1 = group1.txt1.txt1_1;
			var txt1_2 = group1.txt1.txt1_2;
			var txt1_3 = group1.txt1.txt1_3;
			var txt1_4 = group1.txt1.txt1_4;
			var txt1_5 = group1.txt1.txt1_5;
			var txt1_6 = group1.txt1.txt1_6;
			var elements = [txt1_1, txt1_2, txt1_3, txt1_4, txt1_5, txt1_6];
		
		
		var group2 = this.group2;
			var img4 = group2.img4;
			var logo = group2.logo;
			var cta = group2.cta;
			
		var img2 = this.img2;
		var img3 = this.img3;	
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf);
			}
		}
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat:0, repeatDelay:0,ease:Power2.easeOut});
		
		
		tl
				
			.add("frame1")
			.staggerFrom(elements, .1, {alpha:0}, .3, "frame1+=.7")
			.add(autoShot)
			
			.add("frame2", "frame1+=4")
			.from(img2, {duration: .5, y:"+="+h}, "frame2")
			.add(autoShot)
		
			.add("frame3", "frame2+=2")
			.from(img3, {duration:.01, alpha:0}, "frame3")
			.add(autoShot)
		
			.add("frame4", "frame3+=2")
			.from([group2], {duration:.5, y:"+="+h}, "frame4")
			.call(autoShot, [true],"+=0")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// group2
	this.group2 = new lib.group2();
	this.group2.name = "group2";
	this.group2.setTransform(150.35,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.group2).wait(1));

	// img3
	this.img3 = new lib.img3_1();
	this.img3.name = "img3";
	this.img3.setTransform(147,286,0.5,0.5,0,0,0,294,572);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// img2
	this.img2 = new lib.img2_1();
	this.img2.name = "img2";
	this.img2.setTransform(150,300,0.5,0.5,0,0,0,300,600);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// group1
	this.group1 = new lib.group1();
	this.group1.name = "group1";
	this.group1.setTransform(150,300,1,1,0,0,0,300,600);

	this.timeline.addTween(cjs.Tween.get(this.group1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(149.2,299,168.90000000000003,301);
// library properties:
lib.properties = {
	id: '336565F901BB4B639513018BB676A918',
	width: 300,
	height: 600,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"index_atlas_P_1.png", id:"index_atlas_P_1"},
		{src:"index_atlas_NP_1.jpg", id:"index_atlas_NP_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['336565F901BB4B639513018BB676A918'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;