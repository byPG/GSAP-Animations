(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._3 = function() {
	this.initialize(img._3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,888,837);


(lib.GPT = function() {
	this.initialize(img.GPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,700,704);


(lib.img1 = function() {
	this.initialize(img.img1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,971,818);


(lib.img2 = function() {
	this.initialize(img.img2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,243);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteTop = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgjmADcMAbNgiDMAsAAedMglJAeyg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteTop, new cjs.Rectangle(-227.8,-196,455.70000000000005,392), null);


(lib.txtGuide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("A4/jRIRr0nMAgTAbJIxpUog");
	this.shape.setTransform(159.95,152.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtGuide, new cjs.Rectangle(0,0,319.9,305.8), null);


(lib.txtBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2B2B").s().p("EgZ2Ap0MgA9hVZMAyqApxIC9CZIi9CbMgvhAm0IiMByg");
	this.shape.setTransform(171.575,278.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtBg, new cjs.Rectangle(0,0,343.2,558), null);


(lib.txt4b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag1BDQgNgRAFgeIAJgxQAFgbAQgPQAQgOAYAAQAeABAOARQAOARgFAfIgKAxQgEAbgQAPQgQANgZAAQgeABgOgTgAgTg5QgKAKgEASIgJAzQgEAVAJANQAJAMAUgBQAQABALgKQAKgKAEgSIAJgzQAEgWgJgLQgJgNgUAAQgQAAgLAKg");
	this.shape.setTransform(166.471,42.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgkBTIAaiTIgyAAIADgSIB2AAIgEASIgwAAIgaCTg");
	this.shape_1.setTransform(153.2,42.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_2.setTransform(136.975,42.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_3.setTransform(122.9,42.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgYBTIAcilIAVAAIgdClg");
	this.shape_4.setTransform(112.35,42.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAuBTIAWh5IhKBwIgMAAIgjhyIgWB7IgSAAIAdilIAQAAIAoCCIBWiCIAQAAIgdClg");
	this.shape_5.setTransform(98.525,42.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_6.setTransform(79.175,42.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_7.setTransform(64.925,42.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgXBTIAbilIAUAAIgcClg");
	this.shape_8.setTransform(53.3,42.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag7BTIAdilIBaAAIgDARIhHAAIgKA9IA9AAIgDAQIg9AAIgNBHg");
	this.shape_9.setTransform(44.375,42.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA+AAIgDAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_10.setTransform(31.45,42.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAeBTIgahCIgiAAIgLBCIgUAAIAdilIAzAAQAWAAAMANQALAOgEAWIgBAJQgEARgIAJQgJAJgPAEIAcBEgAgbABIAiAAQAOAAAIgFQAIgHACgOIACgJQACgOgGgJQgGgIgNAAIghAAg");
	this.shape_11.setTransform(16.7516,42.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgtBTIAdilIATAAIgaCUIBGAAIgDARg");
	this.shape_12.setTransform(149.6,14.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_13.setTransform(134.975,14.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("Ag8BTIAdilIBcAAIgDARIhJAAIgKA4IA9AAIgCAQIg9AAIgKA7IBIAAIgDARg");
	this.shape_14.setTransform(117.95,14.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgsBTIACgRIAPAAQAPAAAHgIQAHgGADgSIAUh0IAUAAIgUBzQgGAcgLALQgMALgZAAg");
	this.shape_15.setTransform(105.525,14.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_16.setTransform(92.575,14.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgXBTIAcilIAUAAIgdClg");
	this.shape_17.setTransform(83.05,14.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AglBTIgcilIAUAAIAVCJIBFiJIAVAAIhVClg");
	this.shape_18.setTransform(73.625,14.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_19.setTransform(51.525,14.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("Ag4BDQgOgQAFgeIAThpIAUAAIgTBrQgEAVAJAMQAJALASgBQAQABAKgKQALgJADgRIAUhzIAUAAIgVB2QgEAYgQAOQgQANgYgBQgcAAgOgRg");
	this.shape_20.setTransform(35.9092,15.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.2,0,168.8,58.5);


(lib.txt4a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgZBkIAAgYQABgQAFgQQAFgRAQgcQAQgZAFgNQAFgNAAgNIg8AAIAAAZIghAAIAAg7ICDAAIAAAeQAAAPgEAPQgGAPgQAbQgRAcgFAPQgFAQAAAOIAAAYg");
	this.shape.setTransform(112.1,17.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag0BXQgSgQAAgcIAAgHIAkAAIAAAHQAAAOAJAHQAJAHAQAAQARAAAIgGQAJgHAAgNQAAgLgHgHQgHgGgPgDIgRgEQgcgFgOgOQgPgPAAgXQAAgbASgQQATgQAgAAQAeAAASAQQASAPAAAbIAAAGIgkAAIAAgGQAAgMgIgHQgJgHgOAAQgPAAgIAGQgIAGAAAMQAAAKAHAHQAHAGAQADIAQADQAdAGAOAOQAOAPAAAYQAAAegSAPQgTAQgiAAQghAAgTgQg");
	this.shape_1.setTransform(90.975,17.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhGBkIAAjHIBDAAQAkAAATAUQAUAVgBAlIAAArQABAmgUAUQgTAUgkAAgAghBCIAeAAQATAAAJgKQAJgLAAgVIAAgvQAAgVgJgKQgJgLgTAAIgeAAg");
	this.shape_2.setTransform(73.35,17.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,183.4,36.1);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBTIAAilIBjAAIAAAbIhEAAIAAAqIA5AAIAAAZIg5AAIAAAtIBEAAIAAAag");
	this.shape.setTransform(89.35,68.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AghBTIAAgcIANAAQANAAAFgGQAGgGAAgOIAAhvIAeAAIAABtQAAAegNANQgOANgbAAg");
	this.shape_1.setTransform(77.05,68.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAmBTIgLgiIg4AAIgLAiIgeAAIA4ilIAdAAIA5ClgAATAZIgThFIgVBFIAoAAg");
	this.shape_2.setTransform(65.2,68.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPBTIAAilIAfAAIAAClg");
	this.shape_3.setTransform(53.85,68.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOBTIg4ilIAiAAIAmB6IAlh6IAgAAIg5Clg");
	this.shape_4.setTransform(42.6,68.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgxBTIAAilIBjAAIAAAbIhEAAIAAAqIA5AAIAAAZIg5AAIAAAtIBEAAIAAAag");
	this.shape_5.setTransform(24.45,68.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag7BTIAAilIA5AAQAdAAAQARQARARAAAfIAAAkQAAAfgRARQgQAQgdAAgAgcA3IAaAAQAPAAAIgIQAIgJAAgRIAAgoQAAgRgIgJQgIgJgPAAIgaAAg");
	this.shape_6.setTransform(10.025,68.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AguBEQgQgQAAgfIAAgpQABgfAQgRQAQgRAdAAQAeAAAQARQAQARAAAfIAAApQAAAfgQAQQgQASgegBQgeABgQgSgAgWgwQgJAJABARIAAAsQgBASAJAIQAHAKAPgBQAPABAJgKQAIgIAAgSIAAgsQAAgRgIgJQgJgIgPgBQgPABgHAIg");
	this.shape_7.setTransform(169.55,41.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAaBTIgfg9IgYAAIAAA9IgfAAIAAilIA6AAQAZAAANANQAOAMAAAYIAAAIQgBAQgGAKQgHALgMAGIAlBBgAgdgCIAbAAQAJAAAGgGQAGgGgBgKIAAgJQABgLgGgGQgGgGgJAAIgbAAg");
	this.shape_8.setTransform(155.05,41.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgxBTIAAilIBjAAIAAAbIhEAAIAAAqIA5AAIAAAZIg5AAIAAAtIBEAAIAAAag");
	this.shape_9.setTransform(140.75,41.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAkBnIhEhsIAABsIgcAAIAAilIAZAAIBDBsIAAhsIAdAAIAAClgAAGhJQgFgCgFgFIgGgDIgCgBQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAABIgBAHIAAACIgTAAIAAgCQAAgNAGgHQAFgHAKAAQAFAAAEACQAFABAFAFIAGAEIADABQAAAAABAAQAAgBABAAQAAAAAAgBQABAAAAgBIABgHIAAgBIATAAIAAABQAAAOgFAHQgGAGgKAAIgJgBg");
	this.shape_10.setTransform(125.55,39.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAmBTIgMgiIg3AAIgLAiIgfAAIA5ilIAdAAIA4ClgAATAZIgUhFIgUBFIAoAAg");
	this.shape_11.setTransform(109.7,41.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag2BTIAAilIA3AAQAbAAAOANQANANAAAYIAAAMQAAAYgNAMQgOANgbAAIgZAAIAAA2gAgYACIAZAAQALAAAGgFQAGgGAAgLIAAgMQAAgLgGgGQgGgHgLAAIgZAAg");
	this.shape_12.setTransform(95.325,41.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA3BTIAAhjIgtBYIgTAAIgthYIAABjIgcAAIAAilIAYAAIA7B0IA5h0IAZAAIAAClg");
	this.shape_13.setTransform(77.35,41.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AguBEQgQgQAAgfIAAgpQAAgfARgRQAQgRAdAAQAeAAAQARQAQARAAAfIAAApQAAAfgQAQQgQASgegBQgdABgRgSgAgWgwQgJAJABARIAAAsQgBASAJAIQAHAKAPgBQAPABAJgKQAHgIABgSIAAgsQgBgRgHgJQgJgIgPgBQgPABgHAIg");
	this.shape_14.setTransform(59.2,41.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgrBGQgQgRAAgeIAAgtQAAgeAQgRQAPgQAcAAQAdAAAPAQQAQARAAAeIAAAFIgfAAIAAgHQAAgQgHgIQgIgJgOAAQgOAAgHAJQgHAIAAAQIAAAxQAAAQAHAIQAHAJAOgBQAOABAIgJQAHgIAAgQIAAgGIAfAAIAAAEQAAAegQARQgPAPgdAAQgcAAgPgPg");
	this.shape_15.setTransform(44.1,41.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgsBFQgQgRAAgeIAAhpIAfAAIAABrQAAAQAIAIQAHAJAOgBQAPABAHgJQAIgHAAgRIAAhrIAfAAIAABpQAAAegQARQgPAPgeAAQgdAAgPgPg");
	this.shape_16.setTransform(24.275,41.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgrBJQgPgOAAgXIAAgGIAdAAIAAAGQAAALAIAGQAIAHANgBQAOABAHgGQAHgGAAgKQAAgJgGgHQgGgFgMgCIgNgEQgYgEgMgLQgMgMAAgUQAAgWAPgOQAPgNAbAAQAZAAAPANQAPANAAAXIAAAEIgeAAIAAgEQAAgLgHgGQgHgFgMgBQgMAAgHAGQgGAFAAAJQAAAJAGAGQAGAEAMAEIAOACQAYAFALALQAMANAAAVQAAAYgPANQgQAMgcAAQgbAAgQgMg");
	this.shape_17.setTransform(9.275,41.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(0,0,202.5,84.3), null);


(lib.txt1Line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ai9AFIAAgJIF7AAIAAAJg");
	this.shape.setTransform(19,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1Line, new cjs.Rectangle(0,0,38,1), null);


(lib.txt1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgkBTIAaiTIgyAAIADgSIB2AAIgEASIgwAAIgaCTg");
	this.shape.setTransform(153.2,42.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag9BTIAdilIAyAAQAXAAAMANQALANgEAXIgDAOQgDAWgNAKQgNAKgZAAIgiAAIgKA8gAgcAGIAgAAQAPAAAJgGQAIgGADgOIACgPQACgOgGgIQgHgIgNAAIggAAg");
	this.shape_1.setTransform(138.3516,42.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag0BEQgOgRAGgeIAJg0QAFgZAPgPQAQgOAYAAQAbAAAPAPQAOAQgDAXIgBACIgTAAIABgCQACgQgJgKQgJgKgSAAQgQAAgLAJQgKAKgEASIgJA1QgEAVAJAMQAIAMAUgBQAQAAAKgJQAKgJAEgSIACgNIggAAIADgSIA0AAIgGAfQgEAagQAPQgQANgYAAQgdAAgOgRg");
	this.shape_2.setTransform(123.6565,42.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AglBTIAbiTIgyAAIADgSIB2AAIgDASIgyAAIgZCTg");
	this.shape_3.setTransform(110.5,42.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAuBTIgGgoIhBAAIgUAoIgUAAIBVilIASAAIAcClgAAmAbIgNhUIgpBUIA2AAg");
	this.shape_4.setTransform(93.475,42.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAXBTIANhMIhKAAIgNBMIgUAAIAdilIAUAAIgNBJIBLAAIAMhJIAUAAIgdClg");
	this.shape_5.setTransform(79.225,42.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgzBEQgOgRAGgeIAJg0QAFgZAPgPQAQgOAXAAQAcAAAOARQAOASgFAcIAAACIgUAAIABgDQADgVgIgLQgJgMgTAAQgPAAgKAJQgKAKgEASIgJA1QgEAVAJAMQAIAMATgBQAPAAAKgJQALgJADgSIACgKIATAAIgCAKQgEAagQAPQgQANgXAAQgcAAgOgRg");
	this.shape_6.setTransform(63.7112,42.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAbBTIg4iCIgYCCIgSAAIAdilIAQAAIA5CCIAXiCIASAAIgdClg");
	this.shape_7.setTransform(69.525,14.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ag1BDQgNgRAFgeIAJgyQAFgaAQgOQAQgOAYgBQAeAAAOASQAOASgFAeIgKAyQgEAagQAPQgQAOgZgBQgeAAgOgSgAgTg5QgKAJgEATIgJAzQgEAVAJANQAJALAUAAQAQAAALgJQAKgJAEgTIAJgzQAEgWgJgMQgJgMgUAAQgQAAgLAKg");
	this.shape_8.setTransform(53.621,14.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgzBEQgOgRAGgeIAJg0QAFgaAPgOQAQgOAXAAQAcABAOARQAOAQgFAdIAAACIgUAAIABgCQADgWgIgMQgJgLgTAAQgPAAgKAJQgKAKgEASIgJA1QgEAVAJAMQAIALATAAQAPABAKgKQALgJADgSIACgKIATAAIgCAKQgEAbgQAOQgQAOgXgBQgcAAgOgRg");
	this.shape_9.setTransform(38.4612,14.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(28.5,0,132,58.5);


(lib.txt1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgZBkIAAgYQABgQAFgQQAFgRAQgcQAQgZAEgNQAGgNAAgNIg8AAIAAAZIghAAIAAg7ICDAAIAAAeQAAAPgEAPQgGAPgQAbQgRAcgEAPQgGAQAAAOIAAAYg");
	this.shape.setTransform(50.35,17.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag0BXQgSgQAAgcIAAgHIAkAAIAAAHQAAAOAJAHQAJAHAQAAQARAAAIgGQAJgHAAgNQAAgLgHgHQgHgGgPgDIgRgEQgcgFgOgOQgPgPAAgXQAAgbASgQQATgQAgAAQAeAAASAQQASAPAAAbIAAAGIgkAAIAAgGQAAgMgIgHQgJgHgOAAQgPAAgIAGQgIAGAAAMQAAAKAHAHQAHAGAQADIAQADQAdAGAOAOQAOAPAAAYQAAAegSAPQgTAQgiAAQghAAgTgQg");
	this.shape_1.setTransform(29.225,17.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhHBkIAAjHIBFAAQAjAAATAUQAUAVgBAlIAAArQABAmgUAUQgTAUgjAAgAghBCIAfAAQARAAAKgKQAJgLAAgVIAAgvQAAgVgJgKQgKgLgRAAIgfAAg");
	this.shape_2.setTransform(11.6,17.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,183.4,36.1);


(lib.mask1Guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EghRgAJMAhbgZ8MAhIAZ8MghbAaPg");
	this.shape.setTransform(213,167);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mask1Guide, new cjs.Rectangle(0,0,426,334), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As6ToIADhJIACgLQAIgtAegdQFglUBJhLQEVkaBUjYQAuh1AAhpQAAh/guiNQhMjqjrkrQisjcjwjsIWVRaIBVBLQAMALAJAOQANAWAAAVQAAArg0AnI5DTig");
	mask.setTransform(82.775,129.45);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#838382","#838382","#B7B7B6","#EBEBEB","#FFFFFF","#FAFAFA","#ECECEB","#D4D4D3","#B3B3B2","#9D9D9C","#9D9D9C"],[0,0.043,0.216,0.412,0.506,0.588,0.682,0.788,0.898,0.961,1],0,-129.4,0,129.5).s().p("As7UPMAAAgodIZ3AAMAAAAodg");
	this.shape.setTransform(82.775,129.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0,0,165.6,258.9), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("An0GPQgDgCAxgtQBIhCA1g4QDLjWBsjpQAphaAbgbQAkglBHgHQDQgTBegCIADAAQASAAAJAEQAJAEACAJQAFAPgeAWQhtBNjKCeIm1FcQjXCigMAAIAAgBg");
	mask.setTransform(58.1041,48.7588);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],-3.1,-36.4,3.1,35.1).s().p("ApAmLIQ0heIBNN1Iw0Beg");
	this.shape.setTransform(57.725,49.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(8,8.8,100.2,79.9), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ArIC0IhRhFQgVgVgJgXQgEgMAAgPQABgNADgJQAOghAigZIZDzhIAAAUQAAA7gFAfQgJAvgeAeQl7FyguAwQkUEbhVDbQguB2AABrQAAB/AuCMQBLDoDnEoQCrDbDuDpg");
	mask.setTransform(83.0475,129.025);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(61,61,61,0)","#3D3D3D","#000000","#000000"],[0,0.89,0.89,0.961,1],0,-129,0,129).s().p("As8UKMAAAgoTIZ5AAMAAAAoTg");
	this.shape.setTransform(82.925,129.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#E2E1E1","#E2E1E1","#DDDCDC","#CFCECE","#C6C6C6","#EAEAEA","#FFFFFF","#F9F9F9","#E9E9E9","#CECECE","#A8A8A8","#777777","#3D3D3D","rgba(61,61,61,0)","rgba(0,0,0,0)"],[0,0.039,0.118,0.212,0.251,0.4,0.506,0.549,0.604,0.671,0.737,0.812,0.89,0.89,1],0,-129,0,129).s().p("As8UKMAAAgoTIZ5AAMAAAAoTg");
	this.shape_1.setTransform(82.925,129.025);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0.3,0,165.6,258.1), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AEsRQQgzgshghZQiPiDi3jZQici2hPiQQhki3gBibQABiQBhifQBSiGCfiaQBahXD9jWQD/jXBSg5IgCACQi4CQj5D4QlfFfhUDIQg0B6AABhQAAB7ArB7QBdEMFDFoQCrC+DNC3Qg4grhDg7g");
	this.shape.setTransform(750.65,480.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(699.7,359.7,101.89999999999998,241.09999999999997), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgCM9QlCllhdkLQgrh8AAh6QAAhiA0h6QBUjIFgleQD6j5C2iPQgHAJgGAHQl7FyguAxQkTEahXDbQgtB3gBBrQABB+AtCMQBNDnDmEoQCpDZDuDrQjNi3irjAg");
	mask.setTransform(46.05,120.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(253,253,253,0)","#FDFDFD","#F5F5F5","#E7E7E7","#D4D4D3","#BBBBBA","#9D9D9C","#9D9D9C"],[0,0.655,0.655,0.737,0.804,0.863,0.914,0.961,1],0,117.4,0,-117.4).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape.setTransform(46.05,120.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#000000","#2D2D2D","#585858","#808080","#A3A3A3","#C0C0C0","#D7D7D7","#E9E9E9","#F6F6F6","#FDFDFD","#FFFFFF","#FDFDFD","rgba(253,253,253,0)","rgba(0,0,0,0)"],[0,0.039,0.063,0.086,0.114,0.141,0.173,0.208,0.251,0.298,0.361,0.506,0.655,0.655,1],0,117.4,0,-117.4).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape_1.setTransform(46.05,120.4);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,92.1,240.8), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Am9SkQFflUBKhLQETkaBVjXQAvh1gBhrQAAh+guiNQhNjqjqkrQisjcjvjrQDOC4CuDBQFGFsBeEMQAqB5AAB9QAABigyB3QhVDHlgFbQj4D2i5CPg");
	mask.setTransform(46.05,120.375);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(225,225,225,0)","#E1E1E1","#C9C9C9","#AAAAAA","#848484","#585858","#252525","#000000","#000000"],[0,0.694,0.694,0.745,0.792,0.843,0.886,0.933,0.961,1],0,117.4,0,-117.3).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape.setTransform(46.05,120.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#706F6F","#706F6F","#828181","#A3A3A3","#C0C0C0","#D7D7D7","#E9E9E9","#F6F6F6","#FDFDFD","#FFFFFF","#FCFCFC","#F2F2F2","#E1E1E1","rgba(225,225,225,0)","rgba(0,0,0,0)"],[0,0.039,0.055,0.09,0.125,0.165,0.212,0.267,0.341,0.506,0.58,0.639,0.694,0.694,1],0,117.4,0,-117.3).s().p("AnMS0MAAAglnIOYAAMAAAAlng");
	this.shape_1.setTransform(46.05,120.375);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,92.1,240.8), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhgNfQFxljBpkIQAziAAAh0QAAhygziAQigmTrmpJQCtB1COBzQDXCuClCpQFiFsAAEjQAAEkliFsQioCsjUCrQiSB2ipByQD1jAC3iwg");
	this.shape.setTransform(526.125,476.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("An7SzQC4iPD5j2QFflbBVjHQAzh5AAhgQAAh9grh5QhdkMlHlsQiujBjOi4QBfBLC3CoQCPCDC3DZQCbC2BQCQQBkC3AACbQAACQhhCdQhSCDigCaQhZBWj9DUQj+DVhSA5g");
	this.shape_1.setTransform(693.125,610.775);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(473.6,352.9,270.5,378.4), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhRNfQFVljBgkJQAwiAAAhzQAAhxgwiBQiTmSqtpKQLmJKCgGSQAzCAAAByQAAB0gzB/QhpEJlxFjQi2Cwj2DAQDjjACoiwg");
	mask.setTransform(47.7,123.125);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(253,253,253,0)","#FDFDFD","#F5F5F5","#E7E7E7","#D3D3D3","#BABABA","#9B9B9B","#767676","#4A4A4A","#1B1B1B","#000000","#000000"],[0,0.62,0.62,0.682,0.729,0.773,0.812,0.851,0.882,0.914,0.945,0.961,1],0,120.1,0,-120).s().p("AncTPMAAAgmdIO5AAMAAAAmdg");
	this.shape.setTransform(47.7,123.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#000000","#131313","#444444","#707070","#979797","#B7B7B7","#D1D1D1","#E6E6E6","#F4F4F4","#FCFCFC","#FFFFFF","#FDFDFD","rgba(253,253,253,0)","rgba(0,0,0,0)"],[0,0.039,0.051,0.082,0.118,0.157,0.196,0.239,0.286,0.337,0.4,0.506,0.62,0.62,1],0,120.1,0,-120).s().p("AncTPMAAAgmdIO5AAMAAAAmdg");
	this.shape_1.setTransform(47.7,123.125);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,95.4,246.3), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhjpBjqMAAAjHTMDHTAAAMAAADHTg");
	mask.setTransform(637.775,637.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAfbQAAgWABgkQADgoACgOQAEgTAKgTQALgUAPgPQFVlJBVhXQESkYBUjUQAuhzAAhoQAAh9guiKQhbkVk9lzQiqjJjbjOQgagbgIgbQgLAmgrAhI5cTyMAAAgqlIZcT0QAqAfAMAnQALgmArggIZcz0IgCAzQAABBgGAlQgJArggAeQlpFihABCQkSEYhVDYQguB0ABBpQgBB9AuCKQBbEWE9FzQCrDIDaDPQANALAKAQQAQAZAAAaQAAAegVAcQgPAVgXAQI5aT0gAIVhlQDqErBODqQAtCMABB/QAABrgvB1QhVDYkVEZQhJBLlgFUQgeAegIAvQgCALgCAlIgCA0IAAAUIZEzhQA0gnAAgtQAAgVgNgVQgJgPgMgLIhVhKI2WxZQDwDsCtDbgA6EJ7IZEzhQA0gmAAgtQAAgtg0gnI5EzhgAYOIlQjujqiqjbQjnknhNjoQguiLAAiAQAAhrAuh3QBWjbEUkaQAogpGBl6QAfgeAIgvQAFgeAAg7IABgVI5FTiQgiAYgOAiQgDAKAAANQgBAPAEAMQAJAWAVAVIBRBFIWSRWIAAAAg");
	this.shape.setTransform(637.95,545.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(469.6,339.7,336.79999999999995,412.50000000000006), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AGJFHIhphZIm1lcQjKiehthNQgegWAEgPQADgJAJgEQAJgEARAAIAEAAQBlACCNANQBGAHAkAmQAVAWAxBeIBhCcQB3CtBzBsIBkBjQBVBUgDACIAAABQgHAAhXhJg");
	mask.setTransform(55.9242,48.4557);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],3.2,-36.6,-3.1,35.2).s().p("AovGMIBNtyIQSBcIhONxg");
	this.shape.setTransform(56,48.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(7.2,8.5,97.5,79.9), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As7TjIAZgVIABAAQClhwCVh3QDWisCoisQFhlsAAkjQAAkjlhlsQiliqjZitQiNh0iuh1IgZgTIAAhSIZDThQA0AnAAAsQAAAtg0AnI5DThg");
	mask.setTransform(82.8,133.3);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#706F6F","#706F6F","#828181","#B1B1B1","#FDFDFD","#FFFFFF","#ECECEC","#BCBBBB","#6E6D6D","#5F5E5E","#5F5E5E"],[0,0.043,0.122,0.278,0.498,0.506,0.576,0.722,0.922,0.961,1],0,-133.3,0,133.3).s().p("As7U1MAAAgppIZ3AAMAAAAppg");
	this.shape.setTransform(82.8,133.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,165.6,266.6), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnvGPQgDgBCMh9IA/g7QBzhsB3itQA8hYAlhEQAyheAVgWQAjgmBGgHQCNgNBmgCIADAAQASAAAIAEQAJAEADAJQAEAPgeAWQheBCjXCrQk6D5h8BhIhCAyIhuBUQgkAcgGAAIAAgBg");
	mask.setTransform(56.7771,48.6098);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A8A8A7","#000000","#000000","#000000"],[0,0.212,0.808,1],-3.2,-36.5,3.1,35.2).s().p("Ao3mKIQihdIBNNzIwiBcg");
	this.shape.setTransform(56.825,48.825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(7.2,8.7,99.2,79.89999999999999), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnEziIAZAUQDjDACpCwQFUFjBhEIQAvCCAABxQAABygvCCQhhEIlUFjQipCwjjDAIgZAUg");
	mask.setTransform(45.325,125.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FAFAFA","#FAFAFA","#EBEBEB","#808285","#808285"],[0,0.02,0.471,0.961,1],0,-121.9,0,122).s().p("AnETjMAAAgnFIOJAAMAAAAnFg");
	this.shape.setTransform(45.325,125.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,90.7,250.2), null);


(lib.img4Guide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._3();
	this.instance.setTransform(-324,-276.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Guide, new cjs.Rectangle(-324,-276.9,888,837), null);


(lib.img4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._3();
	this.instance.setTransform(-210.15,-211.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4, new cjs.Rectangle(-210.1,-211.1,888,837), null);


(lib.img2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Calque_1
	this.instance = new lib.img2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,243);


(lib.img1_zoom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.img1();
	this.instance.setTransform(0.05,0.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2B2B").s().p("EiIiBnwMAAAjPeMERGAAAMAAADPeg");
	this.shape.setTransform(873.75,668.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_zoom, new cjs.Rectangle(-0.2,0.1,1747.9,1332.8000000000002), null);


(lib.ctaTxt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbApQgJgKAAgSIAAgZQAAgSAKgKQAJgKARAAQASAAAKAKQAKAKAAASIAAAZQAAASgKAKQgKAKgSAAQgRAAgKgKgAgNgcQgFAFAAAKIAAAbQAAAKAFAFQAFAFAIAAQAKAAAEgFQAFgFAAgKIAAgbQAAgKgFgFQgEgGgKAAQgIAAgFAGg");
	this.shape.setTransform(133.05,9.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcAyIAAhjIATAAIAABSIAmAAIAAARg");
	this.shape_1.setTransform(125.075,9.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXAyIgHgVIghAAIgGAVIgTAAIAihjIARAAIAiBjgAAMAPIgMgpIgMApIAYAAg");
	this.shape_2.setTransform(116.35,9.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAPAyIgSglIgOAAIAAAlIgSAAIAAhjIAhAAQAQAAAIAIQAIAHAAAPIAAAEQgBALgDAFQgEAHgIADIAXAngAgRgBIAPAAQAGAAADgEQAEgDAAgGIAAgFQAAgHgEgEQgDgDgGAAIgPAAg");
	this.shape_3.setTransform(107.65,9.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghAyIAAhjIAhAAQAOAAAIAHQAHAGABANIAAACQAAAHgDAFQgDAFgFADQAHABAEAHQAEAFAAAJIAAACQAAANgJAHQgHAHgPAAgAgPAjIASAAQAFAAAEgEQAEgDgBgGIAAgDQABgGgEgEQgEgDgFAAIgSAAgAgPgHIAPAAQAGAAACgDQADgCAAgGIAAgFQAAgEgDgEQgCgCgGAAIgPAAg");
	this.shape_4.setTransform(98.65,9.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaA0QgKgLAAgRIAAg/IATAAIAAA/QAAAKAFAGQAEAEAIAAQAJAAAEgEQAFgGAAgKIAAg/IATAAIAAA/QAAARgKALQgJAJgSAAQgRAAgJgJgAgHguIAMgOIATAAIgQAOg");
	this.shape_5.setTransform(89.275,8.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAqQgJgKAAgSIAAgbQAAgSAJgKQAKgJAQAAQARAAAKAJQAJAKAAASIAAADIgTAAIAAgEQAAgKgEgFQgEgFgJAAQgIAAgEAFQgEAFAAAKIAAAdQAAAKAEAFQAEAEAIAAQAJAAAEgEQAEgFAAgKIAAgEIATAAIAAADQAAASgJAKQgKAJgRAAQgQAAgKgJg");
	this.shape_6.setTransform(80.125,9.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZArQgKgIAAgOIAAgDIASAAIAAADQAAAHAFAEQAFAEAHAAQAIAAAFgEQAEgDAAgGQAAgGgDgDQgEgEgHgBIgIgCQgOgDgIgGQgHgHAAgMQAAgOAJgIQAKgHAPAAQAQAAAIAHQAJAIAAAOIAAACIgSAAIAAgCQAAgHgEgDQgFgEgGAAQgIAAgDADQgEADgBAGQABAFAEAEQADADAHABIAIACQAPADAGAGQAIAIgBAMQABAPgKAHQgJAIgRAAQgQAAgJgIg");
	this.shape_7.setTransform(71.35,9.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdAyIAAhjIA7AAIAAAQIgpAAIAAAaIAiAAIAAAOIgiAAIAAAbIApAAIAAAQg");
	this.shape_8.setTransform(63.35,9.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgjAyIAAhjIAiAAQARAAAKAKQAKALAAASIAAAVQAAATgKAKQgKAKgRAAgAgQAhIAPAAQAJAAAEgFQAFgFAAgLIAAgXQAAgLgFgEQgEgGgJAAIgPAAg");
	this.shape_9.setTransform(54.675,9.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaTxt, new cjs.Rectangle(0,0,187.6,20.1), null);


(lib.ctaBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ap4DZQhpAAhLhAQhKg/AAhaQAAhZBKhAQBLg/BpgBITxAAQBpABBKA/QBLBAAABZQAABahLA/QhKBAhpAAg");
	this.shape.setTransform(88.725,21.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaBg, new cjs.Rectangle(0,0,177.5,43.5), null);


(lib.Cover_Right = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AJPQTIyhvIIhKg9IBKg7ITvwSMgAYAhSIAAAtg");
	this.shape.setTransform(74.9976,121.9951,1.1215,1.1215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cover_Right, new cjs.Rectangle(0,0,150,244), null);


(lib.Cover_Left = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AqEQTMgAYghSITwQSIBJA7IhJA9IyiPIIg2Atg");
	this.shape.setTransform(74.9976,121.9951,1.1215,1.1215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cover_Left, new cjs.Rectangle(0,0,150,244), null);


(lib.white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bQmMAAAghLMAu3AAAMAAAAhLg");
	this.shape.setTransform(150,106.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Cover_Right
	this.Cover_Right = new lib.Cover_Right();
	this.Cover_Right.name = "Cover_Right";
	this.Cover_Right.setTransform(150,88.8);

	this.timeline.addTween(cjs.Tween.get(this.Cover_Right).wait(1));

	// Cover_Left
	this.Cover_Left = new lib.Cover_Left();
	this.Cover_Left.name = "Cover_Left";
	this.Cover_Left.setTransform(0,88.8);

	this.timeline.addTween(cjs.Tween.get(this.Cover_Left).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,300,332.8), null);


(lib.txt4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt4a
	this.txt4a = new lib.txt4a();
	this.txt4a.name = "txt4a";
	this.txt4a.setTransform(-180.2,-46.5);

	this.timeline.addTween(cjs.Tween.get(this.txt4a).wait(1));

	// txt4b
	this.txt4b = new lib.txt4b();
	this.txt4b.name = "txt4b";
	this.txt4b.setTransform(-86.7,36.9,1,1,0,0,0,91.5,28.7);

	this.timeline.addTween(cjs.Tween.get(this.txt4b).wait(1));

	// txt4Line
	this.txt4Line = new lib.txt1Line();
	this.txt4Line.name = "txt4Line";
	this.txt4Line.setTransform(-87.3,-1.35,1.421,1,0,0,0,19.1,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txt4Line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(-180.2,-46.5,270,132), null);


(lib.txt2Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txtGuide
	this.txtGuide = new lib.txtGuide();
	this.txtGuide.name = "txtGuide";
	this.txtGuide.setTransform(-37.65,145.15,1,1,0,0,0,160,152.9);

	this.timeline.addTween(cjs.Tween.get(this.txtGuide).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4+jRIRp0nMAgUAbJIxpUog");
	mask.setTransform(61.3,30.15);

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(0,-13);

	var maskedShapeInstanceList = [this.txt2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2Container, new cjs.Rectangle(-197.6,-13,400.1,311.1), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1a
	this.txt1a = new lib.txt1a();
	this.txt1a.name = "txt1a";
	this.txt1a.setTransform(0.15,15.6);

	this.timeline.addTween(cjs.Tween.get(this.txt1a).wait(1));

	// GPTlogo
	this.instance = new lib.GPT();
	this.instance.setTransform(4.6,94.35,0.03,0.03);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// txt1b
	this.txt1b = new lib.txt1b();
	this.txt1b.name = "txt1b";
	this.txt1b.setTransform(-26.65,61.8);

	this.timeline.addTween(cjs.Tween.get(this.txt1b).wait(1));

	// txt1Line
	this.txt1Line = new lib.txt1Line();
	this.txt1Line.name = "txt1Line";
	this.txt1Line.setTransform(5.15,56.45,1.421,1,0,0,0,0.1,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txt1Line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-93.5,-38.1,277,158.4), null);


(lib.logo_DS_vector = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(22.1,65,0.4799,0.4799,0,0,0,46.1,126.2);

	this.instance_1 = new lib.ClipGroup_1();
	this.instance_1.setTransform(53.1,85.15,0.4799,0.4799,0,0,0,57.6,49.8);

	this.instance_2 = new lib.ClipGroup_2();
	this.instance_2.setTransform(40.25,65.05,0.4799,0.4799,0,0,0,83.9,134.5);

	this.instance_3 = new lib.ClipGroup_3();
	this.instance_3.setTransform(107.45,85.15,0.4799,0.4799,0,0,0,56.7,49.7);

	this.instance_4 = new lib.ClipGroup_4();
	this.instance_4.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_5 = new lib.ClipGroup_5();
	this.instance_5.setTransform(24.5,65,0.4799,0.4799,0,0,0,48.6,124.2);

	this.instance_6 = new lib.ClipGroup_6();
	this.instance_6.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_7 = new lib.ClipGroup_7();
	this.instance_7.setTransform(104.8,129.55,0.4799,0.4799,0,0,0,47.1,121.2);

	this.instance_8 = new lib.ClipGroup_8();
	this.instance_8.setTransform(136.95,67,0.4799,0.4799,0,0,0,47,121.4);

	this.instance_9 = new lib.ClipGroup_9();
	this.instance_9.setTransform(80.5,142.6,0.4799,0.4799,0,0,0,637.1,636.9);

	this.instance_10 = new lib.ClipGroup_10();
	this.instance_10.setTransform(120.6,63.05,0.4799,0.4799,0,0,0,83.5,130.3);

	this.instance_11 = new lib.ClipGroup_11();
	this.instance_11.setTransform(133.35,152.3,0.4799,0.4799,0,0,0,58.6,50);

	this.instance_12 = new lib.ClipGroup_12();
	this.instance_12.setTransform(120.9,133.95,0.4799,0.4799,0,0,0,83.5,130.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-225.2,-163,612.0999999999999,612.1);


(lib.logo_black = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_DS_vector
	this.instance = new lib.logo_DS_vector("synched",0);
	this.instance.setTransform(203.7,143.3,1,1,0,0,0,80.8,143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// DS AUTOMOBILES
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AcjCpQgdgdABg7IA5AAQABAhAOAQQAOARAhAAQAfAAAOgNQAMgNAAgcQABgcgLgQQgLgPgagHIgjgLQgvgPgUgYQgWgZAAgwQAAguAbgbQAdgdA0ABQA7AAAcAaQAcAbAAA4Ig6AAQgBgegMgOQgMgOgeAAQgaAAgNAMQgMALAAAZQAAAbALANQAMAMAcAKIAhAKQAwAOAUAZQATAbAAAzQAAAzgeAcQgeAcg4AAQg9AAgegdgAHbCmQghghAAg7IAAiRQAAg7AhgiQAhghA7AAQA6AAAhAhQAhAiAAA7IAACRQAAA7ghAhQghAgg6AAQg7AAghgggAIFh+QgRASgBAjIAACUQABAiARASQARATAhAAQAgAAARgTQARgSAAgiIAAiUQAAgkgRgRQgRgTggABQghgBgRATgAkKCmQghghABg7IAAiRQgBg7AhgiQAighA6AAQA6AAAiAhQAgAiAAA7IAACRQAAA7ggAhQgiAgg6AAQg6AAgigggAjfh+QgSASAAAjIAACUQAAAiASASQARATAgAAQAgAAASgTQAQgSABgiIAAiUQgBgkgQgRQgSgTggABQgggBgRATgAt2CoQgeggAAg6IAAkOIA6AAIAAESQAAAiAQAQQAPAOAdAAQAfAAAOgOQAPgQABgiIAAkSIA5AAIAAEOQAAA6gdAgQgeAfg7gBQg5ABgfgfgA6eCpQgdgdAAg7IA6AAQAAAhAOAQQAPARAhAAQAeAAAPgNQANgNgBgcQAAgcgKgQQgLgPgagHIgjgLQgvgPgVgYQgUgZgBgwQAAguAbgbQAdgdA1ABQA6AAAcAaQAcAbAAA4Ig6AAQgBgegMgOQgMgOgfAAQgZAAgMAMQgNALAAAZQAAAbAMANQALAMAcAKIAiAKQAvAOATAZQAUAbAAAzQAAAzgeAcQgeAcg4AAQg9AAgegdgAYADBIAAmBIDBAAIAAA1IiHAAIAABtIB4AAIAAAzIh4AAIAAB4ICOAAIAAA0gAT3DBIAAmBIA6AAIAAFNICDAAIAAA0gARSDBIAAmBIA6AAIAAGBgAMTDBIAAmBIB4AAQAwAAAaAaQAZAZAAAxQAAAggKAWQgMAYgWAKQA2ARAABLQgBAygaAcQgcAbgzAAgANNCPIA+AAQAYAAANgPQAMgOAAgdQAAgegMgRQgNgRgXAAIg/AAgANNgcIA9AAQAVAAALgPQALgOAAgbQAAgbgMgPQgMgQgWAAIg6AAgAEjDBIAAkkIhGC5IgyAAIhHi6IAAElIg2AAIAAmBIBHAAIBRDaIBQjaIBEAAIAAGBgAn/DBIAAlNIheAAIAAg0ID3AAIAAA0IhfAAIAAFNgAwbDBIgZhqIhsAAIgZBqIg5AAIBfmBIBUAAIBhGBgAxAAlIgqi0IgqC0IBUAAgA/xDBIAAmBIBuAAQA7AAAhAhQAhAgAAA7IAACLQAAA6ghAgQghAgg7AAgA+4COIA0AAQAigBARgSQARgSAAgiIAAiMQAAgjgRgSQgRgSgiAAIg0AAg");
	this.shape.setTransform(203.35,246.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_black, new cjs.Rectangle(0,0.3,406.8,266.09999999999997), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo_black();
	this.instance.setTransform(0,-0.4,0.5688,0.5688,0,0,0,0,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-58.2,-92.6,348.2,348.2), null);


(lib.LegalFrame2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bgcCTA
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAtQgKgLAAgSIAAgeQAAgTAKgKQAJgLARAAQASAAAKALQAJAKAAATIAAAeQAAASgJALQgKAKgSAAQgRAAgJgKgAgRgjQgHAHAAANIAAAfQAAANAHAHQAGAHALAAQAMAAAGgHQAHgHAAgNIAAgfQAAgNgHgHQgGgHgMAAQgLAAgGAHg");
	this.shape.setTransform(215.375,240.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcA1IAAhpIANAAIAABeIAsAAIAAALg");
	this.shape_1.setTransform(206.975,240.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAdA1IgJgZIgpAAIgIAZIgMAAIAkhpIALAAIAkBpgAARARIgRg1IgRA1IAiAAg");
	this.shape_2.setTransform(197.725,240.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAWA1IgXgqIgWAAIAAAqIgMAAIAAhpIAiAAQAOAAAHAIQAIAHAAAOIAAAGQABALgFAGQgFAHgJACIAaAsgAgXABIAWAAQAIAAAEgEQAFgFAAgJIAAgGQAAgJgFgEQgEgFgIAAIgWAAg");
	this.shape_3.setTransform(188.7,240.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghA1IAAhpIAhAAQAOAAAHAHQAIAGAAANIAAAEQAAAHgDAGQgEAFgFADQAHABAFAHQAEAGABAKIAAADQgBANgHAHQgJAHgOAAgAgUArIAXAAQAJAAAFgFQAEgEAAgJIAAgDQAAgJgEgFQgFgEgJAAIgXAAgAgUgFIAUAAQAIAAAEgEQAFgFAAgHIAAgFQAAgHgFgFQgEgEgIAAIgUAAg");
	this.shape_4.setTransform(179.15,240.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaA3QgJgKAAgSIAAhFIAMAAIAABGQAAANAHAGQAGAGAKAAQAMAAAGgGQAGgGAAgNIAAhGIANAAIAABFQgBASgJAKQgJAKgSAAQgQAAgKgKgAgFgxIANgPIANAAIgPAPg");
	this.shape_5.setTransform(169.15,239.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAtQgKgKAAgSIAAghQAAgSAKgKQAJgKAQAAQARAAAKAKQAJAKAAASIAAAEIgNAAIAAgEQAAgNgFgHQgHgGgLAAQgLAAgFAGQgHAHABANIAAAhQgBANAHAHQAFAGALAAQALAAAHgGQAFgHAAgNIAAgDIANAAIAAADQAAASgJAKQgKAKgRAAQgQAAgJgKg");
	this.shape_6.setTransform(159.4,240.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZAuQgJgIAAgPIAAgDIAMAAIAAADQAAAKAGAFQAGAGAKAAQALAAAGgFQAGgFAAgJQAAgIgFgEQgFgFgKgCIgIgCQgOgDgHgGQgHgHAAgMQAAgOAJgIQAJgIAPAAQAPAAAJAIQAJAIAAAPIAAACIgMAAIAAgCQAAgJgGgGQgGgFgJAAQgKAAgFAFQgGAFAAAIQAAAHAFAFQAFAEAJACIAIACQAPADAHAGQAHAIAAAMQAAAPgJAIQgJAIgRAAQgPAAgKgJg");
	this.shape_7.setTransform(150.025,240.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAALIgtAAIAAAkIAmAAIAAAJIgmAAIAAAmIAuAAIAAALg");
	this.shape_8.setTransform(141.725,240.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgiA1IAAhpIAhAAQARAAAKAKQAJAKAAATIAAAbQAAATgJAKQgKAKgRAAgAgVAqIAUAAQALAAAHgHQAFgHABgNIAAgcQgBgOgFgHQgHgHgLAAIgUAAg");
	this.shape_9.setTransform(132.45,240.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// txtCTA
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(255,255,255,0)").ss(1,1,1).p("AAAAGIAAgL");
	this.shape_10.setTransform(33.95,256.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("A3bCWIAAkrMAu3AAAIAAErg");
	this.shape_11.setTransform(171.1,240.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// logoBlack
	this.logo_black2 = new lib.logo_black();
	this.logo_black2.name = "logo_black2";
	this.logo_black2.setTransform(172.1,51.75,0.24,0.2295,0,0,0,205.7,144.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_black2).wait(1));

	// line
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(0.7,1,1).p("AjIAAIGRAA");
	this.shape_12.setTransform(132.125,144.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

	// legalTxt
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_13.setTransform(264.875,213.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_14.setTransform(260.475,213.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_15.setTransform(256.975,215.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_16.setTransform(253.525,213.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_17.setTransform(249.125,213.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_18.setTransform(244.875,213.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_19.setTransform(241.375,213.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgRAcIAAg3IARAAQAIAAADADQAEAEAAAHIAAACQAAAEgBADQgCACgDACQAEAAACAEQADADAAAFIAAACQAAAHgEADQgFAEgHAAgAgKAXIAMAAQAEAAADgDQACgCAAgFIAAgCQAAgEgCgDQgDgCgEAAIgMAAgAgKgCIAKAAQAEAAADgDQACgCAAgEIAAgCQAAgEgCgDQgDgCgEAAIgKAAg");
	this.shape_20.setTransform(237.875,213.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_21.setTransform(232.625,213.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAVAcIAAgoIgTAlIgDAAIgTglIAAAoIgGAAIAAg3IAGAAIAUArIAWgrIAFAAIAAA3g");
	this.shape_22.setTransform(226.475,213.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_23.setTransform(220.325,213.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_24.setTransform(215.45,213.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgNAXQgFgFAAgJIAAglIAGAAIAAAlQAAAHAEADQADAEAFAAQAGAAAEgEQADgDAAgHIAAglIAGAAIAAAlQAAAJgFAFQgFAGgJAAQgIAAgFgGg");
	this.shape_25.setTransform(210.475,213.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_26.setTransform(205.25,213.225);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_27.setTransform(200.325,213.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgRAcIAAg3IARAAQAJAAAEAFQAFAGABAKIAAANQgBAKgFAGQgEAFgJAAgAgLAWIALAAQAFAAAEgDQADgEAAgHIAAgPQAAgHgDgDQgEgEgFAAIgLAAg");
	this.shape_28.setTransform(195.4,213.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgGAAIAAg3IAFAAIAaArIAAgrIAGAAIAAA3g");
	this.shape_29.setTransform(188.25,213.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_30.setTransform(183.475,213.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_31.setTransform(176.975,213.225);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_32.setTransform(172.575,213.225);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_33.setTransform(168.325,213.225);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_34.setTransform(163.4,213.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgNAYQgFgFgBgKIAAgQQABgKAFgGQAFgFAIAAQAKAAAEAFQAFAFABAIIAAABIgHAAIAAgBQAAgGgEgDQgCgDgHAAQgFAAgEAEQgCADAAAHIAAARQAAAHACAEQAEADAFAAQAGAAADgDQAEgDAAgHIAAgEIgLAAIAAgGIASAAIAAAKQgBAJgFAFQgEAFgKAAQgIAAgFgFg");
	this.shape_35.setTransform(158.3,213.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_36.setTransform(153.725,213.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_37.setTransform(149.475,213.225);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_38.setTransform(143.025,213.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_39.setTransform(138.625,213.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgHAAIAAg3IAGAAIAaArIAAgrIAGAAIAAA3g");
	this.shape_40.setTransform(133.45,213.225);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_41.setTransform(128.025,213.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_42.setTransform(124.275,213.225);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_43.setTransform(120.625,213.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_44.setTransform(116.925,213.225);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgRAcIAAg3IARAAQAJAAAEAFQAGAGAAAKIAAANQAAAKgGAGQgEAFgJAAgAgLAWIALAAQAGAAADgDQADgEAAgHIAAgPQAAgHgDgDQgDgEgGAAIgLAAg");
	this.shape_45.setTransform(113.25,213.225);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgHAAIAAg3IAGAAIAaArIAAgrIAGAAIAAA3g");
	this.shape_46.setTransform(107.8,213.225);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_47.setTransform(102.375,213.225);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_48.setTransform(97.275,213.225);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AAMAcIgMgWIgMAAIAAAWIgGAAIAAg3IASAAQAGAAAFAEQAEAEAAAHIAAADQAAAGgCADQgDADgFACIAOAXgAgMAAIAMAAQADAAADgBQACgDAAgFIAAgDQAAgEgCgDQgDgDgDAAIgMAAg");
	this.shape_49.setTransform(90.775,213.225);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_50.setTransform(86.025,213.225);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgCAcIgTg3IAHAAIAOAtIAQgtIAGAAIgTA3g");
	this.shape_51.setTransform(81.075,213.225);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AAFAMIgFgJIgEAJIgDADIgEgCIADgEIAHgHIgKgCIgEgBIABgEIAEABIAKAEIgCgKIAAgEIAEAAIAAAEIgBAKIAJgEIAFgBIABAEIgEABIgKACIAHAHIACAEIgEACg");
	this.shape_52.setTransform(76.675,211.95);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_53.setTransform(287.175,197.35);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgNAZQgEgFAAgIIAAgCIAGAAIAAACQAAAFADADQADADAFAAQAFAAAEgCQADgDAAgFIAAgBQAAgFgDgCQgEgDgFAAIgEAAIAAgFIAEAAQAEAAADgCQADgCAAgFIAAgBQAAgEgCgDQgEgCgEAAQgFAAgCACQgDADAAAFIAAACIgGAAIAAgCQgBgIAFgEQAEgEAIAAQAHAAAFAEQAFAEAAAGIAAACQgBAEgCADQgCADgDACQAFAAACAEQACADABAFIAAACQAAAHgGAEQgEAEgJAAQgHAAgGgEg");
	this.shape_54.setTransform(283.7,194.925);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgRAdIAAgFQAAgGADgEQACgFAHgDIAGgEQAFgCACgDQACgDAAgEIAAgBQAAgFgDgDQgCgDgFAAQgEAAgDADQgDADAAAGIAAACIgGAAIAAgCQAAgIAEgFQAFgFAHAAQAIAAAEAFQAFAEAAAIIAAABQAAAGgDAEQgEAEgGAEIgGAEQgFACgBACQgCADAAAEIAcAAIAAAGg");
	this.shape_55.setTransform(279.125,194.875);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgNAYQgEgFgBgKIAAgRQABgKAEgFQAFgFAIAAQAIAAAGAFQAEAFAAAKIAAARQAAAKgEAFQgGAFgIAAQgIAAgFgFgAgIgTQgDAEAAAGIAAATQAAAGADAEQADADAFAAQAFAAADgDQADgEABgGIAAgTQgBgGgDgEQgDgDgFAAQgFAAgDADg");
	this.shape_56.setTransform(274.3,194.925);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgRAdIAAgFQAAgGADgEQACgFAHgDIAGgEQAFgCACgDQACgDAAgEIAAgBQAAgFgDgDQgCgDgFAAQgEAAgDADQgDADAAAGIAAACIgGAAIAAgCQAAgIAEgFQAFgFAHAAQAIAAAEAFQAFAEAAAIIAAABQAAAGgDAEQgEAEgGAEIgGAEQgFACgBACQgCADAAAEIAcAAIAAAGg");
	this.shape_57.setTransform(269.525,194.875);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgSAkIAdhHIAHAAIgcBHg");
	this.shape_58.setTransform(265.1,195.275);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AAFAcIAAgwIgMAJIgEgFIARgLIAGAAIAAA3g");
	this.shape_59.setTransform(261.45,194.925);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AAFAcIAAgwIgMAJIgEgFIARgLIAGAAIAAA3g");
	this.shape_60.setTransform(258.05,194.925);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgRAkIAchHIAIAAIgdBHg");
	this.shape_61.setTransform(254.55,195.275);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgNAYQgFgFABgKIAAgRQgBgKAFgFQAFgFAIAAQAJAAAEAFQAGAFAAAKIAAARQAAAKgGAFQgEAFgJAAQgIAAgFgFgAgIgTQgDAEAAAGIAAATQAAAGADAEQADADAFAAQAFAAAEgDQADgEAAgGIAAgTQAAgGgDgEQgEgDgFAAQgFAAgDADg");
	this.shape_62.setTransform(250.4,194.925);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgNAZQgEgFAAgIIAAgCIAGAAIAAACQAAAFADADQADADAFAAQAFAAAEgCQADgDAAgFIAAgBQAAgFgDgCQgEgDgFAAIgEAAIAAgFIAEAAQAEAAADgCQADgCAAgFIAAgBQAAgEgCgDQgEgCgEAAQgFAAgCACQgDADAAAFIAAACIgGAAIAAgCQgBgIAFgEQAEgEAIAAQAHAAAFAEQAFAEAAAGIAAACQgBAEgCADQgCADgDACQAFAAACAEQACADABAFIAAACQAAAHgGAEQgEAEgJAAQgHAAgGgEg");
	this.shape_63.setTransform(245.45,194.925);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_64.setTransform(239.575,194.925);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_65.setTransform(235.225,194.925);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_66.setTransform(228.55,194.925);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgDAcIAAgxIgQAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_67.setTransform(223.75,194.925);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_68.setTransform(219.075,194.925);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_69.setTransform(214.1,194.925);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AANAcIAAgaIgZAAIAAAaIgHAAIAAg3IAHAAIAAAYIAZAAIAAgYIAHAAIAAA3g");
	this.shape_70.setTransform(208.8,194.925);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_71.setTransform(202.325,194.925);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_72.setTransform(197.425,194.925);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgFAAIAAg3IAEAAIAbArIAAgrIAGAAIAAA3g");
	this.shape_73.setTransform(192.1,194.925);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgHAAIAUg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_74.setTransform(186.75,194.925);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgGAAIAAg3IAGAAIAaArIAAgrIAHAAIAAA3g");
	this.shape_75.setTransform(181.45,194.925);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_76.setTransform(177.525,194.925);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgOAcIAAg3IAdAAIAAAGIgXAAIAAAUIAUAAIAAAFIgUAAIAAAYg");
	this.shape_77.setTransform(174.5,194.925);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_78.setTransform(168.025,194.925);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_79.setTransform(164.475,194.925);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgRAAIAAAxg");
	this.shape_80.setTransform(161.05,194.925);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgFAAIAAg3IAEAAIAbArIAAgrIAGAAIAAA3g");
	this.shape_81.setTransform(156,194.925);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_82.setTransform(150.65,194.925);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_83.setTransform(146.275,194.925);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_84.setTransform(142.075,194.925);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_85.setTransform(137.725,194.925);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgDAcIAAgxIgQAAIAAgGIAnAAIAAAGIgRAAIAAAxg");
	this.shape_86.setTransform(133.05,194.925);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_87.setTransform(128.375,194.925);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgHAAIAAg3IAGAAIAaArIAAgrIAHAAIAAA3g");
	this.shape_88.setTransform(121.5,194.925);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_89.setTransform(116.075,194.925);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_90.setTransform(110.975,194.925);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_91.setTransform(104.075,194.925);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgRAcIAAg3IARAAQAJAAAEAFQAGAGAAAKIAAANQAAAKgGAGQgEAFgJAAgAgLAWIALAAQAGAAADgDQADgEAAgHIAAgPQAAgHgDgDQgDgEgGAAIgLAAg");
	this.shape_92.setTransform(98.95,194.925);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgHAAIAAg3IAGAAIAaArIAAgrIAHAAIAAA3g");
	this.shape_93.setTransform(93.5,194.925);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_94.setTransform(88.15,194.925);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_95.setTransform(84.475,194.925);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_96.setTransform(80.825,194.925);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgHAAIAAg3IAGAAIAaArIAAgrIAHAAIAAA3g");
	this.shape_97.setTransform(75.5,194.925);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_98.setTransform(70.15,194.925);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgGAAIAAg3IAEAAIAbArIAAgrIAGAAIAAA3g");
	this.shape_99.setTransform(64.85,194.925);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_100.setTransform(60.925,194.925);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAAUIAUAAIAAAFIgUAAIAAAYg");
	this.shape_101.setTransform(57.9,194.925);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_102.setTransform(211.925,179.15);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AgKAYQgEgFAAgKIgIAAIAAgFIAIAAIAAgHIgIAAIAAgFIAIAAQAAgKAEgFQAGgFAIAAQAJAAAFAFQAEAFAAAKIAAACIgGAAIAAgCQAAgHgDgEQgEgDgFAAQgFAAgEADQgDAEAAAHIAPAAIAAAFIgPAAIAAAHIAMAAIAAAFIgMAAQAAAHADAEQAEADAFAAQAFAAAEgDQADgEAAgHIAAgCIAGAAIAAACQAAAKgEAFQgFAFgJAAQgIAAgGgFg");
	this.shape_103.setTransform(208,176.725);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgMAZQgEgFAAgHIAAgBIAGAAIAAABQAAAFADADQADACAEAAQAGAAADgDQADgDAAgHIAAgJIgFAEQgEACgDAAQgIAAgFgFQgEgEAAgHIAAgCQAAgIAEgFQAGgEAHAAQAJAAAEAFQAGAEAAAIIAAAVQAAAJgGAFQgEAFgJAAQgHAAgFgEgAgHgTQgEACAAAGIAAACQAAAFAEADQADACAEAAQAGAAADgCQADgDAAgFIAAgCQAAgGgDgCQgDgDgGAAQgEAAgDADg");
	this.shape_104.setTransform(202.8,176.725);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgEAcIAAgHIABgKIAGgMIAGgMIACgIIgVAAIAAAIIgHAAIAAgOIAjAAIAAAFIgCAJQgBAFgFAIQgFAHgCAFIgBAJIAAAHg");
	this.shape_105.setTransform(198.325,176.725);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgEAIIACgEIACgDIAAgEIAAgGIAFAAIAAAGIgBAFIgCAFIgCADg");
	this.shape_106.setTransform(195.025,179.825);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgNAYQgEgFAAgKIAAgRQAAgKAEgFQAFgFAIAAQAJAAAEAFQAGAFgBAKIAAARQABAKgGAFQgEAFgJAAQgIAAgFgFgAgIgTQgDAEAAAGIAAATQAAAGADAEQADADAFAAQAGAAADgDQACgEAAgGIAAgTQAAgGgCgEQgDgDgGAAQgFAAgDADg");
	this.shape_107.setTransform(191.65,176.725);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgNAYQgEgEAAgIIAGAAQAAAFAEADQADADAEAAQAFAAADgDQADgDAAgGIAAgDQAAgGgDgCQgDgDgFAAQgDAAgDACIgFAEIgFgBIADgeIAcAAIAAAGIgXAAIgCASIAGgDIAFgBQAIAAAEAEQAFAEAAAIIAAADQAAAIgFAFQgFAFgIAAQgIAAgFgFg");
	this.shape_108.setTransform(186.85,176.775);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgMAZQgGgFAAgIIAAgCIAHAAIAAACQAAAFADADQADADAFAAQAFAAADgCQAEgDAAgFIAAgBQAAgFgEgCQgDgDgFAAIgDAAIAAgFIADAAQAEAAADgCQADgCAAgFIAAgBQAAgEgDgDQgCgCgFAAQgEAAgEACQgCADAAAFIAAACIgHAAIAAgCQAAgIAFgEQAFgEAHAAQAIAAAEAEQAEAEAAAGIAAACQAAAEgBADQgCADgFACQAFAAADAEQACADAAAFIAAACQAAAHgEAEQgGAEgIAAQgIAAgEgEg");
	this.shape_109.setTransform(182.05,176.725);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_110.setTransform(178.625,179.15);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_111.setTransform(175.175,176.725);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AAKAcIAAgMIgaAAIAAgFIATgmIAHAAIgSAlIASAAIAAgLIAHAAIAAAdg");
	this.shape_112.setTransform(170.4,176.725);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgDAWIAAgIIAHAAIAAAIgAgDgNIAAgIIAHAAIAAAIg");
	this.shape_113.setTransform(165.575,177.375);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_114.setTransform(162.125,176.725);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_115.setTransform(157.075,176.725);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AgSAcIAAgFIAcgsIgbAAIAAgGIAjAAIAAAFIgcAsIAdAAIAAAGg");
	this.shape_116.setTransform(152.2,176.725);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_117.setTransform(147.35,176.725);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_118.setTransform(142.975,176.725);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AgQAcIAAg3IAQAAQAJAAAEAEQAEAEAAAHIAAAFQAAAHgEAEQgEAEgJAAIgKAAIAAAUgAgKACIAKAAQAFAAADgCQACgCAAgFIAAgFQAAgEgCgDQgDgDgFAAIgKAAg");
	this.shape_119.setTransform(138.4,176.725);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_120.setTransform(131.6,176.725);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_121.setTransform(314.175,167.625);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_122.setTransform(309.25,167.625);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_123.setTransform(304.45,167.625);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_124.setTransform(299.525,167.625);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_125.setTransform(294.65,167.625);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_126.setTransform(288.025,167.625);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_127.setTransform(284.275,167.625);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_128.setTransform(280.625,167.625);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_129.setTransform(276.075,167.625);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AAMAcIgMgWIgMAAIAAAWIgGAAIAAg3IASAAQAGAAAFAEQAEAEAAAHIAAADQAAAGgCADQgDADgFACIAOAXgAgMAAIAMAAQADAAADgBQACgDAAgFIAAgDQAAgEgCgDQgDgDgDAAIgMAAg");
	this.shape_130.setTransform(271.425,167.625);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AgQAcIAAg3IAQAAQAJAAAEAEQAEAEAAAHIAAAFQAAAHgEAEQgEAEgJAAIgJAAIAAAUgAgJACIAJAAQAFAAADgCQADgCgBgFIAAgFQABgEgDgDQgDgDgFAAIgJAAg");
	this.shape_131.setTransform(266.45,167.625);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_132.setTransform(261.125,170.05);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AgKAYQgEgFAAgKIgHAAIAAgFIAHAAIAAgHIgHAAIAAgFIAHAAQAAgKAEgFQAFgFAJAAQAIAAAFAFQAGAFAAAKIAAACIgHAAIAAgCQAAgHgDgEQgEgDgFAAQgGAAgDADQgDAEAAAHIAPAAIAAAFIgPAAIAAAHIANAAIAAAFIgNAAQAAAHADAEQADADAGAAQAFAAAEgDQADgEAAgHIAAgCIAHAAIAAACQAAAKgGAFQgFAFgIAAQgJAAgFgFg");
	this.shape_133.setTransform(257.2,167.625);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AgMAZQgFgFABgHIAAgBIAGAAIAAABQAAAFADADQADACAEAAQAGAAADgDQADgDAAgHIAAgJIgGAEQgDACgDAAQgIAAgEgFQgFgEgBgHIAAgCQABgIAFgFQAEgEAIAAQAJAAAFAFQAEAEABAIIAAAVQgBAJgEAFQgFAFgJAAQgHAAgFgEgAgHgTQgEACAAAGIAAACQAAAFAEADQADACAEAAQAGAAADgCQADgDAAgFIAAgCQAAgGgDgCQgEgDgFAAQgEAAgDADg");
	this.shape_134.setTransform(252,167.625);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AgRAdIAAgFQAAgGADgEQACgFAHgDIAGgEQAFgCACgDQACgDAAgEIAAgBQAAgFgDgDQgCgDgFAAQgEAAgDADQgDADAAAGIAAACIgGAAIAAgCQAAgIAEgFQAFgFAHAAQAIAAAEAFQAFAEAAAIIAAABQAAAGgDAEQgEAEgGAEIgGAEQgFACgBACQgCADAAAEIAcAAIAAAGg");
	this.shape_135.setTransform(247.375,167.575);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AgEAIIACgEIACgDIAAgEIAAgGIAFAAIAAAGIgBAFIgCAFIgCADg");
	this.shape_136.setTransform(243.775,170.725);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_137.setTransform(240.525,167.625);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AgMAZQgGgFAAgIIAAgCIAHAAIAAACQAAAFADADQADADAFAAQAFAAADgCQAEgDAAgFIAAgBQAAgFgEgCQgDgDgFAAIgDAAIAAgFIADAAQAEAAADgCQADgCAAgFIAAgBQAAgEgDgDQgCgCgFAAQgEAAgEACQgCADAAAFIAAACIgHAAIAAgCQAAgIAFgEQAFgEAHAAQAIAAAEAEQAEAEAAAGIAAACQAAAEgBADQgCADgFACQAFAAADAEQACADAAAFIAAACQAAAHgEAEQgGAEgIAAQgIAAgEgEg");
	this.shape_138.setTransform(235.6,167.625);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_139.setTransform(230.875,167.625);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_140.setTransform(227.275,170.05);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("AgNAZQgFgEAAgHIAAgCQAAgFADgDQACgEAFAAQgEgCgCgDQgCgDAAgEIAAgCQAAgGAFgEQAEgEAHAAQAIAAAFAEQAEAEAAAGIAAACQAAAEgCADQgCADgEACQAFAAADAEQACADAAAFIAAACQAAAHgFAEQgFAEgJAAQgIAAgFgEgAgIAEQgDADAAAFIAAABQAAAFADADQADACAFAAQAGAAADgCQAEgDAAgFIAAgBQAAgFgEgDQgDgCgGAAQgFAAgDACgAgHgUQgCADAAAEIAAABQAAAFACACQADADAEAAQAFAAADgDQADgCAAgFIAAgBQAAgEgDgDQgDgCgFAAQgEAAgDACg");
	this.shape_141.setTransform(223.775,167.625);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#000000").s().p("AgMAZQgGgFAAgIIAAgCIAHAAIAAACQAAAFADADQADADAFAAQAFAAADgCQAEgDAAgFIAAgBQAAgFgEgCQgDgDgFAAIgDAAIAAgFIADAAQAEAAADgCQADgCAAgFIAAgBQAAgEgDgDQgCgCgFAAQgEAAgEACQgCADAAAFIAAACIgHAAIAAgCQAAgIAFgEQAFgEAHAAQAIAAAEAEQAEAEAAAGIAAACQAAAEgBADQgCADgFACQAFAAADAEQACADAAAFIAAACQAAAHgEAEQgGAEgIAAQgIAAgEgEg");
	this.shape_142.setTransform(218.95,167.625);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#000000").s().p("AgDAWIAAgIIAHAAIAAAIgAgDgNIAAgIIAHAAIAAAIg");
	this.shape_143.setTransform(213.825,168.275);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_144.setTransform(210.125,167.625);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#000000").s().p("AgSAcIAAg3IASAAQAIAAAGAFQAEAGAAAKIAAANQAAAKgEAGQgGAFgIAAgAgLAWIALAAQAFAAADgDQAEgEAAgHIAAgPQAAgHgEgDQgDgEgFAAIgLAAg");
	this.shape_145.setTransform(205,167.625);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgFAAIAAg3IAEAAIAbArIAAgrIAHAAIAAA3g");
	this.shape_146.setTransform(199.55,167.625);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_147.setTransform(194.2,167.625);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_148.setTransform(190.525,167.625);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_149.setTransform(186.875,167.625);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgFAAIAAg3IAEAAIAbArIAAgrIAHAAIAAA3g");
	this.shape_150.setTransform(181.55,167.625);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_151.setTransform(176.2,167.625);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgHAAIAAg3IAGAAIAaArIAAgrIAHAAIAAA3g");
	this.shape_152.setTransform(170.9,167.625);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_153.setTransform(166.975,167.625);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAAUIAUAAIAAAFIgUAAIAAAYg");
	this.shape_154.setTransform(163.95,167.625);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_155.setTransform(157.225,167.625);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_156.setTransform(153.475,167.625);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_157.setTransform(149.825,167.625);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_158.setTransform(145.275,167.625);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#000000").s().p("AAMAcIgMgWIgMAAIAAAWIgGAAIAAg3IASAAQAGAAAFAEQAEAEAAAHIAAADQAAAGgCADQgDADgFACIAOAXgAgMAAIAMAAQADAAADgBQACgDAAgFIAAgDQAAgEgCgDQgDgDgDAAIgMAAg");
	this.shape_159.setTransform(140.625,167.625);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#000000").s().p("AgQAcIAAg3IARAAQAHAAAFAEQAEAEAAAHIAAAFQAAAHgEAEQgFAEgHAAIgKAAIAAAUgAgJACIAKAAQAEAAADgCQACgCABgFIAAgFQgBgEgCgDQgDgDgEAAIgKAAg");
	this.shape_160.setTransform(135.65,167.625);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_161.setTransform(130.325,170.05);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_162.setTransform(126.875,167.625);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_163.setTransform(122.475,167.625);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgFAAIAAg3IAEAAIAbArIAAgrIAHAAIAAA3g");
	this.shape_164.setTransform(117.3,167.625);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_165.setTransform(111.875,167.625);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_166.setTransform(108.125,167.625);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_167.setTransform(104.475,167.625);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_168.setTransform(100.775,167.625);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#000000").s().p("AgSAcIAAg3IASAAQAIAAAGAFQAEAGAAAKIAAANQAAAKgEAGQgGAFgIAAgAgLAWIALAAQAFAAADgDQAEgEAAgHIAAgPQAAgHgEgDQgDgEgFAAIgLAAg");
	this.shape_169.setTransform(97.1,167.625);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgFAAIAAg3IAEAAIAbArIAAgrIAGAAIAAA3g");
	this.shape_170.setTransform(91.65,167.625);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_171.setTransform(86.225,167.625);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_172.setTransform(81.125,167.625);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_173.setTransform(74.225,167.625);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#000000").s().p("AgSAcIAAg3IASAAQAIAAAGAFQAEAGAAAKIAAANQAAAKgEAGQgGAFgIAAgAgLAWIALAAQAFAAADgDQAEgEAAgHIAAgPQAAgHgEgDQgDgEgFAAIgLAAg");
	this.shape_174.setTransform(69.1,167.625);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgFAAIAAg3IAEAAIAbArIAAgrIAHAAIAAA3g");
	this.shape_175.setTransform(63.65,167.625);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_176.setTransform(58.875,167.625);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_177.setTransform(55.325,167.625);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_178.setTransform(52.325,167.625);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#000000").s().p("AgQAcIAAg3IAQAAQAJAAAEAEQAEAEAAAHIAAAFQAAAHgEAEQgEAEgJAAIgJAAIAAAUgAgJACIAJAAQAFAAADgCQADgCgBgFIAAgFQABgEgDgDQgDgDgFAAIgJAAg");
	this.shape_179.setTransform(47.75,167.625);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#000000").s().p("AAVAcIAAgoIgTAlIgDAAIgTglIAAAoIgGAAIAAg3IAGAAIAUArIAWgrIAFAAIAAA3g");
	this.shape_180.setTransform(41.675,167.625);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#000000").s().p("AgNAXQgFgFAAgJIAAglIAGAAIAAAlQAAAHAEADQADAEAFAAQAGAAAEgEQADgDAAgHIAAglIAGAAIAAAlQAAAJgFAFQgFAGgJAAQgIAAgFgGg");
	this.shape_181.setTransform(35.475,167.675);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_182.setTransform(30.325,167.625);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_183.setTransform(191.675,160.95);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#000000").s().p("AgKAYQgEgFAAgKIgIAAIAAgFIAIAAIAAgHIgIAAIAAgFIAIAAQAAgKAEgFQAGgFAIAAQAJAAAFAFQAEAFAAAKIAAACIgGAAIAAgCQAAgHgDgEQgEgDgFAAQgFAAgEADQgDAEAAAHIAPAAIAAAFIgPAAIAAAHIAMAAIAAAFIgMAAQAAAHADAEQAEADAFAAQAFAAAEgDQADgEAAgHIAAgCIAGAAIAAACQAAAKgEAFQgFAFgJAAQgIAAgGgFg");
	this.shape_184.setTransform(187.75,158.525);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#000000").s().p("AgRAdIAAgFQAAgGADgEQACgFAHgDIAGgEQAFgCACgDQACgDAAgEIAAgBQAAgFgDgDQgCgDgFAAQgEAAgDADQgDADAAAGIAAACIgGAAIAAgCQAAgIAEgFQAFgFAHAAQAIAAAEAFQAFAEAAAIIAAABQAAAGgDAEQgEAEgGAEIgGAEQgFACgBACQgCADAAAEIAcAAIAAAGg");
	this.shape_185.setTransform(182.825,158.475);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#000000").s().p("AgEAcIAAgHIABgKIAGgMIAGgMIACgIIgVAAIAAAIIgHAAIAAgOIAjAAIAAAFIgCAJIgGANQgFAHgCAFIgBAJIAAAHg");
	this.shape_186.setTransform(178.425,158.525);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#000000").s().p("AgEAIIACgEIACgDIAAgEIAAgGIAFAAIAAAGIgBAFIgCAFIgCADg");
	this.shape_187.setTransform(175.125,161.625);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#000000").s().p("AAFAcIAAgwIgNAJIgDgFIARgLIAGAAIAAA3g");
	this.shape_188.setTransform(172.25,158.525);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#000000").s().p("AgMAZQgEgFgBgHIAAgBIAHAAIAAABQAAAFADADQADACAEAAQAGAAADgDQADgDAAgHIAAgJIgFAEQgEACgDAAQgIAAgEgFQgGgEABgHIAAgCQgBgIAGgFQAEgEAIAAQAIAAAGAFQAEAEAAAIIAAAVQAAAJgEAFQgFAFgJAAQgHAAgFgEgAgIgTQgDACAAAGIAAACQAAAFADADQADACAFAAQAGAAADgCQADgDAAgFIAAgCQAAgGgDgCQgEgDgFAAQgFAAgDADg");
	this.shape_189.setTransform(168.35,158.525);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_190.setTransform(163.575,158.525);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_191.setTransform(159.975,160.95);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_192.setTransform(156.525,158.525);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#000000").s().p("AgNAZQgEgFAAgIIAAgCIAGAAIAAACQAAAFADADQAEADAEAAQAGAAADgCQADgDAAgFIAAgBQAAgFgDgCQgDgDgGAAIgEAAIAAgFIAEAAQAEAAADgCQADgCAAgFIAAgBQAAgEgCgDQgDgCgFAAQgEAAgDACQgDADAAAFIAAACIgGAAIAAgCQAAgIAEgEQAEgEAIAAQAHAAAFAEQAEAEABAGIAAACQAAAEgCADQgDADgDACQAEAAADAEQACADAAAFIAAACQABAHgGAEQgEAEgJAAQgHAAgGgEg");
	this.shape_193.setTransform(151.6,158.525);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#000000").s().p("AgDAWIAAgIIAHAAIAAAIgAgDgNIAAgIIAHAAIAAAIg");
	this.shape_194.setTransform(294.825,150.075);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_195.setTransform(291.125,149.425);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#000000").s().p("AgSAcIAAg3IASAAQAIAAAGAFQAEAGAAAKIAAANQAAAKgEAGQgGAFgIAAgAgLAWIALAAQAFAAADgDQAEgEAAgHIAAgPQAAgHgEgDQgDgEgFAAIgLAAg");
	this.shape_196.setTransform(286,149.425);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_197.setTransform(280.75,149.425);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#000000").s().p("AgRAcIAAg3IARAAQAJAAAEAFQAGAGAAAKIAAANQAAAKgGAGQgEAFgJAAgAgLAWIALAAQAGAAADgDQADgEAAgHIAAgPQAAgHgDgDQgDgEgGAAIgLAAg");
	this.shape_198.setTransform(275.7,149.425);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#000000").s().p("AgNAXQgFgFAAgJIAAglIAGAAIAAAlQAAAHAEADQADAEAFAAQAGAAAEgEQADgDAAgHIAAglIAGAAIAAAlQAAAJgFAFQgFAGgJAAQgIAAgFgGg");
	this.shape_199.setTransform(270.325,149.475);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_200.setTransform(265.675,149.425);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#000000").s().p("AgRAcIAAg3IARAAQAJAAAEAFQAGAGAAAKIAAANQAAAKgGAGQgEAFgJAAgAgLAWIALAAQAFAAAEgDQADgEAAgHIAAgPQAAgHgDgDQgEgEgFAAIgLAAg");
	this.shape_201.setTransform(260.75,149.425);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_202.setTransform(255.5,149.425);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_203.setTransform(249.425,149.425);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_204.setTransform(244.5,149.425);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#000000").s().p("AgDAcIAAgxIgQAAIAAgGIAnAAIAAAGIgRAAIAAAxg");
	this.shape_205.setTransform(239.7,149.425);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_206.setTransform(234.775,149.425);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgRAAIAAAxg");
	this.shape_207.setTransform(229.9,149.425);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_208.setTransform(223.925,149.425);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#000000").s().p("AgDAcIAAgxIgQAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_209.setTransform(219.25,149.425);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#000000").s().p("AAMAcIgMgWIgMAAIAAAWIgGAAIAAg3IASAAQAGAAAFAEQAEAEAAAHIAAADQAAAGgCADQgDADgFACIAOAXgAgMAAIAMAAQADAAADgBQACgDAAgFIAAgDQAAgEgCgDQgDgDgDAAIgMAAg");
	this.shape_210.setTransform(214.725,149.425);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_211.setTransform(209.325,149.425);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#000000").s().p("AgQAcIAAg3IARAAQAHAAAFAEQAEAEAAAHIAAAFQAAAHgEAEQgFAEgHAAIgKAAIAAAUgAgJACIAKAAQAEAAADgCQACgCABgFIAAgFQgBgEgCgDQgDgDgEAAIgKAAg");
	this.shape_212.setTransform(204.5,149.425);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#000000").s().p("AAVAcIAAgoIgTAlIgDAAIgTglIAAAoIgGAAIAAg3IAGAAIAUArIAWgrIAFAAIAAA3g");
	this.shape_213.setTransform(198.425,149.425);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_214.setTransform(193.775,149.425);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_215.setTransform(189.825,151.85);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_216.setTransform(186.375,149.425);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_217.setTransform(181.975,149.425);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_218.setTransform(177.175,149.425);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_219.setTransform(172.775,149.425);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#000000").s().p("AAVAcIAAgoIgTAlIgDAAIgTglIAAAoIgGAAIAAg3IAGAAIAUArIAWgrIAFAAIAAA3g");
	this.shape_220.setTransform(166.825,149.425);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_221.setTransform(159.225,149.425);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#000000").s().p("AgNAZQgEgFAAgIIAAgCIAGAAIAAACQAAAFADADQAEADAEAAQAGAAADgCQADgDAAgFIAAgBQAAgFgDgCQgDgDgGAAIgEAAIAAgFIAEAAQAEAAADgCQADgCAAgFIAAgBQAAgEgCgDQgDgCgFAAQgEAAgEACQgCADAAAFIAAACIgGAAIAAgCQAAgIAEgEQAEgEAIAAQAHAAAFAEQAEAEABAGIAAACQAAAEgCADQgDADgDACQAEAAADAEQACADABAFIAAACQAAAHgGAEQgEAEgJAAQgHAAgGgEg");
	this.shape_222.setTransform(154.3,149.425);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_223.setTransform(147.625,149.425);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#000000").s().p("AgSAcIAAgFIAcgsIgbAAIAAgGIAjAAIAAAFIgcAsIAdAAIAAAGg");
	this.shape_224.setTransform(142.75,149.425);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgHAAIAUg3IAFAAIATA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_225.setTransform(137.9,149.425);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_226.setTransform(133.525,149.425);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#000000").s().p("AgQAcIAAg3IAQAAQAJAAAEAEQAEAEAAAHIAAAFQAAAHgEAEQgEAEgJAAIgKAAIAAAUgAgKACIAKAAQAFAAADgCQACgCAAgFIAAgFQAAgEgCgDQgDgDgFAAIgKAAg");
	this.shape_227.setTransform(128.95,149.425);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_228.setTransform(123.625,151.85);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#000000").s().p("AgKAYQgEgFAAgKIgHAAIAAgFIAHAAIAAgHIgHAAIAAgFIAHAAQAAgKAEgFQAGgFAIAAQAJAAAEAFQAGAFAAAKIAAACIgHAAIAAgCQAAgHgDgEQgEgDgFAAQgFAAgEADQgDAEAAAHIAPAAIAAAFIgPAAIAAAHIANAAIAAAFIgNAAQAAAHADAEQAEADAFAAQAFAAAEgDQADgEAAgHIAAgCIAHAAIAAACQAAAKgGAFQgEAFgJAAQgIAAgGgFg");
	this.shape_229.setTransform(119.7,149.425);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#000000").s().p("AAFAcIAAgwIgNAJIgCgFIAQgLIAGAAIAAA3g");
	this.shape_230.setTransform(115,149.425);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#000000").s().p("AgNAZQgFgEAAgHIAAgCQAAgFADgDQACgEAFAAQgEgCgCgDQgCgDAAgEIAAgCQAAgGAFgEQAEgEAHAAQAIAAAFAEQAEAEAAAGIAAACQAAAEgCADQgCADgEACQAFAAADAEQACADAAAFIAAACQAAAHgFAEQgFAEgJAAQgIAAgFgEgAgIAEQgDADAAAFIAAABQAAAFADADQADACAFAAQAGAAADgCQAEgDAAgFIAAgBQAAgFgEgDQgDgCgGAAQgFAAgDACgAgHgUQgCADAAAEIAAABQAAAFACACQADADAEAAQAFAAADgDQADgCAAgFIAAgBQAAgEgDgDQgDgCgFAAQgEAAgDACg");
	this.shape_231.setTransform(111.175,149.425);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#000000").s().p("AgEAIIACgEIACgDIAAgEIAAgGIAFAAIAAAGIgBAFIgCAFIgCADg");
	this.shape_232.setTransform(107.475,152.525);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#000000").s().p("AAFAcIAAgwIgMAJIgEgFIARgLIAGAAIAAA3g");
	this.shape_233.setTransform(104.6,149.425);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#000000").s().p("AgRAdIAAgFQAAgGADgEQACgFAHgDIAGgEQAFgCACgDQACgDAAgEIAAgBQAAgFgDgDQgCgDgFAAQgEAAgDADQgDADAAAGIAAACIgGAAIAAgCQAAgIAEgFQAFgFAHAAQAIAAAEAFQAFAEAAAIIAAABQAAAGgDAEQgEAEgGAEIgGAEQgFACgBACQgCADAAAEIAcAAIAAAGg");
	this.shape_234.setTransform(100.975,149.375);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#000000").s().p("AAFAcIAAgwIgNAJIgDgFIARgLIAGAAIAAA3g");
	this.shape_235.setTransform(96.65,149.425);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_236.setTransform(94.175,151.85);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#000000").s().p("AgNAYQgEgFgBgKIAAgRQABgKAEgFQAFgFAIAAQAIAAAGAFQAEAFAAAKIAAARQAAAKgEAFQgGAFgIAAQgIAAgFgFgAgIgTQgDAEAAAGIAAATQAAAGADAEQADADAFAAQAFAAADgDQADgEAAgGIAAgTQAAgGgDgEQgDgDgFAAQgFAAgDADg");
	this.shape_237.setTransform(90.6,149.425);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#000000").s().p("AgMAZQgGgFAAgIIAAgCIAHAAIAAACQAAAFADADQADADAFAAQAFAAADgCQAEgDAAgFIAAgBQAAgFgEgCQgDgDgFAAIgDAAIAAgFIADAAQAEAAADgCQADgCAAgFIAAgBQAAgEgCgDQgEgCgEAAQgFAAgDACQgCADAAAFIAAACIgHAAIAAgCQABgIAEgEQAFgEAHAAQAIAAAEAEQAEAEABAGIAAACQgBAEgBADQgDADgEACQAFAAADAEQADADgBAFIAAACQAAAHgEAEQgGAEgIAAQgIAAgEgEg");
	this.shape_238.setTransform(85.65,149.425);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#000000").s().p("AgDAWIAAgIIAHAAIAAAIgAgDgNIAAgIIAHAAIAAAIg");
	this.shape_239.setTransform(80.525,150.075);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_240.setTransform(77.475,149.425);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_241.setTransform(72.8,149.425);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#000000").s().p("AAMAcIgMgWIgMAAIAAAWIgGAAIAAg3IASAAQAGAAAFAEQAEAEAAAHIAAADQAAAGgCADQgDADgFACIAOAXgAgMAAIAMAAQADAAADgBQACgDAAgFIAAgDQAAgEgCgDQgDgDgDAAIgMAAg");
	this.shape_242.setTransform(68.275,149.425);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_243.setTransform(62.875,149.425);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#000000").s().p("AgQAcIAAg3IARAAQAHAAAFAEQAEAEAAAHIAAAFQAAAHgEAEQgFAEgHAAIgLAAIAAAUgAgKACIALAAQAFAAACgCQADgCAAgFIAAgFQAAgEgDgDQgCgDgFAAIgLAAg");
	this.shape_244.setTransform(58.05,149.425);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#000000").s().p("AAVAcIAAgoIgTAlIgDAAIgTglIAAAoIgGAAIAAg3IAGAAIAUArIAWgrIAFAAIAAA3g");
	this.shape_245.setTransform(51.975,149.425);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_246.setTransform(47.325,149.425);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#000000").s().p("AgJAYQgFgFgBgKIgGAAIAAgFIAGAAIAAgHIgGAAIAAgFIAGAAQABgKAFgFQAFgFAHAAQAKAAAFAFQAEAFABAKIAAACIgHAAIAAgCQAAgHgDgEQgDgDgHAAQgFAAgDADQgDAEAAAHIAPAAIAAAFIgPAAIAAAHIANAAIAAAFIgNAAQAAAHADAEQADADAFAAQAHAAADgDQADgEAAgHIAAgCIAHAAIAAACQgBAKgEAFQgFAFgKAAQgHAAgFgFg");
	this.shape_247.setTransform(228.65,140.225);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#000000").s().p("AgEAcIAAgHIABgKIAGgMIAGgMIACgIIgVAAIAAAIIgHAAIAAgOIAjAAIAAAFIgCAJIgGANQgFAHgCAFIgBAJIAAAHg");
	this.shape_248.setTransform(223.875,140.225);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#000000").s().p("AgNAYQgFgFABgKIAAgRQgBgKAFgFQAFgFAIAAQAJAAAEAFQAGAFAAAKIAAARQAAAKgGAFQgEAFgJAAQgIAAgFgFgAgIgTQgDAEAAAGIAAATQAAAGADAEQADADAFAAQAFAAAEgDQADgEAAgGIAAgTQAAgGgDgEQgEgDgFAAQgFAAgDADg");
	this.shape_249.setTransform(219.35,140.225);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#000000").s().p("AgEAIIACgEIACgDIAAgEIAAgGIAFAAIAAAGIgBAFIgCAFIgCADg");
	this.shape_250.setTransform(215.525,143.325);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#000000").s().p("AgMAZQgFgFABgHIAAgBIAGAAIAAABQAAAFADADQADACAEAAQAGAAADgDQADgDAAgHIAAgJIgGAEQgDACgDAAQgIAAgFgFQgEgEAAgHIAAgCQAAgIAEgFQAGgEAHAAQAJAAAEAFQAGAEAAAIIAAAVQAAAJgGAFQgEAFgJAAQgHAAgFgEgAgHgTQgEACAAAGIAAACQAAAFAEADQADACAEAAQAGAAADgCQADgDAAgFIAAgCQAAgGgDgCQgDgDgGAAQgEAAgDADg");
	this.shape_251.setTransform(212.15,140.225);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAHAAQAAAFACADQADADAFAAQAFAAADgDQADgDAAgGIAAgDQAAgGgDgCQgDgDgFAAQgDAAgDACIgEAEIgGgBIACgeIAdAAIAAAGIgXAAIgBASIAEgDIAGgBQAIAAAFAEQAEAEAAAIIAAADQAAAIgFAFQgFAFgIAAQgIAAgEgFg");
	this.shape_252.setTransform(207.5,140.275);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_253.setTransform(202.725,140.225);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_254.setTransform(199.125,142.65);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#000000").s().p("AgMAZQgFgFAAgHIAAgBIAHAAIAAABQAAAFADADQADACAEAAQAGAAADgDQADgDAAgHIAAgJIgFAEQgEACgDAAQgIAAgEgFQgGgEAAgHIAAgCQAAgIAGgFQAEgEAIAAQAIAAAGAFQAEAEAAAIIAAAVQAAAJgEAFQgFAFgJAAQgHAAgFgEgAgIgTQgDACAAAGIAAACQAAAFADADQAEACAEAAQAGAAADgCQADgDAAgFIAAgCQAAgGgDgCQgDgDgGAAQgEAAgEADg");
	this.shape_255.setTransform(195.55,140.225);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#000000").s().p("AgDAWIAAgIIAHAAIAAAIgAgDgNIAAgIIAHAAIAAAIg");
	this.shape_256.setTransform(190.375,140.875);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgHAAIAUg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_257.setTransform(186.75,140.225);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#000000").s().p("AgSAcIAAg3IASAAQAIAAAGAFQAEAGAAAKIAAANQAAAKgEAGQgGAFgIAAgAgLAWIALAAQAFAAADgDQAEgEAAgHIAAgPQAAgHgEgDQgDgEgFAAIgLAAg");
	this.shape_258.setTransform(181.7,140.225);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_259.setTransform(176.45,140.225);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#000000").s().p("AAMAcIgMgWIgMAAIAAAWIgGAAIAAg3IASAAQAGAAAFAEQAEAEAAAHIAAADQAAAGgCADQgDADgFACIAOAXgAgMAAIAMAAQADAAADgBQACgDAAgFIAAgDQAAgEgCgDQgDgDgDAAIgMAAg");
	this.shape_260.setTransform(171.675,140.225);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_261.setTransform(166.65,140.225);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgGAAIAAg3IAEAAIAbArIAAgrIAGAAIAAA3g");
	this.shape_262.setTransform(161.6,140.225);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_263.setTransform(156.825,140.225);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#000000").s().p("AgFAGIAAgLIALAAIAAALg");
	this.shape_264.setTransform(151.6,142.475);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#000000").s().p("AAKAaQgDgDAAgFIAAgGQAAgGADgDQADgDAFAAQAFAAADADQADADAAAGIAAAGQAAAFgDADQgDADgFAAQgFAAgDgDgAAPAIIgBADIAAAHIABADQAAABABAAQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIABgDIAAgHIgBgDQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAgBAAIgDABgAgTAcIAfg3IAIAAIgfA3gAgZgCQgDgDAAgFIAAgHQAAgFADgDQADgDAFAAQAFAAADADQADADAAAFIAAAHQAAAFgDADQgDACgFAAQgFAAgDgCgAgUgUIgBADIAAAHIABADIADABIADgBIABgDIAAgHIgBgDIgDgBIgDABg");
	this.shape_265.setTransform(147.275,140.225);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#000000").s().p("AgGAcIAAgGIABgKIAGgMIAFgKIACgIIgQAAIAAAHIgKAAIAAgQIAlAAIAAAIIgCAJIgGALIgGAMQgBAEAAAFIAAAGg");
	this.shape_266.setTransform(141.925,140.225);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#000000").s().p("AgGAcIAAgGIABgKIAGgMIAFgKIACgIIgQAAIAAAHIgKAAIAAgQIAlAAIAAAIIgCAJIgGALIgGAMQgBAEAAAFIAAAGg");
	this.shape_267.setTransform(137.725,140.225);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#000000").s().p("AgFAHIABgDIACgDIABgEIAAgIIAHAAIAAAHIAAAHIgEAGIgCADg");
	this.shape_268.setTransform(134.375,143.2);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#000000").s().p("AgMAZQgFgFgBgIIAAAAIALAAIAAAAQAAAEACACQACACADAAQAFAAACgCQADgDAAgEIAAgIIgFADIgGABQgIAAgFgFQgFgDAAgIIAAgBQABgJAFgEQAEgFAJAAQAKAAAEAFQAFAFABAJIAAASQgBAKgFAFQgEAFgKAAQgIAAgEgEgAgGgRQgDACAAAFIAAABQAAAEADACQADACADAAQAFAAACgCQADgCAAgEIAAgBQAAgFgDgCQgCgCgFAAQgDAAgDACg");
	this.shape_269.setTransform(130.95,140.225);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#000000").s().p("AgEAWIAAgLIAJAAIAAALgAgEgKIAAgLIAJAAIAAALg");
	this.shape_270.setTransform(126,140.85);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#000000").s().p("AgQAcIAAg3IAhAAIAAAJIgWAAIAAAOIASAAIAAAIIgSAAIAAAPIAWAAIAAAJg");
	this.shape_271.setTransform(122.85,140.225);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#000000").s().p("AANAcIgEgLIgSAAIgEALIgKAAIATg3IAJAAIATA3gAAHAIIgHgWIgGAWIANAAg");
	this.shape_272.setTransform(117.825,140.225);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#000000").s().p("AgEAcIAAguIgQAAIAAgJIApAAIAAAJIgQAAIAAAug");
	this.shape_273.setTransform(112.875,140.225);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_274.setTransform(268.925,133.45);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#000000").s().p("AAKAaQgCgCAAgFIAAgIQAAgFACgCQADgDAFAAQAEAAADADQACACAAAFIAAAIQAAAEgCADQgDADgEAAQgFAAgDgDgAAOAHQAAABAAAAQgBAAAAABQAAAAAAABQAAAAAAABIAAAIQAAAAAAABQAAABAAAAQAAABABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAAAIABgEIAAgIIgBgEQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABQAAAAgBAAgAgSAcIAgg3IAFAAIggA3gAgYgCQgCgDAAgFIAAgHQAAgFACgDQADgDAFAAQAEAAADADQADADAAAFIAAAHQAAAFgDADQgDACgEAAQgFAAgDgCgAgUgWIgBAFIAAAHIABAEQABABAAAAQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBIAAgHQAAgBAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABQAAAAgBAAg");
	this.shape_275.setTransform(264.675,131.025);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#000000").s().p("AgNAZQgFgEAAgHIAAgCQAAgFADgDQACgEAFAAQgEgCgCgDQgCgDAAgEIAAgCQAAgGAFgEQAEgEAHAAQAIAAAFAEQAEAEAAAGIAAACQAAAEgCADQgCADgEACQAFAAADAEQACADAAAFIAAACQAAAHgFAEQgFAEgJAAQgIAAgFgEgAgIAEQgDADAAAFIAAABQAAAFADADQADACAFAAQAGAAADgCQAEgDAAgFIAAgBQAAgFgEgDQgDgCgGAAQgFAAgDACgAgHgUQgCADAAAEIAAABQAAAFACACQADADAEAAQAFAAADgDQADgCAAgFIAAgBQAAgEgDgDQgDgCgFAAQgEAAgDACg");
	this.shape_276.setTransform(259.075,131.025);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#000000").s().p("AgEAIIACgEIACgDIAAgEIAAgGIAFAAIAAAGIgBAFIgCAFIgCADg");
	this.shape_277.setTransform(255.375,134.125);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#000000").s().p("AgEAcIAAgHQAAgFABgFIAGgMIAGgMIACgIIgVAAIAAAIIgHAAIAAgOIAjAAIAAAFIgCAJIgGANQgFAHgCAFIgBAJIAAAHg");
	this.shape_278.setTransform(252.425,131.025);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#000000").s().p("AgDAWIAAgIIAHAAIAAAIgAgDgNIAAgIIAHAAIAAAIg");
	this.shape_279.setTransform(247.625,131.675);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#000000").s().p("AAOAcIgagrIAAArIgHAAIAAg3IAGAAIAaArIAAgrIAHAAIAAA3g");
	this.shape_280.setTransform(243.8,131.025);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_281.setTransform(239.875,131.025);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#000000").s().p("AgDAcIAAgxIgQAAIAAgGIAnAAIAAAGIgRAAIAAAxg");
	this.shape_282.setTransform(236.45,131.025);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_283.setTransform(231.375,133.45);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#000000").s().p("AgJAYQgGgFABgKIgIAAIAAgFIAIAAIAAgHIgIAAIAAgFIAIAAQgBgKAGgFQAEgFAIAAQAJAAAGAFQAEAFAAAKIAAACIgGAAIAAgCQAAgHgDgEQgEgDgGAAQgEAAgEADQgDAEAAAHIAPAAIAAAFIgPAAIAAAHIAMAAIAAAFIgMAAQAAAHADAEQAEADAEAAQAGAAAEgDQADgEAAgHIAAgCIAGAAIAAACQAAAKgEAFQgGAFgJAAQgIAAgEgFg");
	this.shape_284.setTransform(227.45,131.025);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#000000").s().p("AgEAcIAAgHIABgKIAGgMIAGgMIACgIIgVAAIAAAIIgHAAIAAgOIAjAAIAAAFIgCAJIgGANQgFAHgCAFIgBAJIAAAHg");
	this.shape_285.setTransform(222.675,131.025);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#000000").s().p("AgMAZQgFgFAAgHIAAgBIAHAAIAAABQAAAFADADQADACAEAAQAGAAADgDQADgDAAgHIAAgJIgGAEQgDACgDAAQgIAAgEgFQgFgEgBgHIAAgCQABgIAFgFQAEgEAIAAQAJAAAFAFQAEAEAAAIIAAAVQAAAJgEAFQgFAFgJAAQgHAAgFgEgAgIgTQgDACAAAGIAAACQAAAFADADQADACAFAAQAGAAADgCQADgDAAgFIAAgCQAAgGgDgCQgDgDgGAAQgFAAgDADg");
	this.shape_286.setTransform(218.15,131.025);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#000000").s().p("AgEAIIACgEIACgDIAAgEIAAgGIAFAAIAAAGIgBAFIgCAFIgCADg");
	this.shape_287.setTransform(214.475,134.125);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#000000").s().p("AgRAdIAAgFQAAgGADgEQACgFAHgDIAGgEQAFgCACgDQACgDAAgEIAAgBQAAgFgDgDQgCgDgFAAQgEAAgDADQgDADAAAGIAAACIgGAAIAAgCQAAgIAEgFQAFgFAHAAQAIAAAEAFQAFAEAAAIIAAABQAAAGgDAEQgEAEgGAEIgGAEQgFACgBACQgCADAAAEIAcAAIAAAGg");
	this.shape_288.setTransform(211.375,130.975);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#000000").s().p("AAKAcIAAgMIgaAAIAAgFIAUgmIAGAAIgTAlIATAAIAAgLIAHAAIAAAdg");
	this.shape_289.setTransform(206.8,131.025);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#000000").s().p("AgNAYQgFgFABgKIAAgRQgBgKAFgFQAFgFAIAAQAJAAAEAFQAGAFAAAKIAAARQAAAKgGAFQgEAFgJAAQgIAAgFgFgAgIgTQgDAEAAAGIAAATQAAAGADAEQADADAFAAQAFAAAEgDQADgEAAgGIAAgTQAAgGgDgEQgEgDgFAAQgFAAgDADg");
	this.shape_290.setTransform(202.25,131.025);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_291.setTransform(198.625,133.45);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAAgVQAAgJAEgFQAFgFAIAAQAIAAAFAEQAEAFAAAHIAAABIgGAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDADQgDADAAAHIAAAJQACgDAEgBQADgCADAAQAIAAAFAFQAEAEAAAHIAAACQAAAIgEAFQgFAEgJAAQgIAAgEgFgAgIACQgDADAAAFIAAACQAAAGADACQADADAFAAQAGAAADgDQADgCAAgGIAAgCQAAgFgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_292.setTransform(195.175,131.025);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#000000").s().p("AgRAdIAAgFQAAgGADgEQACgFAHgDIAGgEQAFgCACgDQACgDAAgEIAAgBQAAgFgDgDQgCgDgFAAQgEAAgDADQgDADAAAGIAAACIgGAAIAAgCQAAgIAEgFQAFgFAHAAQAIAAAEAFQAFAEAAAIIAAABQAAAGgDAEQgEAEgGAEIgGAEQgFACgBACQgCADAAAEIAcAAIAAAGg");
	this.shape_293.setTransform(190.425,130.975);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#000000").s().p("AgDAWIAAgIIAHAAIAAAIgAgDgNIAAgIIAHAAIAAAIg");
	this.shape_294.setTransform(185.325,131.675);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_295.setTransform(181.7,131.025);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgRAAIAAAxg");
	this.shape_296.setTransform(176.9,131.025);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_297.setTransform(171.975,131.025);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#000000").s().p("AgNAXQgFgFAAgJIAAglIAGAAIAAAlQAAAHAEADQADAEAFAAQAGAAAEgEQADgDAAgHIAAglIAGAAIAAAlQAAAJgFAFQgFAGgJAAQgIAAgFgGg");
	this.shape_298.setTransform(166.675,131.075);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_299.setTransform(161.525,131.025);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#000000").s().p("AAPAcIgEgNIgWAAIgEANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgJAcIASAAg");
	this.shape_300.setTransform(154.7,131.025);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#000000").s().p("AAVAcIAAgoIgTAlIgDAAIgTglIAAAoIgGAAIAAg3IAGAAIAUArIAWgrIAFAAIAAA3g");
	this.shape_301.setTransform(148.625,131.025);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#000000").s().p("AgCAcIAAg3IAFAAIAAA3g");
	this.shape_302.setTransform(143.975,131.025);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#000000").s().p("AgCAcIAAgxIgRAAIAAgGIAnAAIAAAGIgQAAIAAAxg");
	this.shape_303.setTransform(140.55,131.025);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#000000").s().p("AgOAcIAAg3IAGAAIAAAxIAXAAIAAAGg");
	this.shape_304.setTransform(136.425,131.025);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#000000").s().p("AgNAdQgFgFAAgKIAAgkIAGAAIAAAlQAAAGAEAEQADADAFAAQAGAAAEgDQADgEAAgGIAAglIAGAAIAAAkQAAAKgFAFQgFAFgJAAQgIAAgFgFgAgCgaIAGgHIAHAAIgIAHg");
	this.shape_305.setTransform(131.375,130.525);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_306.setTransform(125.925,133.45);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#000000").s().p("AgNAZQgFgFAAgIIAAgBIAHAAIAAABQAAAGADACQADADAFAAQAGAAADgCQADgDAAgFQAAgEgCgCQgDgDgFgBIgEgBQgIgBgDgDQgEgEAAgHQAAgHAFgEQAEgEAIAAQAIAAAFAEQAFAEAAAIIAAABIgHAAIAAgBQAAgFgDgDQgDgCgFAAQgFAAgDACQgDADAAAEQAAAEADACQADADAFABIADABQAIABAEADQAEAEAAAHQAAAIgFAEQgFAEgJAAQgIAAgFgEg");
	this.shape_307.setTransform(122.475,131.025);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#000000").s().p("AAQAcIgFgNIgVAAIgFANIgGAAIATg3IAFAAIAUA3gAAJAJIgJgcIgIAcIARAAg");
	this.shape_308.setTransform(117.5,131.025);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#000000").s().p("AgDAcIAAgxIgQAAIAAgGIAnAAIAAAGIgRAAIAAAxg");
	this.shape_309.setTransform(112.7,131.025);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#000000").s().p("AgNAYQgGgGAAgKIAAgPQAAgKAGgGQAFgFAIAAQAKAAAFAFQAFAGAAAKIAAAPQAAAKgFAGQgFAFgKAAQgIAAgFgFgAgJgSQgDADAAAIIAAAQQAAAHADADQAEAEAFAAQAHAAADgEQADgDAAgHIAAgQQAAgIgDgDQgDgEgHAAQgFAAgEAEg");
	this.shape_310.setTransform(107.775,131.025);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#000000").s().p("AgNAXQgFgFAAgJIAAglIAGAAIAAAlQAAAHAEADQADAEAFAAQAGAAAEgEQADgDAAgHIAAglIAGAAIAAAlQAAAJgFAFQgFAGgJAAQgIAAgFgGg");
	this.shape_311.setTransform(102.475,131.075);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#000000").s().p("AgNAYQgFgFAAgKIAAgRQAAgJAFgGQAFgFAIAAQAJAAAFAFQAFAGAAAJIAAACIgGAAIAAgCQAAgHgEgDQgDgEgGAAQgFAAgDAEQgDADAAAHIAAARQAAAHADAEQADADAFAAQAGAAADgDQAEgEAAgHIAAgCIAGAAIAAACQAAAKgFAFQgFAFgJAAQgIAAgFgFg");
	this.shape_312.setTransform(97.325,131.025);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#000000").s().p("AgMAYQgFgEAAgIIAGAAQAAAFADADQADADAFAAQAFAAADgDQADgDAAgGIAAgDQAAgGgDgCQgDgDgFAAQgDAAgDACIgFAEIgFgBIADgeIAcAAIAAAGIgYAAIgBASIAGgDIAFgBQAIAAAFAEQAEAEAAAIIAAADQAAAIgFAFQgEAFgJAAQgIAAgEgFg");
	this.shape_313.setTransform(90.8,131.075);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#000000").s().p("AgMAZQgGgFABgIIAAgCIAGAAIAAACQAAAFADADQADADAFAAQAGAAACgCQAEgDAAgFIAAgBQAAgFgEgCQgCgDgGAAIgDAAIAAgFIADAAQAEAAADgCQADgCAAgFIAAgBQAAgEgCgDQgEgCgEAAQgEAAgEACQgCADAAAFIAAACIgHAAIAAgCQABgIAEgEQAEgEAIAAQAIAAAEAEQAEAEABAGIAAACQAAAEgCADQgCADgFACQAFAAADAEQADADgBAFIAAACQAAAHgEAEQgGAEgIAAQgIAAgEgEg");
	this.shape_314.setTransform(86,131.025);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#000000").s().p("AAOAcIgbgrIAAArIgGAAIAAg3IAGAAIAaArIAAgrIAHAAIAAA3g");
	this.shape_315.setTransform(79.2,131.025);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#000000").s().p("AgPAcIAAg3IAfAAIAAAGIgYAAIAAATIAUAAIAAAEIgUAAIAAAUIAYAAIAAAGg");
	this.shape_316.setTransform(74.425,131.025);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#000000").s().p("AAGATIgGgNIgFANIgEAFIgJgGIAEgFIAKgLIgOgCIgGgBIADgKIAGADIANAGIgCgOIAAgHIAJAAIAAAHIgCAOIANgGIAGgDIADAKIgGABIgOACIAKALIAEAFIgJAGg");
	this.shape_317.setTransform(199.525,112.475);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#000000").s().p("AgUAjQgIgGABgMIAAgCIANAAIAAACQAAAFAFADQADADAGAAQAHAAADgCQAEgDgBgFQAAgEgCgDQgDgCgGgCIgGgBQgLgDgHgEQgFgGAAgKQAAgKAIgHQAGgGANAAQAMAAAHAGQAIAHAAAKIAAADIgPAAIAAgDQAAgFgDgDQgEgDgFAAQgGABgDACQgEACAAAFQAAAEAEADQACADAHAAIAFACQAMACAFAFQAHAGAAAKQgBAMgHAGQgIAGgNAAQgMAAgIgGg");
	this.shape_318.setTransform(193.35,114.1);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#000000").s().p("AgXAoIAAhPIAuAAIAAANIgfAAIAAAVIAbAAIAAALIgbAAIAAAVIAgAAIAAANg");
	this.shape_319.setTransform(186.95,114.1);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#000000").s().p("AAbAoIAAgwIgWAqIgJAAIgWgqIAAAwIgNAAIAAhPIAMAAIAbA3IAcg3IAMAAIAABPg");
	this.shape_320.setTransform(178.6,114.1);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#000000").s().p("AgbAyIAohjIAPAAIgpBjg");
	this.shape_321.setTransform(170.5,114.625);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#000000").s().p("AgPAiQgIgHAAgNIgKAAIAAgJIAKAAIAAgIIgKAAIAAgJIAKAAQAAgOAIgHQAHgHANAAQAOAAAHAIQAHAHABAPIAAACIgPAAIAAgDQAAgIgDgEQgEgEgHAAQgGAAgEAEQgDADgBAIIASAAIAAAJIgSAAIAAAIIAQAAIAAAJIgQAAQAAAHAFAEQADADAGAAQAHAAAEgEQADgEAAgIIAAgDIAPAAIAAADQgBANgHAJQgHAHgOAAQgNAAgHgHg");
	this.shape_322.setTransform(163.95,114.1);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#000000").s().p("AgTAiQgHgHAAgLIAAgBIAOAAIAAABQAAAFAEAEQADADAFAAQAGAAADgDQADgEAAgGIAAgDQAAgHgDgDQgDgDgGABQgEAAgDABQgDABgCADIgMgCIADgrIAsAAIAAAOIggAAIgBASIAGgDIAHgBQALAAAHAGQAGAGAAALIAAAEQAAANgHAGQgHAHgNgBQgMABgHgHg");
	this.shape_323.setTransform(156.825,114.15);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#000000").s().p("AgUAiQgHgIAAgOIAAgWQAAgPAHgHQAHgIANAAQANAAAIAIQAHAHAAAPIAAAWQAAAOgHAIQgHAHgOAAQgNAAgHgHgAgJgWQgDADAAAIIAAAYQAAAIADADQADAEAGAAQAGAAAEgEQADgDAAgIIAAgYQAAgIgDgDQgEgFgGAAQgGAAgDAFg");
	this.shape_324.setTransform(149.975,114.1);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#000000").s().p("AgTAiQgIgGAAgMIAAgCIAOAAIAAACQAAAGAEADQAEADAFAAQAGAAADgDQAEgCAAgGIAAgBQAAgFgEgEQgDgCgGAAIgGAAIAAgKIAGAAQAFAAADgDQACgCAAgGIAAgBQAAgFgCgDQgDgCgFAAQgFAAgDACQgDAEAAAEIAAADIgPAAIAAgDQAAgKAHgHQAHgGAMAAQALAAAIAFQAHAHAAAJIAAACQgBAFgCAEQgCAFgFACQAGACADAEQADAFAAAHIAAABQAAALgIAGQgHAGgNAAQgNAAgGgHg");
	this.shape_325.setTransform(143.05,114.1);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#000000").s().p("AgGAoIAAgKQAAgHABgHIAJgSQAHgLACgGIACgLIgeAAIAAALIgJAAIAAgUIAxAAIAAAIQAAAGgDAGQgBAHgIALQgGALgDAHQgCAGAAAHIAAAKg");
	this.shape_326.setTransform(179.3,99.45);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#000000").s().p("AgSAjQgHgHAAgLIAAgCIAJAAIAAACQAAAIAEAEQAFAEAHAAQAIAAAFgDQAEgFAAgGQAAgGgDgDQgEgEgIgBIgFgCQgLgCgFgEQgGgGAAgJQAAgKAHgGQAHgGALAAQALAAAHAGQAHAGAAALIAAACIgJAAIAAgCQAAgHgFgEQgEgDgHAAQgHAAgEACQgEAFAAAFQAAAGADADQAEAEAHACIAGABQALABAFAGQAFAFAAAKQAAAKgGAGQgHAGgNAAQgLAAgHgGg");
	this.shape_327.setTransform(170.625,99.45);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#000000").s().p("AgZAoIAAhPIAYAAQANAAAHAIQAHAIAAAOIAAAUQAAAOgHAHQgHAIgNAAgAgQAgIAPAAQAIAAAFgGQAFgFAAgKIAAgVQAAgJgFgGQgFgFgIAAIgPAAg");
	this.shape_328.setTransform(163.675,99.45);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_329.setTransform(170.8,131);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.LegalFrame2, new cjs.Rectangle(20.8,-18.7,300.3,276.8), null);


(lib.img2Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("APOcnIAAAAIAAAAgAK8ZJQoom71oxEMAmpgdxQADAHiFckIiFcjQgBgEkRjag");
	mask.setTransform(181.7273,83.2);

	// img2
	this.img2 = new lib.img2_1();
	this.img2.name = "img2";
	this.img2.setTransform(142.65,93.15,0.6,0.6,0,0,0,238.5,160.1);

	var maskedShapeInstanceList = [this.img2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// msk (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("APOcnIAAAAIAAAAgAK8ZIQoom51oxEMAmpgdyQADAHiFckIiFcjQgBgEkRjbg");
	mask_1.setTransform(313.9273,188.3);

	// imgGuide
	this.imgGuide = new lib.img2_1();
	this.imgGuide.name = "imgGuide";
	this.imgGuide.setTransform(163,148.5,0.2065,0.2065,0,0,0,0.8,0.5);

	var maskedShapeInstanceList = [this.imgGuide];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.imgGuide).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Container, new cjs.Rectangle(-262.1,-48.4,486.90000000000003,247), null);


(lib.img1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1_zoom
	this.img1_zoom = new lib.img1_zoom();
	this.img1_zoom.name = "img1_zoom";
	this.img1_zoom.setTransform(786.5,371.6,1,1,0,0,0,786.5,371.6);

	this.timeline.addTween(cjs.Tween.get(this.img1_zoom).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0.1,1747.9,1332.8000000000002);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AwugHIQmwnIQ3Q3IwmQmg");
	mask.setTransform(107.075,99.1);

	// ctaTxt
	this.ctaTxt = new lib.ctaTxt();
	this.ctaTxt.name = "ctaTxt";
	this.ctaTxt.setTransform(107.15,97.7,1,1,0,0,0,93.8,10);

	var maskedShapeInstanceList = [this.ctaTxt];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaTxt).wait(1));

	// ctaBg
	this.ctaBg = new lib.ctaBg();
	this.ctaBg.name = "ctaBg";
	this.ctaBg.setTransform(106.5,98.25,1,1,0,0,0,88.7,21.8);

	var maskedShapeInstanceList = [this.ctaBg];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ctaBg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-93.7,-21.7,294.6,141.7), null);


(lib.txt4Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt4
	this.txt4 = new lib.txt4();
	this.txt4.name = "txt4";
	this.txt4.setTransform(217.85,160,1,1,0,0,0,-88,0);

	this.timeline.addTween(cjs.Tween.get(this.txt4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt4Container, new cjs.Rectangle(0,0,369.9,344.3), null);


(lib.txt1Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4/jRIRr0nMAgUAbJIxrUog");
	mask.setTransform(177.45,189.8);

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(115.35,107.8);

	var maskedShapeInstanceList = [this.txt1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1Container, new cjs.Rectangle(115.5,123.4,183.39999999999998,104.69999999999999), null);


(lib.logoContainer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// white
	this.white = new lib.white();
	this.white.name = "white";
	this.white.setTransform(-34.1,-59.6);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	// logo
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.setTransform(116,76.2,1,1,0,0,0,116,76.2);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logoContainer, new cjs.Rectangle(-58.2,-92.6,348.2,365.79999999999995), null);


(lib.logo_DS_WIP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo_DS_vector
	this.instance = new lib.logo_DS_vector("synched",0);
	this.instance.setTransform(203.7,143.3,1,1,0,0,0,80.8,143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// DS AUTOMOBILES
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EA7eAFhQg8g9AAh9IB5AAQABBIAdAhQAeAiBEAAQBAAAAdgcQAcgbAAg5QAAg8gXgfQgWgfg3gQIhJgXQhigegqgzQgsg2AAhiQAAhgA4g5QA8g8BtAAQB5AAA7A3QA7A4AAB3Ih5AAQgChBgZgcQgagdg+AAQg2AAgaAYQgaAYAAAzQAAA3AYAdQAXAaA8ATIBFAVQBjAeAoA2QAqA4AABqQAABqg/A6Qg/A8h1AAQh/AAg+g9gAPdFZQhFhFAAh5IAAkxQAAh8BFhFQBEhGB7AAQB6AABEBGQBFBFAAB8IAAExQAAB5hFBFQhEBFh6AAQh7AAhEhFgAQ1kJQgkAnAABHIAAE3QAABIAkAmQAjAmBEAAQBDAAAkgmQAjgmAAhIIAAk3QAAhIgjgmQgkgmhDABQhEgBgjAmgAorFZQhFhFAAh5IAAkxQAAh8BFhFQBFhGB6AAQB6AABFBGQBEBFAAB8IAAExQAAB5hEBFQhFBFh6AAQh6AAhFhFgAnTkJQgkAnAABHIAAE3QAABIAkAmQAjAmBEAAQBDAAAkgmQAjgmAAhIIAAk3QAAhIgjgmQgkgmhDABQhEgBgjAmgA83FcQg+hAAAh6IAAozIB4AAIAAI8QAABGAhAhQAeAeA/AAQA/AAAegeQAgghAAhGIAAo8IB5AAIAAIzQAAB6g+BAQg/BCh5AAQh4AAhAhCgEg3LAFhQg8g9AAh9IB5AAQABBIAdAhQAeAiBEAAQBAAAAdgcQAcgbAAg5QAAg8gXgfQgWgfg3gQIhJgXQhigegqgzQgsg2AAhiQAAhgA4g5QA8g8BuAAQB5AAA6A3QA7A4AAB3Ih5AAQgChBgZgcQgagdg+AAQg2AAgaAYQgaAYAAAzQAAA3AYAdQAXAaA8ATIBFAVQBjAeAoA2QAqA4AABqQAABqg/A6Qg/A8h1AAQh/AAg+g9gEAyAAGSIAAsjIGTAAIAABuIkaAAIAADkID7AAIAABsIj7AAIAAD3IEnAAIAABugEApXAGSIAAsjIB5AAIAAK1IERAAIAABugEAkAAGSIAAsjIB5AAIAAMjgAZnGSIAAsjID6AAQBkAAA1A2QA1A1AABkQAABEgWAuQgXAygvAWQBxAjAACcQAABqg4A4Qg5A5hrAAgAbfEqICBAAQA0AAAagfQAbgeAAg7QAAhAgagjQgagjgyABIiEAAgAbfg7IB/AAQAtAAAXgeQAYgfAAg4QAAg5gaggQgZggguABIh6AAgAJeGSIAApjIiSGEIhoAAIiTmFIAAJkIhzAAIAAsjICUAAICpHHICnnHICOAAIAAMjgAwqGSIAAq2IjFAAIAAhtIIDAAIAABtIjGAAIAAK2gEgiPAGSIg0jdIjhAAIg0DdIh3AAIDFsjICxAAIDHMjgEgjbABLIhYl3IhZF3ICxAAgEhCNAGSIAAsjIDmAAQB6AABFBFQBFBEAAB5IAAEiQAAB4hFBEQhFBDh6AAgEhAWAEmIBtAAQBFAAAkgmQAkgmAAhHIAAkkQAAhIgkgmQgkgmhFAAIhtAAg");
	this.shape.setTransform(203.3718,246.5523,0.48,0.48);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_DS_WIP, new cjs.Rectangle(0,0.3,406.8,266.09999999999997), null);


(lib.img1Container = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask1Guide
	this.mask1Guide = new lib.mask1Guide();
	this.mask1Guide.name = "mask1Guide";
	this.mask1Guide.setTransform(261.8,-261.55,1.5551,1.5551,0,0,0,213,167);

	this.timeline.addTween(cjs.Tween.get(this.mask1Guide).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EBOLCIDMiafh/eIponyIITm2MCjmiHtMgArEVvIADFyg");
	mask.setTransform(11.15,350.05);

	// img1Guide2
	this.img1Guide2 = new lib.img1_1();
	this.img1Guide2.name = "img1Guide2";
	this.img1Guide2.setTransform(-0.6,-6.6,0.404,0.404);

	var maskedShapeInstanceList = [this.img1Guide2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1Guide2).wait(1));

	// msk (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EgzvgAPMAz/goVMAzgAoVMgz/Ao0g");
	mask_1.setTransform(106.425,-99.275);

	// img1Guide
	this.img1Guide = new lib.img1_1();
	this.img1Guide.name = "img1Guide";
	this.img1Guide.setTransform(-39.15,-30,0.3,0.3,0,0,0,-0.5,0);

	var maskedShapeInstanceList = [this.img1Guide];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1Guide).wait(1));

	// msk (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EgzvgAPMAz/goVMAzgAoVMgz/Ao0g");
	mask_2.setTransform(261.775,24.225);

	// img1
	this.img1 = new lib.img1_1();
	this.img1.name = "img1";
	this.img1.setTransform(-28.7,-82.85,0.5,0.5);

	var maskedShapeInstanceList = [this.img1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Container, new cjs.Rectangle(-267.5,-521.2,864.6,1091.6), null);


(lib.logo_wraper2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo_DS_WIP();
	this.instance.setTransform(0,-0.15,0.28,0.28,0,0,0,0,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_wraper2, new cjs.Rectangle(-28.6,-45.6,171.29999999999998,171.4), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var logoContainer = this.logoContainer;	
				var logo = logoContainer.logo;
				var white = logoContainer.white;
			
			var img1Container = this.img1Container;
				var img1 = img1Container.img1;
					var img1_zoom = img1.img1_zoom;
				var img1_2 = img1Container.img1_2;
				var img1_2Guide = img1Container.img1_2Guide;
				
				var img1Guide = img1Container.img1Guide;
				var img1Guide2 = img1Container.img1Guide2;
				var mask1Guide = img1Container.mask1Guide;
					
			var img2Container = this.img2Container;
				var img2 = img2Container.img2;
				var imgGuide = img2Container.imgGuide;
			var img2ContainerGuide = this.img2ContainerGuide;
			
			/*var img3Container = this.img3Container;
				var img3 = img3Container.img3;
				var img3Guide = img3Container.img3Guide;*/
			
			var txt1Container = this.txt1Container;
				var txt1 = this.txt1Container.txt1;
					var txt1a = txt1.txt1a;
					var txt1b = txt1.txt1b;
					var txt1Line = txt1.txt1Line;
			
			var txt2Container = this.txt2Container;
				var txt2 = txt2Container.txt2;
				var txtGuide = txt2Container.txtGuide;
				
			/*var txt3Container = this.txt3Container;
				var txt3 = txt3Container.txt3;*/
				
			var txt4Container = this.txt4Container;
				var txt4 = this.txt4Container.txt4;
					var txt4a = txt4.txt4a;
					var txt4b = txt4.txt4b;
					var txt4Line = txt4.txt4Line;
			
				var img4 = this.img4;
				var img4Guide = this.img4Guide;
				
			var LegalFrame2 = this.LegalFrame2;
				
			var whiteTop = this.whiteTop;	
			var logo2 = this.logo2;	
			var txtBg = this.txtBg;
			var cta = this.cta;
				var ctaTxt = cta.ctaTxt;
				var ctaBg = cta.ctaBg;
		
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf, options) {
			window.parent.postMessage(JSON.stringify({last:tf}), "*");
			if (window.takeAutoShot != undefined) {
				//console.log(tf);
				//console.log(option);
				window.takeAutoShot(tf, options);
			}
		}
		
		/*********** dsLineScale **************/
		function dsLineScale(lineToScale, widestTxt){
			var childrenX = widestTxt.children[0].x;
			for (var i = 0; i < widestTxt.children.length; i++) {
				if ( widestTxt.children[i].x <= childrenX ){
				childrenX = widestTxt.children[i].x;
				var childrenXnext = widestTxt.children[i+1].x;		
				childrenX = childrenX-(childrenXnext - childrenX)/2;	
				}
			}	
			var lineWidth = Math.round((widestTxt.nominalBounds.width * widestTxt.scaleX - (childrenX * 2 * widestTxt.scaleX))/ 3.5);
			var lineScaleX = lineWidth / lineToScale.nominalBounds.width;
			lineToScale.scaleX = lineScaleX;
			console.log(lineWidth);
			}
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat: 0, repeatDelay:0});
		
			///dsLineScale(txt1Line, txt1b);
			dsLineScale(txt4Line, txt4b);
		
		tl
			.to([img1Guide, img1_2Guide, img1Guide2, img4Guide, txtGuide], 0,{alpha: 0}, 0)
		
			/*.add("frame1")
			.from(white, {y:"-="+white.nominalBounds.height, duration: .75, ease:Power1.easeOut}, "frame1+=.75")
			.add(autoShot, "frame1+=.1")*/
		
			.add("frame2")
			.from(img1_zoom, {onStart: ZoomIn, onStartParams:[img1_zoom, 1, 4], ease:Linear.easeOut},"frame2")
			.from(img1.mask, 1, {x: mask1Guide.x, y: mask1Guide.y,/* scaleX: mask1Guide.scaleX, scaleY: mask1Guide.scaleY,*/ ease:Power2.easeOut},"frame2")
			.from(logo2, .7, {alpha:0, ease: Power2.easeIn}, "frame2+=.25")
			.from(txt1.mask, .5, {x:"-="+w, ease:Power1.easeOut},"frame2")
			.add(autoShot)
		
			.add("frame3", "frame2+=2.5")
			.from(txtBg, 1, { x:"-="+w, ease:Power1.easeOut},"frame3")
			.from(txt2.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeOut},"frame3+=.4")
			.from(whiteTop, 1, {x:"+="+w, ease:Power1.easeOut},"frame3+=.65")
			.to(img1, 1, {x: img1Guide.x, y: img1Guide.y, scaleX: img1Guide.scaleX, scaleY: img1Guide.scaleY, ease:Power1.easeOut},"frame3+=.65")
			.from(img2.mask, 1, { x: imgGuide.mask.x, y: imgGuide.mask.y, scaleX: imgGuide.mask.scaleX, scaleY: imgGuide.mask.scaleY, ease:Power1.easeOut},"frame3+=.5")
			.to(img2, 2, {scaleX: .65, scaleY: .65, ease:Power1.easeOut},"frame3+=1")
			.to(img1.mask, 1, {x: img1Guide.mask.x, y: img1Guide.mask.y, ease:Power1.easeOut},"frame3+=2")
			.add(autoShot)
		
			.add("frame4", "frame3+=3")
			.to(txt1, .1, {alpha:0},"frame4")
			//.to(txt2, .5, {alpha:0, ease:Power2.easeOut},"frame4+=.5")
			/*.from(txt3.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeIn},"frame4+=1")
			.from(img3.mask, 1, { x: imgGuide.mask.x, y: imgGuide.mask.y, scaleX: imgGuide.mask.scaleX, scaleY: imgGuide.mask.scaleY, ease:Power1.easeOut},"frame4+=.5")
			.from(img3, 1, {x: img3Guide.x, y: img3Guide.y, scaleX: img3Guide.scaleX, scaleY: img3Guide.scaleY, ease:Power1.easeOut}, "frame4+=.5")
			.from(img3, 5, {onStart: moveInDirection, onStartParams:[img3, 180, 4.5, w/1.4]},"frame4+=1.5")*/
			.add(autoShot, "frame4+=3")
		
			.add("frame5", "frame4+=1")
			.from(img1_2, .1, {alpha:0},"frame5")
			//.to(txt3.mask, .5, {x: txtGuide.x, y: txtGuide.y, scaleX: txtGuide.scaleX, scaleY: txtGuide.scaleY, ease:Linear.easeIn},"frame5")
			.to([img2.mask, whiteTop], .7, {x:"+="+w, ease:Power1.easeIn},"frame5")
			.to([txtBg,txt2], .7, { x:"-="+txtBg.nominalBounds.width, ease:Power1.easeIn},"frame5")
			.to(img1.mask, .7, {y:"-="+h, ease:Power1.easeOut},"frame5")
			.to(img1, .7, {x: img1Guide2.x, y: img1Guide2.y, scaleX: img1Guide2.scaleX, scaleY: img1Guide2.scaleY, ease:Power1.easeInOut},"frame5")
			//.to(img1_2, 1, {x: img1_2Guide.x, y: img1_2Guide.y, scaleX: img1_2Guide.scaleX, scaleY: img1_2Guide.scaleY, ease:Power1.easeInOut},"frame5+=.75")
			//.from(img4, 1, {scaleX: 1.1, scaleY: 1.1, ease:Power1.easeOut})
			.from(img4, .3, {alpha:0, ease:Linear.easeOut}, "frame5+=.3")
			.from(img4, 1, {scaleX: .65 , scaleY: .65, ease:Linear.easeOut}, "frame5+=.5")
			.to(img4, 1, {x: img4Guide.x, y: img4Guide.y, scaleX: img4Guide.scaleX, scaleY: img4Guide.scaleY, ease:Power1.easeOut}, "frame5+=2")
			.from([txt4a, txt4Line], 1, {alpha:0, ease:Linear.easeOut},"frame5+=2.2")
			.from(txt4b, 1, {alpha:0, y:"-="+7, ease:Power1.easeOut},"frame5+=2.6")
			.from(ctaBg.mask, 1, {scaleX: 0, scaleY: 0, ease:Power1.easeInOut},"frame5+=2.8")
			.from(ctaTxt, .3, {alpha:0, ease:Power1.easeIn},"frame5+=3.5")
			.call(autoShot)
		
			.add("frame6", "frame5+=7")
			.from(LegalFrame2, 1, {alpha:0, ease:Linear.easeOut}, "frame6")
			.call(autoShot, [true] ,"+=1")
		
		
		
		function moveInDirection(target, directionInDegrees, t, distance) {
		    var directionInRadians = directionInDegrees * (Math.PI / 180);
		
		    var defaultDistanceX = target.nominalBounds.width * target.scaleX - w;
		    var defaultDistanceY = target.nominalBounds.height * target.scaleY - h;
		
		    var distanceX = distance || defaultDistanceX;
		    var distanceY = distance || defaultDistanceY;
		
		    var xMove = distanceX * Math.cos(directionInRadians);
		    var yMove = distanceY * Math.sin(directionInRadians);
		
		    gsap.to(target, {x: `+=${xMove}`, y: `+=${yMove}`, duration: t, ease:Power1.easeInOut});
		}
		
		
		function ZoomIn(target, scale, t) {
			gsap.fromTo(target, {scaleX:0.9, scaleY:0.9} , {scaleX:scale, scaleY:scale, ease:Power2.easeOut, overwrite:0, rotation:0.001, delay:0, duration: t})
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// LegalFrame2
	this.LegalFrame2 = new lib.LegalFrame2();
	this.LegalFrame2.name = "LegalFrame2";
	this.LegalFrame2.setTransform(140.7,301,1,1,0,0,0,161.4,306.7);

	this.timeline.addTween(cjs.Tween.get(this.LegalFrame2).wait(1));

	// logo2
	this.logo2 = new lib.logo_wraper2();
	this.logo2.name = "logo2";
	this.logo2.setTransform(104.45,11.95,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.logo2).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(83.85,212.95,0.55,0.55,0,0,0,108,96.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt4
	this.txt4Container = new lib.txt4Container();
	this.txt4Container.name = "txt4Container";
	this.txt4Container.setTransform(-176.1,29.1,0.7321,0.7321,0,0,0,-137.5,0);

	this.timeline.addTween(cjs.Tween.get(this.txt4Container).wait(1));

	// txt2
	this.txt2Container = new lib.txt2Container();
	this.txt2Container.name = "txt2Container";
	this.txt2Container.setTransform(6.3,182.4,0.7664,0.7664);

	this.timeline.addTween(cjs.Tween.get(this.txt2Container).wait(1));

	// txtBg
	this.txtBg = new lib.txtBg();
	this.txtBg.name = "txtBg";
	this.txtBg.setTransform(-24.9,58.35,0.9999,0.9999,-1.288,0,0,-0.4,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtBg).wait(1));

	// txt1
	this.txt1Container = new lib.txt1Container();
	this.txt1Container.name = "txt1Container";
	this.txt1Container.setTransform(-187.95,66.35,0.766,0.766,0,0,0,-137.6,0.2);

	this.timeline.addTween(cjs.Tween.get(this.txt1Container).wait(1));

	// img2
	this.img2Container = new lib.img2Container();
	this.img2Container.name = "img2Container";
	this.img2Container.setTransform(0,0,1.7634,1.7634);

	this.timeline.addTween(cjs.Tween.get(this.img2Container).wait(1));

	// whiteTop
	this.whiteTop = new lib.whiteTop();
	this.whiteTop.name = "whiteTop";
	this.whiteTop.setTransform(322.6,-196.85,1.4692,1.4692,0.8676,0,0,0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.whiteTop).wait(1));

	// img1
	this.img1Container = new lib.img1Container();
	this.img1Container.name = "img1Container";
	this.img1Container.setTransform(159.9,291,1,1,0,0,0,159.9,291);

	this.timeline.addTween(cjs.Tween.get(this.img1Container).wait(1));

	// img4Guide
	this.img4Guide = new lib.img4Guide();
	this.img4Guide.name = "img4Guide";
	this.img4Guide.setTransform(185,135.5,0.4,0.4,0,0,0,150.5,141.7);

	this.timeline.addTween(cjs.Tween.get(this.img4Guide).wait(1));

	// img4
	this.img4 = new lib.img4();
	this.img4.name = "img4";
	this.img4.setTransform(94.05,122.8,0.6,0.6,0,0,0,263.7,238.3);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// logo
	this.logoContainer = new lib.logoContainer();
	this.logoContainer.name = "logoContainer";
	this.logoContainer.setTransform(67.8,67.25,0.7099,0.7099,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.logoContainer).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-389,-432.3,1234.1,1689.7);
// library properties:
lib.properties = {
	id: '10544D5684BA4F528969206F0477CF68',
	width: 300,
	height: 250,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"_3.jpg", id:"_3"},
		{src:"GPT.png", id:"GPT"},
		{src:"img1.jpg", id:"img1"},
		{src:"img2.jpg", id:"img2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['10544D5684BA4F528969206F0477CF68'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;