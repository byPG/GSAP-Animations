(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_1", frames: [[0,0,310,107]]},
		{name:"index_atlas_NP_1", frames: [[0,0,600,1200]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.dd = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._img = function() {
	this.initialize(ss["index_atlas_NP_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.square_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.dd();
	this.instance.setTransform(0,0,0.5447,0.5447);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.square_logo, new cjs.Rectangle(0,0,168.9,58.3), null);


(lib.slash1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7FF14").s().p("Ai+DgIC+m/IC/AAIi+G/g");
	this.shape.setTransform(4.65,5.75,0.2527,0.2527,0,0,0,-0.5,0.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slash1, new cjs.Rectangle(0,0,9.7,11.4), null);


(lib.opel_new = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0E0E0E").s().p("AOHCyMgm2gEMIAAgBQgBAAAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAICkhVMAu7AAAIABABIgBABIqpFhg");
	this.shape.setTransform(23.3569,17.5804,0.1441,0.144);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0E0E0E").s().p("An4J0Qj8hqjBjBQjCjChrj6QhukEgBkdQAAgiADgrIBkALQgCAeAAAkQAAEJBmDxQBjDoC0C0QCzC0DqBiQDxBnEIAAQGVgBFOjnQFNjnCQl7IBrAAQiSGlltEEQlsEDm/ABQkcAAkEhug");
	this.shape_1.setTransform(32.4309,29.6765,0.1441,0.144);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0E0E0E").s().p("ATrLXQACgeAAgkQAAkJhmjxQhjjoizi0Qi0izjqhkQjxhlkHAAQmWAAlODnQlNDniPF7IhrAAQCSmmFskCQFskDG/gBQEcgBEDBuQD8BqDCDCQDCDBBrD6QBuEEAAEdQAAAigCArg");
	this.shape_2.setTransform(33.5403,10.6376,0.1441,0.144);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0E0E0E").s().p("A4vCzIgBgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIKoljIABAAMAm1AENQABAAAAAAQAAAAABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIijBWg");
	this.shape_3.setTransform(42.6105,22.73,0.1441,0.144);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0E0E0E").s().p("Aj7ExIgBgBIAApfIABgBICIAAIABABIAAHjIABABIFtAAIABABIAAB6IgBABg");
	this.shape_4.setTransform(62.0723,53.4106,0.144,0.144);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0E0E0E").s().p("AjHEZQhMgigohIQglhEAAhrQAAhqAlhEQAnhJBNggQBOglB5ABQB5gBBNAlQBOAfAnBKQAmBDAABrQAABsgmBDQgoBJhNAhQhMAjh6AAQh6AAhNgjgAAAi/QhNgBgvAWQgtASgUAsQgVA1ABA4QgBA5AVAzQAWAsArAUQA7AVBBgBQBLAAAvgWQAugRAUgtIAAAAQAVg1gBg4QABg5gVgzQgUgsgsgTQg5gVg6AAIgJABg");
	this.shape_5.setTransform(5.3326,53.407,0.144,0.144);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0E0E0E").s().p("AkjExIgBgBIAApfIABgBIFYAAQBVAAAxAUQA1ARAbAxQAaArAABTQAABvg8AwQg7Ayh5AAIjNAAIgBABIAAC6IgBABgAiZi7IAAC6IABABIDFAAQA+AAAYgWQAagXAAgzQABgbgLgZQgMgUgWgKQgUgKgwAAIjFAAg");
	this.shape_6.setTransform(24.87,53.4106,0.144,0.144);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0E0E0E").s().p("AkCExIgBgBIAApfIABgBIIEAAIABABIAAB2IgBABIl8AAIAAABIAAB8IABABIFXAAIABABIAABtIgBABIlYAAIAAABIAACCIAAABIF+AAIABABIAAB2IgBABg");
	this.shape_7.setTransform(42.805,53.4106,0.144,0.144);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.opel_new, new cjs.Rectangle(0.3,0,65.4,58), null);


(lib.letters2b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhABOIAAgRQAcARAiAAQAzABAAgmQAAgOgIgGQgIgJgVgDIgggGQgtgGAAgmQAAgXARgNQASgPAeAAQAjAAAYAPIAAAQQgbgQggAAQgWAAgOAKQgMAJAAARQAAAOAJAIQAHAGARADIAgAGQAaAEALALQAMAKAAAUQAAAZgTANQgSAOgfAAQglAAgZgPg");
	this.shape.setTransform(204.075,29.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABCBaIgUg0IhcAAIgVA0IgQAAIBKizIAWAAIBHCzgAAoAXIgnhmIgpBmIBQAAg");
	this.shape_1.setTransform(187.075,29.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgGBaIAAilIhGAAIAAgOICZAAIAAAOIhFAAIAAClg");
	this.shape_2.setTransform(169.025,29.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgHBaIAAizIAPAAIAACzg");
	this.shape_3.setTransform(156.55,29.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhABOIAAgRQAcARAiAAQAzABAAgmQAAgOgIgGQgIgJgVgDIgggGQgtgGAAgmQAAgXARgNQASgPAeAAQAjAAAYAPIAAAQQgbgQggAAQgWAAgOAKQgMAJAAARQAAAOAJAIQAHAGARADIAgAGQAaAEALALQAMAKAAAUQAAAZgTANQgSAOgfAAQglAAgZgPg");
	this.shape_4.setTransform(145.175,29.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag5BaIAAizIB0AAIAAAOIhlAAIAABBIBaAAIAAANIhaAAIAABJIBlAAIAAAOg");
	this.shape_5.setTransform(129.2,29.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrBGQgWgYAAgtQAAgtAWgZQAVgXAjAAQAcAAAZAOIAAARQgagRgZAAQgcAAgSAUQgSAVAAAmQAAAnASAUQARATAdAAQAZAAAagSIAAARQgZAPgcAAQgjAAgVgXg");
	this.shape_6.setTransform(112.575,29.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ag5BaIAAizIB0AAIAAAOIhlAAIAABBIBaAAIAAANIhaAAIAABJIBlAAIAAAOg");
	this.shape_7.setTransform(96.35,29.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AA2BaIhxijIAACjIgPAAIAAizIAWAAIBwCiIAAiiIAPAAIAACzg");
	this.shape_8.setTransform(77.625,29.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag5BaIAAizIB0AAIAAAOIhlAAIAABBIBaAAIAAANIhaAAIAABJIBlAAIAAAOg");
	this.shape_9.setTransform(52.7,29.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("Ag2BGQgQgTAAgpIAAhlIAQAAIAABkQgBAiAMAQQANASAeAAQAeAAANgSQANgQAAgiIAAhkIAPAAIAABlQAAApgQATQgRAWgmAAQglAAgRgWg");
	this.shape_10.setTransform(34.85,29.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AA0BoIgRgbQgPAGgUAAQhTAAAAhdQAAhdBTAAQBUAAAABdQAAA7glAWIAWAhgAhDgKQAABPBDAAQAPAAANgEIgbgoIAQAAIAWAiQAdgRAAgzQAAhPhEAAQhDAAAABOg");
	this.shape_11.setTransform(15.45,30.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letters2b, new cjs.Rectangle(3.4,8.1,210.79999999999998,42), null);


(lib.letters2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AA2BaIhxijIAACjIgPAAIAAizIAWAAIBwCiIAAiiIAPAAIAACzg");
	this.shape.setTransform(178.825,29.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhTAAQAAhcBTAAQBUAAAABcQAABdhUAAQhTAAAAhdgAhDAAQAABPBDAAQBEAAAAhPQAAhOhEAAQhDAAAABOg");
	this.shape_1.setTransform(158.65,29.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgHBaIAAizIAPAAIAACzg");
	this.shape_2.setTransform(145.15,29.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGBaIAAilIhGAAIAAgOICZAAIAAAOIhFAAIAAClg");
	this.shape_3.setTransform(132.675,29.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgHBaIAAizIAPAAIAACzg");
	this.shape_4.setTransform(120.2,29.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhHBaIAAizIA5AAQBWAAAABZQAAAsgXAXQgXAXgoAAgAg3BMIApAAQBGAAAAhMQAAhLhGAAIgpAAg");
	this.shape_5.setTransform(107.975,29.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag6BaIAAizIB0AAIAAAOIhjAAIAABBIBZAAIAAANIhZAAIAABJIBjAAIAAAOg");
	this.shape_6.setTransform(90.2,29.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAzBaIAAhUIhkAAIAABUIgQAAIAAizIAQAAIAABRIBkAAIAAhRIAQAAIAACzg");
	this.shape_7.setTransform(65.6,29.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgrBGQgWgYAAgtQAAgtAWgZQAVgXAjAAQAcAAAZAOIAAARQgagRgZAAQgcAAgSAUQgSAVAAAmQAAAnASAUQARATAdAAQAZAAAagSIAAARQgZAPgcAAQgjAAgVgXg");
	this.shape_8.setTransform(48.175,29.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ag5BaIAAizIBzAAIAAAOIhjAAIAABBIBZAAIAAANIhZAAIAABJIBjAAIAAAOg");
	this.shape_9.setTransform(31.95,29.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgGBaIAAilIhGAAIAAgOICZAAIAAAOIhFAAIAAClg");
	this.shape_10.setTransform(14.425,29.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letters2, new cjs.Rectangle(3.4,8.1,187.9,42), null);


(lib.letters1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AB3DBIgihgIiuAAIgjBgIg9AAICRmBIBWAAICMGBgABDAqIhCi9IhGC9ICIAAg");
	this.shape.setTransform(346.075,84.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag2D+IAAmBIA8AAIAAGBgAg9iwIAzhNIBIAAIhCBNg");
	this.shape_1.setTransform(320.65,78.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhwCVQgwgyAAhhQAAg+AWgtQAXguAqgXQApgYA6AAQAlAAAeAHQAfAIAcANIAAA8QgbgPgdgJQgdgJgjAAQg8AAgiAkQgjAkAABJQAABIAfAkQAgAjBAAAQAlAAAngKIAAhcIhsAAIAAgwICjAAIAACuQg8AehOAAQhXAAgwgyg");
	this.shape_2.setTransform(290.075,84.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiICVQgwgzAAhiQAAhhAwgzQAwgyBYAAQBZAAAwAyQAwAzAABhQAABigwAzQgwAyhZAAQhYAAgwgygAhbhrQgeAjAABIQAABJAeAkQAeAjA9AAQA+AAAegjQAegjAAhKQAAhIgegkQgegjg+AAQg+AAgdAkg");
	this.shape_3.setTransform(249.45,84.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ah6DBIAAmBIA9AAIAAFJIC4AAIAAA4g");
	this.shape_4.setTransform(213.175,84.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AiICVQgwgzAAhiQAAhhAwgzQAwgyBYAAQBZAAAwAyQAwAzAABhQAABigwAzQgwAyhZAAQhYAAgwgygAhbhrQgeAjAABIQAABJAeAkQAeAjA9AAQA+AAAegjQAegjAAhKQAAhIgegkQgegjg+AAQg+AAgdAkg");
	this.shape_5.setTransform(174.4,84.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABUDBIjAk5IAAE5Ig6AAIAAmBIBTAAIDAE5IAAk5IA6AAIAAGBg");
	this.shape_6.setTransform(131.15,84.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ag8CxQgogXgWgsQgWgsAAhAQAAhAAWgtQAWgtAogXQAogXA1AAQAiAAAaAHQAZAIAYANIAAA8QgXgPgYgJQgZgJgeAAQgkAAgbAQQgbAPgPAhQgQAhAAAwQAABIAhAjQAhAjA3AAQAXAAASgFQASgEAOgIIAggTIAAA8QgYAPgZAIQgaAIglAAQg1AAgogWg");
	this.shape_7.setTransform(91.925,84.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ah/DBIAAmBID/AAIAAA3IjCAAIAABsICsAAIAAAyIisAAIAAB1IDCAAIAAA3g");
	this.shape_8.setTransform(57.625,84.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgeDBIAAlIIiHAAIAAg5IFLAAIAAA5IiHAAIAAFIg");
	this.shape_9.setTransform(20.825,84.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AB3DBIgihgIiuAAIgjBgIg9AAICRmBIBWAAICMGBgABDAqIhCi9IhGC9ICIAAg");
	this.shape_10.setTransform(228.975,27.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("Ah6DBIAAmBIA9AAIAAFJIC4AAIAAA4g");
	this.shape_11.setTransform(194.375,27.825);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AB3DBIgihgIiuAAIgjBgIg9AAICRmBIBWAAICMGBgABDAqIhCi9IhGC9ICIAAg");
	this.shape_12.setTransform(142.525,27.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AifDBIAAmBIB+AAQBcAAAyAwQAzAwAABgQAABfgzAxQgzAxhbAAgAhiCKIBCAAQA/AAAhgiQAhghAAhHQAAhGggghQghgihAAAIhCAAg");
	this.shape_13.setTransform(103.775,27.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AiICVQgwgzAAhiQAAhhAwgzQAvgyBZAAQBZAAAwAyQAwAzAABhQAABigwAzQgwAyhZAAQhZAAgvgygAhchrQgdAjAABIQAABJAeAkQAeAjA9AAQA+AAAegjQAegjAAhKQAAhIgegkQgegjg+AAQg+AAgeAkg");
	this.shape_14.setTransform(61.3,27.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgeDBIAAlIIiHAAIAAg5IFLAAIAAA5IiHAAIAAFIg");
	this.shape_15.setTransform(20.825,27.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letters1b, new cjs.Rectangle(-0.2,-14.8,383.09999999999997,142), null);


(lib.letters1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AB3DBIgihgIiuAAIgjBgIg9AAICRmBIBWAAICMGBgABDAqIhCi9IhGC9ICIAAg");
	this.shape.setTransform(386.525,34.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABTDBIhlibIhNAAIAACbIg9AAIAAmBICYAAQBKAAAlAeQAlAdAAA5QAAAvgaAcQgaAcgvAIIBwCegAhfgMIBiAAQAmAAAUgQQAUgQAAgfQAAgggVgPQgVgQgrAAIhbAAg");
	this.shape_1.setTransform(349.075,34.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgeDBIAAlIIiHAAIAAg5IFLAAIAAA5IiHAAIAAFIg");
	this.shape_2.setTransform(309.425,34.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhSC+QgkgKgXgNIAAg7QAZAQAiAKQAjAKAmAAQArAAAagPQAZgQAAgdQgBgPgGgLQgHgJgOgHQgPgGgagFIg+gLQhjgRgBhWQABgiARgZQARgaAigPQAigOAuAAQApAAAhAIQAhAIAWAOIgDA5QgbgOgfgKQgfgIglAAQgpAAgWAPQgXAQAAAbQAAAYAPALQAOALAfAFIA+ALQA4AJAaAYQAaAZAAAtQgBAngSAaQgTAagiANQgkAOguAAQgogBgjgIg");
	this.shape_3.setTransform(273.05,34.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AB3DBIgihgIiuAAIgjBgIg9AAICRmBIBWAAICMGBgABDAqIhCi9IhGC9ICIAAg");
	this.shape_4.setTransform(235.925,34.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AiICVQgwgzAAhiQAAhhAwgzQAwgyBYAAQBZAAAwAyQAwAzAABhQAABigwAzQgwAyhZAAQhYAAgwgygAhbhrQgeAjAABIQAABJAeAkQAeAjA9AAQA+AAAegjQAegjAAhKQAAhIgegkQgegjg+AAQg+AAgdAkg");
	this.shape_5.setTransform(179.8,34.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgtDBIiEmBIBEAAIBtFSIBylSIBAAAIiKGBg");
	this.shape_6.setTransform(139.35,34.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ah/DBIAAmBID/AAIAAA3IjCAAIAABsICsAAIAAAyIisAAIAAB1IDCAAIAAA3g");
	this.shape_7.setTransform(103.525,34.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ah5CYQglgsgBhYIAAjXIA9AAIAADRQAAApAJAcQAIAbAWAQQAVAPAmAAQAlAAAWgPQAVgOAKgcQAIgbABgrIAAjRIA8AAIAADXQABBYgmAsQglAshUAAQhUAAgmgsg");
	this.shape_8.setTransform(65.45,34.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("ABUDBIjAk5IAAE5Ig6AAIAAmBIBTAAIC/E5IAAk5IA7AAIAAGBg");
	this.shape_9.setTransform(23.45,34.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letters1, new cjs.Rectangle(-0.2,-8.2,408.7,85), null);


(lib.legal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// line
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ACDyKIJYAAAraSLIQZAA");
	this.shape.setTransform(156.3,316.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// txt
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDADgFAAQgEAAgCgDg");
	this.shape_1.setTransform(186.925,429.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_2.setTransform(182.875,427.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_3.setTransform(177.475,427.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDADgFAAQgEAAgCgDg");
	this.shape_4.setTransform(173.125,429.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_5.setTransform(170.275,426.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_6.setTransform(166.025,427.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgaAkIAAhFIAOAAIAAALQAEgNANAAQAKAAAGAGQAGAIAAAMQAAANgGAIQgGAGgKAAQgLAAgFgLIAAAdgAgLgJIAAACQAAAMALAAQAMAAAAgNQAAgOgMAAQgLAAAAANg");
	this.shape_7.setTransform(160.075,428.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgTAVQgHgIgBgNQABgMAHgHQAIgHALAAQANAAAHAHQAHAHAAAMQAAANgHAIQgHAGgNAAQgLAAgIgGgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_8.setTransform(153.6,427.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDADgFAAQgEAAgCgDg");
	this.shape_9.setTransform(149.025,429.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_10.setTransform(144.725,427.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQAEgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_11.setTransform(140.05,427.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgTAVQgHgIgBgNQABgMAHgHQAIgHALAAQANAAAHAHQAHAHAAAMQAAANgHAIQgHAGgNAAQgLAAgIgGgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_12.setTransform(134.7,427.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAALIgUAAIAAARQAAAKAKAAQAFAAAFgCIAAANQgHACgHABQgUAAAAgWg");
	this.shape_13.setTransform(129.05,426.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_14.setTransform(124.025,427.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgRApIAWhRIANAAIgWBRg");
	this.shape_15.setTransform(119.675,426.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgRApIAWhRIANAAIgWBRg");
	this.shape_16.setTransform(116.175,426.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgCQACgDAEAAQAFAAADADQACACAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgKQgDgCAAgEQAAgKAJAAQAKAAAAAKQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_17.setTransform(112.975,427.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_18.setTransform(108.925,427.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgaAkIAAhFIAOAAIAAALQAEgNANAAQAKAAAGAGQAGAIAAAMQAAANgGAIQgGAGgKAAQgLAAgFgLIAAAdgAgLgJIAAACQAAAMALAAQAMAAAAgNQAAgOgMAAQgLAAAAANg");
	this.shape_19.setTransform(103.275,428.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAALIgUAAIAAARQAAAKAJAAQAGAAAFgCIAAANQgHACgHABQgUAAAAgWg");
	this.shape_20.setTransform(97.35,426.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAALIgUAAIAAARQAAAKAKAAQAFAAAFgCIAAANQgHACgHABQgUAAAAgWg");
	this.shape_21.setTransform(92.35,426.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAJAkIAAgeQAAgJgIAAQgJAAAAAOIAAAZIgQAAIAAhHIAQAAIAAAfQAEgMALAAQAIAAAFAEQAFAFAAAJIAAAig");
	this.shape_22.setTransform(86.925,426.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgFAZQgCgDAAgDQAAgDACgBQACgCADgBQADABADACQACABAAADQAAADgCADQgDACgDAAQgDAAgCgCgAgFgOQgCgCAAgCQAAgEACgCQACgCADAAQADAAADACQACACAAAEQAAACgCACQgDADgDAAQgDAAgCgDg");
	this.shape_23.setTransform(80.05,427.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_24.setTransform(75.975,427.55);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_25.setTransform(71.475,427.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgTAUQgGgHAAgNQAAgMAGgHQAIgGALgBQAMABAIAGQAGAHABAMQgBANgGAHQgIAGgMABQgLgBgIgGgAgLgMQgEAEAAAIQAAAJAEAFQADAEAIAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_26.setTransform(66.25,427.55);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_27.setTransform(60.675,426.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_28.setTransform(55.325,426.775);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_29.setTransform(48.55,426.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_30.setTransform(44.425,427.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgYAkIAAhGIAJAAIAAANQADgHAEgEQAFgDAGAAQAGABAFACQAFADAEAGQACAFAAAKQAAAIgCAGQgEAFgFAEQgEADgHAAQgFgBgFgCQgFgDgCgGIAAAegAgHgYQgDACgCAEQgCADAAAGIAAABQAAAIADAFQAFAEAGAAQAGAAAFgEQAEgFAAgIQAAgKgEgDQgEgFgHAAQgEAAgDACg");
	this.shape_31.setTransform(38.7,428.45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgXAaQgIgJAAgRQAAgQAIgIQAJgJAOAAQAQAAAHAJQAJAIAAAQQAAARgJAJQgHAIgQAAQgOAAgJgIgAgPgSQgFAHAAALQAAANAFAGQAFAGAKAAQALAAAFgGQAFgGAAgNQAAgMgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_32.setTransform(31.7,426.775);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_33.setTransform(24.2,426.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_34.setTransform(20.075,427.55);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgNAiQgFgDgEgFQgCgHAAgJQAAgJACgFQAEgFAFgEQAEgDAHAAQAGABAEACQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgEAEQgFADgGAAQgHgBgEgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQADgCADgEQABgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_35.setTransform(13.95,426.55);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAEgKABQgGAAgFgCg");
	this.shape_36.setTransform(255.825,414.65);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgQAeQgHgGAAgOQAAgJADgFQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAAKIAAAGIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPAFQAAgNgOAAQgFAAgEAEQgEADgBAGIAcAAIAAAAgAgEgWIAIgNIAMAAIgLANg");
	this.shape_37.setTransform(250.475,413.65);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgFAaIgVgyIAMAAIAOAqIAQgqIALAAIgWAyg");
	this.shape_38.setTransform(244.8,414.65);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIABgBIAAgCQAAgFgDgCQgEgCgFAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHgBgFgEgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQABgDABgFIAAgBIgNAAQgFAAgDACg");
	this.shape_39.setTransform(239.15,414.65);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_40.setTransform(234.925,414.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAGACAEQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_41.setTransform(230.175,413.95);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgDgCQgCgCgGAAIgJABIgJADIAAgKIAJgCIAKgBQALgBAFAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIgBgEgEgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_42.setTransform(222.45,414.65);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_43.setTransform(214.525,414.65);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAGACAEQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_44.setTransform(209.175,413.95);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgLAAIAAgyIAKAAIAAANQACgIAFgCQAGgEAFAAQAGAAAEACQAEACACAEQADAFAAAGIAAAgg");
	this.shape_45.setTransform(203.9,414.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_46.setTransform(197.925,414.65);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAFQgDAEAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAFQgEAEAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAFQAFAEAAAKIAAAgg");
	this.shape_47.setTransform(190.625,414.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAJAAIAMAAIACgBIABgBIAAgCQAAgFgEgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHgBgFgEgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAAEgBQADgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_48.setTransform(183.15,414.65);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgFAaIgVgyIAMAAIAOAqIAQgqIALAAIgWAyg");
	this.shape_49.setTransform(177.75,414.65);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_50.setTransform(173.575,413.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAEgKABQgGAAgFgCg");
	this.shape_51.setTransform(169.725,414.65);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgCgEAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgDAGgFAEQgEADgGAAQgGAAgEgCg");
	this.shape_52.setTransform(164.05,414.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_53.setTransform(159.85,413.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_54.setTransform(155.975,414.65);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AAQAaIgQgVIgPAVIgLAAIAVgaIgTgYIALAAIANASIANgSIAMAAIgUAYIAXAag");
	this.shape_55.setTransform(150.6,414.65);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_56.setTransform(144.875,414.65);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIABgBIAAgCQAAgFgEgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgHgBgFgEgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAAEgBQADgCABgEQADgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_57.setTransform(136.7,414.65);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgGAAgIQAAgJADgGQACgFAGgEQAEgCAHAAQAFgBAFADQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgEADQgFAEgGAAQgHAAgEgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQAEgCACgEQABgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_58.setTransform(130.85,413.65);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_59.setTransform(126.575,413.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_60.setTransform(124,413.6);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgRAgQgEgDAAgIQAAgIAFgDQAFgEAIAAIAMAAIACgBIABgBIAAgCQAAgEgDgCQgEgCgFAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAHIAAAjIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHgBgFgEgAgJAPQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACgAgFgWIAIgNIANAAIgMANg");
	this.shape_61.setTransform(119.9,413.65);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgFAaIgVgyIAMAAIAOAqIARgqIAKAAIgWAyg");
	this.shape_62.setTransform(114.5,414.65);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIABgBIAAgCQAAgFgDgCQgEgCgFAAIgKABIgHADIAAgKIAJgCIAJgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgIgBgEgEgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_63.setTransform(106.3,414.65);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAGACAEQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_64.setTransform(101.225,413.95);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_65.setTransform(97.175,414.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_66.setTransform(92.125,414.65);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIABgBIABgBIAAgCQAAgGACgEQACgFAFgCQADgCAHAAQAHAAAGACIAAAJIgGgBIgFgBQgGAAgDACQgCADAAAGIAAADIAUAAIAAAIIgUAAIAAAqg");
	this.shape_67.setTransform(87.3,413.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgWAaQgJgJAAgRQAAgQAJgIQAHgJAPAAQAPAAAJAJQAIAIAAAQQAAARgIAJQgJAIgPAAQgPAAgHgIgAgPgSQgFAHAAALQAAANAFAGQAGAGAJAAQAKAAAGgGQAFgGAAgNQAAgMgFgGQgGgGgKAAQgKAAgFAGg");
	this.shape_68.setTransform(81.35,413.875);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgEAFQgCgCgBgDQABgCACgCQACgCACAAQAEAAACACQABACAAACQAAADgBACQgCACgEAAQgCAAgCgCg");
	this.shape_69.setTransform(71.35,416.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIABgBIAAgCQgBgFgDgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgHgBgFgEgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDABgFIAAgBIgNAAQgFAAgDACg");
	this.shape_70.setTransform(67.3,414.65);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_71.setTransform(63.075,414.6);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_72.setTransform(57.85,414.65);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgOAiQgFgDgDgGQgCgGAAgIQAAgJACgGQADgFAFgEQAFgCAHAAQAFgBAFADQAFADACAGIAAgfIALAAIAABHIgLAAIAAgNQgBAHgFADQgFAEgGAAQgHAAgFgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQADgCACgEQACgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_73.setTransform(51.5,413.65);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIAAgBIAAgCQAAgFgCgCQgDgCgGAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHgBgFgEgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQABgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_74.setTransform(45.75,414.65);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_75.setTransform(41.525,414.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgCgEAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQADgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgCAGgFAEQgFADgGAAQgGAAgEgCg");
	this.shape_76.setTransform(36.15,414.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgLAjQgFgBgEgCIAAgJQAJAFAKAAQAHAAAEgEQAEgEABgIIAAgIQgCAGgFADQgFADgFAAQgGAAgFgDQgFgDgDgFQgDgFAAgIQAAgJADgHQADgGAFgCQAFgDAGAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgDAFQgEAFgGADQgGACgHAAIgKgBgAgKgWQgDAEAAAJQAAAJADADQAEAEAGAAQAEAAADgCQAEgBACgEQABgCABgFIAAgCQgBgJgDgEQgEgEgHAAQgGAAgEAEg");
	this.shape_77.setTransform(29.95,415.625);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_78.setTransform(24.225,414.65);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAEgKABQgGAAgFgCg");
	this.shape_79.setTransform(18.875,414.65);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgCgCQgEgCgFAAIgJABIgJADIAAgKIAKgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIgBgEgEgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgBQADgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_80.setTransform(13.55,414.65);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAFAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgIAAgEgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_81.setTransform(239.55,401.75);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_82.setTransform(235.75,400.7);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_83.setTransform(229.075,401.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgOAiQgFgDgDgGQgCgFAAgKQAAgIACgFQADgHAFgCQAFgDAHgBQAFAAAFADQAFADACAGIAAggIALAAIAABHIgLAAIAAgLQgBAGgFAEQgFACgGAAQgHAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_84.setTransform(222.95,400.75);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAFgDAFAAQAGAAADACQAFACACAFQACAEABAGIAAAgg");
	this.shape_85.setTransform(214.55,401.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgSAeQgIgGAAgOQAAgMAIgHQAGgHAMAAQAMAAAHAHQAIAHAAAMQAAANgIAHQgHAHgMgBQgMABgGgHgAgLgCQgEAEAAAIQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgIgEgEQgEgFgIAAQgHAAgEAFgAgGgWIAIgOIANAAIgMAOg");
	this.shape_86.setTransform(208.4,400.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_87.setTransform(204.025,400.6);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_88.setTransform(200.125,401.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgYAjIAAhEIAJAAIAAAMQADgHAEgDQAFgDAFgBQAIAAAEADQAGADACAGQAEAGAAAIQAAAJgEAGQgCAFgGAEQgFACgGAAQgGAAgEgCQgFgDgDgGIAAAdgAgHgXQgEABgCAEQgCAEAAAEIAAACQAAAIAFAFQAEADAGAAQAGAAAFgDQAEgFAAgIQAAgKgEgDQgEgEgHgBQgDABgEACg");
	this.shape_89.setTransform(194.7,402.65);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_90.setTransform(190.025,400.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_91.setTransform(187.025,401.7);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_92.setTransform(182.225,401.75);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_93.setTransform(177.175,401.75);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFAAgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEABgFIAAgZIAKAAIAAAyIgKAAIAAgNQgDAIgEADQgGADgFAAQgFAAgFgCg");
	this.shape_94.setTransform(171.5,401.8);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_95.setTransform(166.025,401.75);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_96.setTransform(158.125,401.75);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgFAAgKQAAgIADgFQACgHAGgCQAEgDAHgBQAFAAAFADQAFADACAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgEAEQgFACgGAAQgHAAgEgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQAEgCACgEQABgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_97.setTransform(152,400.75);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_98.setTransform(143.975,401.75);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgCgFgBIgJACIgIADIAAgJIAIgDIAKgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgIAAgEgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_99.setTransform(138.65,401.75);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADADABAHQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_100.setTransform(131.625,401.7);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_101.setTransform(125.275,401.7);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQAMAAAIAHQAGAHAAAMQAAANgGAHQgIAHgMgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_102.setTransform(120.05,401.75);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_103.setTransform(114.1,401.7);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIAAgCIAAgDQAAgEgCgCQgDgCgGgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgFAEQgEACgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_104.setTransform(105.6,401.75);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgCgFgBIgJACIgIADIAAgJIAIgDIAKgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgIAAgEgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_105.setTransform(97.7,401.75);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_106.setTransform(92.625,401.05);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_107.setTransform(87.425,401.75);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgNAuIAAgJIAHACQAFgBABgCQACgCAAgGIAAgzIALAAIAAA0QAAAJgFAEQgEAFgIAAQgFAAgEgBgAACgiQgBgDAAgDQAAgDABgBQACgCAEAAQADAAACACQABABAAADQAAADgBADQgCABgDAAQgEAAgCgBg");
	this.shape_108.setTransform(82.525,401.6);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFAAgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEABgFIAAgZIAKAAIAAAyIgKAAIAAgNQgDAIgEADQgGADgFAAQgFAAgFgCg");
	this.shape_109.setTransform(78.8,401.8);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_110.setTransform(72.875,400.975);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgEAFQgCgCAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_111.setTransform(66.15,403.7);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_112.setTransform(61.9,401.75);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgOAiQgFgDgDgGQgCgFAAgKQAAgIACgFQADgHAFgCQAFgDAHgBQAFAAAFADQAFADACAGIAAggIALAAIAABHIgLAAIAAgLQgBAGgFAEQgFACgGAAQgHAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_113.setTransform(55.55,400.75);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIAAgCIAAgDQAAgEgCgCQgDgCgGgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgFAEQgEACgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_114.setTransform(49.8,401.75);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_115.setTransform(44.725,401.05);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_116.setTransform(39.55,401.75);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_117.setTransform(35.325,401.7);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_118.setTransform(30.575,401.05);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_119.setTransform(25.3,401.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_120.setTransform(19.15,401.75);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_121.setTransform(13.525,401.75);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_122.setTransform(195.15,387.8);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_123.setTransform(192.525,387.7);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AgFAaIgVgzIAMAAIAOArIAQgrIALAAIgVAzg");
	this.shape_124.setTransform(188.35,388.85);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_125.setTransform(184.175,387.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFADAHABIAIgBIAHgDIAAAJIgHADIgJAAQgMAAgGgGg");
	this.shape_126.setTransform(180.275,388.85);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AgNAiQgFgDgDgFQgDgHAAgJQAAgJADgFQADgFAFgEQAEgDAHAAQAGABAEACQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgEAEQgFADgGgBQgHAAgEgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQADgCADgEQABgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_127.setTransform(171.9,387.85);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgDQgEgCgFAAIgKABIgHAEIAAgJIAJgEIAJgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGgBQgIABgEgEgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAADgBQAEgDACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_128.setTransform(166.15,388.85);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AgNAiQgFgDgEgFQgCgHAAgJQAAgJACgFQAEgFAFgEQAEgDAHAAQAGABAEACQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgEAEQgFADgGgBQgHAAgEgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAEAAAEgCQADgCACgEQACgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_129.setTransform(160.3,387.85);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_130.setTransform(156.025,387.7);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_131.setTransform(153.45,387.8);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_132.setTransform(150.825,387.7);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AgIAiQgFgEgCgGIAAAMIgJAAIAAhHIAKAAIAAAfQACgFAEgEQAFgDAGAAQAHABAFACQAEADAEAGQACAEAAAKQAAAIgCAHQgEAFgEAEQgFADgHgBQgGABgFgDgAgHgFQgDACgCADQgCAEAAAFIAAABQAAAJADAFQAEADAHABQAGgBAFgDQAEgFAAgJQAAgJgEgDQgEgFgHAAQgDAAgEACg");
	this.shape_133.setTransform(146.6,387.85);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGgBQgIABgEgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAAEgBQADgDABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_134.setTransform(140.45,388.85);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJgBQgFABgDABQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKgBQgGAAgFgBg");
	this.shape_135.setTransform(135.375,388.85);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgDQAFgEAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_136.setTransform(129.95,388.8);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAGgGAMgBQAMABAHAGQAIAHAAAMQAAANgIAHQgHAGgMAAQgMAAgGgGgAgLgMQgEAEAAAIQAAAJAEAFQADADAIABQAIgBAEgDQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_137.setTransform(123.8,388.85);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AgZAkIAAhGIAKAAIAAANQADgHAEgEQAFgDAFAAQAIABAFACQAEADADAGQAEAFAAAKQAAAIgEAGQgDAFgEAEQgGADgGAAQgGgBgEgCQgFgDgDgGIAAAegAgHgYQgDACgDAEQgCAEAAAFIAAABQAAAIAFAFQAEADAGABQAGgBAFgDQAEgFAAgIQAAgJgEgEQgEgFgHAAQgDAAgEACg");
	this.shape_138.setTransform(117.85,389.75);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJgBQgFABgDABQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKgBQgGAAgFgBg");
	this.shape_139.setTransform(111.975,388.85);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_140.setTransform(106.625,388.85);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_141.setTransform(102.125,388.8);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_142.setTransform(94.525,388.85);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#000000").s().p("AgOAiQgFgDgDgFQgCgHAAgJQAAgJACgFQADgFAFgEQAFgDAHAAQAFABAFACQAFADACAGIAAgfIALAAIAABHIgLAAIAAgMQgBAGgFAEQgFADgGgBQgHAAgFgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_143.setTransform(88.4,387.85);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AgTAUQgGgHgBgNQABgMAGgHQAIgGALgBQANABAGAGQAIAHgBAMQABANgIAHQgGAGgNAAQgLAAgIgGgAgLgMQgEAEAAAIQAAAJAEAFQAEADAHABQAIgBAEgDQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_144.setTransform(79.9,388.85);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_145.setTransform(75.175,388.8);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFAAgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEABgFIAAgZIAKAAIAAAyIgKAAIAAgMQgDAGgEAEQgGADgFAAQgFAAgFgCg");
	this.shape_146.setTransform(69.8,388.9);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#000000").s().p("AgLAjQgFgBgEgCIAAgJQAJAFAKAAQAHAAAEgEQAEgEABgIIAAgIQgCAGgFADQgFADgFAAQgGAAgFgDQgFgDgDgFQgDgFAAgIQAAgJADgHQADgGAFgCQAFgDAGAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgDAFQgEAFgGADQgGACgHAAIgKgBgAgJgWQgEAEAAAJQAAAJAEADQAEAEAFAAQAEAAADgCQAEgBACgEQABgCABgFIAAgCQgBgJgDgEQgEgEgHAAQgGAAgDAEg");
	this.shape_147.setTransform(63.6,389.825);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_148.setTransform(57.875,388.85);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJgBQgFABgDABQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKgBQgGAAgFgBg");
	this.shape_149.setTransform(52.525,388.85);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgDQAEgEAGAAQAGAAADACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_150.setTransform(44.55,388.8);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAHgGALgBQANABAGAGQAIAHgBAMQABANgIAHQgGAGgNAAQgLAAgHgGgAgLgMQgEAEAAAIQAAAJAEAFQAEADAHABQAIgBAEgDQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_151.setTransform(38.4,388.85);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFADAHABIAIgBIAHgDIAAAJIgHADIgJAAQgMAAgGgGg");
	this.shape_152.setTransform(32.775,388.85);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#000000").s().p("AgHAOIAEgbIALAAIgIAbg");
	this.shape_153.setTransform(26.4,391.65);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#000000").s().p("AAEAhIAAg1IgSAEIAAgKIAdgGIAABBg");
	this.shape_154.setTransform(22.95,388.1);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#000000").s().p("AgNAhIAag4IgkAAIAAgJIAvAAIAAAHIgZA6g");
	this.shape_155.setTransform(18.175,388.1);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#000000").s().p("AAFAhIAAg1IgTAEIAAgKIAdgGIAABBg");
	this.shape_156.setTransform(12.95,388.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#000000").s().p("AgOAFIAAgIIAdAAIAAAIg");
	this.shape_157.setTransform(235.25,376);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#000000").s().p("AgSAgIAAgKQAEACAGAAQAGAAADgCQAEgCABgFQACgFAAgIIAAgZIgVAAIAAgKIAgAAIAAAkQAAALgDAGQgDAHgFADQgGAEgIAAQgHAAgFgCg");
	this.shape_158.setTransform(230.275,375.25);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#000000").s().p("AAUAhIgFgRIgeAAIgFARIgLAAIAZhBIAOAAIAYBBgAALAHIgLgfIgLAfIAWAAg");
	this.shape_159.setTransform(224.5,375.2);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_160.setTransform(215.725,375.95);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#000000").s().p("AgFAaIgVgyIAMAAIAOAqIAQgqIALAAIgVAyg");
	this.shape_161.setTransform(210.05,375.95);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIABgBIAAgCQAAgFgDgDQgEgBgFAAIgKABIgHADIAAgKIAJgCIAJgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgIAAgEgFgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_162.setTransform(204.4,375.95);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_163.setTransform(200.6,374.9);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_164.setTransform(196.725,375.95);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIAAgBIAAgCQAAgFgCgDQgDgBgGAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHAAgFgFgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQABgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_165.setTransform(188.85,375.95);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_166.setTransform(185.05,374.9);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAFgCQAEgEAGAAQAFAAAEACQAFACACAEQADAFgBAGIAAAgg");
	this.shape_167.setTransform(178.3,375.9);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIgBAEgEQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_168.setTransform(172.15,375.95);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_169.setTransform(166.525,375.95);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_170.setTransform(158.925,375.95);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_171.setTransform(153.575,375.95);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQACgIAGgCQAFgEAFAAQAGAAAEACQAEACACAEQACAFABAGIAAAgg");
	this.shape_172.setTransform(147.85,375.9);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAHgGALAAQANAAAGAGQAIAHAAAMQAAANgIAHQgGAHgNAAQgLAAgHgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIgBAEgEQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_173.setTransform(141.7,375.95);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_174.setTransform(137.325,374.8);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_175.setTransform(133.475,375.95);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQACgIAGgCQAFgEAFAAQAGAAAEACQAEACACAEQACAFABAGIAAAgg");
	this.shape_176.setTransform(128.05,375.9);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_177.setTransform(122.075,375.95);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#000000").s().p("AgYAhIAAhBIAZAAQAMAAAGAFQAGAGAAALQAAAHgDADQgDAGgFACQgFADgHAAIgQAAIAAAWgAgOACIAPAAQAGAAAEgDQAEgDgBgHQABgFgEgEQgDgDgIAAIgOAAg");
	this.shape_178.setTransform(116.3,375.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_179.setTransform(107.575,375.95);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#000000").s().p("AgOAiQgFgDgDgGQgCgGAAgIQAAgJACgGQADgFAFgEQAFgCAHAAQAFgBAFADQAFADACAGIAAgfIALAAIAABHIgLAAIAAgNQgBAHgFADQgFAEgGAAQgHAAgFgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQADgCACgEQACgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_180.setTransform(101.45,374.95);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_181.setTransform(93.425,375.95);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#000000").s().p("AgSAUQgIgGAAgOQAAgMAIgHQAHgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgHgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIgBAEgEQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_182.setTransform(87.9,375.95);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgCgGAAgIQAAgJACgGQAEgFAEgEQAFgCAHAAQAGgBAEADQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgEADQgFAEgGAAQgHAAgFgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAEAAAEgCQADgCACgEQACgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_183.setTransform(81.55,374.95);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAFgCQAEgEAGAAQAFAAAEACQAFACACAEQADAFgBAGIAAAgg");
	this.shape_184.setTransform(75.7,375.9);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIgBAEgEQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_185.setTransform(69.55,375.95);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAKIggAAIAAAUIAeAAIAAAIIgeAAIAAAbg");
	this.shape_186.setTransform(63.75,375.2);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#000000").s().p("AgZAjIAAgJIADABIAEAAIAFgBQADgBACgDIAEgGIgWgyIALAAIAQApIAQgpIAKAAIgUAyQgEAHgDAEQgDAEgEADQgEACgGAAIgIgBg");
	this.shape_187.setTransform(55.3,376.95);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_188.setTransform(47.325,375.95);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAHgGALAAQANAAAGAGQAIAHAAAMQAAANgIAHQgGAHgNAAQgLAAgHgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIgBAEgEQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_189.setTransform(41.8,375.95);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_190.setTransform(37.075,375.9);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgCgEgBgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQABgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgBAGgGAEQgFADgFAAQgGAAgEgCg");
	this.shape_191.setTransform(31.7,376);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#000000").s().p("AgLAjQgFgBgEgCIAAgJQAJAFAKAAQAHAAAEgEQAFgEgBgIIAAgIQgBAGgFADQgFADgFAAQgGAAgGgDQgEgDgDgFQgDgFAAgIQAAgJADgHQADgGAEgCQAGgDAGAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgEAFQgDAFgGADQgGACgHAAIgKgBgAgJgWQgFAEAAAJQAAAJAFADQADAEAGAAQAEAAAEgCQADgBACgEQABgCAAgFIAAgCQAAgJgDgEQgEgEgHAAQgFAAgEAEg");
	this.shape_192.setTransform(25.5,376.925);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_193.setTransform(19.775,375.95);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAgBIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_194.setTransform(13.975,375.175);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_195.setTransform(257.475,363.05);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgFgBgKQABgIADgFQACgHAGgCQAFgDAGgBQAFAAAFADQAFADADAGIAAggIAJAAIAABHIgJAAIAAgLQgDAGgEADQgFADgGAAQgGAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAEAAAEgCQAEgCACgEQACgEAAgEIAAgDQAAgIgEgDQgFgEgHgBQgGABgEAEg");
	this.shape_196.setTransform(251.35,362.05);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_197.setTransform(244.6,362);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgFADQgEADgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_198.setTransform(240.5,363.05);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_199.setTransform(236.275,363);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_200.setTransform(231.225,363.05);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgLAAIAAgyIAKAAIAAAMQACgGAFgEQAGgDAFAAQAGAAAEACQAEACACAFQADAEAAAGIAAAgg");
	this.shape_201.setTransform(225.5,363);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_202.setTransform(219.525,363.05);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#000000").s().p("AgSAaQgJgJAAgRQAAgJAEgIQAEgIAHgEQAIgEAJAAQAGAAAFABIAKAEIAAAKIgJgEQgFgCgGAAQgKAAgGAHQgGAGAAALQAAANAGAGQAFAGAKAAQAHAAAGgCIAAgPIgSAAIAAgIIAcAAIAAAdQgKAFgOAAQgOAAgIgIg");
	this.shape_203.setTransform(213.275,362.275);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_204.setTransform(204.55,363);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#000000").s().p("AgSAeQgIgGAAgOQAAgMAIgHQAHgHALAAQANAAAGAHQAIAHAAAMQAAANgIAHQgGAHgNgBQgLABgHgHgAgLgCQgEAEAAAIQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgIgEgEQgEgFgIAAQgHAAgEAFgAgGgWIAIgOIANAAIgMAOg");
	this.shape_205.setTransform(198.4,362.05);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_206.setTransform(194.025,361.9);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_207.setTransform(190.125,363.05);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_208.setTransform(185.025,363.05);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_209.setTransform(179.675,363.05);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_210.setTransform(175.175,363);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_211.setTransform(171.625,361.9);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#000000").s().p("AgaAhIAAhBIAVAAQAPAAAJAIQAJAIAAAQQAAAQgJAJQgJAIgPAAgAgQAYIALAAQALAAAFgGQAGgGgBgMQABgLgGgGQgFgGgLAAIgLAAg");
	this.shape_212.setTransform(167.05,362.3);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgCQgCgCgGgBIgJACIgJADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEADQgFADgGAAQgIAAgEgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_213.setTransform(158.1,363.05);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_214.setTransform(154.3,362);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgEQAGgDAFAAQAFAAAFACQAEACACAFQADAEAAAGIAAAgg");
	this.shape_215.setTransform(147.55,363);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_216.setTransform(141.575,363.05);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgHALAAQAMAAAIAHQAGAHAAAMQAAANgGAHQgIAHgMgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_217.setTransform(133.2,363.05);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGACIgHABQgIABgFgGg");
	this.shape_218.setTransform(127.625,362.35);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_219.setTransform(123.925,361.9);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_220.setTransform(120.925,363);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_221.setTransform(116.125,363.05);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_222.setTransform(111.075,363.05);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEAAAGIAAAgg");
	this.shape_223.setTransform(105.65,363);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_224.setTransform(101.175,361.9);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_225.setTransform(94.3,363.05);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#000000").s().p("AgOAiQgFgDgDgGQgCgFAAgKQAAgIACgFQADgHAFgCQAFgDAHgBQAFAAAFADQAFADACAGIAAggIALAAIAABHIgLAAIAAgLQgBAGgFADQgFADgGAAQgHAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgDQAAgIgEgDQgEgEgHgBQgGABgEAEg");
	this.shape_226.setTransform(87.95,362.05);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIAAgCIAAgDQAAgEgCgCQgDgCgGgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgFADQgEADgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_227.setTransform(82.2,363.05);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_228.setTransform(78.4,362);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQADgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgNQgCAIgFADQgFADgGAAQgFAAgFgCg");
	this.shape_229.setTransform(73.95,363.1);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_230.setTransform(68.425,363.05);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAGAAADACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_231.setTransform(63,363);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_232.setTransform(58.525,361.9);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#000000").s().p("AgFAZIgVgxIAMAAIAOApIAQgpIALAAIgVAxg");
	this.shape_233.setTransform(54.35,363.05);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_234.setTransform(46.425,363.05);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAHgHALAAQANAAAGAHQAIAHAAAMQAAANgIAHQgGAHgNgBQgLABgHgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_235.setTransform(40.9,363.05);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_236.setTransform(36.175,363);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFgBgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQABgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgNQgBAIgGADQgFADgFAAQgGAAgEgCg");
	this.shape_237.setTransform(30.8,363.1);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#000000").s().p("AgLAjQgFgBgEgCIAAgJQAJAFAKAAQAHAAAEgEQAFgEgBgIIAAgIQgBAGgFADQgFADgFAAQgGAAgGgDQgEgDgDgFQgDgFAAgIQAAgJADgHQADgGAEgCQAGgDAGAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgEAFQgDAFgGADQgGACgHAAIgKgBgAgJgWQgFAEAAAJQAAAJAFADQADAEAGAAQAEAAAEgCQADgBACgEQABgCAAgFIAAgCQAAgJgDgEQgEgEgHAAQgFAAgEAEg");
	this.shape_238.setTransform(24.6,364.025);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_239.setTransform(18.875,363.05);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_240.setTransform(13.525,363.05);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_241.setTransform(267.775,350.15);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#000000").s().p("AgOAiQgFgDgDgFQgCgHAAgJQAAgJACgFQADgFAFgEQAFgDAHAAQAFABAFACQAFADACAGIAAgfIALAAIAABHIgLAAIAAgMQgBAGgFAEQgFADgGAAQgHgBgFgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_242.setTransform(261.65,349.15);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_243.setTransform(253.325,350.15);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgCIAAgMIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_244.setTransform(247.975,349.45);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAFgDQAGgEAFAAQAFAAAFACQAEACACAFQACAEABAGIAAAgg");
	this.shape_245.setTransform(242.7,350.1);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_246.setTransform(236.725,350.15);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#000000").s().p("AgLAjQgFgBgEgCIAAgJQAJAFAKAAQAHAAAEgEQAEgEABgIIAAgIQgCAGgFADQgFADgFAAQgGAAgFgDQgFgDgDgFQgDgFAAgIQAAgJADgHQADgGAFgCQAFgDAGAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgDAFQgEAFgGADQgGACgHAAIgKgBgAgKgWQgDAEAAAJQAAAJADADQAEAEAGAAQAEAAADgCQAEgBACgEQABgCABgFIAAgCQgBgJgDgEQgEgEgHAAQgGAAgEAEg");
	this.shape_247.setTransform(230.65,351.125);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAADgCQAEgBACgEQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_248.setTransform(224.95,350.15);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#000000").s().p("AgHAOIAEgbIALAAIgIAbg");
	this.shape_249.setTransform(218.55,352.95);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#000000").s().p("AAUAhIgGgQIgdAAIgGAQIgKAAIAZhBIAOAAIAYBBgAALAHIgLgfIgLAfIAWAAg");
	this.shape_250.setTransform(214.05,349.4);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_251.setTransform(207.675,349.375);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#000000").s().p("AgKAfQgGgEgEgIQgEgIAAgLQAAgKAEgIQAEgHAGgEQAIgEAIAAQAFAAAFABQAFABAEADIAAAKIgJgEQgEgCgFAAQgGAAgEADQgFADgDAFQgCAGAAAHQAAANAFAGQAHAGAIAAIAHgBIAFgCIAGgDIAAAKQgEADgFABQgEABgGAAQgIAAgIgDg");
	this.shape_252.setTransform(199.15,349.375);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAAVIAfAAIAAAIIgfAAIAAAbg");
	this.shape_253.setTransform(193.4,349.4);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIggAAIAAASIAcAAIAAAIIgcAAIAAAUIAgAAIAAAKg");
	this.shape_254.setTransform(187.45,349.4);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#000000").s().p("AgHAOIAEgbIALAAIgIAbg");
	this.shape_255.setTransform(180.55,352.95);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgDQgCgCgGAAIgKABIgIAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgDACABAEQgBADADADQADACAEAAQADAAAEgCQADgBABgEQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_256.setTransform(176.65,350.15);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#000000").s().p("AANAkIAAgeQAAgMgMAAQgDAAgDACQgEACgCADQgCAEAAAGIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAFgDQAEgEAGAAQAFAAAEACQAFACACAFQACAEAAAFIAAAhgAgQgWQAAgFACgCQABgDACgBIAFgCIADABIADADIACAAIABABIABABQABAAAAgBQABAAAAAAQAAAAAAAAQABgBAAAAIABgEIAGAAQAAAGgCADQgDAEgEAAIgDgBIgDgDIgDgBIgBgBQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAAAIgBAFg");
	this.shape_257.setTransform(171.2,349.1);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgDQgEgCgFAAIgKABIgHAEIAAgJIAJgEIAJgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGAAQgIAAgEgEgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAADgCQAEgBACgEQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_258.setTransform(165.25,350.15);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#000000").s().p("AgZAkIAAhGIAKAAIAAANQACgHAFgEQAFgDAFAAQAHABAGACQAEADAEAGQADAFAAAKQAAAIgDAGQgEAFgEAEQgGADgGAAQgGgBgFgCQgEgDgDgGIAAAegAgHgYQgEACgBAEQgDADAAAGIAAABQAAAIAFAFQADAEAHgBQAGABAFgEQAEgFAAgIQAAgJgEgEQgEgFgHAAQgEAAgDACg");
	this.shape_259.setTransform(159.8,351.05);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFAAgDABQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKAAQgGgBgFgBg");
	this.shape_260.setTransform(153.925,350.15);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAASIAeAAIAAAIIgeAAIAAAUIAhAAIAAAKg");
	this.shape_261.setTransform(148.5,349.4);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFAAgDABQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKAAQgGgBgFgBg");
	this.shape_262.setTransform(140.375,350.15);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_263.setTransform(135.025,350.15);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHgBIAIAAIAHgDIAAAJIgHADIgJABQgMgBgGgGg");
	this.shape_264.setTransform(129.625,350.15);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_265.setTransform(125.775,349);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#000000").s().p("AgFAaIgVgzIAMAAIAOAqIAQgqIALAAIgWAzg");
	this.shape_266.setTransform(121.6,350.15);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_267.setTransform(117.075,350.1);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_268.setTransform(112.025,350.15);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABIAKAEIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_269.setTransform(106.225,349.375);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_270.setTransform(99.45,349.1);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAADgCQAEgBACgEQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_271.setTransform(95.35,350.15);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_272.setTransform(91.475,349);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHgBIAIAAIAHgDIAAAJIgHADIgJABQgMgBgGgGg");
	this.shape_273.setTransform(87.575,350.15);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgDQAFgEAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_274.setTransform(82.15,350.1);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgDQgCgCgGAAIgJABIgJAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgIAAgEgEgAgJAFQgDACABAEQgBADADADQADACAEAAQADAAAEgCQADgBABgEQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_275.setTransform(76.2,350.15);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAAMQADgGAFgDQAEgEAGAAQAFAAAEACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_276.setTransform(70.75,350.1);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_277.setTransform(66.275,349);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAAVIAfAAIAAAIIgfAAIAAAbg");
	this.shape_278.setTransform(62.2,349.4);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFAAgDABQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKAAQgGgBgFgBg");
	this.shape_279.setTransform(54.075,350.15);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_280.setTransform(50.225,349);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgCIAAgMIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_281.setTransform(46.375,349.45);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAFgDQAGgEAFAAQAFAAAFACQAEACACAFQACAEABAGIAAAgg");
	this.shape_282.setTransform(41.1,350.1);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgDQgDgCgFAAIgJABIgJAEIAAgJIAKgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgIAAgEgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAAEgCQADgBABgEQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_283.setTransform(35.15,350.15);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_284.setTransform(31.35,349.1);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_285.setTransform(28.8,349.1);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_286.setTransform(24.675,350.15);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgCIAAgMIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_287.setTransform(19.325,349.45);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABIAKAEIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_288.setTransform(13.975,349.375);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_289.setTransform(267.925,337.25);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgGAAgIQAAgJADgGQACgFAGgEQAEgCAHAAQAFgBAFADQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgEADQgFAEgGAAQgHAAgEgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQAEgCACgEQABgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_290.setTransform(261.8,336.25);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgLAAIAAgyIAKAAIAAANQACgIAFgCQAGgEAFAAQAGAAAEACQAEACACAEQADAFAAAGIAAAgg");
	this.shape_291.setTransform(253.4,337.2);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#000000").s().p("AgSAeQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAIAGQAGAHABAMQgBANgGAHQgIAHgMAAQgMAAgGgHgAgLgCQgEAEAAAIQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgIgEgEQgEgFgIABQgHgBgEAFgAgFgXIAHgMIANAAIgMAMg");
	this.shape_292.setTransform(247.25,336.25);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_293.setTransform(242.875,336.1);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_294.setTransform(238.975,337.25);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIABgBIAAgCQAAgFgDgCQgEgCgFAAIgKABIgHADIAAgKIAJgCIAJgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgIAAgEgFgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_295.setTransform(233.65,337.25);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_296.setTransform(229.775,336.1);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgEgGAAgIQAAgJAEgGQACgFAGgEQAFgCAGAAQAFgBAFADQAFADADAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgFADQgFAEgGAAQgGAAgFgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAEAAAEgCQAEgCACgEQACgDAAgFIAAgCQAAgJgFgEQgEgDgHAAQgGAAgEADg");
	this.shape_297.setTransform(225.15,336.25);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_298.setTransform(219.375,337.25);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAFQgDAEAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAFQgEAEAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAFQAFAEAAAKIAAAgg");
	this.shape_299.setTransform(212.075,337.2);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAEAAAIIAAAYg");
	this.shape_300.setTransform(205.725,337.2);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_301.setTransform(200.675,337.25);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAGACAEQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_302.setTransform(195.325,336.55);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQACgIAFgCQAGgEAFAAQAFAAAFACQAEACACAEQACAFABAGIAAAgg");
	this.shape_303.setTransform(190.05,337.2);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_304.setTransform(185.575,336.1);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIABgBIAAgCQgBgFgDgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgHAAgFgFgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDABgFIAAgBIgNAAQgFAAgDACg");
	this.shape_305.setTransform(178.9,337.25);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_306.setTransform(175.1,336.2);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgLAAIAAgyIAKAAIAAANQACgIAFgCQAGgEAFAAQAGAAAEACQAEACACAEQADAFAAAGIAAAgg");
	this.shape_307.setTransform(168.35,337.2);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAIAGQAGAHABAMQgBANgGAHQgIAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_308.setTransform(162.2,337.25);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_309.setTransform(156.575,337.25);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#000000").s().p("AgZAjIAAgJIADABIAEAAIAGgBQACgBACgDIAEgGIgWgyIALAAIAQApIAQgpIAKAAIgUAyQgDAHgEAEQgDAEgEADQgEACgHAAIgHgBg");
	this.shape_310.setTransform(148.65,338.25);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_311.setTransform(141.9,340.05);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_312.setTransform(138.275,337.25);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgGALAAQAMAAAIAGQAGAHAAAMQAAANgGAHQgIAHgMAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_313.setTransform(132.75,337.25);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAEAAAIIAAAYg");
	this.shape_314.setTransform(128.025,337.2);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgCgEAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgDAGgEAEQgFADgGAAQgGAAgEgCg");
	this.shape_315.setTransform(122.65,337.3);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#000000").s().p("AgLAjQgGgBgDgCIAAgJQAJAFAJAAQAIAAAEgEQAEgEABgIIAAgIQgDAGgEADQgFADgFAAQgHAAgEgDQgFgDgDgFQgDgFAAgIQAAgJADgHQADgGAFgCQAEgDAHAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgDAFQgEAFgGADQgGACgHAAIgKgBgAgKgWQgDAEAAAJQAAAJADADQAFAEAFAAQAEAAADgCQAEgBACgEQABgCABgFIAAgCQgBgJgDgEQgEgEgHAAQgFAAgFAEg");
	this.shape_316.setTransform(116.45,338.225);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_317.setTransform(110.725,337.25);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_318.setTransform(105.375,337.25);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_319.setTransform(97.475,337.25);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#000000").s().p("AgNAiQgFgDgEgGQgCgGAAgIQAAgJACgGQAEgFAFgEQAEgCAHAAQAGgBAEADQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgEADQgFAEgGAAQgHAAgEgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQADgCADgEQABgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_320.setTransform(91.35,336.25);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIABgBIAAgCQgBgFgDgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgHAAgFgFgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDABgFIAAgBIgNAAQgFAAgDACg");
	this.shape_321.setTransform(83.05,337.25);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#000000").s().p("AgIAkIAAgyIAJAAIAAAygAgKgWIAJgNIAMAAIgLANg");
	this.shape_322.setTransform(79.575,336.2);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#000000").s().p("AANAkIAAgeQAAgMgMAAQgDAAgDACQgEACgBADQgCAEAAAGIAAAZIgKAAIAAgyIAJAAIAAANQACgIAGgCQAFgEAFAAQAGAAAEACQAEACACAEQACAFABAFIAAAhgAgQgWQAAgEACgDQABgEACgBIAEgBIAFABIACACIABABIACABIACABQAAAAAAgBQABAAAAAAQAAAAAAAAQABgBAAAAIABgEIAHAAQgBAGgCADQgDADgEAAIgEAAIgCgDIgCgBIgCgBQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAABIgBAEg");
	this.shape_323.setTransform(74.95,336.2);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgDgCQgCgCgGAAIgJABIgJADIAAgKIAJgCIAKgBQALgBAFAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIAAgEgFgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_324.setTransform(69,337.25);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#000000").s().p("AgYAkIAAhFIAJAAIAAALQADgGAEgEQAFgCAGAAQAGgBAFADQAGADACAGQADAFAAAKQAAAIgDAFQgCAHgGACQgEAEgHAAQgFAAgFgDQgFgDgCgGIAAAegAgHgXQgEABgCAEQgBADAAAGIAAACQAAAHADAEQAFAFAGAAQAHAAAEgFQAEgEAAgIQAAgJgEgFQgEgDgHAAQgEAAgDACg");
	this.shape_325.setTransform(63.55,338.15);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAFQgDAEAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAFQgEAEAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAFQAFAEAAAKIAAAgg");
	this.shape_326.setTransform(55.725,337.2);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQAMAAAIAGQAGAHAAAMQAAANgGAHQgIAHgMAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_327.setTransform(48.05,337.25);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_328.setTransform(42.425,337.25);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#000000").s().p("AgSAUQgIgGAAgOQAAgMAIgHQAHgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgHgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_329.setTransform(34.35,337.25);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAFQgDAEAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAFQgEAEAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAFQAFAEAAAKIAAAgg");
	this.shape_330.setTransform(26.825,337.2);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_331.setTransform(19.15,337.25);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_332.setTransform(13.525,337.25);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#000000").s().p("AgHAOIAEgbIALAAIgIAbg");
	this.shape_333.setTransform(245.8,327.15);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgCQgCgDgGAAIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_334.setTransform(241.9,324.35);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_335.setTransform(236.825,323.65);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_336.setTransform(233.2,323.3);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgDgFAAIgJACIgJADIAAgJIAKgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgIAAgEgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_337.setTransform(229.1,324.35);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#000000").s().p("AAaAhIAAgzIgXAzIgFAAIgXg0IAAA0IgKAAIAAhBIAOAAIAVAxIAWgxIAOAAIAABBg");
	this.shape_338.setTransform(222.075,323.6);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#000000").s().p("AgXAiIAAgJIAVgSIAHgHIAFgHQABgDAAgDQAAgFgDgDQgDgCgGAAQgFAAgGACQgGACgFADIAAgKQAKgHANAAQAHAAAFADQAFACADAEQACAEAAAFQAAAFgCAFQgCAFgEADIgKAKIgMALIAgAAIAAAKg");
	this.shape_339.setTransform(212.275,323.525);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#000000").s().p("AgXAiIAAgJIAVgSIAHgHIAFgHQABgDAAgDQAAgFgDgDQgDgCgGAAQgFAAgGACQgGACgFADIAAgKQAKgHANAAQAHAAAFADQAFACADAEQACAEAAAFQAAAFgCAFQgCAFgEADIgKAKIgMALIAgAAIAAAKg");
	this.shape_340.setTransform(206.575,323.525);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#000000").s().p("AAFAhIAAg1IgTAEIAAgKIAdgGIAABBg");
	this.shape_341.setTransform(201.3,323.6);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#000000").s().p("AAFAhIAAg1IgTAEIAAgKIAdgGIAABBg");
	this.shape_342.setTransform(197,323.6);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#000000").s().p("AATAhIgTgbIgTAbIgMAAIAagiIgYgfIAOAAIAPAXIAQgXIANAAIgXAfIAaAig");
	this.shape_343.setTransform(191.8,323.6);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#000000").s().p("AgZAhIAAhBIAZAAQAMAAAGAEQAGAEAAAIQAAAGgDAEQgDAEgFACQANACAAANQAAAJgGAEQgGAFgMAAgAgOAYIAPAAQAHAAAEgDQADgCAAgFQABgGgEgCQgDgDgIAAIgPAAgAgOgEIAPAAQAFAAAEgDQADgCAAgFQAAgFgDgCQgDgDgHAAIgOAAg");
	this.shape_344.setTransform(185.5,323.6);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#000000").s().p("AATAhIgTgbIgSAbIgNAAIAZgiIgWgfIAMAAIAQAXIAQgXIANAAIgXAfIAaAig");
	this.shape_345.setTransform(178.8,323.6);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#000000").s().p("AgHAOIAEgbIALAAIgIAbg");
	this.shape_346.setTransform(171.65,327.15);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#000000").s().p("AAQAZIgQgUIgPAUIgLAAIAVgZIgTgYIALAAIANASIANgSIAMAAIgUAXIAXAag");
	this.shape_347.setTransform(167.7,324.35);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_348.setTransform(161.975,324.35);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_349.setTransform(157.825,323.2);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#000000").s().p("AgIAiQgEgDgDgHIAAALIgKAAIAAhHIAKAAIAAAhQADgHAEgCQAFgDAFgBQAHAAAGADQAEADAEAGQADAFAAAIQAAAKgDAGQgEAFgEAEQgGACgGAAQgGAAgFgCgAgHgEQgDABgCADQgCAEgBAEIAAACQABAJAEAFQADADAHAAQAHAAAEgDQAEgFAAgJQAAgKgEgCQgEgEgHgBQgEAAgDADg");
	this.shape_350.setTransform(153.6,323.35);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#000000").s().p("AATAhIgTgbIgSAbIgNAAIAZgiIgWgfIANAAIAPAXIARgXIAMAAIgXAfIAaAig");
	this.shape_351.setTransform(147,323.6);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_352.setTransform(139.925,321.7);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAJAAIAMAAIACAAIABgCIAAgDQAAgEgEgCQgCgDgGAAIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQACACAFAAQADAAAEgCQADgCABgDQADgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_353.setTransform(135.8,324.35);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#000000").s().p("AgEAhIAAg4IgYAAIAAgJIA5AAIAAAJIgYAAIAAA4g");
	this.shape_354.setTransform(130.05,323.6);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_355.setTransform(122.9,327.15);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_356.setTransform(119.275,323.65);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_357.setTransform(114.075,324.35);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_358.setTransform(108.425,324.35);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_359.setTransform(103.925,324.3);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_360.setTransform(99.175,323.65);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_361.setTransform(93.825,323.575);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgDgFAAgKQAAgIADgFQAEgHAEgCQAGgDAGgBQAGAAAEADQAFADADAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgFAEQgFACgGAAQgGAAgGgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQAEgCABgEQADgEAAgEIAAgDQAAgIgFgDQgEgEgHgBQgGABgEAEg");
	this.shape_362.setTransform(85,323.35);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_363.setTransform(80.375,324.3);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgHALAAQAMAAAIAHQAGAHAAAMQAAANgGAHQgIAHgMgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_364.setTransform(75.15,324.35);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#000000").s().p("AgLAjQgGgBgDgCIAAgJQAJAFAJAAQAIAAAEgEQAEgEAAgIIAAgIQgCAGgEADQgEADgGAAQgHAAgEgDQgFgDgDgFQgDgFAAgIQAAgJADgHQADgGAFgCQAEgDAHAAQAGAAAEADQAFADACAGIAAgLIAKAAIAAAuQAAAJgDAFQgEAFgGADQgGACgHAAIgKgBgAgKgWQgDAEAAAJQAAAJADADQAFAEAFAAQAEAAADgCQAEgBACgEQACgCgBgFIAAgCQAAgJgDgEQgEgEgHAAQgFAAgFAEg");
	this.shape_365.setTransform(68.85,325.325);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_366.setTransform(64.625,323.2);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#000000").s().p("AAOAhIgRgaIgMAAIAAAaIgLAAIAAhBIAaAAQAMAAAHAFQAGAFAAAKQAAAIgEAEQgFAEgJACIAUAbgAgPgBIAQAAQAGgBAEgCQADgDAAgFQAAgFgDgDQgFgDgGAAIgPAAg");
	this.shape_367.setTransform(60.3,323.6);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_368.setTransform(51.375,324.35);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_369.setTransform(46.025,323.65);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQAAgEgEgCQgCgDgGAAIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQACACAFAAQADAAAEgCQADgCABgDQADgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_370.setTransform(40.85,324.35);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#000000").s().p("AgHAiQgFgDgDgHIAAALIgJAAIAAhHIAJAAIAAAhQADgHAFgCQAEgDAFgBQAIAAAEADQAGADACAGQAEAFAAAIQAAAKgEAGQgCAFgGAEQgFACgGAAQgGAAgEgCgAgHgEQgEABgCADQgCAEAAAEIAAACQAAAJAFAFQAEADAGAAQAGAAAFgDQAEgFAAgJQAAgKgEgCQgEgEgHgBQgDAAgEADg");
	this.shape_371.setTransform(35.4,323.35);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#000000").s().p("AAUAhIgGgQIgdAAIgGAQIgKAAIAZhBIAOAAIAYBBgAALAHIgLggIgLAgIAWAAg");
	this.shape_372.setTransform(28.65,323.6);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#000000").s().p("AgNAhQgFgBgFgDIABgKIAKAEIAKACQAFAAADgCQAEgBACgCQABgDAAgDQAAgEgDgDQgFgDgGAAIgKAAIAAgIIAKAAQAFAAADgCQAFgDAAgFQAAgEgFgDQgEgDgGAAQgGAAgEACQgGABgDACIAAgKQAIgEAMAAQAHAAAGACQAGACADAEQACAEAAAGQAAAFgDAEQgDAEgHACQAIABAEAEQADAEAAAGQAAAGgDAEQgDAEgGADQgGACgHAAQgGAAgGgBg");
	this.shape_373.setTransform(19.9,323.575);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#000000").s().p("AgMAgIgLgDIABgKQAFACAFABIALACQAGAAAEgDQAEgDAAgGQAAgHgFgDQgEgCgIAAIgJAAIgIABIAAghIAqAAIAAAJIggAAIAAAQIALgBQALAAAHAFQAGAEAAALQAAAGgDAFQgEAFgFADQgGACgHAAQgGAAgFgBg");
	this.shape_374.setTransform(14.1,323.65);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#000000").s().p("AgHAOIAEgbIALAAIgIAbg");
	this.shape_375.setTransform(269.55,314.25);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_376.setTransform(265.625,311.45);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFgBgDACQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_377.setTransform(260.275,311.45);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFgBgDACQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_378.setTransform(255.225,311.45);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgDAGgEAEQgFADgGAAQgGAAgEgCg");
	this.shape_379.setTransform(249.55,311.5);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAHgGALgBQANABAGAGQAIAHgBAMQABANgIAHQgGAGgNABQgLgBgHgGgAgLgMQgEAEAAAIQAAAJAEAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_380.setTransform(243.6,311.45);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#000000").s().p("AAQAhIAAgdIgfAAIAAAdIgKAAIAAhBIAKAAIAAAbIAfAAIAAgbIAKAAIAABBg");
	this.shape_381.setTransform(237.075,310.7);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#000000").s().p("AgZAhIAAhBIAZAAQAMAAAGADQAGAFAAAJQAAAFgDAEQgDAEgFACQANACAAANQAAAJgGAFQgGAEgMAAgAgOAYIAPAAQAHAAAEgDQADgCAAgFQAAgGgDgDQgDgCgIAAIgPAAgAgOgEIAOAAQAHAAADgCQADgDABgFQgBgFgDgDQgDgBgHAAIgOAAg");
	this.shape_382.setTransform(228.05,310.7);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#000000").s().p("AgEAhIAAhBIAJAAIAABBg");
	this.shape_383.setTransform(223.225,310.7);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#000000").s().p("AAaAhIAAgzIgXAzIgFAAIgXg0IAAA0IgKAAIAAhBIAOAAIAVAxIAWgxIAOAAIAABBg");
	this.shape_384.setTransform(217.375,310.7);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAGAAADACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_385.setTransform(207.45,311.4);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_386.setTransform(201.475,311.45);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_387.setTransform(194.85,310.4);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHgBgFgDgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAADgBQAEgDACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_388.setTransform(190.75,311.45);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_389.setTransform(186.875,310.3);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHAAIAIgBIAHgDIAAAJIgHADIgJABQgMgBgGgGg");
	this.shape_390.setTransform(182.975,311.45);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAHgGALgBQANABAGAGQAIAHgBAMQABANgIAHQgGAGgNABQgLgBgHgGgAgLgMQgEAEAAAIQAAAJAEAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_391.setTransform(177.45,311.45);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFgBgDACQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_392.setTransform(171.875,311.45);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#000000").s().p("AgTAUQgGgHAAgNQAAgMAGgHQAIgGALgBQAMABAIAGQAGAHAAAMQAAANgGAHQgIAGgMABQgLgBgIgGgAgLgMQgEAEAAAIQAAAJAEAFQADAEAIAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_393.setTransform(163.8,311.45);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_394.setTransform(159.425,310.3);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_395.setTransform(156.85,310.4);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_396.setTransform(154.225,310.3);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHAAIAIgBIAHgDIAAAJIgHADIgJABQgMgBgGgGg");
	this.shape_397.setTransform(150.325,311.45);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_398.setTransform(146.475,310.3);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_399.setTransform(140.675,311.4);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#000000").s().p("AgTAUQgGgHgBgNQABgMAGgHQAIgGALgBQANABAGAGQAIAHgBAMQABANgIAHQgGAGgNABQgLgBgIgGgAgLgMQgEAEAAAIQAAAJAEAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_400.setTransform(133,311.45);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#000000").s().p("AgOAiQgFgDgDgFQgCgHAAgJQAAgJACgFQADgFAFgEQAFgDAHAAQAFABAFACQAFADACAGIAAgfIALAAIAABHIgLAAIAAgMQgBAGgFAEQgFADgGAAQgHgBgFgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgDQAAgIgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_401.setTransform(126.65,310.45);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_402.setTransform(118.25,311.4);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAGgGAMgBQAMABAHAGQAIAHAAAMQAAANgIAHQgHAGgMABQgMgBgGgGgAgLgMQgEAEAAAIQAAAJAEAFQADAEAIAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_403.setTransform(112.1,311.45);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHAAIAIgBIAHgDIAAAJIgHADIgJABQgMgBgGgGg");
	this.shape_404.setTransform(106.475,311.45);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#000000").s().p("AgZAjIAAgJIADAAIAEAAIAGAAQACgBACgCIAEgHIgWgzIAMAAIAPAqIAPgqIALAAIgVAzQgDAHgDAEQgCAFgEACQgFABgHAAIgHAAg");
	this.shape_405.setTransform(98.55,312.45);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#000000").s().p("AgNAnQAJgHAEgKQAEgKAAgMQAAgLgEgKQgEgKgJgHIAFgGQAKAIAGALQAGAMAAANQAAAOgGAMQgGALgKAIg");
	this.shape_406.setTransform(90.925,311.075);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#000000").s().p("AgSAbQgEgEgCgGQgCgGAAgJQAAgQAIgKQAHgJAPAAIAKABIAIADIAAAJIgIgDIgJgBQgJAAgGAHQgFAGAAAMQACgEAFgDQAGgDAFAAQAHAAAGADQAFACADAEQADAFAAAHQAAAGgDAFQgDAFgGADQgGADgIAAQgMAAgHgHgAgHAAQgDABgCADQgCADAAAEQAAAEACAEQACADADACQAEABADAAQAIAAAEgDQAEgEAAgGQAAgHgEgDQgEgDgIAAQgDAAgEABg");
	this.shape_407.setTransform(86.275,310.675);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#000000").s().p("AgSAbQgEgEgCgGQgCgGAAgJQAAgQAIgKQAHgJAPAAIAKABIAIADIAAAJIgIgDIgJgBQgJAAgGAHQgFAGAAAMQACgEAFgDQAGgDAFAAQAHAAAGADQAFACADAEQADAFAAAHQAAAGgDAFQgDAFgGADQgGADgIAAQgMAAgHgHgAgHAAQgDABgCADQgCADAAAEQAAAEACAEQACADADACQAEABADAAQAIAAAEgDQAEgEAAgGQAAgHgEgDQgEgDgIAAQgDAAgEABg");
	this.shape_408.setTransform(79.975,310.675);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#000000").s().p("AgNAhIgIgDIAAgJIAIADIAJABQAJAAAGgHQAFgGAAgMQgCAEgFADQgFADgGAAQgHAAgGgDQgFgCgDgFQgDgEAAgHQAAgGADgFQADgFAGgDQAGgDAIAAQAMAAAHAHQAEAEACAGQACAGAAAJQAAAQgIAKQgHAJgPAAIgKgBgAgLgVQgEAEAAAGQAAAHAEADQAEADAHAAQAEAAAEgCQADAAACgDQACgDAAgEQAAgEgCgEQgCgDgDgCQgDgCgFAAQgHAAgEAEg");
	this.shape_409.setTransform(73.625,310.675);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#000000").s().p("AgOAfQgGgCgDgEQgEgEAAgHQAAgDACgDQACgDAEgCQADgDAFAAQgGgCgEgEQgEgEAAgFQABgGADgEQACgEAHgCQAFgCAHAAQAIAAAGACQAGACADAEQADAEAAAGQAAAFgDAFQgEADgGACIAIACQADADACADQACADAAADQAAAHgDAEQgEAEgGACQgGADgJAAQgHAAgHgDgAgLAGQgEADgBAFQABAGAEACQADADAIABQAIgBAFgDQAEgCAAgGQAAgLgRAAQgIAAgDADgAgKgWQgEADAAAEQAAAFAEADQAEADAGgBQAHAAAFgCQADgDAAgFQAAgEgDgDQgFgDgHAAQgGAAgEADg");
	this.shape_410.setTransform(67.3,310.7);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#000000").s().p("AgSAbQgEgEgCgGQgCgGAAgJQAAgQAIgKQAHgJAPAAIAKABIAIADIAAAJIgIgDIgJgBQgJAAgGAHQgFAGAAAMQACgEAFgDQAGgDAFAAQAHAAAGADQAFACADAEQADAFAAAHQAAAGgDAFQgDAFgGADQgGADgIAAQgMAAgHgHgAgHAAQgDABgCADQgCADAAAEQAAAEACAEQACADADACQAEABADAAQAIAAAEgDQAEgEAAgGQAAgHgEgDQgEgDgIAAQgDAAgEABg");
	this.shape_411.setTransform(60.975,310.675);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#000000").s().p("AgKAfQgGgEgEgIQgEgIAAgLQAAgKAEgIQAEgHAGgEQAIgEAIAAQAFAAAFABQAFABADADIAAAKIgIgEQgEgCgFAAQgGAAgEADQgFADgDAFQgCAGAAAHQAAANAFAGQAHAGAIAAIAHgBIAGgCIAFgDIAAAKQgEADgFABQgEABgGAAQgIAAgIgDg");
	this.shape_412.setTransform(54.8,310.675);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#000000").s().p("AgTAUQgGgHgBgNQABgMAGgHQAIgGALgBQAMABAIAGQAGAHAAAMQAAANgGAHQgIAGgMABQgLgBgIgGgAgLgMQgEAEAAAIQAAAJAEAFQADAEAIAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_413.setTransform(46.25,311.45);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_414.setTransform(41.525,311.4);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_415.setTransform(36.775,310.75);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFgBgDACQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_416.setTransform(31.875,311.45);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_417.setTransform(28.025,310.3);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#000000").s().p("AgLAjQgGgBgDgCIAAgJQAJAFAKAAQAHAAAEgEQAFgEAAgIIAAgIQgCAGgFADQgEADgGAAQgGAAgGgDQgEgDgDgFQgDgFAAgIQAAgJADgHQADgGAEgCQAGgDAGAAQAGAAAEADQAFADACAGIAAgLIAKAAIAAAuQAAAJgEAFQgDAFgGADQgGACgHAAIgKgBgAgJgWQgEAEgBAJQABAJAEADQAEAEAFAAQAEAAAEgCQADgBACgEQACgCAAgFIAAgCQAAgJgEgEQgEgEgHAAQgGAAgDAEg");
	this.shape_418.setTransform(23.45,312.425);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_419.setTransform(17.725,311.45);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_420.setTransform(13.225,311.4);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_421.setTransform(259.175,298.55);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgEgGAAgIQAAgJAEgGQACgFAGgEQAFgCAGAAQAFgBAFADQAFADADAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgFADQgFAEgGAAQgGAAgFgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAEAAAEgCQAEgCACgEQACgDAAgFIAAgCQAAgJgFgEQgEgDgHAAQgGAAgEADg");
	this.shape_422.setTransform(253.05,297.55);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#000000").s().p("AgMAOQgGgFABgJQgBgIAGgFQAEgEAIgBQAJABAFAEQAEAFAAAIQAAAJgEAFQgFAEgJAAQgIAAgEgEgAgHgIQgCADAAAFQAAALAJAAQAFAAADgDQACgDAAgFQAAgKgKAAQgEAAgDACg");
	this.shape_423.setTransform(245.3,296.25);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgDAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAEgCQAFgEAGAAQAFAAAEACQAFACACAEQACAFAAAGIAAAgg");
	this.shape_424.setTransform(240.15,298.5);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_425.setTransform(233.2,297.5);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_426.setTransform(229.075,298.55);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgDAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAEgCQAFgEAGAAQAFAAAEACQAFACACAEQACAFAAAGIAAAgg");
	this.shape_427.setTransform(220.8,298.5);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgGALAAQAMAAAIAGQAGAHAAAMQAAANgGAHQgIAHgMAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQADAEAIABQAIgBAEgEQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_428.setTransform(214.65,298.55);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAEAHABIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_429.setTransform(209.025,298.55);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_430.setTransform(202.65,301.35);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgGgBgIQABgJADgGQACgFAGgEQAFgCAGAAQAFgBAFADQAFADADAGIAAgfIAJAAIAABHIgJAAIAAgNQgDAHgEADQgFAEgGAAQgGAAgFgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAEAAAEgCQAEgCACgEQABgDABgFIAAgCQAAgJgEgEQgFgDgHAAQgGAAgEADg");
	this.shape_431.setTransform(198.25,297.55);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_432.setTransform(192.475,298.55);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_433.setTransform(187.125,297.85);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_434.setTransform(183.425,297.4);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAFQgDAEAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAFQgEAEAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAFQAFAEAAAKIAAAgg");
	this.shape_435.setTransform(177.625,298.5);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_436.setTransform(171.625,297.4);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#000000").s().p("AgUAhIAAhBIAKAAIAAA3IAfAAIAAAKg");
	this.shape_437.setTransform(167.775,297.8);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_438.setTransform(159.425,298.55);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#000000").s().p("AgZAkIAAhFIAKAAIAAALQACgGAFgEQAFgCAGAAQAHgBAFADQAFADADAGQACAFAAAKQAAAIgCAFQgDAHgFACQgFAEgHAAQgFAAgGgDQgEgDgCgGIAAAegAgHgXQgDABgCAEQgCADAAAGIAAACQAAAHAEAEQADAEAHABQAHgBAEgEQAEgEAAgIQAAgJgEgFQgEgDgHAAQgEAAgDACg");
	this.shape_439.setTransform(153.7,299.45);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAIAGQAGAHABAMQgBANgGAHQgIAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAEAHABQAIgBAEgEQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_440.setTransform(147.35,298.55);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_441.setTransform(142.625,298.5);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgDgEABgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQACgEAAgFIAAgZIAJAAIAAAyIgJAAIAAgMQgCAGgGAEQgEADgGAAQgFAAgFgCg");
	this.shape_442.setTransform(137.25,298.6);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAATIAeAAIAAAIIgeAAIAAATIAhAAIAAAKg");
	this.shape_443.setTransform(131.4,297.8);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_444.setTransform(122.975,298.55);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAEAHABIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_445.setTransform(117.575,298.55);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAANQADgIAFgCQAEgEAGAAQAFAAAEACQAFACACAEQADAFgBAGIAAAgg");
	this.shape_446.setTransform(112.15,298.5);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAJAAIAMAAIACgBIABgBIAAgCQAAgFgEgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHgBgFgEgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAAEgBQADgDACgDQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_447.setTransform(106.2,298.55);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_448.setTransform(101.975,298.5);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgCgEgBgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgCAGgEAEQgGADgFAAQgGAAgEgCg");
	this.shape_449.setTransform(96.6,298.6);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_450.setTransform(91.125,298.55);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAFgCQAEgEAGAAQAFAAAEACQAFACACAEQACAFAAAGIAAAgg");
	this.shape_451.setTransform(85.7,298.5);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#000000").s().p("AgEAhIAAhBIAJAAIAABBg");
	this.shape_452.setTransform(81.175,297.8);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_453.setTransform(74.425,298.55);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#000000").s().p("AgLAlIAAgqIgIAAIAAgIIAFAAIACgBIABgBIAAgCQAAgGACgEQADgFAEgCQAEgCAGAAQAIAAAEACIAAAJIgFgBIgFgBQgGAAgDACQgCADAAAGIAAADIAUAAIAAAIIgUAAIAAAqg");
	this.shape_454.setTransform(69.6,297.4);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_455.setTransform(65.975,297.4);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#000000").s().p("AgUAhIAAhBIAKAAIAAA3IAfAAIAAAKg");
	this.shape_456.setTransform(62.125,297.8);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_457.setTransform(54.075,298.55);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_458.setTransform(50.225,297.4);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_459.setTransform(46.375,297.85);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQACgIAFgCQAGgEAFAAQAFAAAFACQAEACACAEQACAFABAGIAAAgg");
	this.shape_460.setTransform(41.1,298.5);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgDgCQgDgCgFAAIgJABIgJADIAAgKIAKgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIgBgEgEgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgBQADgDABgDQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_461.setTransform(35.15,298.55);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_462.setTransform(31.35,297.5);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_463.setTransform(28.8,297.5);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_464.setTransform(24.675,298.55);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_465.setTransform(19.325,297.85);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAgBIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_466.setTransform(13.975,297.775);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_467.setTransform(120.7,285.6);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_468.setTransform(114.55,285.65);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_469.setTransform(108.925,285.65);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_470.setTransform(101.05,285.65);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGACIgHABQgIABgFgGg");
	this.shape_471.setTransform(95.975,284.95);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_472.setTransform(92.275,284.5);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_473.setTransform(89.275,285.6);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_474.setTransform(84.475,285.65);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_475.setTransform(79.425,285.65);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFAAgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEAAgFIAAgZIALAAIAAAyIgLAAIAAgNQgCAIgEADQgGADgFAAQgGAAgEgCg");
	this.shape_476.setTransform(73.75,285.7);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_477.setTransform(68.275,285.65);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_478.setTransform(61.9,288.45);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgHAMAAQAMAAAIAHQAGAHABAMQgBANgGAHQgIAHgMgBQgMABgGgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_479.setTransform(57.8,285.65);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgEgFAAgKQAAgIAEgFQACgHAGgCQAFgDAGgBQAFAAAFADQAFADADAGIAAggIAJAAIAABHIgJAAIAAgLQgCAGgFAEQgFACgGAAQgGAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAEAAAEgCQAEgCACgEQACgEAAgEIAAgDQAAgIgFgDQgEgEgHgBQgGABgEAEg");
	this.shape_480.setTransform(51.45,284.65);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_481.setTransform(45.7,285.65);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_482.setTransform(41.825,284.5);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_483.setTransform(37.925,285.65);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_484.setTransform(32.5,285.6);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAJAAIAMAAIACAAIABgCIAAgDQAAgEgEgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgFAEQgEACgGAAQgHAAgFgDgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgCQAEgCACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_485.setTransform(26.55,285.65);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgEQAGgDAFAAQAFAAAFACQAEACACAFQADAEAAAGIAAAgg");
	this.shape_486.setTransform(21.1,285.6);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_487.setTransform(16.625,284.5);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIACAAIAAgCIAAgCQAAgGACgEQADgEAEgCQAEgDAGAAQAHAAAGADIAAAIIgGgBIgGgBQgFAAgDADQgCADAAAFIAAADIATAAIAAAIIgTAAIAAAqg");
	this.shape_488.setTransform(13.3,284.5);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_489.setTransform(243.55,271.7);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGgBQgIABgEgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAAEgBQADgDABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_490.setTransform(239.45,272.75);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHAAQgIAAgFgFg");
	this.shape_491.setTransform(234.375,272.05);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_492.setTransform(230.675,271.6);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#000000").s().p("AgYAkIAAhGIAJAAIAAANQADgHAEgEQAFgDAGAAQAGABAFACQAGADACAGQADAFAAAKQAAAIgDAGQgCAFgGAEQgEADgHgBQgFAAgFgCQgFgDgCgGIAAAegAgHgYQgEACgCAEQgBAEAAAFIAAABQAAAIADAFQAFAEAGAAQAHAAAEgEQAEgFAAgIQAAgJgEgEQgEgFgHAAQgEAAgDACg");
	this.shape_493.setTransform(226.45,273.65);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgDQgCgCgGAAIgKABIgIAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGgBQgHABgFgEgAgJAFQgDACABAEQgBADADADQADACAEAAQADAAAEgBQADgDABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_494.setTransform(220.3,272.75);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHAAIAIgBIAHgDIAAAJIgHADIgJAAQgMAAgGgGg");
	this.shape_495.setTransform(215.175,272.75);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_496.setTransform(208.85,271.7);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_497.setTransform(204.725,272.75);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgDQAFgEAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_498.setTransform(196.45,272.7);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_499.setTransform(190.475,272.75);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#000000").s().p("AgSAUQgIgHABgNQgBgMAIgHQAGgGAMgBQAMABAIAGQAHAHAAAMQAAANgHAHQgIAGgMAAQgMAAgGgGgAgLgMQgEAEAAAIQAAAJAEAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_500.setTransform(182.1,272.75);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgCAEQgCAEAAAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgDQAFgEAGAAQAFAAAEACQAFACACAFQACAEAAAGIAAAgg");
	this.shape_501.setTransform(176.15,272.7);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#000000").s().p("AgZAjIAAgJIADAAIAEAAIAFAAQADgBACgCIAEgHIgWgzIAMAAIAPAqIAQgqIAKAAIgVAzQgDAHgDAEQgDAFgDACQgFABgGAAIgIAAg");
	this.shape_502.setTransform(167.6,273.75);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#000000").s().p("AgNAiQgFgDgDgFQgDgHAAgJQAAgJADgFQADgFAFgEQAEgDAHAAQAGABAEACQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgEAEQgFADgGgBQgHAAgEgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_503.setTransform(158.85,271.75);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgDQgEgCgFAAIgKABIgHAEIAAgJIAJgEIAJgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGgBQgIABgEgEgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAADgBQAEgDACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_504.setTransform(153.1,272.75);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#000000").s().p("AgNAiQgFgDgEgFQgCgHAAgJQAAgJACgFQAEgFAFgEQAEgDAHAAQAGABAEACQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgEAEQgFADgGgBQgHAAgEgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAEAAAEgCQADgCACgEQACgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_505.setTransform(147.25,271.75);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_506.setTransform(142.975,271.6);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_507.setTransform(140.4,271.7);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGgBQgHABgFgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAADgBQAEgDABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_508.setTransform(136.3,272.75);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQABgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgBAGgGAEQgFADgFAAQgFAAgFgCg");
	this.shape_509.setTransform(130.6,272.8);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJgBQgFABgDABQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKgBQgGAAgFgBg");
	this.shape_510.setTransform(125.125,272.75);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgDQAEgEAGAAQAGAAADACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_511.setTransform(119.7,272.7);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_512.setTransform(113.725,272.75);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_513.setTransform(106.425,272.7);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgDQgEgCgFAAIgKABIgHAEIAAgJIAJgEIAJgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGgBQgIABgEgEgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAADgBQAEgDACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_514.setTransform(96.4,272.75);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_515.setTransform(92.6,271.7);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgDQAFgEAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_516.setTransform(85.85,272.7);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_517.setTransform(79.875,272.75);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAHgGALgBQANABAGAGQAIAHAAAMQAAANgIAHQgGAGgNAAQgLAAgHgGgAgLgMQgEAEAAAIQAAAJAEAFQAEAEAHAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_518.setTransform(71.5,272.75);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#000000").s().p("AgNAiQgGgDgCgFQgDgHAAgJQAAgJADgFQACgFAGgEQAEgDAHAAQAFABAFACQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgEAEQgFADgGgBQgHAAgEgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQAEgCACgEQABgEAAgEIAAgCQAAgJgDgDQgFgFgHAAQgGAAgEAFg");
	this.shape_519.setTransform(65.15,271.75);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_520.setTransform(60.875,271.6);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQADgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgCAGgFAEQgFADgGAAQgFAAgFgCg");
	this.shape_521.setTransform(56.4,272.8);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_522.setTransform(52.2,271.7);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHAAIAIgBIAHgDIAAAJIgHADIgJAAQgMAAgGgGg");
	this.shape_523.setTransform(48.325,272.75);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAFgDQAGgEAFAAQAFAAAFACQAEACACAFQACAEABAGIAAAgg");
	this.shape_524.setTransform(42.9,272.7);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_525.setTransform(38.425,271.6);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#000000").s().p("AgNAnQAJgHAEgKQAEgKAAgMQAAgLgEgKQgEgKgJgHIAFgGQAKAIAGALQAGAMAAANQAAAOgGAMQgGALgKAIg");
	this.shape_526.setTransform(32.375,272.375);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJgBQgFABgDABQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKgBQgGAAgFgBg");
	this.shape_527.setTransform(28.325,272.75);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMAAQgLAAgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_528.setTransform(22.975,272.75);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_529.setTransform(15.675,272.7);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_530.setTransform(265.4,258.8);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIAAgBIAAgCQAAgFgCgCQgDgCgGAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHAAgFgFgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQABgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_531.setTransform(261.3,259.85);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#000000").s().p("AgKAcQgHgGgCgMIgIAAIABgGIAGAAIAAgEIAAgDIgHAAIABgGIAHAAQACgMAIgGQAHgGALAAQAGAAAEABQAFABAEADIAAAKIgJgEQgEgCgFAAQgPAAgDAPIAWAAIAAAGIgXAAIgBADIABAEIAXAAIAAAGIgXAAQACAIAFAEQAEADAIAAQAGAAAEgBIAIgFIAAAKQgEADgEABQgFABgGAAQgLAAgIgGg");
	this.shape_532.setTransform(252.875,259.075);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#000000").s().p("AgOAgQgGgCgDgFQgEgFAAgFQAAgEACgDQACgDAEgCQADgDAFAAQgGgCgEgEQgEgEAAgFQABgGADgEQACgEAHgCQAFgCAHAAQAIAAAGACQAGACADAEQADAEAAAGQAAAFgDAFQgEADgGACIAIACQADADACADQACADAAAEQAAAGgDAEQgEAFgGACQgGACgJAAQgHAAgHgCgAgLAGQgEADgBAGQABAEAEAEQADACAIAAQAIAAAFgCQAEgEAAgEQAAgMgRABQgIAAgDACgAgKgWQgEADAAAFQAAAFAEACQAEACAGABQAHgBAFgCQADgDAAgEQAAgFgDgDQgFgDgHAAQgGAAgEADg");
	this.shape_533.setTransform(246.4,259.1);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#000000").s().p("AgXAiIAAgJIAVgSIAHgHIAFgHQABgDAAgDQAAgFgDgDQgDgCgGAAQgFAAgGACQgGACgFADIAAgKQAKgHANAAQAHAAAFADQAFACADAEQACAEAAAFQAAAFgCAFQgCAFgEADIgKAKIgMALIAgAAIAAAKg");
	this.shape_534.setTransform(240.425,259.025);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_535.setTransform(236.2,262.65);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#000000").s().p("AAGAhIAAgNIgjAAIAAgIIAggsIAOAAIAAArIANAAIAAAJIgNAAIAAANgAgSALIAYAAIAAghg");
	this.shape_536.setTransform(231.725,259.1);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#000000").s().p("AAFAhIAAg1IgTAEIAAgKIAdgGIAABBg");
	this.shape_537.setTransform(225.95,259.1);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#000000").s().p("AgHAaQgGgMAAgOQAAgNAGgMQAFgLAMgIIAEAGQgJAHgEAKQgEAKAAALQAAAMAEAKQAEAKAJAHIgEAGQgMgIgFgLg");
	this.shape_538.setTransform(222.5,259.475);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_539.setTransform(216.5,258.8);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAJAAIAMAAIACgBIABgBIAAgCQAAgFgEgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHAAgFgFgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAAEgBQADgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_540.setTransform(212.4,259.85);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAEgCQAGgEAFAAQAFAAAFACQAEACACAEQADAFAAAGIAAAgg");
	this.shape_541.setTransform(206.95,259.8);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgGALAAQAMAAAIAGQAGAHABAMQgBANgGAHQgIAHgMAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_542.setTransform(200.8,259.85);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_543.setTransform(196.425,258.7);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_544.setTransform(192.525,259.85);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#000000").s().p("AgYAkIAAhFIAJAAIAAALQADgGAEgEQAFgCAGAAQAHgBAFADQAEADAEAGQACAFAAAKQAAAIgCAFQgEAHgEACQgFAEgHAAQgFAAgGgDQgEgDgCgGIAAAegAgHgXQgDABgCAEQgCADAAAGIAAACQAAAHADAEQAEAFAHAAQAGAAAFgFQAEgEAAgIQAAgJgEgFQgEgDgHAAQgDAAgEACg");
	this.shape_545.setTransform(187.1,260.75);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAHAGQAIAHAAAMQAAANgIAHQgHAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_546.setTransform(180.75,259.85);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_547.setTransform(172.15,259.85);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_548.setTransform(166.575,259.15);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_549.setTransform(162.875,258.7);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgDgGAAgIQAAgJADgGQAEgFAEgEQAGgCAGAAQAFgBAFADQAFADADAGIAAgfIAKAAIAABHIgKAAIAAgNQgDAHgEADQgFAEgGAAQgGAAgGgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQADgCACgEQACgDABgFIAAgCQgBgJgEgEQgEgDgHAAQgGAAgEADg");
	this.shape_550.setTransform(158.25,258.85);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#000000").s().p("AgQAeQgHgGAAgOQAAgJADgFQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAAKIAAAGIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPAFQAAgNgOAAQgFAAgEAEQgEADgBAGIAcAAIAAAAgAgEgXIAIgMIAMAAIgLAMg");
	this.shape_551.setTransform(152.475,258.85);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_552.setTransform(147.975,259.8);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#000000").s().p("AgKAfQgGgEgEgIQgEgIAAgLQAAgKAEgIQAEgHAGgEQAIgEAIAAQAGAAAEABQAEABAEADIAAAKIgIgEQgEgCgFAAQgHAAgDADQgEADgEAFQgCAGAAAHQAAANAGAGQAFAGAJAAIAHgBIAGgCIAFgDIAAAKQgEADgFABQgEABgGAAQgIAAgIgDg");
	this.shape_553.setTransform(142.75,259.075);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_554.setTransform(134.375,259.85);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#000000").s().p("AgNAiQgFgDgEgGQgCgGAAgIQAAgJACgGQAEgFAFgEQAEgCAHAAQAGgBAEADQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgEADQgFAEgGAAQgHAAgEgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAEAAAEgCQADgCADgEQABgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_555.setTransform(128.25,258.85);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#000000").s().p("AgSAUQgIgGAAgOQAAgMAIgHQAGgGAMAAQAMAAAHAGQAIAHAAAMQAAANgIAHQgHAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_556.setTransform(119.75,259.85);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_557.setTransform(115.025,259.8);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgCgEgBgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgCAGgEAEQgGADgFAAQgGAAgEgCg");
	this.shape_558.setTransform(109.65,259.9);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#000000").s().p("AgLAjQgFgBgEgCIAAgJQAJAFAKAAQAHAAAEgEQAFgEAAgIIAAgIQgDAGgEADQgEADgGAAQgGAAgGgDQgEgDgDgFQgDgFAAgIQAAgJADgHQADgGAEgCQAGgDAGAAQAGAAAEADQAFADACAGIAAgLIAKAAIAAAuQAAAJgEAFQgDAFgGADQgGACgHAAIgKgBgAgJgWQgFAEAAAJQAAAJAFADQADAEAGAAQAEAAAEgCQADgBACgEQACgCAAgFIAAgCQAAgJgEgEQgEgEgHAAQgFAAgEAEg");
	this.shape_559.setTransform(103.45,260.825);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_560.setTransform(97.725,259.85);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAgBIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_561.setTransform(91.925,259.075);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#000000").s().p("AgEAFQgDgCAAgDQAAgCADgCQABgCADAAQAEAAACACQACACAAACQAAADgCACQgCACgEAAQgDAAgBgCg");
	this.shape_562.setTransform(85.2,261.8);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAHgGALAAQANAAAGAGQAIAHAAAMQAAANgIAHQgGAHgNAAQgLAAgHgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_563.setTransform(80.95,259.85);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgGAAgIQAAgJADgGQACgFAGgEQAEgCAHAAQAFgBAFADQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgEADQgFAEgGAAQgHAAgEgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQAEgCACgEQABgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_564.setTransform(74.6,258.85);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAJAAIAMAAIACgBIABgBIAAgCQAAgFgEgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgIAAgEgFgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAAEgBQADgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_565.setTransform(68.85,259.85);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_566.setTransform(63.775,259.15);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_567.setTransform(59.725,259.8);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_568.setTransform(54.675,259.85);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIACgBIAAgBIAAgCQAAgGACgEQACgFAFgCQADgCAHAAQAHAAAGACIAAAJIgGgBIgGgBQgFAAgDACQgCADAAAGIAAADIATAAIAAAIIgTAAIAAAqg");
	this.shape_569.setTransform(49.85,258.7);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgGALAAQAMAAAIAGQAGAHAAAMQAAANgGAHQgIAHgMAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_570.setTransform(44.55,259.85);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_571.setTransform(37.7,258.8);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACADQACAEAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_572.setTransform(33.575,259.85);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAANQADgIAFgCQAEgEAGAAQAFAAAEACQAFACACAEQADAFgBAGIAAAgg");
	this.shape_573.setTransform(25.3,259.8);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_574.setTransform(19.15,259.85);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_575.setTransform(13.525,259.85);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_576.setTransform(270.825,246.9);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_577.setTransform(267.275,245.8);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgCgFAAgKQAAgIACgFQAEgHAEgCQAGgDAGgBQAFAAAFADQAFADADAGIAAggIAKAAIAABHIgKAAIAAgLQgDAGgEAEQgFACgGAAQgGAAgGgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEABgEIAAgDQgBgIgEgDQgEgEgHgBQgGABgEAEg");
	this.shape_578.setTransform(262.65,245.95);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_579.setTransform(258.375,245.8);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_580.setTransform(254.475,246.95);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQACAEAAAGIAAAgg");
	this.shape_581.setTransform(249.05,246.9);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_582.setTransform(244.575,245.8);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAHgHALAAQANAAAGAHQAIAHAAAMQAAANgIAHQgGAHgNgBQgLABgHgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_583.setTransform(240.25,246.95);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_584.setTransform(234.625,246.95);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgHAMAAQAMAAAIAHQAGAHABAMQgBANgGAHQgIAHgMgBQgMABgGgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_585.setTransform(226.55,246.95);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_586.setTransform(220.6,246.9);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_587.setTransform(212.075,246.95);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgCgFAAgKQAAgIACgFQAEgHAEgCQAGgDAGgBQAFAAAFADQAFADADAGIAAggIAKAAIAABHIgKAAIAAgLQgDAGgEAEQgFACgGAAQgGAAgGgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEABgEIAAgDQgBgIgEgDQgEgEgHgBQgGABgEAEg");
	this.shape_588.setTransform(205.95,245.95);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_589.setTransform(200.175,246.95);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgNQgDAIgEADQgFADgGAAQgGAAgEgCg");
	this.shape_590.setTransform(194.2,247);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#000000").s().p("AgZAjIAAhEIAKAAIAAAMQACgHAFgDQAFgDAGgBQAHAAAFADQAFADADAGQACAGAAAIQAAAJgCAGQgDAFgFAEQgFACgHAAQgFAAgGgCQgEgDgCgGIAAAdgAgHgXQgDABgCAEQgCAEAAAEIAAACQAAAIADAFQAEADAHAAQAHAAAEgDQAEgFAAgIQAAgKgEgDQgEgEgHgBQgEABgDACg");
	this.shape_591.setTransform(188.35,247.85);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQAMAAAIAHQAGAHAAAMQAAANgGAHQgIAHgMgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_592.setTransform(179.45,246.95);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgCgFAAgKQAAgIACgFQAEgHAEgCQAGgDAGgBQAFAAAFADQAFADADAGIAAggIAKAAIAABHIgKAAIAAgLQgDAGgEAEQgFACgGAAQgGAAgGgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEABgEIAAgDQgBgIgEgDQgEgEgHgBQgGABgEAEg");
	this.shape_593.setTransform(173.1,245.95);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_594.setTransform(167.35,246.95);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#000000").s().p("AgVAZIAAgIIAegiIgeAAIAAgHIAqAAIAAAHIgeAiIAfAAIAAAIg");
	this.shape_595.setTransform(162.225,246.95);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_596.setTransform(158.275,245.8);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_597.setTransform(155.7,245.9);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_598.setTransform(151.6,246.95);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQABgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgNQgBAIgGADQgFADgFAAQgFAAgFgCg");
	this.shape_599.setTransform(145.9,247);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_600.setTransform(140.425,246.95);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_601.setTransform(136.575,245.8);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#000000").s().p("AgFAZIgVgxIAMAAIAOApIAQgpIALAAIgWAxg");
	this.shape_602.setTransform(132.4,246.95);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_603.setTransform(124,246.95);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_604.setTransform(119.7,245.9);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_605.setTransform(115.575,246.95);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgCgFAAgKQAAgIACgFQAEgHAEgCQAFgDAHgBQAGAAAEADQAFADACAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgEAEQgFACgGAAQgHAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAEAAAEgCQADgCACgEQACgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_606.setTransform(109.45,245.95);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgHALAAQAMAAAIAHQAGAHAAAMQAAANgGAHQgIAHgMgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_607.setTransform(103.5,246.95);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADADABAHQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_608.setTransform(95.975,246.9);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_609.setTransform(87.5,245.9);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIggAAIAAASIAcAAIAAAIIgcAAIAAAVIAgAAIAAAJg");
	this.shape_610.setTransform(83.3,246.2);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#000000").s().p("AgEAFQgCgCAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_611.setTransform(76.5,248.9);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#000000").s().p("AAGAhIAAgOIgjAAIAAgIIAggrIAOAAIAAAqIANAAIAAAJIgNAAIAAAOgAgSAKIAYAAIAAghg");
	this.shape_612.setTransform(71.875,246.2);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#000000").s().p("AgXAiIAAgJIAVgSIAHgHIAFgHQABgDAAgDQAAgFgDgDQgDgCgGAAQgFAAgGACQgGACgFADIAAgKQAKgHANAAQAHAAAFADQAFACADAEQACAEAAAFQAAAFgCAFQgCAFgEADIgKAKIgMALIAgAAIAAAKg");
	this.shape_613.setTransform(65.675,246.125);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#000000").s().p("AgOAeQgGgEgDgHQgEgIAAgLQAAgKAEgHQADgIAGgEQAGgEAIAAQAJAAAGAEQAGAEAEAHQADAIAAAKQAAALgDAIQgEAHgGAEQgGAEgJAAQgIAAgGgEgAgLgRQgFAGAAALQAAANAFAGQAEAGAHAAQAIAAAFgGQAEgGAAgNQAAgLgEgHQgFgGgIAAQgHAAgEAHg");
	this.shape_614.setTransform(59.475,246.175);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#000000").s().p("AgXAiIAAgJIAVgSIAHgHIAFgHQABgDAAgDQAAgFgDgDQgDgCgGAAQgFAAgGACQgGACgFADIAAgKQAKgHANAAQAHAAAFADQAFACADAEQACAEAAAFQAAAFgCAFQgCAFgEADIgKAKIgMALIAgAAIAAAKg");
	this.shape_615.setTransform(53.425,246.125);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#000000").s().p("AgPApIAWhRIAJAAIgWBRg");
	this.shape_616.setTransform(48.875,246.325);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#000000").s().p("AgNAhQgGgBgEgDIAAgKIALAEIALACQAEAAADgCQADgBACgCQACgDAAgDQAAgEgDgDQgEgDgHAAIgKAAIAAgIIAKAAQAFAAAEgCQADgDAAgFQAAgEgDgDQgFgDgGAAQgFAAgFACQgGABgEACIAAgKQAJgEAMAAQAHAAAFACQAHACACAEQADAEAAAGQAAAFgDAEQgEAEgGACQAIABADAEQAEAEAAAGQAAAGgDAEQgDAEgGADQgGACgHAAQgGAAgGgBg");
	this.shape_617.setTransform(44.5,246.175);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#000000").s().p("AgOAeQgGgEgDgHQgEgIAAgLQAAgKAEgHQADgIAGgEQAGgEAIAAQAJAAAGAEQAGAEAEAHQADAIAAAKQAAALgDAIQgEAHgGAEQgGAEgJAAQgIAAgGgEgAgLgRQgFAGAAALQAAANAFAGQAEAGAHAAQAIAAAFgGQAEgGAAgNQAAgLgEgHQgFgGgIAAQgHAAgEAHg");
	this.shape_618.setTransform(38.275,246.175);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#000000").s().p("AgPApIAWhRIAJAAIgWBRg");
	this.shape_619.setTransform(33.375,246.325);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#000000").s().p("AAEAhIAAg1IgSAEIAAgKIAdgGIAABBg");
	this.shape_620.setTransform(29.45,246.2);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#000000").s().p("AgNAhQgGgBgEgDIAAgKIALAEIALACQAEAAADgCQADgBACgCQACgDAAgDQAAgEgDgDQgEgDgHAAIgKAAIAAgIIAKAAQAFAAAEgCQADgDAAgFQAAgEgDgDQgFgDgGAAQgFAAgFACQgGABgEACIAAgKQAJgEAMAAQAHAAAFACQAHACACAEQADAEAAAGQAAAFgDAEQgEAEgGACQAIABADAEQAEAEAAAGQAAAGgDAEQgDAEgGADQgGACgHAAQgGAAgGgBg");
	this.shape_621.setTransform(24.7,246.175);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_622.setTransform(17.95,245.9);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_623.setTransform(13.825,246.95);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAADgBQAEgDACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_624.setTransform(229,234.05);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_625.setTransform(223.925,233.35);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFAAgDABQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKAAQgGgBgFgBg");
	this.shape_626.setTransform(219.025,234.05);

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAADgBQAEgDACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_627.setTransform(213.7,234.05);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#000000").s().p("AANAkIAAgeQAAgMgMAAQgDAAgDACQgEACgCADQgBAEAAAGIAAAZIgKAAIAAhHIAKAAIAAAhQACgHAFgDQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAFIAAAhg");
	this.shape_628.setTransform(208.25,233);

	this.shape_629 = new cjs.Shape();
	this.shape_629.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAADgBQAEgDACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_629.setTransform(199.75,234.05);

	this.shape_630 = new cjs.Shape();
	this.shape_630.graphics.f("#000000").s().p("AgOAiQgEgDgEgFQgDgHAAgJQAAgJADgFQAEgFAEgEQAGgDAGAAQAGABAEACQAFADADAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgFAEQgFADgGAAQgGgBgGgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAFAAADgCQAEgCABgEQADgEAAgEIAAgDQAAgIgFgDQgEgFgHAAQgGAAgEAFg");
	this.shape_630.setTransform(193.9,233.05);

	this.shape_631 = new cjs.Shape();
	this.shape_631.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_631.setTransform(189.625,232.9);

	this.shape_632 = new cjs.Shape();
	this.shape_632.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_632.setTransform(187.05,233);

	this.shape_633 = new cjs.Shape();
	this.shape_633.graphics.f("#000000").s().p("AgRAhQgEgFAAgHQAAgIAFgDQAEgEAKAAIALAAIACAAIABgCIAAgDQgBgDgDgDQgCgCgGAAIgKABIgIAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAIIAAAjIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAPQgDACABAEQgBADADADQADACAEAAQADAAAEgBQADgDABgDQACgDABgEIAAgCIgNAAQgFAAgDACgAgEgXIAHgMIANAAIgMAMg");
	this.shape_633.setTransform(182.95,233.05);

	this.shape_634 = new cjs.Shape();
	this.shape_634.graphics.f("#000000").s().p("AgFAaIgVgzIAMAAIAOArIAQgrIALAAIgVAzg");
	this.shape_634.setTransform(177.55,234.05);

	this.shape_635 = new cjs.Shape();
	this.shape_635.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgDQgCgCgGAAIgJABIgJAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgIAAgEgEgAgJAFQgDACABAEQgBADADADQADACAEAAQADAAAEgBQADgDABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_635.setTransform(169.35,234.05);

	this.shape_636 = new cjs.Shape();
	this.shape_636.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_636.setTransform(164.275,233.35);

	this.shape_637 = new cjs.Shape();
	this.shape_637.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_637.setTransform(160.225,234);

	this.shape_638 = new cjs.Shape();
	this.shape_638.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_638.setTransform(155.175,234.05);

	this.shape_639 = new cjs.Shape();
	this.shape_639.graphics.f("#000000").s().p("AgLAlIAAgqIgIAAIAAgIIAFAAIADAAIAAgCIAAgCQAAgGACgEQADgEAEgDQAEgCAGAAQAIAAAEACIAAAJIgFgCIgGAAQgFAAgDACQgCADAAAGIAAADIATAAIAAAIIgTAAIAAAqg");
	this.shape_639.setTransform(150.35,232.9);

	this.shape_640 = new cjs.Shape();
	this.shape_640.graphics.f("#000000").s().p("AgXAaQgIgJAAgRQAAgQAIgIQAJgJAOAAQAQAAAIAJQAIAIAAAQQAAARgIAJQgIAIgQAAQgOAAgJgIgAgPgSQgFAHAAALQAAANAFAGQAGAGAJAAQALAAAFgGQAFgGAAgNQAAgMgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_640.setTransform(144.4,233.275);

	this.shape_641 = new cjs.Shape();
	this.shape_641.graphics.f("#000000").s().p("AgEAFQgDgCAAgDQAAgCADgCQABgCADAAQAEAAACACQACACgBACQABADgCACQgCACgEAAQgDAAgBgCg");
	this.shape_641.setTransform(136.95,236);

	this.shape_642 = new cjs.Shape();
	this.shape_642.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgDQgCgCgGAAIgJABIgJAEIAAgJIAJgEIAKgBQALABAFAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgIAAgEgEgAgJAFQgDACABAEQgBADADADQADACAEAAQADAAAEgBQADgDABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_642.setTransform(132.9,234.05);

	this.shape_643 = new cjs.Shape();
	this.shape_643.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_643.setTransform(127.825,233.35);

	this.shape_644 = new cjs.Shape();
	this.shape_644.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAGgGAMgBQAMABAHAGQAIAHAAAMQAAANgIAHQgHAGgMABQgMgBgGgGgAgLgMQgEAEAAAIQAAAJAEAFQADAEAIAAQAIAAAEgEQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_644.setTransform(122.45,234.05);

	this.shape_645 = new cjs.Shape();
	this.shape_645.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQADgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgCAGgFAEQgFADgGAAQgFAAgFgCg");
	this.shape_645.setTransform(116.25,234.1);

	this.shape_646 = new cjs.Shape();
	this.shape_646.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHAAIAIgBIAHgDIAAAJIgHADIgJABQgMgBgGgGg");
	this.shape_646.setTransform(110.725,234.05);

	this.shape_647 = new cjs.Shape();
	this.shape_647.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgDQgCgCgGAAIgKABIgIAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgDACABAEQgBADADADQADACAEAAQADAAAEgBQADgDABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_647.setTransform(102.85,234.05);

	this.shape_648 = new cjs.Shape();
	this.shape_648.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_648.setTransform(95.825,234);

	this.shape_649 = new cjs.Shape();
	this.shape_649.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_649.setTransform(89.825,232.9);

	this.shape_650 = new cjs.Shape();
	this.shape_650.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_650.setTransform(85.975,233.35);

	this.shape_651 = new cjs.Shape();
	this.shape_651.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_651.setTransform(82.35,233);

	this.shape_652 = new cjs.Shape();
	this.shape_652.graphics.f("#000000").s().p("AgOAjQgEgCgCgFQgDgFAAgFIAAghIALAAIAAAeQAAAGADAEQADADAGAAQADgBAEgBQADgDABgEQACgEABgGIAAgYIAKAAIAAAzIgKAAIAAgNQgDAHgEAEQgGADgFAAQgFAAgFgCgAgFgXIAIgMIANAAIgLAMg");
	this.shape_652.setTransform(77.9,233.05);

	this.shape_653 = new cjs.Shape();
	this.shape_653.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIAAgCIAAgDQAAgEgCgDQgDgCgGAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGAAQgHAAgFgEgAgJAFQgDACAAAEQAAADADADQADACAEAAQADAAADgBQAEgDACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_653.setTransform(69.6,234.05);

	this.shape_654 = new cjs.Shape();
	this.shape_654.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_654.setTransform(65.8,233);

	this.shape_655 = new cjs.Shape();
	this.shape_655.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_655.setTransform(60.275,234);

	this.shape_656 = new cjs.Shape();
	this.shape_656.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIABgCIAAgDQAAgEgEgDQgCgCgGAAIgKABIgIAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgHAAgFgEgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAAEgBQADgDABgDQADgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_656.setTransform(55.25,234.05);

	this.shape_657 = new cjs.Shape();
	this.shape_657.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_657.setTransform(51.375,232.9);

	this.shape_658 = new cjs.Shape();
	this.shape_658.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMgBIAIABQAEABAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEAEAAAIQAAAJAEAFQAFAEAHAAIAIgBIAHgDIAAAJIgHADIgJABQgMgBgGgGg");
	this.shape_658.setTransform(47.475,234.05);

	this.shape_659 = new cjs.Shape();
	this.shape_659.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQACAEAAAGIAAAgg");
	this.shape_659.setTransform(42.05,234);

	this.shape_660 = new cjs.Shape();
	this.shape_660.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgDQgEgCgFAAIgKABIgHAEIAAgJIAJgEIAJgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGAAQgIAAgEgEgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAADgBQAEgDACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_660.setTransform(36.1,234.05);

	this.shape_661 = new cjs.Shape();
	this.shape_661.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgLAAIAAgyIAKAAIAAAMQACgGAFgEQAGgDAFAAQAGAAAEACQAEACACAFQADAEAAAGIAAAgg");
	this.shape_661.setTransform(30.65,234);

	this.shape_662 = new cjs.Shape();
	this.shape_662.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_662.setTransform(26.175,232.9);

	this.shape_663 = new cjs.Shape();
	this.shape_663.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIACAAIAAgCIAAgCQAAgGACgEQACgEAFgDQADgCAHAAQAHAAAGACIAAAJIgGgCIgGAAQgFAAgDACQgCADAAAGIAAADIATAAIAAAIIgTAAIAAAqg");
	this.shape_663.setTransform(22.85,232.9);

	this.shape_664 = new cjs.Shape();
	this.shape_664.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_664.setTransform(17.725,234.05);

	this.shape_665 = new cjs.Shape();
	this.shape_665.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_665.setTransform(13.225,234);

	this.shape_666 = new cjs.Shape();
	this.shape_666.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAHAGQAIAHAAAMQAAANgIAHQgHAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_666.setTransform(218.55,221.15);

	this.shape_667 = new cjs.Shape();
	this.shape_667.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_667.setTransform(211.275,221.1);

	this.shape_668 = new cjs.Shape();
	this.shape_668.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgDgCQgCgCgGAAIgJABIgJADIAAgKIAJgCIAKgBQALgBAFAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIAAgEgFgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_668.setTransform(206.25,221.15);

	this.shape_669 = new cjs.Shape();
	this.shape_669.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAANQADgIAFgCQAEgEAGAAQAFAAAEACQAFACACAEQADAFgBAGIAAAgg");
	this.shape_669.setTransform(200.8,221.1);

	this.shape_670 = new cjs.Shape();
	this.shape_670.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgGALAAQANAAAGAGQAIAHgBAMQABANgIAHQgGAHgNAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_670.setTransform(194.65,221.15);

	this.shape_671 = new cjs.Shape();
	this.shape_671.graphics.f("#000000").s().p("AgIAhQgEgDgDgGIAAAMIgKAAIAAhHIAKAAIAAAfQADgFAEgEQAFgCAFAAQAHgBAGADQAEADAEAGQADAEAAAKQAAAIgDAGQgEAHgEACQgGAEgGAAQgGAAgFgEgAgHgEQgDABgCADQgCADgBAGIAAACQABAIAEAEQADAFAHAAQAHAAAEgFQAEgEAAgJQAAgJgEgEQgEgDgHAAQgEAAgDACg");
	this.shape_671.setTransform(188.7,220.15);

	this.shape_672 = new cjs.Shape();
	this.shape_672.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIAAgBIAAgCQAAgFgCgCQgDgCgGAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHAAgFgFgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQABgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_672.setTransform(182.55,221.15);

	this.shape_673 = new cjs.Shape();
	this.shape_673.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAIAGQAHAHAAAMQAAANgHAHQgIAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_673.setTransform(174.45,221.15);

	this.shape_674 = new cjs.Shape();
	this.shape_674.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_674.setTransform(167.55,223.95);

	this.shape_675 = new cjs.Shape();
	this.shape_675.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgGALAAQAMAAAIAGQAGAHABAMQgBANgGAHQgIAHgMAAQgLAAgIgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_675.setTransform(163.45,221.15);

	this.shape_676 = new cjs.Shape();
	this.shape_676.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_676.setTransform(159.15,220.1);

	this.shape_677 = new cjs.Shape();
	this.shape_677.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgDgEABgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgDAGgFAEQgEADgGAAQgFAAgFgCg");
	this.shape_677.setTransform(154.7,221.2);

	this.shape_678 = new cjs.Shape();
	this.shape_678.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_678.setTransform(149.175,221.15);

	this.shape_679 = new cjs.Shape();
	this.shape_679.graphics.f("#000000").s().p("AgIAkIAAgyIAJAAIAAAygAgKgWIAJgNIAMAAIgLANg");
	this.shape_679.setTransform(145.725,220.1);

	this.shape_680 = new cjs.Shape();
	this.shape_680.graphics.f("#000000").s().p("AANAkIAAgeQAAgMgMAAQgDAAgDACQgEACgCADQgBAEAAAGIAAAZIgKAAIAAhHIAKAAIAAAhQACgHAFgDQAEgDAGAAQAGAAAEACQAEACACAEQACAFABAFIAAAhg");
	this.shape_680.setTransform(141.1,220.1);

	this.shape_681 = new cjs.Shape();
	this.shape_681.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_681.setTransform(135.125,221.15);

	this.shape_682 = new cjs.Shape();
	this.shape_682.graphics.f("#000000").s().p("AgGAaIgUgyIALAAIAPAqIARgqIAKAAIgWAyg");
	this.shape_682.setTransform(129.45,221.15);

	this.shape_683 = new cjs.Shape();
	this.shape_683.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgCgEgBgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgCAGgEAEQgGADgFAAQgGAAgEgCg");
	this.shape_683.setTransform(120.9,221.2);

	this.shape_684 = new cjs.Shape();
	this.shape_684.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_684.setTransform(115.425,221.15);

	this.shape_685 = new cjs.Shape();
	this.shape_685.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_685.setTransform(108.675,221.1);

	this.shape_686 = new cjs.Shape();
	this.shape_686.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgDgCQgCgCgGAAIgJABIgJADIAAgKIAJgCIAKgBQALgBAFAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIAAgEgFgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_686.setTransform(103.65,221.15);

	this.shape_687 = new cjs.Shape();
	this.shape_687.graphics.f("#000000").s().p("AgLAjQgGgBgDgCIAAgJQAJAFAJAAQAIAAAEgEQAFgEgBgIIAAgIQgCAGgEADQgFADgFAAQgHAAgFgDQgEgDgDgFQgDgFAAgIQAAgJADgHQADgGAEgCQAFgDAHAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgEAFQgDAFgGADQgGACgHAAIgKgBgAgJgWQgFAEAAAJQAAAJAFADQADAEAGAAQAEAAAEgCQADgBACgEQABgCAAgFIAAgCQABgJgEgEQgEgEgHAAQgFAAgEAEg");
	this.shape_687.setTransform(97.85,222.125);

	this.shape_688 = new cjs.Shape();
	this.shape_688.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_688.setTransform(92.125,221.15);

	this.shape_689 = new cjs.Shape();
	this.shape_689.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_689.setTransform(87.625,221.1);

	this.shape_690 = new cjs.Shape();
	this.shape_690.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_690.setTransform(82.875,220.45);

	this.shape_691 = new cjs.Shape();
	this.shape_691.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAFgCQAEgEAGAAQAFAAAEACQAFACACAEQACAFAAAGIAAAgg");
	this.shape_691.setTransform(77.6,221.1);

	this.shape_692 = new cjs.Shape();
	this.shape_692.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_692.setTransform(71.625,221.15);

	this.shape_693 = new cjs.Shape();
	this.shape_693.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_693.setTransform(63.425,221.15);

	this.shape_694 = new cjs.Shape();
	this.shape_694.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_694.setTransform(58.925,221.1);

	this.shape_695 = new cjs.Shape();
	this.shape_695.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_695.setTransform(54.175,220.45);

	this.shape_696 = new cjs.Shape();
	this.shape_696.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgDAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAEgCQAFgEAGAAQAFAAAEACQAFACACAEQACAFAAAGIAAAgg");
	this.shape_696.setTransform(48.9,221.1);

	this.shape_697 = new cjs.Shape();
	this.shape_697.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_697.setTransform(42.925,221.15);

	this.shape_698 = new cjs.Shape();
	this.shape_698.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_698.setTransform(35.875,221.1);

	this.shape_699 = new cjs.Shape();
	this.shape_699.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_699.setTransform(32.325,220);

	this.shape_700 = new cjs.Shape();
	this.shape_700.graphics.f("#000000").s().p("AgLAjQgFgBgEgCIAAgJQAJAFAKAAQAHAAAEgEQAFgEgBgIIAAgIQgBAGgFADQgFADgFAAQgGAAgGgDQgEgDgDgFQgDgFAAgIQAAgJADgHQADgGAEgCQAGgDAGAAQAFAAAFADQAFADACAGIAAgLIAKAAIAAAuQAAAJgEAFQgDAFgGADQgGACgHAAIgKgBgAgJgWQgFAEAAAJQAAAJAFADQADAEAGAAQAEAAAEgCQADgBACgEQABgCAAgFIAAgCQAAgJgDgEQgEgEgHAAQgFAAgEAEg");
	this.shape_700.setTransform(27.75,222.125);

	this.shape_701 = new cjs.Shape();
	this.shape_701.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_701.setTransform(22.025,221.15);

	this.shape_702 = new cjs.Shape();
	this.shape_702.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_702.setTransform(17.95,220.1);

	this.shape_703 = new cjs.Shape();
	this.shape_703.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_703.setTransform(13.825,221.15);

	this.shape_704 = new cjs.Shape();
	this.shape_704.graphics.f("#000000").s().p("AgRAhQgEgEAAgIQAAgHAFgEQAFgEAIAAIAMAAIACAAIABgCIAAgDQAAgDgDgCQgEgCgFgBIgKACIgHADIAAgJIAJgDIAJgCQALAAAEAFQAGAFAAAHIAAAiIgKAAIAAgKQgCAFgFAEQgEACgGAAQgIAAgEgDgAgJAPQgCACgBAEQABAEACACQACACAFAAQADAAADgCQAEgCACgDQACgDAAgEIAAgCIgNAAQgFAAgDACgAgEgWIAHgOIANAAIgMAOg");
	this.shape_704.setTransform(253,207.25);

	this.shape_705 = new cjs.Shape();
	this.shape_705.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_705.setTransform(248.775,208.2);

	this.shape_706 = new cjs.Shape();
	this.shape_706.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgFgBgKQABgIADgFQACgHAGgCQAFgDAGgBQAFAAAFADQAFADADAGIAAggIAJAAIAABHIgJAAIAAgLQgDAGgEAEQgFACgGAAQgGAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAEAAAEgCQAEgCACgEQABgEABgEIAAgDQAAgIgEgDQgFgEgHgBQgGABgEAEg");
	this.shape_706.setTransform(243.25,207.25);

	this.shape_707 = new cjs.Shape();
	this.shape_707.graphics.f("#000000").s().p("AgSAUQgIgGAAgOQAAgMAIgHQAHgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgHgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_707.setTransform(237.3,208.25);

	this.shape_708 = new cjs.Shape();
	this.shape_708.graphics.f("#000000").s().p("AgZAjIAAhEIAKAAIAAAMQACgHAFgDQAFgDAFgBQAHAAAGADQAEADAEAGQADAGAAAIQAAAJgDAGQgEAFgEAEQgGACgGAAQgGAAgFgCQgEgDgDgGIAAAdgAgHgXQgEABgBAEQgDAEAAAEIAAACQAAAIAFAFQADADAHAAQAGAAAFgDQAEgFAAgIQAAgKgEgDQgEgEgHgBQgEABgDACg");
	this.shape_708.setTransform(231.35,209.15);

	this.shape_709 = new cjs.Shape();
	this.shape_709.graphics.f("#000000").s().p("AgSAUQgIgGAAgOQAAgMAIgHQAHgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgHgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_709.setTransform(222.45,208.25);

	this.shape_710 = new cjs.Shape();
	this.shape_710.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_710.setTransform(216.875,207.55);

	this.shape_711 = new cjs.Shape();
	this.shape_711.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgFAEQgEACgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_711.setTransform(211.7,208.25);

	this.shape_712 = new cjs.Shape();
	this.shape_712.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_712.setTransform(207.475,208.2);

	this.shape_713 = new cjs.Shape();
	this.shape_713.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_713.setTransform(202.725,207.55);

	this.shape_714 = new cjs.Shape();
	this.shape_714.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_714.setTransform(197.45,208.2);

	this.shape_715 = new cjs.Shape();
	this.shape_715.graphics.f("#000000").s().p("AgSAUQgIgGAAgOQAAgMAIgHQAGgHAMAAQAMAAAHAHQAIAHAAAMQAAANgIAHQgHAHgMgBQgMABgGgHgAgLgMQgEAFAAAHQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_715.setTransform(191.3,208.25);

	this.shape_716 = new cjs.Shape();
	this.shape_716.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_716.setTransform(185.675,208.25);

	this.shape_717 = new cjs.Shape();
	this.shape_717.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_717.setTransform(179.35,207.2);

	this.shape_718 = new cjs.Shape();
	this.shape_718.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_718.setTransform(175.225,208.25);

	this.shape_719 = new cjs.Shape();
	this.shape_719.graphics.f("#000000").s().p("AgNAiQgGgDgCgGQgDgFAAgKQAAgIADgFQACgHAGgCQAEgDAHgBQAFAAAFADQAFADACAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgEAEQgFACgGAAQgHAAgEgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQAEgCACgEQABgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_719.setTransform(169.1,207.25);

	this.shape_720 = new cjs.Shape();
	this.shape_720.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_720.setTransform(162.35,207.2);

	this.shape_721 = new cjs.Shape();
	this.shape_721.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIAAgCIAAgDQAAgEgCgCQgDgCgGgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgFAEQgEACgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_721.setTransform(158.25,208.25);

	this.shape_722 = new cjs.Shape();
	this.shape_722.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_722.setTransform(152.8,208.2);

	this.shape_723 = new cjs.Shape();
	this.shape_723.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_723.setTransform(148.325,207.1);

	this.shape_724 = new cjs.Shape();
	this.shape_724.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIABAAIABgCIAAgCQAAgGACgEQACgEAFgCQAEgDAGAAQAIAAAFADIAAAIIgGgBIgFgBQgGAAgDADQgCADAAAFIAAADIAUAAIAAAIIgUAAIAAAqg");
	this.shape_724.setTransform(145,207.1);

	this.shape_725 = new cjs.Shape();
	this.shape_725.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_725.setTransform(138.9,207.2);

	this.shape_726 = new cjs.Shape();
	this.shape_726.graphics.f("#000000").s().p("AAVAhIgHgQIgcAAIgHAQIgKAAIAZhBIAOAAIAYBBgAAMAHIgMggIgLAgIAXAAg");
	this.shape_726.setTransform(134.2,207.5);

	this.shape_727 = new cjs.Shape();
	this.shape_727.graphics.f("#000000").s().p("AgEAFQgDgCAAgDQAAgDADgBQABgCADAAQAEAAACACQACABAAADQAAADgCACQgCACgEAAQgDAAgBgCg");
	this.shape_727.setTransform(127.05,210.2);

	this.shape_728 = new cjs.Shape();
	this.shape_728.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_728.setTransform(123.275,208.25);

	this.shape_729 = new cjs.Shape();
	this.shape_729.graphics.f("#000000").s().p("AgQAeQgHgGAAgOQAAgJADgFQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPAFQAAgNgOAAQgFAAgEAEQgEADgBAGIAcAAIAAAAgAgEgWIAIgOIAMAAIgLAOg");
	this.shape_729.setTransform(117.925,207.25);

	this.shape_730 = new cjs.Shape();
	this.shape_730.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_730.setTransform(112.525,208.25);

	this.shape_731 = new cjs.Shape();
	this.shape_731.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAGAAADACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_731.setTransform(107.1,208.2);

	this.shape_732 = new cjs.Shape();
	this.shape_732.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQAAgEgEgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQACACAFAAQADAAAEgCQADgCABgDQADgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_732.setTransform(101.15,208.25);

	this.shape_733 = new cjs.Shape();
	this.shape_733.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_733.setTransform(96.925,208.2);

	this.shape_734 = new cjs.Shape();
	this.shape_734.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIABAAIABgCIAAgCQAAgGACgEQACgEAFgCQADgDAHAAQAHAAAGADIAAAIIgGgBIgFgBQgGAAgDADQgCADAAAFIAAADIAUAAIAAAIIgUAAIAAAqg");
	this.shape_734.setTransform(92.7,207.1);

	this.shape_735 = new cjs.Shape();
	this.shape_735.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_735.setTransform(84.95,208.2);

	this.shape_736 = new cjs.Shape();
	this.shape_736.graphics.f("#000000").s().p("AgSAeQgIgGAAgOQAAgMAIgHQAGgHAMAAQAMAAAHAHQAIAHAAAMQAAANgIAHQgHAHgMgBQgMABgGgHgAgLgCQgEAEAAAIQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgIgEgEQgEgFgIAAQgHAAgEAFgAgGgWIAIgOIANAAIgMAOg");
	this.shape_736.setTransform(78.8,207.25);

	this.shape_737 = new cjs.Shape();
	this.shape_737.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_737.setTransform(74.425,207.1);

	this.shape_738 = new cjs.Shape();
	this.shape_738.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_738.setTransform(70.525,208.25);

	this.shape_739 = new cjs.Shape();
	this.shape_739.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_739.setTransform(65.2,208.25);

	this.shape_740 = new cjs.Shape();
	this.shape_740.graphics.f("#000000").s().p("AgVAZIAAgIIAegiIgeAAIAAgHIAqAAIAAAHIgeAiIAfAAIAAAIg");
	this.shape_740.setTransform(60.075,208.25);

	this.shape_741 = new cjs.Shape();
	this.shape_741.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_741.setTransform(56.125,207.1);

	this.shape_742 = new cjs.Shape();
	this.shape_742.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_742.setTransform(52.275,207.55);

	this.shape_743 = new cjs.Shape();
	this.shape_743.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_743.setTransform(48.225,208.2);

	this.shape_744 = new cjs.Shape();
	this.shape_744.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_744.setTransform(43,208.25);

	this.shape_745 = new cjs.Shape();
	this.shape_745.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADADABAHQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_745.setTransform(35.475,208.2);

	this.shape_746 = new cjs.Shape();
	this.shape_746.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgCQgEgCgFgBIgKACIgHADIAAgJIAJgDIAJgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgFAEQgEACgGAAQgIAAgEgDgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgCQAEgCACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_746.setTransform(28,208.25);

	this.shape_747 = new cjs.Shape();
	this.shape_747.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_747.setTransform(20.075,208.25);

	this.shape_748 = new cjs.Shape();
	this.shape_748.graphics.f("#000000").s().p("AgNAiQgFgDgEgGQgCgFAAgKQAAgIACgFQAEgHAFgCQAEgDAHgBQAGAAAEADQAFADACAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgEAEQgFACgGAAQgHAAgEgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCADgEQABgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_748.setTransform(13.95,207.25);

	this.shape_749 = new cjs.Shape();
	this.shape_749.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAJAAIAMAAIACAAIABgCIAAgDQAAgEgEgDQgCgCgGAAIgKABIgIAEIAAgJIAJgEIAKgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGAAQgIAAgEgEgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAAEgBQADgDACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_749.setTransform(265.5,195.35);

	this.shape_750 = new cjs.Shape();
	this.shape_750.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAAMQACgHAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_750.setTransform(258.475,195.3);

	this.shape_751 = new cjs.Shape();
	this.shape_751.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_751.setTransform(250.975,195.35);

	this.shape_752 = new cjs.Shape();
	this.shape_752.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgBIAAgNIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHAAQgIAAgFgFg");
	this.shape_752.setTransform(245.625,194.65);

	this.shape_753 = new cjs.Shape();
	this.shape_753.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFAAgDABQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFAEgKAAQgGgBgFgBg");
	this.shape_753.setTransform(240.725,195.35);

	this.shape_754 = new cjs.Shape();
	this.shape_754.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_754.setTransform(236.875,194.2);

	this.shape_755 = new cjs.Shape();
	this.shape_755.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_755.setTransform(232.575,194.575);

	this.shape_756 = new cjs.Shape();
	this.shape_756.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDACgFAAQgEAAgCgCg");
	this.shape_756.setTransform(225.525,197.05);

	this.shape_757 = new cjs.Shape();
	this.shape_757.graphics.f("#000000").s().p("AAPAdQgFgFAAgHQAAgIAFgFQAFgEAJAAQAJAAAGAEQAEAFAAAIQAAAHgEAFQgGAFgJAAQgJAAgFgFgAAXARQAAAHAGAAQAGAAAAgHQAAgIgGAAQgGAAAAAIgAgeAhIAZgjIASgeIASAAIgZAjIgSAegAgqgDQgFgEAAgIQAAgIAFgFQAFgFAJAAQAJAAAFAFQAFAFAAAIQAAAIgFAEQgFAFgJAAQgJAAgFgFgAgigPQAAAHAGAAQAGAAAAgHQAAgIgGAAQgGAAAAAIg");
	this.shape_757.setTransform(218.875,194.575);

	this.shape_758 = new cjs.Shape();
	this.shape_758.graphics.f("#000000").s().p("AgSAbQgJgHAAgSQAAgQAIgJQAHgKAQAAQALAAAIADIAAAOQgIgEgJAAQgRAAAAAUQABgEAFgDQAFgCAFAAQALAAAFAFQAHAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgHgHgAgHAEQgDADAAAEQAAAFADADQACADAFAAQAMAAAAgLQAAgKgLAAQgFAAgDADg");
	this.shape_758.setTransform(210.55,194.575);

	this.shape_759 = new cjs.Shape();
	this.shape_759.graphics.f("#000000").s().p("AgQAhIAYgzIggAAIAAgOIAxAAIAAALIgZA2g");
	this.shape_759.setTransform(204.45,194.6);

	this.shape_760 = new cjs.Shape();
	this.shape_760.graphics.f("#000000").s().p("AgKAOIAFgbIAQAAIgKAbg");
	this.shape_760.setTransform(200.15,198.075);

	this.shape_761 = new cjs.Shape();
	this.shape_761.graphics.f("#000000").s().p("AgQAhIAYgzIggAAIAAgOIAxAAIAAALIgZA2g");
	this.shape_761.setTransform(196,194.6);

	this.shape_762 = new cjs.Shape();
	this.shape_762.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgCQACgDAEAAQAFAAADADQACACAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgKQgDgCAAgEQAAgKAJAAQAKAAAAAKQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_762.setTransform(189.075,195.3);

	this.shape_763 = new cjs.Shape();
	this.shape_763.graphics.f("#000000").s().p("AgWAhIAAhBIAtAAIAAAOIgdAAIAAAMIAZAAIAAAMIgZAAIAAAOIAdAAIAAANg");
	this.shape_763.setTransform(184.775,194.6);

	this.shape_764 = new cjs.Shape();
	this.shape_764.graphics.f("#000000").s().p("AAQAhIgEgNIgYAAIgFANIgPAAIAWhBIAVAAIAWBBgAAIAGIgIgaIgIAaIAQAAg");
	this.shape_764.setTransform(178.275,194.6);

	this.shape_765 = new cjs.Shape();
	this.shape_765.graphics.f("#000000").s().p("AgHAhIAAgzIgVAAIAAgOIA5AAIAAAOIgVAAIAAAzg");
	this.shape_765.setTransform(171.525,194.6);

	this.shape_766 = new cjs.Shape();
	this.shape_766.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDACgFAAQgEAAgCgCg");
	this.shape_766.setTransform(164.225,197.05);

	this.shape_767 = new cjs.Shape();
	this.shape_767.graphics.f("#000000").s().p("AAPAdQgFgFAAgHQAAgIAFgFQAFgEAJAAQAJAAAGAEQAEAFAAAIQAAAHgEAFQgGAFgJAAQgJAAgFgFgAAXARQAAAHAGAAQAGAAAAgHQAAgIgGAAQgGAAAAAIgAgeAhIAZgjIASgeIASAAIgZAjIgSAegAgqgDQgFgEAAgIQAAgIAFgFQAFgFAJAAQAJAAAFAFQAFAFAAAIQAAAIgFAEQgFAFgJAAQgJAAgFgFgAgigPQAAAHAGAAQAGAAAAgHQAAgIgGAAQgGAAAAAIg");
	this.shape_767.setTransform(157.575,194.575);

	this.shape_768 = new cjs.Shape();
	this.shape_768.graphics.f("#000000").s().p("AgWAfIAAgOQAIAEAKAAQAQAAABgUQgCAEgFADQgFACgFAAQgLAAgGgFQgGgFAAgKQAAgKAHgHQAHgGAMAAQANAAAHAHQAJAIAAARQAAAQgHAJQgIAKgQAAQgMAAgHgDgAgLgKQgBAKAMAAQAGAAACgDQADgCABgFQgBgFgDgDQgDgDgFAAQgLAAAAALg");
	this.shape_768.setTransform(149.2,194.575);

	this.shape_769 = new cjs.Shape();
	this.shape_769.graphics.f("#000000").s().p("AgWAfIAAgOQAIAEAKAAQAQAAABgUQgDAEgEADQgFACgFAAQgKAAgHgFQgGgFAAgKQAAgKAHgHQAHgGAMAAQANAAAHAHQAJAIAAARQAAAQgIAJQgIAKgPAAQgLAAgIgDgAgLgKQgBAKAMAAQAGAAACgDQADgCAAgFQAAgFgDgDQgDgDgFAAQgLAAAAALg");
	this.shape_769.setTransform(142.8,194.575);

	this.shape_770 = new cjs.Shape();
	this.shape_770.graphics.f("#000000").s().p("AgKAOIAFgbIAQAAIgKAbg");
	this.shape_770.setTransform(138.15,198.075);

	this.shape_771 = new cjs.Shape();
	this.shape_771.graphics.f("#000000").s().p("AgYAeIABgPQALAFAKgBQALAAAAgJQAAgIgPgBQgJABgHACIAAgkIAsAAIAAANIgeAAIAAAKIAIAAQAZAAAAATQAAAMgHAFQgHAHgMgBQgMABgLgEg");
	this.shape_771.setTransform(133.975,194.65);

	this.shape_772 = new cjs.Shape();
	this.shape_772.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgCQACgDAEAAQAFAAADADQACACAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgKQgDgCAAgEQAAgKAJAAQAKAAAAAKQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_772.setTransform(126.825,195.3);

	this.shape_773 = new cjs.Shape();
	this.shape_773.graphics.f("#000000").s().p("AAJAhIgXguIAAAuIgPAAIAAhBIAVAAIAXAtIAAgtIAPAAIAABBg");
	this.shape_773.setTransform(121.625,194.6);

	this.shape_774 = new cjs.Shape();
	this.shape_774.graphics.f("#000000").s().p("AgHAhIAAhBIAPAAIAABBg");
	this.shape_774.setTransform(116.425,194.6);

	this.shape_775 = new cjs.Shape();
	this.shape_775.graphics.f("#000000").s().p("AgHAhIAAgzIgVAAIAAgOIA5AAIAAAOIgVAAIAAAzg");
	this.shape_775.setTransform(111.675,194.6);

	this.shape_776 = new cjs.Shape();
	this.shape_776.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDACgFAAQgEAAgCgCg");
	this.shape_776.setTransform(104.375,197.05);

	this.shape_777 = new cjs.Shape();
	this.shape_777.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_777.setTransform(99.575,194.575);

	this.shape_778 = new cjs.Shape();
	this.shape_778.graphics.f("#000000").s().p("AgYAeIABgOQAKAEALAAQAKAAABgHQgBgHgJAAIgMAAIAAgMIALAAQAJAAAAgGQAAgHgMAAQgJAAgJAEIAAgOQAJgEAMAAQAMAAAHAFQAGAFABAIQAAALgNAEQAOACAAAMQAAAJgHAGQgHAFgMAAQgNAAgKgEg");
	this.shape_778.setTransform(93.55,194.575);

	this.shape_779 = new cjs.Shape();
	this.shape_779.graphics.f("#000000").s().p("AADAhIAAgMIghAAIAAgMIAegpIATAAIAAAoIAMAAIAAANIgMAAIAAAMgAgOAIIARAAIAAgag");
	this.shape_779.setTransform(87.075,194.6);

	this.shape_780 = new cjs.Shape();
	this.shape_780.graphics.f("#000000").s().p("AgKAOIAFgbIAPAAIgJAbg");
	this.shape_780.setTransform(82.15,198.075);

	this.shape_781 = new cjs.Shape();
	this.shape_781.graphics.f("#000000").s().p("AgQAhIAYgzIggAAIAAgOIAxAAIAAALIgZA2g");
	this.shape_781.setTransform(78,194.6);

	this.shape_782 = new cjs.Shape();
	this.shape_782.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_782.setTransform(72.325,194.525);

	this.shape_783 = new cjs.Shape();
	this.shape_783.graphics.f("#000000").s().p("AgTAbQgIgHAAgSQAAgQAHgJQAIgKAQAAQALAAAIADIAAAOQgIgEgKAAQgQAAgBAUQACgEAFgDQAFgCAFAAQAKAAAHAFQAGAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgIgHgAgHAEQgEADAAAEQAAAFAEADQADADAEAAQANAAAAgLQAAgKgMAAQgGAAgCADg");
	this.shape_783.setTransform(66.25,194.575);

	this.shape_784 = new cjs.Shape();
	this.shape_784.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDACgFAAQgEAAgCgCg");
	this.shape_784.setTransform(61.525,197.05);

	this.shape_785 = new cjs.Shape();
	this.shape_785.graphics.f("#000000").s().p("AgSAbQgJgHAAgSQAAgQAHgJQAIgKAQAAQAMAAAHADIAAAOQgIgEgKAAQgQAAgBAUQACgEAFgDQAFgCAFAAQALAAAFAFQAHAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgHgHgAgHAEQgDADgBAEQABAFADADQADADAEAAQAMAAAAgLQABgKgMAAQgGAAgCADg");
	this.shape_785.setTransform(56.9,194.575);

	this.shape_786 = new cjs.Shape();
	this.shape_786.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_786.setTransform(50.825,194.525);

	this.shape_787 = new cjs.Shape();
	this.shape_787.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgCQACgDAEAAQAFAAADADQACACAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgKQgDgCAAgEQAAgKAJAAQAKAAAAAKQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_787.setTransform(43.825,195.3);

	this.shape_788 = new cjs.Shape();
	this.shape_788.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_788.setTransform(39.775,195.3);

	this.shape_789 = new cjs.Shape();
	this.shape_789.graphics.f("#000000").s().p("AgTAVQgIgIAAgNQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHgBAMQABANgIAIQgHAGgNAAQgMAAgHgGgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_789.setTransform(34.1,195.3);

	this.shape_790 = new cjs.Shape();
	this.shape_790.graphics.f("#000000").s().p("AgVAaIAAgMIAZgbIgZAAIAAgMIArAAIAAAMIgaAbIAaAAIAAAMg");
	this.shape_790.setTransform(28.375,195.325);

	this.shape_791 = new cjs.Shape();
	this.shape_791.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQAAgHAFgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAWAAABATIAAAhIgPAAIAAgKQgEALgMAAQgHAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_791.setTransform(22.9,195.3);

	this.shape_792 = new cjs.Shape();
	this.shape_792.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_792.setTransform(18.875,194.3);

	this.shape_793 = new cjs.Shape();
	this.shape_793.graphics.f("#000000").s().p("AgaAkIAAhFIAOAAIAAALQAEgNANAAQAKAAAGAGQAGAIAAAMQAAANgGAIQgGAGgKAAQgLAAgFgLIAAAdgAgLgJIAAACQAAAMALAAQAMAAAAgNQAAgOgMAAQgLAAAAANg");
	this.shape_793.setTransform(14.375,196.2);

	this.shape_794 = new cjs.Shape();
	this.shape_794.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQAAgHAFgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAWAAABASIAAAiIgPAAIAAgJQgEAKgMAAQgHAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgFIAAgBIgJAAQgIAAAAAGg");
	this.shape_794.setTransform(188.95,182.4);

	this.shape_795 = new cjs.Shape();
	this.shape_795.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_795.setTransform(182.325,181.4);

	this.shape_796 = new cjs.Shape();
	this.shape_796.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAAAASIAAAiIgOAAIAAgJQgEAKgLAAQgIAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgFIAAgBIgJAAQgIAAAAAGg");
	this.shape_796.setTransform(178.05,182.4);

	this.shape_797 = new cjs.Shape();
	this.shape_797.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgMIAOAAIAAAPIAUAAIAAALIgUAAIAAARQAAAKAJAAQAGAAAFgBIAAAMQgHADgHAAQgUgBAAgVg");
	this.shape_797.setTransform(172.85,181.75);

	this.shape_798 = new cjs.Shape();
	this.shape_798.graphics.f("#000000").s().p("AgTAUQgIgGAAgOQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHgBAMQABAOgIAGQgHAHgNAAQgMAAgHgHgAgLAAQAAAOALAAQANAAAAgOQAAgNgNAAQgLAAAAANg");
	this.shape_798.setTransform(167.3,182.4);

	this.shape_799 = new cjs.Shape();
	this.shape_799.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgMIAOAAIAAAPIAUAAIAAALIgUAAIAAARQAAAKAKAAQAFAAAFgBIAAAMQgHADgHAAQgUgBAAgVg");
	this.shape_799.setTransform(161.65,181.75);

	this.shape_800 = new cjs.Shape();
	this.shape_800.graphics.f("#000000").s().p("AgTAUQgHgGgBgOQABgMAHgHQAIgHALAAQANAAAHAHQAHAHAAAMQAAAOgHAGQgHAHgNAAQgLAAgIgHgAgLAAQAAAOALAAQAMAAAAgOQAAgNgMAAQgLAAAAANg");
	this.shape_800.setTransform(153.5,182.4);

	this.shape_801 = new cjs.Shape();
	this.shape_801.graphics.f("#000000").s().p("AgHAmIAAgzIAOAAIAAAzgAgJgcQAAgJAJAAQAKAAAAAJQAAAJgKAAQgJAAAAgJg");
	this.shape_801.setTransform(148.95,181.225);

	this.shape_802 = new cjs.Shape();
	this.shape_802.graphics.f("#000000").s().p("AgNAUQgIgGAAgOQAAgMAIgHQAGgHAMAAQAIAAAIAEIAAANQgGgEgIAAQgNAAAAANQAAAOANAAQAHAAAIgEIAAANQgHAEgKAAQgMAAgGgHg");
	this.shape_802.setTransform(144.9,182.4);

	this.shape_803 = new cjs.Shape();
	this.shape_803.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAHIgiAAQABAFADADQAEACAGABQALAAAIgFIAAAMQgIAEgNAAQgMAAgIgHgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_803.setTransform(139.575,182.4);

	this.shape_804 = new cjs.Shape();
	this.shape_804.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQAEgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_804.setTransform(134.9,182.375);

	this.shape_805 = new cjs.Shape();
	this.shape_805.graphics.f("#000000").s().p("AgZAhIAAhBIAZAAQAaAAAAAXQAAAKgGAGQgHAGgLAAIgMAAIAAAUgAgKAAIAKAAQALAAAAgKQAAgJgLAAIgKAAg");
	this.shape_805.setTransform(129.625,181.7);

	this.shape_806 = new cjs.Shape();
	this.shape_806.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgDADgDQACgCAEAAQAFAAADACQACADAAADQAAAEgCACQgDAEgFAAQgEAAgCgEg");
	this.shape_806.setTransform(122.175,184.15);

	this.shape_807 = new cjs.Shape();
	this.shape_807.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_807.setTransform(117.375,181.675);

	this.shape_808 = new cjs.Shape();
	this.shape_808.graphics.f("#000000").s().p("AgYAeIABgOQAKAEAKAAQAMAAAAgHQAAgHgLAAIgLAAIAAgMIALAAQAJAAAAgGQAAgHgMAAQgKAAgIAEIAAgOQAJgEALAAQAMAAAIAFQAGAFAAAIQAAALgMAEQAOACAAAMQAAAJgHAGQgHAFgNAAQgLAAgLgEg");
	this.shape_808.setTransform(111.35,181.675);

	this.shape_809 = new cjs.Shape();
	this.shape_809.graphics.f("#000000").s().p("AgUAdQgIgFAAgKQAAgLAPgEQgNgDAAgLQAAgJAHgFQAIgEALAAQANAAAGAEQAIAFAAAJQAAALgNADQAHABAEAFQAEAEAAAFQAAAKgIAFQgHAFgOAAQgNAAgHgFgAgLAOQAAAIALAAQANAAAAgIQAAgJgNAAQgLAAAAAJgAgKgOQAAAIAKAAQALAAAAgIQAAgHgLAAQgKAAAAAHg");
	this.shape_809.setTransform(105.1,181.7);

	this.shape_810 = new cjs.Shape();
	this.shape_810.graphics.f("#000000").s().p("AgJAOIAEgbIAPAAIgJAbg");
	this.shape_810.setTransform(100.4,185.175);

	this.shape_811 = new cjs.Shape();
	this.shape_811.graphics.f("#000000").s().p("AgVAdQgHgFAAgKQAAgLAPgEQgNgDAAgLQAAgJAHgFQAIgEALAAQAMAAAIAEQAHAFAAAJQAAALgNADQAIABADAFQAEAEAAAFQAAAKgIAFQgHAFgOAAQgNAAgIgFgAgMAOQAAAIAMAAQANAAAAgIQAAgJgNAAQgMAAAAAJgAgKgOQAAAIAKAAQALAAAAgIQAAgHgLAAQgKAAAAAHg");
	this.shape_811.setTransform(95.85,181.7);

	this.shape_812 = new cjs.Shape();
	this.shape_812.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_812.setTransform(89.325,181.675);

	this.shape_813 = new cjs.Shape();
	this.shape_813.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_813.setTransform(82.725,181.675);

	this.shape_814 = new cjs.Shape();
	this.shape_814.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgDADgDQACgCAEAAQAFAAADACQACADAAADQAAAEgCACQgDAEgFAAQgEAAgCgEg");
	this.shape_814.setTransform(77.925,184.15);

	this.shape_815 = new cjs.Shape();
	this.shape_815.graphics.f("#000000").s().p("AABAhIAAgwIgRADIAAgPIAhgFIAABBg");
	this.shape_815.setTransform(74.05,181.7);

	this.shape_816 = new cjs.Shape();
	this.shape_816.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_816.setTransform(69.175,181.625);

	this.shape_817 = new cjs.Shape();
	this.shape_817.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgDQACgCAEAAQAFAAADACQACADAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgJQgDgDAAgFQAAgJAJAAQAKAAAAAJQAAAFgCADQgDACgFAAQgEAAgCgCg");
	this.shape_817.setTransform(62.175,182.4);

	this.shape_818 = new cjs.Shape();
	this.shape_818.graphics.f("#000000").s().p("AgTAUQgIgGAAgOQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHAAAMQAAAOgIAGQgHAHgNAAQgMAAgHgHgAgLAAQAAAOALAAQANAAAAgOQAAgNgNAAQgLAAAAANg");
	this.shape_818.setTransform(57.6,182.4);

	this.shape_819 = new cjs.Shape();
	this.shape_819.graphics.f("#000000").s().p("AgUAfQgGgIAAgMQAAgNAGgIQAGgGAKAAQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgNQgDAOgNAAQgKgBgGgFgAgLAKQAAAOALAAQAMAAAAgNIAAgBQAAgNgMgBQgLAAAAAOg");
	this.shape_819.setTransform(51.175,181.45);

	this.shape_820 = new cjs.Shape();
	this.shape_820.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQgBgHAFgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAAAASIAAAiIgQAAIAAgJQgDAKgMAAQgHAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgFIAAgBIgKAAQgHAAAAAGg");
	this.shape_820.setTransform(45.25,182.4);

	this.shape_821 = new cjs.Shape();
	this.shape_821.graphics.f("#000000").s().p("AgUAfQgGgIAAgMQAAgNAGgIQAGgGAKAAQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgNQgDAOgNAAQgKgBgGgFgAgLAKQAAAOALAAQAMAAAAgNIAAgBQAAgNgMgBQgLAAAAAOg");
	this.shape_821.setTransform(39.275,181.45);

	this.shape_822 = new cjs.Shape();
	this.shape_822.graphics.f("#000000").s().p("AgTAWQgFgFABgJIAAghIAOAAIAAAcQAAAKAJAAQAJAAAAgNIAAgZIAPAAIAAAyIgOAAIAAgLQgEAMgNAAQgHAAgFgEg");
	this.shape_822.setTransform(33.1,182.475);

	this.shape_823 = new cjs.Shape();
	this.shape_823.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAHIgiAAQABAFADADQAEACAGABQALAAAIgFIAAAMQgIAEgNAAQgMAAgIgHgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_823.setTransform(27.275,182.4);

	this.shape_824 = new cjs.Shape();
	this.shape_824.graphics.f("#000000").s().p("AgUAfQgGgIAAgMQAAgNAGgIQAGgGAKAAQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgNQgDAOgNAAQgKgBgGgFgAgLAKQAAAOALAAQAMAAAAgNIAAgBQAAgNgMgBQgLAAAAAOg");
	this.shape_824.setTransform(21.075,181.45);

	this.shape_825 = new cjs.Shape();
	this.shape_825.graphics.f("#000000").s().p("AAQAhIgEgNIgYAAIgFANIgPAAIAWhBIAVAAIAWBBgAAIAGIgIgaIgIAaIAQAAg");
	this.shape_825.setTransform(14.525,181.7);

	this.shape_826 = new cjs.Shape();
	this.shape_826.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_826.setTransform(247.375,168.5);

	this.shape_827 = new cjs.Shape();
	this.shape_827.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQAAgHAEgEQAFgEAJAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAFIAAgOQAKgEAKAAQAXAAgBATIAAAhIgOAAIAAgJQgEAKgLAAQgIAAgFgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_827.setTransform(243.1,169.5);

	this.shape_828 = new cjs.Shape();
	this.shape_828.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAJAAQAGAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_828.setTransform(237.9,168.85);

	this.shape_829 = new cjs.Shape();
	this.shape_829.graphics.f("#000000").s().p("AgTAUQgHgGgBgOQABgMAHgHQAIgHALAAQANAAAHAHQAHAHAAAMQAAAOgHAGQgHAHgNAAQgLAAgIgHgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_829.setTransform(232.35,169.5);

	this.shape_830 = new cjs.Shape();
	this.shape_830.graphics.f("#000000").s().p("AgHAhIAAgzIgVAAIAAgOIA5AAIAAAOIgVAAIAAAzg");
	this.shape_830.setTransform(226.025,168.8);

	this.shape_831 = new cjs.Shape();
	this.shape_831.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAGIgiAAQABAHADACQAEADAGAAQALgBAIgEIAAALQgIAFgNAAQgMAAgIgHgAALgFQAAgKgKAAQgIAAgCAKIAUAAIAAAAg");
	this.shape_831.setTransform(217.375,169.5);

	this.shape_832 = new cjs.Shape();
	this.shape_832.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAKAAQAFAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_832.setTransform(211.95,168.85);

	this.shape_833 = new cjs.Shape();
	this.shape_833.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQADgPAOAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_833.setTransform(207.7,169.475);

	this.shape_834 = new cjs.Shape();
	this.shape_834.graphics.f("#000000").s().p("AgTAUQgHgGAAgOQAAgMAHgHQAIgHALAAQANAAAHAHQAHAHABAMQgBAOgHAGQgHAHgNAAQgLAAgIgHgAgLABQAAANALAAQAMAAAAgOQAAgNgMAAQgLAAAAAOg");
	this.shape_834.setTransform(202.35,169.5);

	this.shape_835 = new cjs.Shape();
	this.shape_835.graphics.f("#000000").s().p("AgaAkIAAhGIAOAAIAAAMQAEgNANAAQAKAAAGAHQAGAGAAAOQAAAMgGAHQgGAHgKAAQgLAAgFgKIAAAcgAgLgIIAAABQAAAMALAAQAMAAAAgNQAAgOgMAAQgLAAAAAOg");
	this.shape_835.setTransform(196.175,170.4);

	this.shape_836 = new cjs.Shape();
	this.shape_836.graphics.f("#000000").s().p("AAZAaIAAgcQAAgKgIAAQgKAAABANIAAAZIgOAAIAAgcQgBgKgHAAQgJAAAAANIAAAZIgQAAIAAgyIAPAAIAAALQAEgNANAAQALAAADANQAEgNAMAAQAIAAAFAFQAEAFAAAJIAAAhg");
	this.shape_836.setTransform(188.3,169.45);

	this.shape_837 = new cjs.Shape();
	this.shape_837.graphics.f("#000000").s().p("AgHAhIAAhBIAPAAIAABBg");
	this.shape_837.setTransform(182.175,168.8);

	this.shape_838 = new cjs.Shape();
	this.shape_838.graphics.f("#000000").s().p("AgGAHQgDgDAAgEQAAgEADgCQACgCAEgBQAFABADACQACACAAAEQAAAEgCADQgDACgFAAQgEAAgCgCg");
	this.shape_838.setTransform(176.575,171.25);

	this.shape_839 = new cjs.Shape();
	this.shape_839.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_839.setTransform(171.775,168.775);

	this.shape_840 = new cjs.Shape();
	this.shape_840.graphics.f("#000000").s().p("AgYAeIABgOQAKAEALAAQALAAgBgHQABgHgKAAIgLAAIAAgMIAKAAQAJAAAAgGQAAgHgLAAQgKAAgJAEIAAgOQAJgEAMAAQALAAAIAFQAHAFAAAIQAAALgNAEQAOACAAAMQAAAJgHAGQgIAFgLAAQgMAAgLgEg");
	this.shape_840.setTransform(165.75,168.775);

	this.shape_841 = new cjs.Shape();
	this.shape_841.graphics.f("#000000").s().p("AADAhIAAgNIghAAIAAgLIAegpIATAAIAAAoIAMAAIAAAMIgMAAIAAANgAgOAIIARAAIAAgag");
	this.shape_841.setTransform(159.275,168.8);

	this.shape_842 = new cjs.Shape();
	this.shape_842.graphics.f("#000000").s().p("AgKAOIAFgbIAQAAIgKAbg");
	this.shape_842.setTransform(154.35,172.275);

	this.shape_843 = new cjs.Shape();
	this.shape_843.graphics.f("#000000").s().p("AgPAhIAXgzIggAAIAAgOIAxAAIAAALIgZA2g");
	this.shape_843.setTransform(150.2,168.8);

	this.shape_844 = new cjs.Shape();
	this.shape_844.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_844.setTransform(144.525,168.725);

	this.shape_845 = new cjs.Shape();
	this.shape_845.graphics.f("#000000").s().p("AgQAhIAYgzIggAAIAAgOIAxAAIAAALIgZA2g");
	this.shape_845.setTransform(138.75,168.8);

	this.shape_846 = new cjs.Shape();
	this.shape_846.graphics.f("#000000").s().p("AgGAHQgDgDAAgEQAAgEADgCQACgCAEgBQAFABADACQACACAAAEQAAAEgCADQgDACgFAAQgEAAgCgCg");
	this.shape_846.setTransform(134.425,171.25);

	this.shape_847 = new cjs.Shape();
	this.shape_847.graphics.f("#000000").s().p("AgYAeIABgOQAKAEAKAAQAMAAAAgHQAAgHgLAAIgLAAIAAgMIALAAQAJAAAAgGQAAgHgLAAQgLAAgIAEIAAgOQAJgEALAAQANAAAGAFQAIAFgBAIQAAALgMAEQAOACAAAMQAAAJgHAGQgHAFgNAAQgMAAgKgEg");
	this.shape_847.setTransform(130.15,168.775);

	this.shape_848 = new cjs.Shape();
	this.shape_848.graphics.f("#000000").s().p("AgGAYQgDgCAAgEQAAgFADgCQACgDAEAAQAFAAADADQACACAAAFQAAAEgCACQgDADgFAAQgEAAgCgDgAgGgJQgDgDAAgEQAAgKAJAAQAKAAAAAKQAAAEgCADQgDACgFAAQgEAAgCgCg");
	this.shape_848.setTransform(123.075,169.5);

	this.shape_849 = new cjs.Shape();
	this.shape_849.graphics.f("#000000").s().p("AgTAUQgHgGgBgOQABgMAHgHQAIgHALAAQANAAAHAHQAHAHAAAMQAAAOgHAGQgHAHgNAAQgLAAgIgHgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_849.setTransform(118.5,169.5);

	this.shape_850 = new cjs.Shape();
	this.shape_850.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAKAAQAFAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_850.setTransform(112.85,168.85);

	this.shape_851 = new cjs.Shape();
	this.shape_851.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgJgcQABgJAIAAQAJAAAAAJQAAAJgJAAQgIAAgBgJg");
	this.shape_851.setTransform(108.95,168.325);

	this.shape_852 = new cjs.Shape();
	this.shape_852.graphics.f("#000000").s().p("AgUAfQgGgIAAgNQAAgMAGgIQAGgGAKgBQALAAAFALIAAgeIAPAAIAABHIgPAAIAAgLQgDAMgNAAQgKAAgGgFgAgLAKQAAAOALAAQAMAAAAgOIAAgBQAAgNgMABQgLAAAAANg");
	this.shape_852.setTransform(104.125,168.55);

	this.shape_853 = new cjs.Shape();
	this.shape_853.graphics.f("#000000").s().p("AgRAeQgHgHAAgOQAAgLAIgIQAHgGALgBQALAAAGAHQAGAGAAAKIAAAIIgiAAQABAGADADQAEACAGAAQALAAAIgEIAAALQgIAFgNgBQgMABgIgHgAALAEQAAgKgKABQgIgBgCAKIAUAAIAAAAgAgGgWIAGgOIATAAIgMAOg");
	this.shape_853.setTransform(98.225,168.55);

	this.shape_854 = new cjs.Shape();
	this.shape_854.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAOQACgPAOAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_854.setTransform(93.55,169.475);

	this.shape_855 = new cjs.Shape();
	this.shape_855.graphics.f("#000000").s().p("AgNAUQgIgGAAgOQAAgMAIgHQAHgHALAAQAIAAAIADIAAAOQgGgEgIAAQgNAAAAANQAAAOANAAQAHAAAIgEIAAANQgHAEgKAAQgLAAgHgHg");
	this.shape_855.setTransform(88.75,169.5);

	this.shape_856 = new cjs.Shape();
	this.shape_856.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_856.setTransform(82.275,168.5);

	this.shape_857 = new cjs.Shape();
	this.shape_857.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAGIgiAAQABAHADACQAEADAGAAQALgBAIgEIAAALQgIAFgNAAQgMAAgIgHgAALgFQAAgKgKAAQgIAAgCAKIAUAAIAAAAg");
	this.shape_857.setTransform(78.025,169.5);

	this.shape_858 = new cjs.Shape();
	this.shape_858.graphics.f("#000000").s().p("AgUAfQgGgIAAgNQAAgMAGgIQAGgGAKgBQALAAAFALIAAgeIAPAAIAABHIgPAAIAAgLQgDAMgNAAQgKAAgGgFgAgLAKQAAAOALAAQAMAAAAgOIAAgBQAAgNgMABQgLAAAAANg");
	this.shape_858.setTransform(71.825,168.55);

	this.shape_859 = new cjs.Shape();
	this.shape_859.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_859.setTransform(64.775,168.5);

	this.shape_860 = new cjs.Shape();
	this.shape_860.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgEAJAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAFIAAgOQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgJQgEAKgLAAQgIAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_860.setTransform(60.5,169.5);

	this.shape_861 = new cjs.Shape();
	this.shape_861.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAJAAQAGAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_861.setTransform(55.3,168.85);

	this.shape_862 = new cjs.Shape();
	this.shape_862.graphics.f("#000000").s().p("AgTAUQgIgGAAgOQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHgBAMQABAOgIAGQgHAHgNAAQgMAAgHgHgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_862.setTransform(49.75,169.5);

	this.shape_863 = new cjs.Shape();
	this.shape_863.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAKAAQAFAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_863.setTransform(44.1,168.85);

	this.shape_864 = new cjs.Shape();
	this.shape_864.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAGIgiAAQABAHADACQAEADAGAAQALgBAIgEIAAALQgIAFgNAAQgMAAgIgHgAALgFQAAgKgKAAQgIAAgCAKIAUAAIAAAAg");
	this.shape_864.setTransform(36.225,169.5);

	this.shape_865 = new cjs.Shape();
	this.shape_865.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAKAAQAFAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_865.setTransform(30.8,168.85);

	this.shape_866 = new cjs.Shape();
	this.shape_866.graphics.f("#000000").s().p("AgUAWIAAgLQAIAEALABQAJAAAAgFQAAgEgHAAIgHgCQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBANQgIgFgKAAQgHAAAAAFQAAADAGABIAGAAQAJACAEADQADACAAAHQAAASgWAAQgNAAgHgFg");
	this.shape_866.setTransform(25.775,169.5);

	this.shape_867 = new cjs.Shape();
	this.shape_867.graphics.f("#000000").s().p("AgTAUQgHgGAAgOQAAgMAHgHQAIgHALAAQANAAAHAHQAHAHABAMQgBAOgHAGQgHAHgNAAQgLAAgIgHgAgLABQAAANALAAQAMAAAAgOQAAgNgMAAQgLAAAAAOg");
	this.shape_867.setTransform(20.1,169.5);

	this.shape_868 = new cjs.Shape();
	this.shape_868.graphics.f("#000000").s().p("AgQAaQgIgJAAgRQAAgPAIgJQAJgJAOAAQAKAAAIAEIAAAPQgIgFgJAAQgIAAgDAFQgGAFAAAJQAAAVARAAQAJAAAIgHIAAAPQgHAFgLAAQgOAAgJgIg");
	this.shape_868.setTransform(13.975,168.775);

	this.shape_869 = new cjs.Shape();
	this.shape_869.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDADgFAAQgEAAgCgDg");
	this.shape_869.setTransform(248.475,158.35);

	this.shape_870 = new cjs.Shape();
	this.shape_870.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_870.setTransform(243.675,155.875);

	this.shape_871 = new cjs.Shape();
	this.shape_871.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_871.setTransform(237.625,155.825);

	this.shape_872 = new cjs.Shape();
	this.shape_872.graphics.f("#000000").s().p("AgUAdQgIgFAAgKQAAgLAPgDQgNgEAAgLQAAgIAIgGQAHgEALAAQANAAAGAEQAIAGAAAIQAAALgNAEQAIAAADAFQAEAEAAAFQAAAKgIAFQgIAFgNAAQgNAAgHgFgAgLANQAAAJALAAQANAAAAgJQAAgIgNAAQgLAAAAAIgAgKgOQAAAHAKABQALgBAAgHQAAgHgLAAQgKAAAAAHg");
	this.shape_872.setTransform(231.45,155.9);

	this.shape_873 = new cjs.Shape();
	this.shape_873.graphics.f("#000000").s().p("AgJAOIAEgbIAPAAIgJAbg");
	this.shape_873.setTransform(226.75,159.375);

	this.shape_874 = new cjs.Shape();
	this.shape_874.graphics.f("#000000").s().p("AADAhIAAgNIghAAIAAgLIAegpIATAAIAAAoIAMAAIAAAMIgMAAIAAANgAgOAIIARAAIAAgag");
	this.shape_874.setTransform(221.975,155.9);

	this.shape_875 = new cjs.Shape();
	this.shape_875.graphics.f("#000000").s().p("AADAhIAAgNIghAAIAAgLIAegpIATAAIAAAoIAMAAIAAAMIgMAAIAAANgAgOAIIARAAIAAgag");
	this.shape_875.setTransform(215.025,155.9);

	this.shape_876 = new cjs.Shape();
	this.shape_876.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_876.setTransform(208.275,155.875);

	this.shape_877 = new cjs.Shape();
	this.shape_877.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDADgFAAQgEAAgCgDg");
	this.shape_877.setTransform(203.475,158.35);

	this.shape_878 = new cjs.Shape();
	this.shape_878.graphics.f("#000000").s().p("AgYAeIABgOQAKAEAKAAQALAAABgHQgBgHgJAAIgMAAIAAgMIALAAQAJAAAAgGQAAgHgMAAQgKAAgIAEIAAgOQAJgEALAAQAMAAAIAFQAGAFAAAIQAAALgMAEQAOACAAAMQAAAJgHAGQgHAFgMAAQgNAAgKgEg");
	this.shape_878.setTransform(199.2,155.875);

	this.shape_879 = new cjs.Shape();
	this.shape_879.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgCQACgDAEAAQAFAAADADQACACAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgKQgDgCAAgEQAAgKAJAAQAKAAAAAKQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_879.setTransform(192.125,156.6);

	this.shape_880 = new cjs.Shape();
	this.shape_880.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_880.setTransform(188.075,156.6);

	this.shape_881 = new cjs.Shape();
	this.shape_881.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_881.setTransform(182.675,156.6);

	this.shape_882 = new cjs.Shape();
	this.shape_882.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_882.setTransform(177.225,156.6);

	this.shape_883 = new cjs.Shape();
	this.shape_883.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_883.setTransform(171.825,156.6);

	this.shape_884 = new cjs.Shape();
	this.shape_884.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAOQADgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_884.setTransform(167.15,156.575);

	this.shape_885 = new cjs.Shape();
	this.shape_885.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_885.setTransform(162.075,156.6);

	this.shape_886 = new cjs.Shape();
	this.shape_886.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAALIgUAAIAAARQAAAKAJAAQAGAAAFgCIAAANQgHACgHABQgUAAAAgWg");
	this.shape_886.setTransform(156.65,155.95);

	this.shape_887 = new cjs.Shape();
	this.shape_887.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIAAAFAEQAFAFAAAJIAAAig");
	this.shape_887.setTransform(151.225,156.55);

	this.shape_888 = new cjs.Shape();
	this.shape_888.graphics.f("#000000").s().p("AgHAhIAAhBIAPAAIAABBg");
	this.shape_888.setTransform(146.625,155.9);

	this.shape_889 = new cjs.Shape();
	this.shape_889.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDADgFAAQgEAAgCgDg");
	this.shape_889.setTransform(141.025,158.35);

	this.shape_890 = new cjs.Shape();
	this.shape_890.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_890.setTransform(136.225,155.875);

	this.shape_891 = new cjs.Shape();
	this.shape_891.graphics.f("#000000").s().p("AACAhIAAgwIgSADIAAgPIAhgFIAABBg");
	this.shape_891.setTransform(130.6,155.9);

	this.shape_892 = new cjs.Shape();
	this.shape_892.graphics.f("#000000").s().p("AgSAbQgJgHAAgSQAAgQAIgJQAIgKAPAAQALAAAIADIAAAOQgIgEgKAAQgQAAgBAUQADgEAEgDQAFgCAFAAQALAAAFAFQAHAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgHgHgAgHAEQgDADAAAEQAAAFADADQADADAEAAQAMAAAAgLQABgKgMAAQgGAAgCADg");
	this.shape_892.setTransform(125.4,155.875);

	this.shape_893 = new cjs.Shape();
	this.shape_893.graphics.f("#000000").s().p("AgKAOIAFgbIAQAAIgKAbg");
	this.shape_893.setTransform(120.7,159.375);

	this.shape_894 = new cjs.Shape();
	this.shape_894.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_894.setTransform(116.575,155.825);

	this.shape_895 = new cjs.Shape();
	this.shape_895.graphics.f("#000000").s().p("AgUAdQgIgFAAgKQAAgLAPgDQgNgEAAgLQAAgIAIgGQAHgEALAAQANAAAGAEQAIAGAAAIQAAALgNAEQAIAAADAFQAEAEAAAFQAAAKgIAFQgIAFgNAAQgNAAgHgFgAgLANQAAAJALAAQANAAAAgJQAAgIgNAAQgLAAAAAIgAgKgOQAAAHAKABQALgBAAgHQAAgHgLAAQgKAAAAAHg");
	this.shape_895.setTransform(110.4,155.9);

	this.shape_896 = new cjs.Shape();
	this.shape_896.graphics.f("#000000").s().p("AgSAbQgJgHAAgSQAAgQAIgJQAHgKAQAAQAMAAAHADIAAAOQgIgEgJAAQgRAAAAAUQACgEAEgDQAFgCAFAAQALAAAFAFQAHAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgHgHgAgIAEQgCADAAAEQAAAFACADQADADAFAAQAMAAAAgLQAAgKgMAAQgEAAgEADg");
	this.shape_896.setTransform(104,155.875);

	this.shape_897 = new cjs.Shape();
	this.shape_897.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgCQACgDAEAAQAFAAADADQACACAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgKQgDgCAAgEQAAgKAJAAQAKAAAAAKQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_897.setTransform(96.675,156.6);

	this.shape_898 = new cjs.Shape();
	this.shape_898.graphics.f("#000000").s().p("AgQAmQARgOAAgYQAAgWgRgPIAHgJQAZARAAAdQAAAfgZAQg");
	this.shape_898.setTransform(92.95,156.275);

	this.shape_899 = new cjs.Shape();
	this.shape_899.graphics.f("#000000").s().p("AAPAdQgFgFAAgHQAAgIAFgFQAFgEAJAAQAJAAAGAEQAEAFAAAIQAAAHgEAFQgGAFgJAAQgJAAgFgFgAAXARQAAAHAGAAQAGAAAAgHQAAgIgGAAQgGAAAAAIgAgeAhIAZgjIASgeIASAAIgZAjIgSAegAgqgDQgFgEAAgIQAAgIAFgFQAFgFAJAAQAJAAAFAFQAFAFAAAIQAAAIgFAEQgFAFgJAAQgJAAgFgFgAgigPQAAAHAGAAQAGAAAAgHQAAgIgGAAQgGAAAAAIg");
	this.shape_899.setTransform(86.025,155.875);

	this.shape_900 = new cjs.Shape();
	this.shape_900.graphics.f("#000000").s().p("AgYAeIABgPQALAFAKgBQALAAAAgJQAAgIgPgBQgJABgHACIAAgkIAsAAIAAANIgeAAIAAAKIAIAAQAZAAAAATQAAAMgHAFQgHAHgMAAQgMAAgLgEg");
	this.shape_900.setTransform(77.975,155.95);

	this.shape_901 = new cjs.Shape();
	this.shape_901.graphics.f("#000000").s().p("AgWAfIAAgOQAIAEAKAAQAQAAABgUQgDAEgEADQgFACgFAAQgKAAgHgFQgGgFAAgKQAAgKAHgHQAHgGAMAAQANAAAHAHQAJAIAAARQAAAQgIAJQgIAKgPAAQgLAAgIgDgAgLgKQgBAKAMAAQAGAAACgDQADgCAAgFQAAgFgDgDQgDgDgFAAQgLAAAAALg");
	this.shape_901.setTransform(71.7,155.875);

	this.shape_902 = new cjs.Shape();
	this.shape_902.graphics.f("#000000").s().p("AgKAOIAFgbIAQAAIgKAbg");
	this.shape_902.setTransform(67.05,159.375);

	this.shape_903 = new cjs.Shape();
	this.shape_903.graphics.f("#000000").s().p("AgYAeIABgOQAKAEALAAQAKAAABgHQgBgHgJAAIgMAAIAAgMIALAAQAJAAAAgGQAAgHgMAAQgJAAgJAEIAAgOQAJgEAMAAQAMAAAHAFQAGAFABAIQAAALgNAEQAOACAAAMQAAAJgHAGQgHAFgMAAQgNAAgKgEg");
	this.shape_903.setTransform(62.95,155.875);

	this.shape_904 = new cjs.Shape();
	this.shape_904.graphics.f("#000000").s().p("AgPAAQAAgdAZgRIAHAJQgRAPAAAWQAAAYARAOIgHAJQgZgQAAgfg");
	this.shape_904.setTransform(58.25,156.275);

	this.shape_905 = new cjs.Shape();
	this.shape_905.graphics.f("#000000").s().p("AgTAXQgEgEABgIQAAgHAEgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAgBATIAAAhIgOAAIAAgKQgEALgLAAQgIAAgFgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_905.setTransform(50.5,156.6);

	this.shape_906 = new cjs.Shape();
	this.shape_906.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAOQACgPAOAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_906.setTransform(46.05,156.575);

	this.shape_907 = new cjs.Shape();
	this.shape_907.graphics.f("#000000").s().p("AgTAWQgEgFgBgJIAAghIAQAAIAAAcQgBAKAJAAQAKAAAAgNIAAgZIAOAAIAAAyIgOAAIAAgLQgEAMgMAAQgJAAgEgEg");
	this.shape_907.setTransform(40.7,156.675);

	this.shape_908 = new cjs.Shape();
	this.shape_908.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAALIgUAAIAAARQAAAKAJAAQAGAAAFgCIAAANQgHACgHABQgUAAAAgWg");
	this.shape_908.setTransform(35.15,155.95);

	this.shape_909 = new cjs.Shape();
	this.shape_909.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAOQACgPAOAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_909.setTransform(30.9,156.575);

	this.shape_910 = new cjs.Shape();
	this.shape_910.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_910.setTransform(25.825,156.6);

	this.shape_911 = new cjs.Shape();
	this.shape_911.graphics.f("#000000").s().p("AgaAkIAAhFIAOAAIAAALQAEgNANAAQAKAAAGAGQAGAIAAAMQAAANgGAIQgGAGgKAAQgLAAgFgLIAAAdgAgLgJIAAACQAAAMALAAQAMAAAAgNQAAgOgMAAQgLAAAAANg");
	this.shape_911.setTransform(19.875,157.5);

	this.shape_912 = new cjs.Shape();
	this.shape_912.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQgBgHAFgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAABATIAAAhIgQAAIAAgKQgDALgMAAQgHAAgFgEgAgJALQAAAGAHAAQADAAAEgDQADgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_912.setTransform(13.65,156.6);

	this.shape_913 = new cjs.Shape();
	this.shape_913.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAHIgiAAQABAFADADQAEACAGABQALAAAIgFIAAAMQgIAEgNAAQgMAAgIgHgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_913.setTransform(235.275,143.7);

	this.shape_914 = new cjs.Shape();
	this.shape_914.graphics.f("#000000").s().p("AgUAfQgGgIAAgMQAAgNAGgIQAGgGAKAAQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgNQgDAOgNAAQgKgBgGgFgAgLAKQAAAOALAAQAMAAAAgNIAAgBQAAgNgMgBQgLAAAAAOg");
	this.shape_914.setTransform(229.075,142.75);

	this.shape_915 = new cjs.Shape();
	this.shape_915.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIgBAFAFQAFAFAAAKIAAAhg");
	this.shape_915.setTransform(220.425,143.65);

	this.shape_916 = new cjs.Shape();
	this.shape_916.graphics.f("#000000").s().p("AgTAeQgIgHAAgNQAAgMAIgIQAHgGAMAAQANAAAHAGQAIAIAAAMQAAANgIAHQgHAHgNAAQgMAAgHgHgAgLAKQAAANALAAQANABAAgOQAAgNgNgBQgLAAAAAOgAgHgWIAHgNIARAAIgMANg");
	this.shape_916.setTransform(214.2,142.75);

	this.shape_917 = new cjs.Shape();
	this.shape_917.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAAAAJQAAAJgKAAQgIAAAAgJg");
	this.shape_917.setTransform(209.65,142.525);

	this.shape_918 = new cjs.Shape();
	this.shape_918.graphics.f("#000000").s().p("AgUAXIAAgNQAIAGALAAQAJgBAAgEQAAgDgHgBIgHgBQgPgDAAgMQAAgRAVAAQAMAAAIAEIgBANQgIgFgKAAQgHAAAAAFQAAADAGABIAGABQAJABAEADQADACAAAHQAAASgWAAQgNAAgHgEg");
	this.shape_918.setTransform(205.575,143.7);

	this.shape_919 = new cjs.Shape();
	this.shape_919.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAgBAJQABAJgKAAQgIAAAAgJg");
	this.shape_919.setTransform(201.55,142.525);

	this.shape_920 = new cjs.Shape();
	this.shape_920.graphics.f("#000000").s().p("AAZAbIAAgdQAAgLgIAAQgKAAAAAOIAAAaIgOAAIAAgdQABgLgIAAQgKAAABAOIAAAaIgQAAIAAgzIAPAAIAAAKQADgLANAAQAMAAADALQAEgLANAAQAHgBAEAFQAFAFAAAKIAAAhg");
	this.shape_920.setTransform(195.55,143.65);

	this.shape_921 = new cjs.Shape();
	this.shape_921.graphics.f("#000000").s().p("AgTAUQgHgGgBgOQABgMAHgHQAIgHALAAQANAAAHAHQAHAHAAAMQAAAOgHAGQgHAHgNAAQgLAAgIgHgAgLAAQAAAOALAAQANAAAAgOQAAgNgNAAQgLAAAAANg");
	this.shape_921.setTransform(187.8,143.7);

	this.shape_922 = new cjs.Shape();
	this.shape_922.graphics.f("#000000").s().p("AgQAaQgIgJAAgRQAAgPAIgJQAJgJAOAAQAKAAAIAEIAAAPQgIgFgJAAQgIAAgDAFQgGAFAAAJQAAAVARAAQAJAAAIgHIAAAPQgHAFgLAAQgOAAgJgIg");
	this.shape_922.setTransform(181.675,142.975);

	this.shape_923 = new cjs.Shape();
	this.shape_923.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgDADgDQACgCAEAAQAFAAADACQACADAAADQAAAEgCACQgDAEgFAAQgEAAgCgEg");
	this.shape_923.setTransform(174.625,145.45);

	this.shape_924 = new cjs.Shape();
	this.shape_924.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_924.setTransform(169.825,142.975);

	this.shape_925 = new cjs.Shape();
	this.shape_925.graphics.f("#000000").s().p("AABAhIAAgwIgRADIAAgPIAhgFIAABBg");
	this.shape_925.setTransform(164.2,143);

	this.shape_926 = new cjs.Shape();
	this.shape_926.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_926.setTransform(158.875,142.975);

	this.shape_927 = new cjs.Shape();
	this.shape_927.graphics.f("#000000").s().p("AgJAOIAEgbIAQAAIgKAbg");
	this.shape_927.setTransform(154.1,146.475);

	this.shape_928 = new cjs.Shape();
	this.shape_928.graphics.f("#000000").s().p("AADAhIAAgMIghAAIAAgNIAegoIATAAIAAAnIAMAAIAAAOIgMAAIAAAMgAgOAHIARAAIAAgZg");
	this.shape_928.setTransform(149.325,143);

	this.shape_929 = new cjs.Shape();
	this.shape_929.graphics.f("#000000").s().p("AgSAbQgJgHAAgSQAAgQAIgJQAHgKAQAAQAMAAAHADIAAAOQgIgEgJAAQgRAAAAAUQACgEAEgDQAFgCAFAAQALAAAFAFQAHAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgHgHgAgIAEQgCADAAAEQAAAFACADQADADAFAAQAMAAAAgLQAAgKgMAAQgEAAgEADg");
	this.shape_929.setTransform(142.7,142.975);

	this.shape_930 = new cjs.Shape();
	this.shape_930.graphics.f("#000000").s().p("AgWAfIAAgOQAIAEAKAAQAQAAABgUQgCAEgFADQgFACgFAAQgKAAgHgFQgGgFAAgKQAAgKAHgHQAHgGAMAAQANAAAIAHQAIAIAAARQAAAQgHAJQgIAKgQAAQgLAAgIgDgAgMgKQAAAKAMAAQAGAAACgDQAEgCAAgFQAAgFgEgDQgDgDgFAAQgMAAAAALg");
	this.shape_930.setTransform(136.25,142.975);

	this.shape_931 = new cjs.Shape();
	this.shape_931.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgDADgDQACgCAEAAQAFAAADACQACADAAADQAAAEgCACQgDAEgFAAQgEAAgCgEg");
	this.shape_931.setTransform(131.575,145.45);

	this.shape_932 = new cjs.Shape();
	this.shape_932.graphics.f("#000000").s().p("AgPAhIAXg0IggAAIAAgNIAxAAIAAALIgZA2g");
	this.shape_932.setTransform(127.25,143);

	this.shape_933 = new cjs.Shape();
	this.shape_933.graphics.f("#000000").s().p("AABAhIAAgwIgRADIAAgPIAhgFIAABBg");
	this.shape_933.setTransform(122,143);

	this.shape_934 = new cjs.Shape();
	this.shape_934.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgDQACgCAEAAQAFAAADACQACADAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgJQgDgDAAgFQAAgJAJAAQAKAAAAAJQAAAFgCADQgDACgFAAQgEAAgCgCg");
	this.shape_934.setTransform(115.875,143.7);

	this.shape_935 = new cjs.Shape();
	this.shape_935.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQAAgHAFgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAWAAABASIAAAiIgPAAIAAgJQgEAKgMAAQgHAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgFIAAgBIgJAAQgIAAAAAGg");
	this.shape_935.setTransform(111.55,143.7);

	this.shape_936 = new cjs.Shape();
	this.shape_936.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQAEgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_936.setTransform(107.1,143.675);

	this.shape_937 = new cjs.Shape();
	this.shape_937.graphics.f("#000000").s().p("AgTAWQgFgFAAgJIAAghIAQAAIAAAcQAAAKAIAAQAJAAAAgNIAAgZIAQAAIAAAyIgPAAIAAgLQgFAMgMAAQgHAAgFgEg");
	this.shape_937.setTransform(101.75,143.775);

	this.shape_938 = new cjs.Shape();
	this.shape_938.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgMIAOAAIAAAPIAUAAIAAALIgUAAIAAARQAAAKAKAAQAFAAAFgBIAAAMQgHADgHAAQgUgBAAgVg");
	this.shape_938.setTransform(96.2,143.05);

	this.shape_939 = new cjs.Shape();
	this.shape_939.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAOQACgPAOAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_939.setTransform(91.95,143.675);

	this.shape_940 = new cjs.Shape();
	this.shape_940.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAHIgiAAQABAFADADQAEACAGABQALAAAIgFIAAAMQgIAEgNAAQgMAAgIgHgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_940.setTransform(86.875,143.7);

	this.shape_941 = new cjs.Shape();
	this.shape_941.graphics.f("#000000").s().p("AgaAkIAAhGIAOAAIAAAMQAEgNANAAQAKAAAGAHQAGAGAAANQAAANgGAHQgGAHgKAAQgLAAgFgKIAAAcgAgLgJIAAABQAAANALAAQAMAAAAgNQAAgOgMAAQgLAAAAANg");
	this.shape_941.setTransform(80.925,144.6);

	this.shape_942 = new cjs.Shape();
	this.shape_942.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQAAgHAEgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAgBASIAAAiIgPAAIAAgJQgDAKgLAAQgIAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgFIAAgBIgKAAQgHAAAAAGg");
	this.shape_942.setTransform(74.7,143.7);

	this.shape_943 = new cjs.Shape();
	this.shape_943.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAHIgiAAQABAFADADQAEACAGABQALAAAIgFIAAAMQgIAEgNAAQgMAAgIgHgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_943.setTransform(66.625,143.7);

	this.shape_944 = new cjs.Shape();
	this.shape_944.graphics.f("#000000").s().p("AgUAfQgGgIAAgMQAAgNAGgIQAGgGAKAAQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgNQgDAOgNAAQgKgBgGgFgAgLAKQAAAOALAAQAMAAAAgNIAAgBQAAgNgMgBQgLAAAAAOg");
	this.shape_944.setTransform(60.425,142.75);

	this.shape_945 = new cjs.Shape();
	this.shape_945.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIgBAFAFQAFAFAAAKIAAAhg");
	this.shape_945.setTransform(51.775,143.65);

	this.shape_946 = new cjs.Shape();
	this.shape_946.graphics.f("#000000").s().p("AgTAeQgIgHABgNQgBgMAIgIQAHgGAMAAQANAAAHAGQAIAIAAAMQAAANgIAHQgHAHgNAAQgMAAgHgHgAgLAKQAAANALAAQANABgBgOQABgNgNgBQgLAAAAAOgAgHgWIAHgNIASAAIgNANg");
	this.shape_946.setTransform(45.55,142.75);

	this.shape_947 = new cjs.Shape();
	this.shape_947.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgJgcQABgJAIAAQAJAAAAAJQAAAJgJAAQgIAAgBgJg");
	this.shape_947.setTransform(41,142.525);

	this.shape_948 = new cjs.Shape();
	this.shape_948.graphics.f("#000000").s().p("AgUAXIAAgNQAIAGALAAQAJgBAAgEQAAgDgHgBIgHgBQgPgDAAgMQAAgRAVAAQAMAAAIAEIgBANQgIgFgKAAQgHAAAAAFQAAADAGABIAGABQAJABAEADQADACAAAHQAAASgWAAQgNAAgHgEg");
	this.shape_948.setTransform(36.925,143.7);

	this.shape_949 = new cjs.Shape();
	this.shape_949.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQgBgJAJAAQAJAAAAAJQAAAJgJAAQgJAAABgJg");
	this.shape_949.setTransform(32.9,142.525);

	this.shape_950 = new cjs.Shape();
	this.shape_950.graphics.f("#000000").s().p("AAZAbIAAgdQAAgLgIAAQgKAAAAAOIAAAaIgNAAIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAAKQADgLANAAQAMAAADALQAEgLANAAQAIgBADAFQAFAFAAAKIAAAhg");
	this.shape_950.setTransform(26.9,143.65);

	this.shape_951 = new cjs.Shape();
	this.shape_951.graphics.f("#000000").s().p("AgTAUQgIgGAAgOQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHgBAMQABAOgIAGQgHAHgNAAQgMAAgHgHgAgLAAQAAAOALAAQANAAAAgOQAAgNgNAAQgLAAAAANg");
	this.shape_951.setTransform(19.15,143.7);

	this.shape_952 = new cjs.Shape();
	this.shape_952.graphics.f("#000000").s().p("AgNAUQgIgGAAgOQAAgMAIgHQAGgHAMAAQAJAAAHAEIAAANQgGgEgIAAQgNAAAAANQAAAOANAAQAHAAAIgEIAAANQgHAEgKAAQgMAAgGgHg");
	this.shape_952.setTransform(13.5,143.7);

	this.shape_953 = new cjs.Shape();
	this.shape_953.graphics.f("#000000").s().p("AAJAaIAAgcQAAgKgIAAQgJAAAAANIAAAZIgQAAIAAgyIAPAAIAAALQAEgNAMAAQAIAAAFAFQAFAFAAAJIAAAhg");
	this.shape_953.setTransform(242.375,130.75);

	this.shape_954 = new cjs.Shape();
	this.shape_954.graphics.f("#000000").s().p("AgTAUQgIgGAAgOQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHgBAMQABAOgIAGQgHAHgNAAQgMAAgHgHgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_954.setTransform(236.15,130.8);

	this.shape_955 = new cjs.Shape();
	this.shape_955.graphics.f("#000000").s().p("AgNAUQgIgGAAgOQAAgMAIgHQAHgHALAAQAIAAAIADIAAAOQgGgEgIAAQgNAAAAANQAAAOANAAQAHAAAIgEIAAANQgHAEgKAAQgLAAgHgHg");
	this.shape_955.setTransform(230.5,130.8);

	this.shape_956 = new cjs.Shape();
	this.shape_956.graphics.f("#000000").s().p("AgTAUQgIgGAAgOQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHAAAMQAAAOgIAGQgHAHgNAAQgMAAgHgHgAgLABQAAANALAAQANAAAAgOQAAgNgNAAQgLAAAAAOg");
	this.shape_956.setTransform(222.3,130.8);

	this.shape_957 = new cjs.Shape();
	this.shape_957.graphics.f("#000000").s().p("AgUAfQgGgIAAgNQAAgMAGgIQAGgGAKgBQALAAAFALIAAgeIAPAAIAABHIgPAAIAAgLQgDAMgNAAQgKAAgGgFgAgLAKQAAAOALAAQAMAAAAgOIAAgBQAAgNgMABQgLAAAAANg");
	this.shape_957.setTransform(215.875,129.85);

	this.shape_958 = new cjs.Shape();
	this.shape_958.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQgBgHAFgEQAFgEAKAAIAIAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAFIAAgOQAKgEAKAAQAXAAAAATIAAAhIgQAAIAAgJQgDAKgMAAQgHAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_958.setTransform(209.95,130.8);

	this.shape_959 = new cjs.Shape();
	this.shape_959.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAAAAJQAAAJgKAAQgIAAAAgJg");
	this.shape_959.setTransform(205.85,129.625);

	this.shape_960 = new cjs.Shape();
	this.shape_960.graphics.f("#000000").s().p("AgOAUQgGgGgBgOQABgMAGgHQAIgHALAAQAIAAAIADIAAAOQgGgEgIAAQgNAAAAANQAAAOANAAQAIAAAGgEIAAANQgGAEgKAAQgLAAgIgHg");
	this.shape_960.setTransform(201.8,130.8);

	this.shape_961 = new cjs.Shape();
	this.shape_961.graphics.f("#000000").s().p("AAJAaIAAgcQAAgKgIAAQgJAAAAANIAAAZIgQAAIAAgyIAPAAIAAALQAEgNAMAAQAIAAAFAFQAFAFAAAJIAAAhg");
	this.shape_961.setTransform(196.325,130.75);

	this.shape_962 = new cjs.Shape();
	this.shape_962.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQAAgHAEgEQAFgEAKAAIAIAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAFIAAgOQAKgEAKAAQAXAAgBATIAAAhIgPAAIAAgJQgDAKgLAAQgIAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_962.setTransform(190.35,130.8);

	this.shape_963 = new cjs.Shape();
	this.shape_963.graphics.f("#000000").s().p("AAJAaIAAgcQAAgKgIAAQgJAAAAANIAAAZIgQAAIAAgyIAPAAIAAALQAEgNAMAAQAIAAAFAFQAFAFAAAJIAAAhg");
	this.shape_963.setTransform(184.725,130.75);

	this.shape_964 = new cjs.Shape();
	this.shape_964.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgJgcQAAgJAJAAQAJAAAAAJQAAAJgJAAQgJAAAAgJg");
	this.shape_964.setTransform(180.15,129.625);

	this.shape_965 = new cjs.Shape();
	this.shape_965.graphics.f("#000000").s().p("AgNAlIAAgnIgHAAIAAgLIAFAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBIAAgBQAAgIAGgFQAGgGAJAAQAIAAAFACIAAAMQgFgCgFAAQgJAAAAAJIAAACIARAAIAAALIgRAAIAAAng");
	this.shape_965.setTransform(176.525,129.675);

	this.shape_966 = new cjs.Shape();
	this.shape_966.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_966.setTransform(170.175,129.8);

	this.shape_967 = new cjs.Shape();
	this.shape_967.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgEAJAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAFIAAgOQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgJQgEAKgLAAQgIAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_967.setTransform(165.9,130.8);

	this.shape_968 = new cjs.Shape();
	this.shape_968.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAJAAQAGAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_968.setTransform(160.7,130.15);

	this.shape_969 = new cjs.Shape();
	this.shape_969.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAAAAJQAAAJgKAAQgIAAAAgJg");
	this.shape_969.setTransform(156.8,129.625);

	this.shape_970 = new cjs.Shape();
	this.shape_970.graphics.f("#000000").s().p("AgaAkIAAhFIAOAAIAAALQAEgNANAAQAKAAAGAHQAGAGAAAOQAAAMgGAHQgGAHgKAAQgLAAgFgKIAAAcgAgLgIIAAABQAAAMALAAQAMAAAAgNQAAgOgMAAQgLAAAAAOg");
	this.shape_970.setTransform(152.225,131.7);

	this.shape_971 = new cjs.Shape();
	this.shape_971.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgEAJAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAFIAAgOQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgJQgEAKgLAAQgIAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_971.setTransform(146,130.8);

	this.shape_972 = new cjs.Shape();
	this.shape_972.graphics.f("#000000").s().p("AgQAaQgIgJAAgRQAAgPAIgJQAJgJAOAAQAKAAAIAEIAAAPQgIgFgJAAQgIAAgDAFQgGAFAAAJQAAAVARAAQAJAAAIgHIAAAPQgHAFgLAAQgOAAgJgIg");
	this.shape_972.setTransform(140.325,130.075);

	this.shape_973 = new cjs.Shape();
	this.shape_973.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgEADgCQACgCAEgBQAFABADACQACACAAAEQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_973.setTransform(133.275,132.55);

	this.shape_974 = new cjs.Shape();
	this.shape_974.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_974.setTransform(128.475,130.075);

	this.shape_975 = new cjs.Shape();
	this.shape_975.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_975.setTransform(122.425,130.025);

	this.shape_976 = new cjs.Shape();
	this.shape_976.graphics.f("#000000").s().p("AgPAhIAXgzIggAAIAAgOIAxAAIAAALIgYA2g");
	this.shape_976.setTransform(116.65,130.1);

	this.shape_977 = new cjs.Shape();
	this.shape_977.graphics.f("#000000").s().p("AgJAOIAEgbIAQAAIgKAbg");
	this.shape_977.setTransform(112.35,133.575);

	this.shape_978 = new cjs.Shape();
	this.shape_978.graphics.f("#000000").s().p("AADAhIAAgNIghAAIAAgMIAegoIATAAIAAAoIAMAAIAAAMIgMAAIAAANgAgOAIIARAAIAAgag");
	this.shape_978.setTransform(107.575,130.1);

	this.shape_979 = new cjs.Shape();
	this.shape_979.graphics.f("#000000").s().p("AADAhIAAgNIghAAIAAgMIAegoIATAAIAAAoIAMAAIAAAMIgMAAIAAANgAgOAIIARAAIAAgag");
	this.shape_979.setTransform(100.625,130.1);

	this.shape_980 = new cjs.Shape();
	this.shape_980.graphics.f("#000000").s().p("AABAhIAAgwIgRADIAAgPIAhgFIAABBg");
	this.shape_980.setTransform(94.75,130.1);

	this.shape_981 = new cjs.Shape();
	this.shape_981.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAGIgiAAQABAHADACQAEADAGAAQALgBAIgEIAAALQgIAFgNAAQgMAAgIgHgAALgFQAAgKgKAAQgIAAgCAKIAUAAIAAAAg");
	this.shape_981.setTransform(87.275,130.8);

	this.shape_982 = new cjs.Shape();
	this.shape_982.graphics.f("#000000").s().p("AgUAfQgGgIAAgNQAAgMAGgIQAGgGAKgBQALAAAFALIAAgeIAPAAIAABHIgPAAIAAgLQgDAMgNAAQgKAAgGgFgAgLAKQAAAOALAAQAMAAAAgOIAAgBQAAgNgMABQgLAAAAANg");
	this.shape_982.setTransform(81.075,129.85);

	this.shape_983 = new cjs.Shape();
	this.shape_983.graphics.f("#000000").s().p("AgJAOIAEgbIAPAAIgJAbg");
	this.shape_983.setTransform(73.95,133.575);

	this.shape_984 = new cjs.Shape();
	this.shape_984.graphics.f("#000000").s().p("AAZAaIAAgcQAAgKgIAAQgKAAABANIAAAZIgOAAIAAgcQgBgKgHAAQgJAAAAANIAAAZIgQAAIAAgyIAPAAIAAALQAEgNANAAQALAAADANQAEgNAMAAQAIAAAFAFQAEAFAAAJIAAAhg");
	this.shape_984.setTransform(68.15,130.75);

	this.shape_985 = new cjs.Shape();
	this.shape_985.graphics.f("#000000").s().p("AAHAkIgRgXIAAAXIgPAAIAAhHIAPAAIAAAnIAQgTIATAAIgWAYIAXAbg");
	this.shape_985.setTransform(60.75,129.8);

	this.shape_986 = new cjs.Shape();
	this.shape_986.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_986.setTransform(51.575,130.075);

	this.shape_987 = new cjs.Shape();
	this.shape_987.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_987.setTransform(44.975,130.075);

	this.shape_988 = new cjs.Shape();
	this.shape_988.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_988.setTransform(38.375,130.075);

	this.shape_989 = new cjs.Shape();
	this.shape_989.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgEADgCQACgCAEgBQAFABADACQACACAAAEQAAAEgCACQgDADgFAAQgEAAgCgDg");
	this.shape_989.setTransform(33.575,132.55);

	this.shape_990 = new cjs.Shape();
	this.shape_990.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_990.setTransform(28.825,130.075);

	this.shape_991 = new cjs.Shape();
	this.shape_991.graphics.f("#000000").s().p("AgYAeIABgOQAKAEAKAAQAMAAAAgHQAAgHgLAAIgLAAIAAgMIALAAQAJAAAAgGQAAgHgMAAQgKAAgIAEIAAgOQAJgEALAAQAMAAAIAFQAGAFAAAIQAAALgMAEQAOACAAAMQAAAJgHAGQgHAFgNAAQgLAAgLgEg");
	this.shape_991.setTransform(22.7,130.075);

	this.shape_992 = new cjs.Shape();
	this.shape_992.graphics.f("#000000").s().p("AgZAjIAAgNIAHABIAHgBQADgCABgEIgVgzIARAAIAMAkIAMgkIAQAAIgUAzQgEAKgFAFQgHAFgKAAIgIgBg");
	this.shape_992.setTransform(14.075,131.825);

	this.shape_993 = new cjs.Shape();
	this.shape_993.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_993.setTransform(252.225,117.9);

	this.shape_994 = new cjs.Shape();
	this.shape_994.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_994.setTransform(246.825,117.9);

	this.shape_995 = new cjs.Shape();
	this.shape_995.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_995.setTransform(241.375,117.9);

	this.shape_996 = new cjs.Shape();
	this.shape_996.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_996.setTransform(235.975,117.9);

	this.shape_997 = new cjs.Shape();
	this.shape_997.graphics.f("#000000").s().p("AAZAbIAAgdQAAgLgIAAQgKAAAAAOIAAAaIgNAAIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAAKQADgMAOABQALgBADAMQAEgMAMABQAJAAADAEQAFAFAAAJIAAAig");
	this.shape_997.setTransform(228.6,117.85);

	this.shape_998 = new cjs.Shape();
	this.shape_998.graphics.f("#000000").s().p("AgSAbQgJgHAAgSQAAgQAIgJQAHgKAQAAQALAAAIADIAAAOQgIgEgJAAQgRAAAAAUQABgEAFgDQAFgCAFAAQALAAAFAFQAHAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgHgHgAgHAEQgDADAAAEQAAAFADADQACADAFAAQAMAAAAgLQAAgKgLAAQgFAAgDADg");
	this.shape_998.setTransform(218.2,117.175);

	this.shape_999 = new cjs.Shape();
	this.shape_999.graphics.f("#000000").s().p("AgYAeIABgOQAKAEAKAAQAMAAAAgHQAAgHgLAAIgLAAIAAgMIALAAQAJAAAAgGQAAgHgMAAQgKAAgIAEIAAgOQAJgEALAAQAMAAAIAFQAGAFAAAIQAAALgMAEQAOACAAAMQAAAJgHAGQgHAFgNAAQgLAAgLgEg");
	this.shape_999.setTransform(212.15,117.175);

	this.shape_1000 = new cjs.Shape();
	this.shape_1000.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_1000.setTransform(203.725,117.9);

	this.shape_1001 = new cjs.Shape();
	this.shape_1001.graphics.f("#000000").s().p("AgUAeQgGgGAAgOQAAgMAGgHQAGgIAKABQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgMQgDANgNAAQgKAAgGgHgAgLAKQAAAOALAAQAMAAAAgOIAAAAQAAgOgMAAQgLAAAAAOg");
	this.shape_1001.setTransform(197.525,116.95);

	this.shape_1002 = new cjs.Shape();
	this.shape_1002.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIAAAFAEQAFAFAAAJIAAAig");
	this.shape_1002.setTransform(188.875,117.85);

	this.shape_1003 = new cjs.Shape();
	this.shape_1003.graphics.f("#000000").s().p("AgTAeQgHgHAAgNQAAgNAHgGQAIgIALABQANgBAHAIQAHAGABANQgBANgHAHQgHAGgNABQgLgBgIgGgAgLAKQAAAOALAAQAMAAAAgOQAAgOgMAAQgLAAAAAOgAgHgWIAHgNIASAAIgMANg");
	this.shape_1003.setTransform(182.65,116.95);

	this.shape_1004 = new cjs.Shape();
	this.shape_1004.graphics.f("#000000").s().p("AgHAmIAAgzIAOAAIAAAzgAgJgcQAAgJAJAAQAKAAgBAJQABAJgKAAQgJAAAAgJg");
	this.shape_1004.setTransform(178.1,116.725);

	this.shape_1005 = new cjs.Shape();
	this.shape_1005.graphics.f("#000000").s().p("AgNAVQgIgIABgNQgBgMAIgHQAHgHALAAQAJAAAHAEIAAAMQgGgDgIAAQgNAAAAANQAAAOANAAQAHAAAIgEIAAANQgHAEgKAAQgLAAgHgGg");
	this.shape_1005.setTransform(174.05,117.9);

	this.shape_1006 = new cjs.Shape();
	this.shape_1006.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQAAgHAFgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAWAAABATIAAAhIgPAAIAAgKQgEALgMAAQgHAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_1006.setTransform(168.7,117.9);

	this.shape_1007 = new cjs.Shape();
	this.shape_1007.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQAEgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_1007.setTransform(164.25,117.875);

	this.shape_1008 = new cjs.Shape();
	this.shape_1008.graphics.f("#000000").s().p("AgTAWQgFgFAAgJIAAghIAPAAIAAAcQABAKAIAAQAJAAAAgNIAAgZIAQAAIAAAyIgPAAIAAgLQgFAMgMAAQgHAAgFgEg");
	this.shape_1008.setTransform(158.9,117.975);

	this.shape_1009 = new cjs.Shape();
	this.shape_1009.graphics.f("#000000").s().p("AgUAeQgGgGAAgOQAAgMAGgHQAGgIAKABQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgMQgDANgNAAQgKAAgGgHgAgLAKQAAAOALAAQAMAAAAgOIAAAAQAAgOgMAAQgLAAAAAOg");
	this.shape_1009.setTransform(152.575,116.95);

	this.shape_1010 = new cjs.Shape();
	this.shape_1010.graphics.f("#000000").s().p("AgSAXQgEgEgBgIQAAgHAFgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAABATIAAAhIgPAAIAAgKQgEALgMAAQgHAAgEgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_1010.setTransform(144.05,117.9);

	this.shape_1011 = new cjs.Shape();
	this.shape_1011.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIAAAFAEQAFAFAAAJIAAAig");
	this.shape_1011.setTransform(138.425,117.85);

	this.shape_1012 = new cjs.Shape();
	this.shape_1012.graphics.f("#000000").s().p("AgTAWQgFgFABgJIAAghIAOAAIAAAcQAAAKAJAAQAKAAgBgNIAAgZIAPAAIAAAyIgOAAIAAgLQgEAMgMAAQgJAAgEgEg");
	this.shape_1012.setTransform(132.2,117.975);

	this.shape_1013 = new cjs.Shape();
	this.shape_1013.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQAAgHAEgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAgBATIAAAhIgPAAIAAgKQgDALgLAAQgIAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_1013.setTransform(123.75,117.9);

	this.shape_1014 = new cjs.Shape();
	this.shape_1014.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAOQACgPAOAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_1014.setTransform(119.3,117.875);

	this.shape_1015 = new cjs.Shape();
	this.shape_1015.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQgBgHAFgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAAAATIAAAhIgQAAIAAgKQgDALgLAAQgIAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_1015.setTransform(114.2,117.9);

	this.shape_1016 = new cjs.Shape();
	this.shape_1016.graphics.f("#000000").s().p("AgaAkIAAhFIAOAAIAAALQAEgNANAAQAKAAAGAGQAGAIAAAMQAAANgGAIQgGAGgKAAQgLAAgFgLIAAAdgAgLgJIAAACQAAAMALAAQAMAAAAgNQAAgOgMAAQgLAAAAANg");
	this.shape_1016.setTransform(108.475,118.8);

	this.shape_1017 = new cjs.Shape();
	this.shape_1017.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_1017.setTransform(101.125,116.9);

	this.shape_1018 = new cjs.Shape();
	this.shape_1018.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQAAgHAEgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAgBATIAAAhIgOAAIAAgKQgEALgLAAQgIAAgFgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_1018.setTransform(96.85,117.9);

	this.shape_1019 = new cjs.Shape();
	this.shape_1019.graphics.f("#000000").s().p("AgTAWQgEgFAAgJIAAghIAPAAIAAAcQgBAKAJAAQAKAAAAgNIAAgZIAOAAIAAAyIgOAAIAAgLQgEAMgMAAQgJAAgEgEg");
	this.shape_1019.setTransform(91.1,117.975);

	this.shape_1020 = new cjs.Shape();
	this.shape_1020.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_1020.setTransform(85.525,117.9);

	this.shape_1021 = new cjs.Shape();
	this.shape_1021.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIAAAFAEQAFAFAAAJIAAAig");
	this.shape_1021.setTransform(79.975,117.85);

	this.shape_1022 = new cjs.Shape();
	this.shape_1022.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_1022.setTransform(74.025,117.9);

	this.shape_1023 = new cjs.Shape();
	this.shape_1023.graphics.f("#000000").s().p("AAZAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgPAAIAAgdQAAgLgHAAQgKAAAAAOIAAAaIgPAAIAAgzIAPAAIAAAKQADgMANABQAMgBADAMQAEgMANABQAHAAAFAEQAEAFAAAJIAAAig");
	this.shape_1023.setTransform(66.65,117.85);

	this.shape_1024 = new cjs.Shape();
	this.shape_1024.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgKQgEALgLAAQgIAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_1024.setTransform(56.55,117.9);

	this.shape_1025 = new cjs.Shape();
	this.shape_1025.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQAEgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_1025.setTransform(52.1,117.875);

	this.shape_1026 = new cjs.Shape();
	this.shape_1026.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_1026.setTransform(47.025,117.9);

	this.shape_1027 = new cjs.Shape();
	this.shape_1027.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAAAAJQAAAJgKAAQgIAAAAgJg");
	this.shape_1027.setTransform(42.7,116.725);

	this.shape_1028 = new cjs.Shape();
	this.shape_1028.graphics.f("#000000").s().p("AgOAVQgGgIAAgNQAAgMAGgHQAIgHALAAQAJAAAHAEIAAAMQgGgDgIAAQgNAAAAANQAAAOANAAQAIAAAGgEIAAANQgGAEgKAAQgLAAgIgGg");
	this.shape_1028.setTransform(38.65,117.9);

	this.shape_1029 = new cjs.Shape();
	this.shape_1029.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIAAAFAEQAFAFAAAJIAAAig");
	this.shape_1029.setTransform(33.175,117.85);

	this.shape_1030 = new cjs.Shape();
	this.shape_1030.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgDAJAAIAJAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgKQgEALgLAAQgIAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_1030.setTransform(27.2,117.9);

	this.shape_1031 = new cjs.Shape();
	this.shape_1031.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIAAAFAEQAFAFAAAJIAAAig");
	this.shape_1031.setTransform(21.575,117.85);

	this.shape_1032 = new cjs.Shape();
	this.shape_1032.graphics.f("#000000").s().p("AgHAmIAAgzIAOAAIAAAzgAgJgcQAAgJAJAAQAKAAgBAJQABAJgKAAQgJAAAAgJg");
	this.shape_1032.setTransform(17,116.725);

	this.shape_1033 = new cjs.Shape();
	this.shape_1033.graphics.f("#000000").s().p("AgNAlIAAgnIgHAAIAAgLIAFAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAgBAAAAIAAgBQAAgIAGgFQAGgGAJAAQAIAAAFACIAAAMQgFgCgFAAQgJAAAAAJIAAACIARAAIAAALIgRAAIAAAng");
	this.shape_1033.setTransform(13.375,116.775);

	this.shape_1034 = new cjs.Shape();
	this.shape_1034.graphics.f("#000000").s().p("AgSAXQgEgEAAgIQgBgHAFgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAABASIAAAiIgQAAIAAgJQgDAKgMAAQgHAAgEgEgAgJALQAAAGAHAAQADAAAEgDQADgDAAgFIAAgBIgJAAQgIAAAAAGg");
	this.shape_1034.setTransform(240.45,105);

	this.shape_1035 = new cjs.Shape();
	this.shape_1035.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgMIAOAAIAAAPIAUAAIAAALIgUAAIAAARQAAAKAKAAQAFAAAFgBIAAAMQgHADgHAAQgUgBAAgVg");
	this.shape_1035.setTransform(235.25,104.35);

	this.shape_1036 = new cjs.Shape();
	this.shape_1036.graphics.f("#000000").s().p("AgTAUQgIgGABgOQgBgMAIgHQAIgHALAAQANAAAHAHQAIAHAAAMQAAAOgIAGQgHAHgNAAQgLAAgIgHgAgLAAQAAAOALAAQAMAAAAgOQAAgNgMAAQgLAAAAANg");
	this.shape_1036.setTransform(229.7,105);

	this.shape_1037 = new cjs.Shape();
	this.shape_1037.graphics.f("#000000").s().p("AgTAWQgEgFgBgJIAAghIAQAAIAAAcQAAAKAIAAQAKAAAAgNIAAgZIAPAAIAAAyIgPAAIAAgLQgEAMgNAAQgIAAgEgEg");
	this.shape_1037.setTransform(223.5,105.075);

	this.shape_1038 = new cjs.Shape();
	this.shape_1038.graphics.f("#000000").s().p("AgQAaQgIgJAAgRQAAgPAIgJQAJgJAOAAQAKAAAIAEIAAAPQgIgFgJAAQgIAAgDAFQgGAFAAAJQAAAVARAAQAJAAAIgHIAAAPQgHAFgLAAQgOAAgJgIg");
	this.shape_1038.setTransform(217.475,104.275);

	this.shape_1039 = new cjs.Shape();
	this.shape_1039.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgDADgDQACgCAEAAQAFAAADACQACADAAADQAAAEgCACQgDAEgFAAQgEAAgCgEg");
	this.shape_1039.setTransform(210.425,106.75);

	this.shape_1040 = new cjs.Shape();
	this.shape_1040.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_1040.setTransform(205.625,104.275);

	this.shape_1041 = new cjs.Shape();
	this.shape_1041.graphics.f("#000000").s().p("AACAhIAAgwIgSADIAAgPIAhgFIAABBg");
	this.shape_1041.setTransform(200,104.3);

	this.shape_1042 = new cjs.Shape();
	this.shape_1042.graphics.f("#000000").s().p("AgSAbQgJgHAAgSQAAgQAIgJQAHgKAQAAQALAAAIADIAAAOQgIgEgJAAQgRAAAAAUQABgEAFgDQAFgCAFAAQALAAAFAFQAHAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgHgHgAgHAEQgDADAAAEQAAAFADADQACADAFAAQAMAAAAgLQAAgKgLAAQgFAAgDADg");
	this.shape_1042.setTransform(194.8,104.275);

	this.shape_1043 = new cjs.Shape();
	this.shape_1043.graphics.f("#000000").s().p("AgJAOIAEgbIAQAAIgKAbg");
	this.shape_1043.setTransform(190.1,107.775);

	this.shape_1044 = new cjs.Shape();
	this.shape_1044.graphics.f("#000000").s().p("AgUAdQgIgFAAgKQAAgLAPgEQgNgDAAgLQAAgJAIgFQAHgEALAAQANAAAGAEQAIAFAAAJQAAALgNADQAIABADAFQAEAEAAAFQAAAKgIAFQgIAFgNAAQgNAAgHgFgAgLAOQAAAIALAAQANAAAAgIQAAgJgNAAQgLAAAAAJgAgKgOQAAAIAKAAQALAAAAgIQAAgHgLAAQgKAAAAAHg");
	this.shape_1044.setTransform(185.55,104.3);

	this.shape_1045 = new cjs.Shape();
	this.shape_1045.graphics.f("#000000").s().p("AACAhIAAgwIgSADIAAgPIAhgFIAABBg");
	this.shape_1045.setTransform(179.9,104.3);

	this.shape_1046 = new cjs.Shape();
	this.shape_1046.graphics.f("#000000").s().p("AgTAbQgIgHAAgSQAAgQAHgJQAIgKAQAAQALAAAIADIAAAOQgIgEgKAAQgQAAgBAUQACgEAFgDQAFgCAFAAQAKAAAHAFQAGAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgIgHgAgHAEQgEADAAAEQAAAFAEADQADADAEAAQANAAgBgLQABgKgMAAQgGAAgCADg");
	this.shape_1046.setTransform(174.7,104.275);

	this.shape_1047 = new cjs.Shape();
	this.shape_1047.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgDADgDQACgCAEAAQAFAAADACQACADAAADQAAAEgCACQgDAEgFAAQgEAAgCgEg");
	this.shape_1047.setTransform(169.975,106.75);

	this.shape_1048 = new cjs.Shape();
	this.shape_1048.graphics.f("#000000").s().p("AgYAdIABgOQALAEAKAAQALABAAgKQAAgJgPAAQgJAAgHACIAAgkIAsAAIAAAOIgeAAIAAALIAIgBQAZAAAAATQAAAMgHAGQgHAFgMABQgMAAgLgFg");
	this.shape_1048.setTransform(165.625,104.35);

	this.shape_1049 = new cjs.Shape();
	this.shape_1049.graphics.f("#000000").s().p("AgGAYQgDgCAAgFQAAgEADgDQACgCAEAAQAFAAADACQACADAAAEQAAAFgCACQgDADgFAAQgEAAgCgDgAgGgJQgDgDAAgFQAAgJAJAAQAKAAAAAJQAAAFgCADQgDACgFAAQgEAAgCgCg");
	this.shape_1049.setTransform(158.475,105);

	this.shape_1050 = new cjs.Shape();
	this.shape_1050.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQgBgHAFgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAAAASIAAAiIgQAAIAAgJQgDAKgMAAQgHAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgFIAAgBIgJAAQgIAAAAAGg");
	this.shape_1050.setTransform(154.15,105);

	this.shape_1051 = new cjs.Shape();
	this.shape_1051.graphics.f("#000000").s().p("AgUAfQgGgIAAgMQAAgNAGgIQAGgGAKAAQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgNQgDAOgNAAQgKgBgGgFgAgLAKQAAAOALAAQAMAAAAgNIAAgBQAAgNgMgBQgLAAAAAOg");
	this.shape_1051.setTransform(148.175,104.05);

	this.shape_1052 = new cjs.Shape();
	this.shape_1052.graphics.f("#000000").s().p("AgSAXQgEgEgBgIQAAgHAFgEQAFgDAKAAIAIAAQABAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAABASIAAAiIgPAAIAAgJQgEAKgMAAQgHAAgEgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgFIAAgBIgJAAQgIAAAAAGg");
	this.shape_1052.setTransform(142.25,105);

	this.shape_1053 = new cjs.Shape();
	this.shape_1053.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQAEgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_1053.setTransform(137.8,104.975);

	this.shape_1054 = new cjs.Shape();
	this.shape_1054.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgMIAOAAIAAAPIAUAAIAAALIgUAAIAAARQAAAKAKAAQAFAAAFgBIAAAMQgHADgHAAQgUgBAAgVg");
	this.shape_1054.setTransform(133,104.35);

	this.shape_1055 = new cjs.Shape();
	this.shape_1055.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIgBAFAFQAFAFAAAKIAAAhg");
	this.shape_1055.setTransform(127.575,104.95);

	this.shape_1056 = new cjs.Shape();
	this.shape_1056.graphics.f("#000000").s().p("AgWAhIAAhBIAtAAIAAANIgdAAIAAANIAZAAIAAAMIgZAAIAAAOIAdAAIAAANg");
	this.shape_1056.setTransform(121.625,104.3);

	this.shape_1057 = new cjs.Shape();
	this.shape_1057.graphics.f("#000000").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_1057.setTransform(114.85,107);

	this.shape_1058 = new cjs.Shape();
	this.shape_1058.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIABgBIAAgCQAAgFgDgDQgEgBgFAAIgKABIgHADIAAgKIAJgCIAJgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgIAAgEgFgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_1058.setTransform(110.8,105.05);

	this.shape_1059 = new cjs.Shape();
	this.shape_1059.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1059.setTransform(106.575,105);

	this.shape_1060 = new cjs.Shape();
	this.shape_1060.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_1060.setTransform(101.525,105.05);

	this.shape_1061 = new cjs.Shape();
	this.shape_1061.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_1061.setTransform(97.375,103.9);

	this.shape_1062 = new cjs.Shape();
	this.shape_1062.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_1062.setTransform(93.475,105.05);

	this.shape_1063 = new cjs.Shape();
	this.shape_1063.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgDAEAAAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAEgCQAFgEAGAAQAFAAAEACQAFACACAEQACAFAAAGIAAAgg");
	this.shape_1063.setTransform(88.05,105);

	this.shape_1064 = new cjs.Shape();
	this.shape_1064.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIABgBIAAgCQAAgFgDgDQgEgBgFAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHAAgFgFgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_1064.setTransform(82.1,105.05);

	this.shape_1065 = new cjs.Shape();
	this.shape_1065.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQACgIAFgCQAGgEAFAAQAFAAAFACQAEACACAEQACAFABAGIAAAgg");
	this.shape_1065.setTransform(76.65,105);

	this.shape_1066 = new cjs.Shape();
	this.shape_1066.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_1066.setTransform(72.175,103.9);

	this.shape_1067 = new cjs.Shape();
	this.shape_1067.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIABgBIABgBIAAgCQAAgGACgEQACgFAFgCQADgCAHAAQAHAAAGACIAAAJIgGgBIgFgBQgGAAgDACQgCADAAAGIAAADIAUAAIAAAIIgUAAIAAAqg");
	this.shape_1067.setTransform(68.85,103.9);

	this.shape_1068 = new cjs.Shape();
	this.shape_1068.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQADgIAFgCQAFgEAFAAQAGAAAEACQAEACACAEQACAFABAGIAAAgg");
	this.shape_1068.setTransform(61.1,105);

	this.shape_1069 = new cjs.Shape();
	this.shape_1069.graphics.f("#000000").s().p("AgSAeQgIgGAAgOQAAgMAIgHQAGgGAMAAQAMAAAHAGQAIAHAAAMQAAANgIAHQgHAHgMAAQgMAAgGgHgAgLgCQgEAEAAAIQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgIgEgEQgEgFgIABQgHgBgEAFgAgGgWIAIgNIANAAIgMANg");
	this.shape_1069.setTransform(54.95,104.05);

	this.shape_1070 = new cjs.Shape();
	this.shape_1070.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_1070.setTransform(50.575,103.9);

	this.shape_1071 = new cjs.Shape();
	this.shape_1071.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_1071.setTransform(46.675,105.05);

	this.shape_1072 = new cjs.Shape();
	this.shape_1072.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgCgDQgEgBgFAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgHAAgFgFgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAADgBQAEgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_1072.setTransform(41.35,105.05);

	this.shape_1073 = new cjs.Shape();
	this.shape_1073.graphics.f("#000000").s().p("AgIAhQgFgDgCgGIAAAMIgJAAIAAhHIAKAAIAAAfQACgFAEgEQAFgCAGAAQAHgBAFADQAEADAEAGQACAEAAAKQAAAIgCAGQgEAHgEACQgFAEgHAAQgGAAgFgEgAgHgFQgDACgCADQgCADAAAGIAAACQAAAIADAEQAEAFAHAAQAGAAAFgFQAEgEAAgJQAAgJgEgEQgEgDgHAAQgDAAgEABg");
	this.shape_1073.setTransform(35.9,104.05);

	this.shape_1074 = new cjs.Shape();
	this.shape_1074.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAHAGQAIAHAAAMQAAANgIAHQgHAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_1074.setTransform(29.55,105.05);

	this.shape_1075 = new cjs.Shape();
	this.shape_1075.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1075.setTransform(24.825,105);

	this.shape_1076 = new cjs.Shape();
	this.shape_1076.graphics.f("#000000").s().p("AgYAkIAAhFIAJAAIAAALQADgGAEgEQAFgCAGAAQAHgBAEADQAFADAEAGQACAFAAAKQAAAIgCAFQgEAHgFACQgEAEgHAAQgFAAgGgDQgEgDgCgGIAAAegAgHgYQgDACgCAEQgCADAAAGIAAACQAAAHADAEQAEAFAHAAQAGAAAFgFQAEgEAAgIQAAgJgEgFQgEgDgHAAQgDAAgEABg");
	this.shape_1076.setTransform(19.7,105.95);

	this.shape_1077 = new cjs.Shape();
	this.shape_1077.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgCgDQgEgBgFAAIgJABIgJADIAAgKIAKgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIAAgEgFgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgBQADgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_1077.setTransform(13.55,105.05);

	this.shape_1078 = new cjs.Shape();
	this.shape_1078.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIAAgCIAAgDQAAgEgCgCQgDgCgGgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgLQgCAGgFADQgEADgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1078.setTransform(261.3,92.15);

	this.shape_1079 = new cjs.Shape();
	this.shape_1079.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgHAMAAQAMAAAIAHQAHAHAAAMQAAANgHAHQgIAHgMgBQgMABgGgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_1079.setTransform(253.2,92.15);

	this.shape_1080 = new cjs.Shape();
	this.shape_1080.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_1080.setTransform(247.625,91.45);

	this.shape_1081 = new cjs.Shape();
	this.shape_1081.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1081.setTransform(242.425,92.15);

	this.shape_1082 = new cjs.Shape();
	this.shape_1082.graphics.f("#000000").s().p("AgNAuIAAgJIAHACQAFgBABgCQACgCAAgGIAAgzIALAAIAAA0QAAAJgFAEQgEAFgIAAQgFAAgEgBgAACgiQgBgDAAgDQAAgDABgBQACgCAEAAQADAAACACQABABAAADQAAADgBADQgCABgDAAQgEAAgCgBg");
	this.shape_1082.setTransform(237.525,92);

	this.shape_1083 = new cjs.Shape();
	this.shape_1083.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgCgFAAgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgNQgDAIgEADQgFADgGAAQgGAAgEgCg");
	this.shape_1083.setTransform(233.8,92.2);

	this.shape_1084 = new cjs.Shape();
	this.shape_1084.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_1084.setTransform(227.875,91.375);

	this.shape_1085 = new cjs.Shape();
	this.shape_1085.graphics.f("#000000").s().p("AgFAFQgBgCAAgDQAAgDABgBQACgCADAAQADAAACACQACABABADQgBADgCACQgCACgDAAQgDAAgCgCg");
	this.shape_1085.setTransform(221.15,94.1);

	this.shape_1086 = new cjs.Shape();
	this.shape_1086.graphics.f("#000000").s().p("AAUAhIgFgQIgeAAIgFAQIgLAAIAZhBIAOAAIAYBBgAALAHIgLggIgLAgIAWAAg");
	this.shape_1086.setTransform(216.5,91.4);

	this.shape_1087 = new cjs.Shape();
	this.shape_1087.graphics.f("#000000").s().p("AgFAFQgCgCAAgDQAAgDACgBQACgCADAAQADAAADACQACABAAADQAAADgCACQgDACgDAAQgDAAgCgCg");
	this.shape_1087.setTransform(211.9,94.1);

	this.shape_1088 = new cjs.Shape();
	this.shape_1088.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABQAGACAEACIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_1088.setTransform(207.675,91.375);

	this.shape_1089 = new cjs.Shape();
	this.shape_1089.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_1089.setTransform(200.85,94.95);

	this.shape_1090 = new cjs.Shape();
	this.shape_1090.graphics.f("#000000").s().p("AgKAfQgGgEgEgIQgEgIAAgLQAAgKAEgIQAEgHAGgEQAIgEAIAAQAGAAAEABQAEABAEADIAAAKIgIgEQgEgCgFAAQgHAAgDADQgEADgEAFQgCAGAAAHQAAANAGAGQAFAGAJAAIAHgBIAGgCIAFgDIAAAKQgEADgFABQgEABgGAAQgIAAgIgDg");
	this.shape_1090.setTransform(196.75,91.375);

	this.shape_1091 = new cjs.Shape();
	this.shape_1091.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAAWIAfAAIAAAIIgfAAIAAAag");
	this.shape_1091.setTransform(191,91.4);

	this.shape_1092 = new cjs.Shape();
	this.shape_1092.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAASIAeAAIAAAIIgeAAIAAAVIAhAAIAAAJg");
	this.shape_1092.setTransform(185.05,91.4);

	this.shape_1093 = new cjs.Shape();
	this.shape_1093.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgLQgCAGgEADQgFADgGAAQgHAAgFgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_1093.setTransform(176.65,92.15);

	this.shape_1094 = new cjs.Shape();
	this.shape_1094.graphics.f("#000000").s().p("AANAkIAAgeQAAgMgMAAQgDAAgDACQgEACgCADQgCAEAAAGIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQACAEAAAFIAAAhgAgQgWQAAgEACgEQABgCACgBIAFgCIADABIADACIACABIABABIABAAQABAAAAAAQABAAAAAAQAAAAAAAAQABgBAAAAIABgEIAGAAQAAAHgCADQgDACgEAAIgDAAIgDgCIgDgCIgBgBQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAABIgBAEg");
	this.shape_1094.setTransform(171.2,91.1);

	this.shape_1095 = new cjs.Shape();
	this.shape_1095.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgCQgEgCgFgBIgKACIgHADIAAgJIAJgDIAJgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgLQgCAGgFADQgEADgGAAQgIAAgEgDgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgCQAEgCACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_1095.setTransform(165.25,92.15);

	this.shape_1096 = new cjs.Shape();
	this.shape_1096.graphics.f("#000000").s().p("AgZAjIAAhEIAKAAIAAAMQACgHAFgDQAFgDAFgBQAHAAAGADQAEADAEAGQADAGAAAIQAAAJgDAFQgEAGgEAEQgGACgGAAQgGAAgFgCQgEgDgDgGIAAAdgAgHgXQgEABgBAEQgDAEAAAEIAAACQAAAIAFAFQADADAHAAQAGAAAFgDQAEgFAAgIQAAgKgEgDQgEgEgHgBQgEABgDACg");
	this.shape_1096.setTransform(159.8,93.05);

	this.shape_1097 = new cjs.Shape();
	this.shape_1097.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1097.setTransform(153.925,92.15);

	this.shape_1098 = new cjs.Shape();
	this.shape_1098.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAASIAeAAIAAAIIgeAAIAAAVIAhAAIAAAJg");
	this.shape_1098.setTransform(148.5,91.4);

	this.shape_1099 = new cjs.Shape();
	this.shape_1099.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1099.setTransform(140.375,92.15);

	this.shape_1100 = new cjs.Shape();
	this.shape_1100.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1100.setTransform(135.025,92.15);

	this.shape_1101 = new cjs.Shape();
	this.shape_1101.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_1101.setTransform(129.625,92.15);

	this.shape_1102 = new cjs.Shape();
	this.shape_1102.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1102.setTransform(125.775,91);

	this.shape_1103 = new cjs.Shape();
	this.shape_1103.graphics.f("#000000").s().p("AgFAZIgVgxIAMAAIAOApIAQgpIALAAIgWAxg");
	this.shape_1103.setTransform(121.6,92.15);

	this.shape_1104 = new cjs.Shape();
	this.shape_1104.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1104.setTransform(117.075,92.1);

	this.shape_1105 = new cjs.Shape();
	this.shape_1105.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1105.setTransform(112.025,92.15);

	this.shape_1106 = new cjs.Shape();
	this.shape_1106.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABIAKAEIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_1106.setTransform(106.225,91.375);

	this.shape_1107 = new cjs.Shape();
	this.shape_1107.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1107.setTransform(99.45,91.1);

	this.shape_1108 = new cjs.Shape();
	this.shape_1108.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgLQgCAGgEADQgFADgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAADgCQAEgCACgDQABgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1108.setTransform(95.35,92.15);

	this.shape_1109 = new cjs.Shape();
	this.shape_1109.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1109.setTransform(91.475,91);

	this.shape_1110 = new cjs.Shape();
	this.shape_1110.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_1110.setTransform(87.575,92.15);

	this.shape_1111 = new cjs.Shape();
	this.shape_1111.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_1111.setTransform(82.15,92.1);

	this.shape_1112 = new cjs.Shape();
	this.shape_1112.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgCQgCgCgGgBIgJACIgJADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgLQgCAGgEADQgFADgGAAQgIAAgEgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1112.setTransform(76.2,92.15);

	this.shape_1113 = new cjs.Shape();
	this.shape_1113.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgCAEAAAFIAAAZIgJAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAFAAAEACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_1113.setTransform(70.75,92.1);

	this.shape_1114 = new cjs.Shape();
	this.shape_1114.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1114.setTransform(66.275,91);

	this.shape_1115 = new cjs.Shape();
	this.shape_1115.graphics.f("#000000").s().p("AgVAhIAAhBIArAAIAAAJIghAAIAAAWIAfAAIAAAIIgfAAIAAAag");
	this.shape_1115.setTransform(62.2,91.4);

	this.shape_1116 = new cjs.Shape();
	this.shape_1116.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1116.setTransform(54.075,92.15);

	this.shape_1117 = new cjs.Shape();
	this.shape_1117.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1117.setTransform(50.225,91);

	this.shape_1118 = new cjs.Shape();
	this.shape_1118.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_1118.setTransform(46.375,91.45);

	this.shape_1119 = new cjs.Shape();
	this.shape_1119.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAFgEQAGgDAFAAQAFAAAFACQAEACACAFQACAEABAGIAAAgg");
	this.shape_1119.setTransform(41.1,92.1);

	this.shape_1120 = new cjs.Shape();
	this.shape_1120.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgCQgDgCgFgBIgJACIgJADIAAgJIAKgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgLQgCAGgEADQgFADgGAAQgIAAgEgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1120.setTransform(35.15,92.15);

	this.shape_1121 = new cjs.Shape();
	this.shape_1121.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1121.setTransform(31.35,91.1);

	this.shape_1122 = new cjs.Shape();
	this.shape_1122.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1122.setTransform(28.8,91.1);

	this.shape_1123 = new cjs.Shape();
	this.shape_1123.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1123.setTransform(24.675,92.15);

	this.shape_1124 = new cjs.Shape();
	this.shape_1124.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_1124.setTransform(19.325,91.45);

	this.shape_1125 = new cjs.Shape();
	this.shape_1125.graphics.f("#000000").s().p("AgNAhQgGgCgEgCIAAgKIAKAEQAGACAGAAQAHAAAEgDQAFgCAAgGQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBgBAAAAIgHgCIgKgCQgRgCAAgOQAAgGADgFQADgEAGgDQAFgCAIAAQAHAAAFABIAKAEIgBAKIgKgEQgFgCgGAAQgHAAgEADQgDADAAAFQAAAEACABQADACAFABIAKACQAJACAFADQAEAEAAAIQAAAHgDAEQgDAFgGACQgGACgHAAQgHAAgGgBg");
	this.shape_1125.setTransform(13.975,91.375);

	this.shape_1126 = new cjs.Shape();
	this.shape_1126.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_1126.setTransform(147.025,79.25);

	this.shape_1127 = new cjs.Shape();
	this.shape_1127.graphics.f("#000000").s().p("AgOAiQgEgDgDgFQgEgHAAgJQAAgJAEgFQADgFAEgEQAGgDAGAAQAGABAEACQAFADADAGIAAgfIAKAAIAABHIgKAAIAAgMQgCAGgFAEQgFADgGAAQgGgBgGgCgAgKgCQgEADAAAJQAAAJAEAFQAEAEAGAAQAEAAAEgCQADgCADgEQACgEAAgEIAAgCQAAgJgFgDQgEgFgHAAQgGAAgEAFg");
	this.shape_1127.setTransform(140.9,78.25);

	this.shape_1128 = new cjs.Shape();
	this.shape_1128.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFgBgDACQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_1128.setTransform(132.875,79.25);

	this.shape_1129 = new cjs.Shape();
	this.shape_1129.graphics.f("#000000").s().p("AgQAeQgHgHAAgNQAAgJADgFQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAALIAAAFIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPAFQAAgNgOAAQgFAAgEADQgEAEgBAGIAcAAIAAAAgAgEgXIAIgMIAMAAIgLAMg");
	this.shape_1129.setTransform(127.525,78.25);

	this.shape_1130 = new cjs.Shape();
	this.shape_1130.graphics.f("#000000").s().p("AgFAaIgVgzIAMAAIAOArIAQgrIALAAIgVAzg");
	this.shape_1130.setTransform(121.85,79.25);

	this.shape_1131 = new cjs.Shape();
	this.shape_1131.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIABgCIAAgDQAAgEgDgDQgEgCgFAAIgKABIgHAEIAAgJIAJgEIAJgBQALABAEAEQAGAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGAAQgIgBgEgDgAgJAFQgCACgBAEQABADACADQACACAFAAQADAAADgBQAEgDACgDQACgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_1131.setTransform(116.2,79.25);

	this.shape_1132 = new cjs.Shape();
	this.shape_1132.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAFAAAHIAAAYg");
	this.shape_1132.setTransform(111.975,79.2);

	this.shape_1133 = new cjs.Shape();
	this.shape_1133.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgIIAHAAIACAAIAAgCIAAgMIALAAIAAAOIAVAAIAAAIIgVAAIAAAVQAAAGACAEQACADAGAAQAGAAAFgCIAAAJIgGACIgHABQgIgBgFgFg");
	this.shape_1133.setTransform(107.225,78.55);

	this.shape_1134 = new cjs.Shape();
	this.shape_1134.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgEAEQgFADgGAAQgIgBgEgDgAgJAFQgCACAAAEQAAADACADQADACAEAAQADAAAEgBQADgDABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1134.setTransform(99.5,79.25);

	this.shape_1135 = new cjs.Shape();
	this.shape_1135.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFgBgDACQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_1135.setTransform(91.875,79.25);

	this.shape_1136 = new cjs.Shape();
	this.shape_1136.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_1136.setTransform(86.525,79.25);

	this.shape_1137 = new cjs.Shape();
	this.shape_1137.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFgBgDACQgDACAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_1137.setTransform(81.175,79.25);

	this.shape_1138 = new cjs.Shape();
	this.shape_1138.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_1138.setTransform(75.825,79.25);

	this.shape_1139 = new cjs.Shape();
	this.shape_1139.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_1139.setTransform(68.525,79.2);

	this.shape_1140 = new cjs.Shape();
	this.shape_1140.graphics.f("#000000").s().p("AgSAbQgEgEgCgGQgCgGAAgJQAAgQAIgKQAHgJAPAAIAKABIAIADIAAAJIgIgDIgJgBQgJAAgGAHQgFAGAAAMQACgEAFgDQAGgDAFAAQAHAAAGADQAFACADAEQADAFAAAHQAAAGgDAFQgDAFgGADQgGADgIAAQgMAAgHgHgAgHAAQgDABgCADQgCADAAAEQAAAEACAEQACADADACQAEABADAAQAIAAAEgDQAEgEAAgGQAAgHgEgDQgEgDgIAAQgDAAgEABg");
	this.shape_1140.setTransform(58.175,78.475);

	this.shape_1141 = new cjs.Shape();
	this.shape_1141.graphics.f("#000000").s().p("AgMAhQgGgBgFgDIABgKIAKAEIAKACQAEAAAEgCQAEgBACgCQABgDAAgDQAAgEgDgDQgFgDgGAAIgKAAIAAgIIAKAAQAFAAADgCQAFgDAAgFQAAgEgFgDQgEgDgGAAQgFAAgFACQgGABgDACIAAgKQAIgEAMAAQAHAAAGACQAFACAEAEQADAEAAAGQgBAFgDAEQgEAEgGACQAHABAFAEQADAEAAAGQAAAGgDAEQgDAEgGADQgGACgHAAQgGAAgFgBg");
	this.shape_1141.setTransform(52.2,78.475);

	this.shape_1142 = new cjs.Shape();
	this.shape_1142.graphics.f("#000000").s().p("AgSAUQgIgHAAgNQAAgMAIgHQAGgGAMgBQAMABAHAGQAIAHAAAMQAAANgIAHQgHAGgMABQgMgBgGgGgAgLgMQgEAEAAAIQAAAJAEAFQADADAIABQAIgBAEgDQAEgFAAgJQAAgIgEgEQgEgEgIgBQgHABgEAEg");
	this.shape_1142.setTransform(43.7,79.25);

	this.shape_1143 = new cjs.Shape();
	this.shape_1143.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_1143.setTransform(36.175,79.2);

	this.shape_1144 = new cjs.Shape();
	this.shape_1144.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgCAAgCQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_1144.setTransform(30.175,78.1);

	this.shape_1145 = new cjs.Shape();
	this.shape_1145.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgDAEAAAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgDQAFgEAGAAQAFAAAEACQAFACACAFQACAEAAAGIAAAgg");
	this.shape_1145.setTransform(25.95,79.2);

	this.shape_1146 = new cjs.Shape();
	this.shape_1146.graphics.f("#000000").s().p("AgIAkIAAgyIAJAAIAAAygAgKgWIAJgNIAMAAIgLANg");
	this.shape_1146.setTransform(21.875,78.2);

	this.shape_1147 = new cjs.Shape();
	this.shape_1147.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADAEABAGQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_1147.setTransform(15.675,79.2);

	this.shape_1148 = new cjs.Shape();
	this.shape_1148.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEAAAFIAAAZIgLAAIAAgyIAKAAIAAANQACgIAFgCQAGgEAFAAQAGAAAEACQAEACACAEQADAFAAAGIAAAgg");
	this.shape_1148.setTransform(257.45,66.3);

	this.shape_1149 = new cjs.Shape();
	this.shape_1149.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1149.setTransform(251.475,66.35);

	this.shape_1150 = new cjs.Shape();
	this.shape_1150.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_1150.setTransform(247.325,65.2);

	this.shape_1151 = new cjs.Shape();
	this.shape_1151.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_1151.setTransform(243.425,66.35);

	this.shape_1152 = new cjs.Shape();
	this.shape_1152.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAEgCQAGgEAFAAQAFAAAFACQAEACACAEQADAFAAAGIAAAgg");
	this.shape_1152.setTransform(238,66.3);

	this.shape_1153 = new cjs.Shape();
	this.shape_1153.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIAAgBIAAgCQAAgFgCgCQgDgCgGAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHAAgFgFgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgBQAEgCACgEQABgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_1153.setTransform(232.05,66.35);

	this.shape_1154 = new cjs.Shape();
	this.shape_1154.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQACgIAGgCQAFgEAFAAQAGAAAEACQAEACACAEQACAFABAGIAAAgg");
	this.shape_1154.setTransform(226.6,66.3);

	this.shape_1155 = new cjs.Shape();
	this.shape_1155.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_1155.setTransform(222.125,65.2);

	this.shape_1156 = new cjs.Shape();
	this.shape_1156.graphics.f("#000000").s().p("AgLAlIAAgqIgJAAIAAgIIAHAAIABgBIABgBIAAgCQAAgGACgEQACgFAFgCQAEgCAGAAQAIAAAFACIAAAJIgGgBIgFgBQgGAAgDACQgCADAAAGIAAADIAUAAIAAAIIgUAAIAAAqg");
	this.shape_1156.setTransform(218.8,65.2);

	this.shape_1157 = new cjs.Shape();
	this.shape_1157.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1157.setTransform(211.125,66.35);

	this.shape_1158 = new cjs.Shape();
	this.shape_1158.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgDgEAAgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEAAgFIAAgZIALAAIAAAyIgLAAIAAgMQgCAGgEAEQgGADgFAAQgGAAgEgCg");
	this.shape_1158.setTransform(205.15,66.4);

	this.shape_1159 = new cjs.Shape();
	this.shape_1159.graphics.f("#000000").s().p("AAPAkIAAgfQgCAHgFACQgEAEgGAAQgHAAgEgDQgFgDgDgGQgDgGAAgHQAAgJADgHQADgFAFgEQAEgCAHAAQAFAAAFACQAGADABAHIAAgLIAKAAIAABFgAgKgWQgEAFAAAKQAAAHAEAEQAEAFAGAAQAFAAADgCQADgCADgEQABgCAAgFIAAgCQAAgJgDgFQgFgDgHAAQgGAAgEADg");
	this.shape_1159.setTransform(198.9,67.25);

	this.shape_1160 = new cjs.Shape();
	this.shape_1160.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_1160.setTransform(190.875,66.35);

	this.shape_1161 = new cjs.Shape();
	this.shape_1161.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1161.setTransform(185.525,66.35);

	this.shape_1162 = new cjs.Shape();
	this.shape_1162.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAEAAAIIAAAYg");
	this.shape_1162.setTransform(181.025,66.3);

	this.shape_1163 = new cjs.Shape();
	this.shape_1163.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIAAgBIAAgCQAAgFgCgCQgEgCgFAAIgJABIgIADIAAgKIAJgCIAJgBQAKgBAGAFQAFAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgIAAgEgFgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgBQADgCABgEQACgDAAgFIAAgBIgMAAQgFAAgDACg");
	this.shape_1163.setTransform(176,66.35);

	this.shape_1164 = new cjs.Shape();
	this.shape_1164.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1164.setTransform(172.2,65.3);

	this.shape_1165 = new cjs.Shape();
	this.shape_1165.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgDgEABgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgMQgDAGgFAEQgEADgGAAQgFAAgFgCg");
	this.shape_1165.setTransform(167.75,66.4);

	this.shape_1166 = new cjs.Shape();
	this.shape_1166.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_1166.setTransform(162.225,66.35);

	this.shape_1167 = new cjs.Shape();
	this.shape_1167.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_1167.setTransform(158.375,65.2);

	this.shape_1168 = new cjs.Shape();
	this.shape_1168.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_1168.setTransform(154.525,65.65);

	this.shape_1169 = new cjs.Shape();
	this.shape_1169.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAEAAAIIAAAYg");
	this.shape_1169.setTransform(150.475,66.3);

	this.shape_1170 = new cjs.Shape();
	this.shape_1170.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAFgDAIAAIAMAAIACgBIABgBIAAgCQAAgFgDgCQgEgCgFAAIgKABIgHADIAAgKIAJgCIAJgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgIAAgEgFgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_1170.setTransform(145.45,66.35);

	this.shape_1171 = new cjs.Shape();
	this.shape_1171.graphics.f("#000000").s().p("AgZAkIAAhFIAKAAIAAALQACgGAFgEQAFgCAFAAQAHgBAGADQAEADAEAGQADAFAAAKQAAAIgDAFQgEAHgEACQgGAEgGAAQgGAAgFgDQgEgDgDgGIAAAegAgHgXQgEABgBAEQgDADAAAGIAAACQAAAHAFAEQADAFAHAAQAGAAAFgFQAEgEAAgIQAAgJgEgFQgEgDgHAAQgEAAgDACg");
	this.shape_1171.setTransform(140,67.25);

	this.shape_1172 = new cjs.Shape();
	this.shape_1172.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_1172.setTransform(131.575,66.35);

	this.shape_1173 = new cjs.Shape();
	this.shape_1173.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1173.setTransform(126.225,66.35);

	this.shape_1174 = new cjs.Shape();
	this.shape_1174.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_1174.setTransform(120.875,65.65);

	this.shape_1175 = new cjs.Shape();
	this.shape_1175.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAANQADgIAEgCQAGgEAFAAQAFAAAFACQAEACACAEQADAFAAAGIAAAgg");
	this.shape_1175.setTransform(115.6,66.3);

	this.shape_1176 = new cjs.Shape();
	this.shape_1176.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1176.setTransform(109.625,66.35);

	this.shape_1177 = new cjs.Shape();
	this.shape_1177.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgZQgCgBAAgDQAAgEACgBQACgCACAAQADAAACACQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_1177.setTransform(105.475,65.2);

	this.shape_1178 = new cjs.Shape();
	this.shape_1178.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1178.setTransform(102.9,65.3);

	this.shape_1179 = new cjs.Shape();
	this.shape_1179.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_1179.setTransform(99.025,66.35);

	this.shape_1180 = new cjs.Shape();
	this.shape_1180.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAKAAIALAAIACgBIABgBIAAgCQgBgFgDgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgEACQgFAEgGAAQgHAAgFgFgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgBQADgCABgEQACgDABgFIAAgBIgNAAQgFAAgDACg");
	this.shape_1180.setTransform(91.15,66.35);

	this.shape_1181 = new cjs.Shape();
	this.shape_1181.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAOQACgHAEgEQAFgEAHAAIAAALQgIAAgFAEQgEAEAAAIIAAAYg");
	this.shape_1181.setTransform(86.925,66.3);

	this.shape_1182 = new cjs.Shape();
	this.shape_1182.graphics.f("#000000").s().p("AgRAWQgEgDAAgIQAAgIAFgDQAEgDAJAAIAMAAIACgBIABgBIAAgCQAAgFgEgCQgCgCgGAAIgKABIgIADIAAgKIAJgCIAKgBQALgBAEAFQAGAFAAAIIAAAiIgKAAIAAgMQgCAHgFACQgEAEgGAAQgHAAgFgFgAgJAFQgCACgBAEQABAEACACQACACAFAAQADAAADgBQAEgCACgEQACgDAAgFIAAgBIgNAAQgFAAgDACg");
	this.shape_1182.setTransform(81.9,66.35);

	this.shape_1183 = new cjs.Shape();
	this.shape_1183.graphics.f("#000000").s().p("AgZAkIAAhFIAKAAIAAALQADgGAEgEQAFgCAFAAQAIgBAFADQAEADADAGQAEAFAAAKQAAAIgEAFQgDAHgEACQgGAEgGAAQgGAAgFgDQgEgDgDgGIAAAegAgHgXQgDABgDAEQgCADAAAGIAAACQAAAHAFAEQAEAFAGAAQAGAAAFgFQAEgEAAgIQAAgJgEgFQgEgDgHAAQgDAAgEACg");
	this.shape_1183.setTransform(76.45,67.25);

	this.shape_1184 = new cjs.Shape();
	this.shape_1184.graphics.f("#000000").s().p("AgNAnQAJgHAEgKQAEgKAAgMQAAgLgEgKQgEgKgJgHIAFgGQAKAIAGALQAGAMAAANQAAAOgGAMQgGALgKAIg");
	this.shape_1184.setTransform(68.375,65.975);

	this.shape_1185 = new cjs.Shape();
	this.shape_1185.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_1185.setTransform(64.325,66.35);

	this.shape_1186 = new cjs.Shape();
	this.shape_1186.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAGgGAMAAQAMAAAIAGQAHAHAAAMQAAANgHAHQgIAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQAEAFAHAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_1186.setTransform(58.8,66.35);

	this.shape_1187 = new cjs.Shape();
	this.shape_1187.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgVIgJAAIAAgIIAHAAIACgBIAAgBIAAgOIALAAIAAAQIAVAAIAAAIIgVAAIAAAUQAAAHACADQACADAGAAQAGAAAFgCIAAAIIgGADIgHABQgIAAgFgGg");
	this.shape_1187.setTransform(53.225,65.65);

	this.shape_1188 = new cjs.Shape();
	this.shape_1188.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQACgIAGgCQAFgEAFAAQAGAAAEACQAEACACAEQACAFABAGIAAAgg");
	this.shape_1188.setTransform(47.95,66.3);

	this.shape_1189 = new cjs.Shape();
	this.shape_1189.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1189.setTransform(41.975,66.35);

	this.shape_1190 = new cjs.Shape();
	this.shape_1190.graphics.f("#000000").s().p("AgOAYQgEgCgCgFQgDgEABgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQACgEAAgFIAAgZIAJAAIAAAyIgJAAIAAgMQgCAGgGAEQgEADgGAAQgFAAgFgCg");
	this.shape_1190.setTransform(36,66.4);

	this.shape_1191 = new cjs.Shape();
	this.shape_1191.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_1191.setTransform(30.475,66.35);

	this.shape_1192 = new cjs.Shape();
	this.shape_1192.graphics.f("#000000").s().p("AgLAZIgJgDIAAgJIAJAEQAFABAGABQAFAAADgCQADgDAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEgBIgIgBQgIgBgEgCQgDgEAAgGQAAgHAFgFQAGgDAJAAIALABIAIACIgBAJQgIgFgJABQgFAAgDACQgDACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADAAACADQABADAAAEQAAAIgGAEQgFAFgKAAQgGAAgFgCg");
	this.shape_1192.setTransform(25.425,66.35);

	this.shape_1193 = new cjs.Shape();
	this.shape_1193.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgGAFgDQAGgCAGAAQALAAAGAFQAGAGAAALIAAAFIglAAQAAAGACAEQACADAEACQAEABAFABQAKgBAJgEIAAAIIgJAEIgMABQgLAAgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1193.setTransform(20.075,66.35);

	this.shape_1194 = new cjs.Shape();
	this.shape_1194.graphics.f("#000000").s().p("AgNAiQgFgDgEgGQgCgGAAgIQAAgJACgGQAEgFAFgEQAEgCAHAAQAGgBAEADQAFADACAGIAAgfIAKAAIAABHIgKAAIAAgNQgCAHgEADQgFAEgGAAQgHAAgEgDgAgKgDQgEAEAAAKQAAAIAEAEQAEAFAGAAQAFAAADgCQADgCADgEQABgDAAgFIAAgCQAAgJgDgEQgFgDgHAAQgGAAgEADg");
	this.shape_1194.setTransform(13.95,65.35);

	this.shape_1195 = new cjs.Shape();
	this.shape_1195.graphics.f("#000000").s().p("AgZAjIAAgJIADAAIAEAAIAGgBQACAAACgCIAEgIIgWgxIAMAAIAPAoIAPgoIALAAIgVAxQgDAIgDAEQgCAEgEACQgFACgHAAIgHAAg");
	this.shape_1195.setTransform(215.45,54.45);

	this.shape_1196 = new cjs.Shape();
	this.shape_1196.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1196.setTransform(207.175,53.45);

	this.shape_1197 = new cjs.Shape();
	this.shape_1197.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_1197.setTransform(201.825,52.75);

	this.shape_1198 = new cjs.Shape();
	this.shape_1198.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1198.setTransform(197.775,53.4);

	this.shape_1199 = new cjs.Shape();
	this.shape_1199.graphics.f("#000000").s().p("AgSAUQgIgGABgOQgBgMAIgHQAHgHALAAQANAAAGAHQAIAHAAAMQAAANgIAHQgGAHgNgBQgLABgHgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_1199.setTransform(192.55,53.45);

	this.shape_1200 = new cjs.Shape();
	this.shape_1200.graphics.f("#000000").s().p("AgYAjIAAhEIAJAAIAAAMQADgHAEgDQAFgDAFgBQAIAAAEADQAGADACAGQAEAGAAAIQAAAJgEAGQgCAFgGAEQgFACgGAAQgGAAgEgCQgFgDgDgGIAAAdgAgHgXQgEABgCAEQgCAEAAAEIAAACQAAAIAFAFQAEADAGAAQAGAAAFgDQAEgFAAgIQAAgKgEgDQgEgEgHgBQgDABgEACg");
	this.shape_1200.setTransform(186.6,54.35);

	this.shape_1201 = new cjs.Shape();
	this.shape_1201.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1201.setTransform(180.725,53.45);

	this.shape_1202 = new cjs.Shape();
	this.shape_1202.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_1202.setTransform(175.3,53.4);

	this.shape_1203 = new cjs.Shape();
	this.shape_1203.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgCQgCgCgGgBIgJACIgJADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgIAAgEgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1203.setTransform(169.35,53.45);

	this.shape_1204 = new cjs.Shape();
	this.shape_1204.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1204.setTransform(165.125,53.4);

	this.shape_1205 = new cjs.Shape();
	this.shape_1205.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_1205.setTransform(160.375,52.75);

	this.shape_1206 = new cjs.Shape();
	this.shape_1206.graphics.f("#000000").s().p("AgHAOIAFgbIAKAAIgIAbg");
	this.shape_1206.setTransform(154.15,56.25);

	this.shape_1207 = new cjs.Shape();
	this.shape_1207.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1207.setTransform(150.525,53.45);

	this.shape_1208 = new cjs.Shape();
	this.shape_1208.graphics.f("#000000").s().p("AgTAUQgGgGAAgOQAAgMAGgHQAIgHALAAQAMAAAIAHQAGAHABAMQgBANgGAHQgIAHgMgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQADADAIAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_1208.setTransform(145,53.45);

	this.shape_1209 = new cjs.Shape();
	this.shape_1209.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_1209.setTransform(139.425,52.75);

	this.shape_1210 = new cjs.Shape();
	this.shape_1210.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1210.setTransform(134.525,53.45);

	this.shape_1211 = new cjs.Shape();
	this.shape_1211.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1211.setTransform(129.175,53.45);

	this.shape_1212 = new cjs.Shape();
	this.shape_1212.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFABgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQACgEAAgFIAAgZIAKAAIAAAyIgKAAIAAgNQgDAIgFADQgEADgGAAQgFAAgFgCg");
	this.shape_1212.setTransform(123.2,53.5);

	this.shape_1213 = new cjs.Shape();
	this.shape_1213.graphics.f("#000000").s().p("AgYAjIAAhEIAJAAIAAAMQADgHAEgDQAFgDAGgBQAHAAAFADQAEADAEAGQACAGAAAIQAAAJgCAGQgEAFgEAEQgFACgHAAQgFAAgGgCQgEgDgCgGIAAAdgAgHgXQgDABgCAEQgCAEAAAEIAAACQAAAIADAFQAEADAHAAQAGAAAFgDQAEgFAAgIQAAgKgEgDQgEgEgHgBQgDABgEACg");
	this.shape_1213.setTransform(117.35,54.35);

	this.shape_1214 = new cjs.Shape();
	this.shape_1214.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADADABAHQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_1214.setTransform(109.525,53.4);

	this.shape_1215 = new cjs.Shape();
	this.shape_1215.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1215.setTransform(103.525,52.3);

	this.shape_1216 = new cjs.Shape();
	this.shape_1216.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1216.setTransform(97.125,53.45);

	this.shape_1217 = new cjs.Shape();
	this.shape_1217.graphics.f("#000000").s().p("AgTAUQgGgGgBgOQABgMAGgHQAIgHALAAQANAAAGAHQAIAHgBAMQABANgIAHQgGAHgNgBQgLABgIgHgAgLgMQgEAFAAAHQAAAJAEAFQAEADAHAAQAIAAAEgDQAEgFAAgJQAAgHgEgFQgEgFgIAAQgHAAgEAFg");
	this.shape_1217.setTransform(91.6,53.45);

	this.shape_1218 = new cjs.Shape();
	this.shape_1218.graphics.f("#000000").s().p("AgOAiQgFgDgDgGQgCgFAAgKQAAgIACgFQADgHAFgCQAFgDAHgBQAFAAAFADQAFADACAGIAAggIALAAIAABHIgLAAIAAgLQgBAGgFAEQgFACgGAAQgHAAgFgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_1218.setTransform(85.25,52.45);

	this.shape_1219 = new cjs.Shape();
	this.shape_1219.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1219.setTransform(80.975,52.3);

	this.shape_1220 = new cjs.Shape();
	this.shape_1220.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFABgGIAAggIAKAAIAAAdQAAAHADADQADADAGAAQADAAADgCQAEgCACgEQACgEgBgFIAAgZIAKAAIAAAyIgKAAIAAgNQgBAIgGADQgEADgGAAQgFAAgFgCg");
	this.shape_1220.setTransform(76.5,53.5);

	this.shape_1221 = new cjs.Shape();
	this.shape_1221.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1221.setTransform(72.3,52.4);

	this.shape_1222 = new cjs.Shape();
	this.shape_1222.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_1222.setTransform(68.425,53.45);

	this.shape_1223 = new cjs.Shape();
	this.shape_1223.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAGAAADACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_1223.setTransform(63,53.4);

	this.shape_1224 = new cjs.Shape();
	this.shape_1224.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1224.setTransform(58.525,52.3);

	this.shape_1225 = new cjs.Shape();
	this.shape_1225.graphics.f("#000000").s().p("AgIAaQgFgMAAgOQAAgNAFgMQAHgLAKgIIAFAGQgJAHgFAKQgDAKAAALQAAAMADAKQAFAKAJAHIgFAGQgKgIgHgLg");
	this.shape_1225.setTransform(55.7,53.075);

	this.shape_1226 = new cjs.Shape();
	this.shape_1226.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1226.setTransform(48.425,53.45);

	this.shape_1227 = new cjs.Shape();
	this.shape_1227.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1227.setTransform(43.075,53.45);

	this.shape_1228 = new cjs.Shape();
	this.shape_1228.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1228.setTransform(38.575,53.4);

	this.shape_1229 = new cjs.Shape();
	this.shape_1229.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_1229.setTransform(33.55,53.45);

	this.shape_1230 = new cjs.Shape();
	this.shape_1230.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1230.setTransform(28.175,53.45);

	this.shape_1231 = new cjs.Shape();
	this.shape_1231.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1231.setTransform(24.1,52.4);

	this.shape_1232 = new cjs.Shape();
	this.shape_1232.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAFgDAIAAIAMAAIACAAIAAgCIAAgDQABgEgDgCQgEgCgFgBIgJACIgIADIAAgJIAJgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgFAEQgEACgGAAQgHAAgFgDgAgJAFQgDACAAAEQAAAEADACQADACAEAAQADAAADgCQAEgCACgDQACgDgBgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1232.setTransform(20,53.45);

	this.shape_1233 = new cjs.Shape();
	this.shape_1233.graphics.f("#000000").s().p("AgZAhIAAhBIAZAAQAMAAAGAEQAGAEAAAIQAAAHgDADQgCAEgHACQAOACAAANQAAAJgGAEQgGAFgMAAgAgPAYIAQAAQAHAAADgDQAFgCAAgFQgBgGgDgCQgDgDgIAAIgQAAgAgPgEIAPAAQAGAAAEgDQAEgCAAgFQAAgFgEgCQgDgDgHAAIgPAAg");
	this.shape_1233.setTransform(14.45,52.7);

	this.shape_1234 = new cjs.Shape();
	this.shape_1234.graphics.f("#000000").s().p("AgZAjIAAgJIADAAIAEAAIAGAAQACgBACgCIAEgHIgWgzIAMAAIAPAqIAPgqIALAAIgVAzQgDAHgDAEQgCAFgEACQgFABgHAAIgHAAg");
	this.shape_1234.setTransform(243.35,41.55);

	this.shape_1235 = new cjs.Shape();
	this.shape_1235.graphics.f("#000000").s().p("AgRAXQgEgFAAgHQAAgIAFgDQAFgDAIAAIAMAAIACAAIAAgCIAAgDQAAgEgCgDQgEgCgFAAIgJABIgIAEIAAgJIAJgEIAJgBQAKABAGAEQAFAEAAAJIAAAiIgKAAIAAgLQgCAFgFAEQgEADgGAAQgHgBgFgDgAgJAFQgDACAAAEQAAADADADQADACAEAAQADAAADgCQAEgCACgDQACgDgBgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1235.setTransform(235.1,40.55);

	this.shape_1236 = new cjs.Shape();
	this.shape_1236.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1236.setTransform(231.3,39.5);

	this.shape_1237 = new cjs.Shape();
	this.shape_1237.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFAAgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEABgFIAAgZIAKAAIAAAyIgKAAIAAgMQgDAGgEAEQgGADgFAAQgFAAgFgCg");
	this.shape_1237.setTransform(226.85,40.6);

	this.shape_1238 = new cjs.Shape();
	this.shape_1238.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFACAGgBQAFAAADgBQADgCAAgEQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQgCgCgEAAIgIgCQgIgBgEgCQgDgEAAgGQAAgHAFgEQAGgFAJAAIALABIAIAEIgBAIQgIgEgJAAQgFAAgDABQgDACAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAEAAIAIABIAJADQADABACACQABADAAAEQAAAIgGAFQgFADgKABQgGgBgFgBg");
	this.shape_1238.setTransform(221.375,40.55);

	this.shape_1239 = new cjs.Shape();
	this.shape_1239.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgEQAGgDAFAAQAFAAAFACQAEACACAFQADAEAAAGIAAAgg");
	this.shape_1239.setTransform(215.95,40.5);

	this.shape_1240 = new cjs.Shape();
	this.shape_1240.graphics.f("#000000").s().p("AgIAkIAAgyIAJAAIAAAygAgKgWIAJgNIAMAAIgLANg");
	this.shape_1240.setTransform(211.875,39.5);

	this.shape_1241 = new cjs.Shape();
	this.shape_1241.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgBAEQgCAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQACgGAGgEQAFgDAFAAQAGAAAEACQAEACACAFQACAEABAGIAAAgg");
	this.shape_1241.setTransform(207.25,40.5);

	this.shape_1242 = new cjs.Shape();
	this.shape_1242.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_1242.setTransform(201.275,40.55);

	this.shape_1243 = new cjs.Shape();
	this.shape_1243.graphics.f("#000000").s().p("AgYAhIAAhBIAZAAQAMAAAGAGQAGAFAAALQAAAHgDAEQgDAEgFADQgFACgHABIgQAAIAAAWgAgOACIAPAAQAGgBAEgCQAEgDgBgHQABgGgEgDQgDgDgIAAIgOAAg");
	this.shape_1243.setTransform(195.5,39.8);

	this.shape_1244 = new cjs.Shape();
	this.shape_1244.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgEQAGgDAFAAQAFAAAFACQAEACACAFQADAEAAAGIAAAgg");
	this.shape_1244.setTransform(186.7,40.5);

	this.shape_1245 = new cjs.Shape();
	this.shape_1245.graphics.f("#000000").s().p("AgQAUQgHgHAAgNQAAgIADgGQAEgGAFgDQAGgDAGAAQALAAAGAHQAGAFAAAMIAAAEIglAAQAAAGACADQACAFAEABQAEACAFgBQAKAAAJgEIAAAIIgJAEIgMABQgLgBgHgGgAAPgEQAAgOgOAAQgFAAgEADQgEAEgBAHIAcAAIAAAAg");
	this.shape_1245.setTransform(180.725,40.55);

	this.shape_1246 = new cjs.Shape();
	this.shape_1246.graphics.f("#000000").s().p("AgTALIgJAAIACgIIAGAAIAAgDIAAgCIgIAAIACgIIAHAAQACgLAIgGQAIgGAKAAQALAAAIAEIAAAOQgIgFgJAAQgLAAgDAKIAQAAIAAAIIgSAAIAAACIAAADIASAAIAAAIIgRAAQADAKAMAAQAJAAAJgFIAAANQgIAFgMAAQgXAAgFgXg");
	this.shape_1246.setTransform(172.025,39.775);

	this.shape_1247 = new cjs.Shape();
	this.shape_1247.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_1247.setTransform(165.525,39.775);

	this.shape_1248 = new cjs.Shape();
	this.shape_1248.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_1248.setTransform(158.925,39.775);

	this.shape_1249 = new cjs.Shape();
	this.shape_1249.graphics.f("#000000").s().p("AgWAfIAAgOQAHAEAKAAQARAAAAgUQgCAEgEADQgFACgFAAQgLAAgGgFQgGgFAAgKQAAgKAGgHQAIgGAMAAQANAAAIAHQAIAIAAARQAAAQgIAJQgHAKgQAAQgMAAgHgDgAgMgKQAAAKAMAAQAGAAADgDQACgCAAgFQAAgFgCgDQgDgDgGAAQgMAAAAALg");
	this.shape_1249.setTransform(152.4,39.775);

	this.shape_1250 = new cjs.Shape();
	this.shape_1250.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgDAEABQAFgBADADQACADAAADQAAAFgCACQgDADgFAAQgEAAgCgDg");
	this.shape_1250.setTransform(147.725,42.25);

	this.shape_1251 = new cjs.Shape();
	this.shape_1251.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_1251.setTransform(143.425,39.725);

	this.shape_1252 = new cjs.Shape();
	this.shape_1252.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_1252.setTransform(137.675,39.725);

	this.shape_1253 = new cjs.Shape();
	this.shape_1253.graphics.f("#000000").s().p("AgRAVQgHgIAAgNQAAgMAIgHQAHgHALAAQALAAAGAGQAGAHAAALIAAAHIgiAAQABAFADADQAEADAGgBQALAAAIgDIAAALQgIAEgNAAQgMAAgIgGgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_1253.setTransform(129.325,40.5);

	this.shape_1254 = new cjs.Shape();
	this.shape_1254.graphics.f("#000000").s().p("AgUAeQgGgGAAgOQAAgMAGgHQAGgIAKAAQALABAFAKIAAgdIAPAAIAABHIgPAAIAAgMQgDANgNAAQgKAAgGgHgAgLAKQAAAOALAAQAMAAAAgOIAAAAQAAgOgMAAQgLAAAAAOg");
	this.shape_1254.setTransform(123.125,39.55);

	this.shape_1255 = new cjs.Shape();
	this.shape_1255.graphics.f("#000000").s().p("AgTAVQgHgIAAgNQAAgMAHgHQAIgHALAAQANAAAHAHQAHAHAAAMQAAANgHAIQgHAGgNAAQgLAAgIgGgAgLABQAAANALAAQAMAAAAgOQAAgNgMAAQgLAAAAAOg");
	this.shape_1255.setTransform(114.35,40.5);

	this.shape_1256 = new cjs.Shape();
	this.shape_1256.graphics.f("#000000").s().p("AgUAeQgGgGAAgOQAAgMAGgHQAGgIAKAAQALABAFAKIAAgdIAPAAIAABHIgPAAIAAgMQgDANgNAAQgKAAgGgHgAgLAKQAAAOALAAQAMAAAAgOIAAAAQAAgOgMAAQgLAAAAAOg");
	this.shape_1256.setTransform(107.925,39.55);

	this.shape_1257 = new cjs.Shape();
	this.shape_1257.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgDAJgBIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgKQgEALgMAAQgHAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_1257.setTransform(102,40.5);

	this.shape_1258 = new cjs.Shape();
	this.shape_1258.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAALIgUAAIAAARQAAAKAJAAQAGAAAFgCIAAANQgHACgHABQgUAAAAgWg");
	this.shape_1258.setTransform(96.8,39.85);

	this.shape_1259 = new cjs.Shape();
	this.shape_1259.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMgBQAIABAFAEQAFAFAAAJIAAAig");
	this.shape_1259.setTransform(91.375,40.45);

	this.shape_1260 = new cjs.Shape();
	this.shape_1260.graphics.f("#000000").s().p("AgTAVQgIgIABgNQgBgMAIgHQAHgHAMAAQANAAAHAHQAIAHAAAMQAAANgIAIQgHAGgNAAQgMAAgHgGgAgLABQAAANALAAQAMAAABgOQgBgNgMAAQgLAAAAAOg");
	this.shape_1260.setTransform(85.15,40.5);

	this.shape_1261 = new cjs.Shape();
	this.shape_1261.graphics.f("#000000").s().p("AgOAVQgGgIgBgNQABgMAGgHQAIgHALAAQAJAAAHAEIAAAMQgGgDgIAAQgNAAAAANQAAAOANAAQAIAAAGgEIAAANQgGAEgKAAQgLAAgIgGg");
	this.shape_1261.setTransform(79.5,40.5);

	this.shape_1262 = new cjs.Shape();
	this.shape_1262.graphics.f("#000000").s().p("AgHAkIAAhHIAPAAIAABHg");
	this.shape_1262.setTransform(73.025,39.5);

	this.shape_1263 = new cjs.Shape();
	this.shape_1263.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQgBgHAFgEQAFgDAKgBIAIAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAgBATIAAAhIgPAAIAAgKQgDALgLAAQgIAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_1263.setTransform(68.75,40.5);

	this.shape_1264 = new cjs.Shape();
	this.shape_1264.graphics.f("#000000").s().p("AgZAjIAAgNIAHABIAHgBQADgCABgEIgVgzIARAAIAMAkIAMgkIAQAAIgUAzQgEAKgFAFQgHAFgKAAIgIgBg");
	this.shape_1264.setTransform(60.475,41.525);

	this.shape_1265 = new cjs.Shape();
	this.shape_1265.graphics.f("#000000").s().p("AgUAXIAAgMQAIAEALAAQAJABAAgFQAAgEgHgBIgHgBQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBAMQgIgEgKAAQgHAAAAAEQAAAEAGABIAGABQAJABAEADQADADAAAGQAAASgWAAQgNAAgHgEg");
	this.shape_1265.setTransform(52.225,40.5);

	this.shape_1266 = new cjs.Shape();
	this.shape_1266.graphics.f("#000000").s().p("AgTAXQgDgEAAgIQAAgHAEgEQAFgDAKgBIAIAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgLAAgHAEIAAgNQAKgEAKAAQAXAAgBATIAAAhIgPAAIAAgKQgDALgLAAQgIAAgFgEgAgJALQAAAGAHAAQAEAAADgDQADgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_1266.setTransform(46.8,40.5);

	this.shape_1267 = new cjs.Shape();
	this.shape_1267.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAAAAJQAAAJgKAAQgIAAAAgJg");
	this.shape_1267.setTransform(42.7,39.325);

	this.shape_1268 = new cjs.Shape();
	this.shape_1268.graphics.f("#000000").s().p("AgOAVQgGgIAAgNQAAgMAGgHQAIgHALAAQAJAAAHAEIAAAMQgGgDgIAAQgNAAAAANQAAAOANAAQAIAAAGgEIAAANQgGAEgKAAQgLAAgIgGg");
	this.shape_1268.setTransform(38.65,40.5);

	this.shape_1269 = new cjs.Shape();
	this.shape_1269.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMgBQAIABAFAEQAFAFAAAJIAAAig");
	this.shape_1269.setTransform(33.175,40.45);

	this.shape_1270 = new cjs.Shape();
	this.shape_1270.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgDAJgBIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAEIAAgNQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgKQgEALgLAAQgIAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgKAAQgHAAAAAGg");
	this.shape_1270.setTransform(27.2,40.5);

	this.shape_1271 = new cjs.Shape();
	this.shape_1271.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMgBQAIABAFAEQAFAFAAAJIAAAig");
	this.shape_1271.setTransform(21.575,40.45);

	this.shape_1272 = new cjs.Shape();
	this.shape_1272.graphics.f("#000000").s().p("AgHAmIAAgzIAOAAIAAAzgAgJgcQAAgJAJAAQAKAAgBAJQABAJgKAAQgJAAAAgJg");
	this.shape_1272.setTransform(17,39.325);

	this.shape_1273 = new cjs.Shape();
	this.shape_1273.graphics.f("#000000").s().p("AgNAlIAAgnIgHAAIAAgLIAFAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAgBAAAAIAAgBQAAgIAGgFQAGgGAJAAQAIAAAFACIAAAMQgFgCgFAAQgJAAAAAJIAAACIARAAIAAALIgRAAIAAAng");
	this.shape_1273.setTransform(13.375,39.375);

	this.shape_1274 = new cjs.Shape();
	this.shape_1274.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAgBAJQABAJgKAAQgIAAAAgJg");
	this.shape_1274.setTransform(267.7,26.425);

	this.shape_1275 = new cjs.Shape();
	this.shape_1275.graphics.f("#000000").s().p("AgUAXIAAgNQAIAGALAAQAJgBAAgEQAAgDgHgBIgHgBQgPgDAAgMQAAgRAVAAQAMAAAIAEIgBANQgIgFgKAAQgHAAAAAFQAAADAGABIAGABQAJABAEADQADACAAAHQAAASgWAAQgNAAgHgEg");
	this.shape_1275.setTransform(263.625,27.6);

	this.shape_1276 = new cjs.Shape();
	this.shape_1276.graphics.f("#000000").s().p("AgTAUQgIgGABgOQgBgMAIgHQAIgHALAAQANAAAHAHQAIAHAAAMQAAAOgIAGQgHAHgNAAQgLAAgIgHgAgLAAQAAAOALAAQAMAAAAgOQAAgNgMAAQgLAAAAANg");
	this.shape_1276.setTransform(255.35,27.6);

	this.shape_1277 = new cjs.Shape();
	this.shape_1277.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgJgcQAAgJAJAAQAJAAAAAJQAAAJgJAAQgJAAAAgJg");
	this.shape_1277.setTransform(250.8,26.425);

	this.shape_1278 = new cjs.Shape();
	this.shape_1278.graphics.f("#000000").s().p("AgNAUQgIgGABgOQgBgMAIgHQAGgHAMAAQAIAAAIAEIAAANQgGgEgIAAQgNAAAAANQAAAOANAAQAHAAAIgEIAAANQgHAEgKAAQgMAAgGgHg");
	this.shape_1278.setTransform(246.75,27.6);

	this.shape_1279 = new cjs.Shape();
	this.shape_1279.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAHIgiAAQABAFADADQAEACAGABQALAAAIgFIAAAMQgIAEgNAAQgMAAgIgHgAALgEQAAgLgKAAQgIAAgCALIAUAAIAAAAg");
	this.shape_1279.setTransform(241.425,27.6);

	this.shape_1280 = new cjs.Shape();
	this.shape_1280.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAOQACgPAOAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_1280.setTransform(236.75,27.575);

	this.shape_1281 = new cjs.Shape();
	this.shape_1281.graphics.f("#000000").s().p("AgZAhIAAhBIAZAAQAaAAAAAXQAAAKgGAGQgHAGgLAAIgMAAIAAAUgAgKAAIAKAAQALAAAAgKQAAgJgLAAIgKAAg");
	this.shape_1281.setTransform(231.475,26.9);

	this.shape_1282 = new cjs.Shape();
	this.shape_1282.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAANQADgIAFgCQAFgEAFAAQAGAAAEACQAEACACAEQACAFAAAGIAAAgg");
	this.shape_1282.setTransform(222.65,27.6);

	this.shape_1283 = new cjs.Shape();
	this.shape_1283.graphics.f("#000000").s().p("AgSAUQgIgGAAgOQAAgMAIgHQAGgGAMAAQAMAAAHAGQAIAHAAAMQAAANgIAHQgHAHgMAAQgMAAgGgHgAgLgMQgEAFAAAHQAAAJAEAEQADAFAIAAQAIAAAEgFQAEgEAAgJQAAgHgEgFQgEgFgIABQgHgBgEAFg");
	this.shape_1283.setTransform(216.5,27.65);

	this.shape_1284 = new cjs.Shape();
	this.shape_1284.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgGAMAAIAIABQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAEQgEAFAAAIQAAAJAEAEQAFAFAHAAIAIgBIAHgEIAAAJIgHAEIgJABQgMAAgGgHg");
	this.shape_1284.setTransform(210.875,27.65);

	this.shape_1285 = new cjs.Shape();
	this.shape_1285.graphics.f("#000000").s().p("AgQAmQARgOAAgYQAAgWgRgPIAHgJQAaARAAAdQAAAfgaAQg");
	this.shape_1285.setTransform(203.55,27.275);

	this.shape_1286 = new cjs.Shape();
	this.shape_1286.graphics.f("#000000").s().p("AAMAhIgMgsIgMAsIgTAAIgShBIAQAAIAMAwIAOgwIAQAAIANAwIANgwIAPAAIgTBBg");
	this.shape_1286.setTransform(196.575,26.9);

	this.shape_1287 = new cjs.Shape();
	this.shape_1287.graphics.f("#000000").s().p("AAHAkIgRgXIAAAXIgQAAIAAhHIAQAAIAAAoIARgUIATAAIgYAYIAZAbg");
	this.shape_1287.setTransform(188.6,26.6);

	this.shape_1288 = new cjs.Shape();
	this.shape_1288.graphics.f("#000000").s().p("AACAhIAAgwIgSADIAAgPIAhgFIAABBg");
	this.shape_1288.setTransform(182.9,26.9);

	this.shape_1289 = new cjs.Shape();
	this.shape_1289.graphics.f("#000000").s().p("AgVAdQgHgFAAgKQAAgLAPgEQgNgDAAgLQAAgJAIgFQAGgEAMAAQAMAAAIAEQAHAFAAAJQAAALgNADQAHABAEAFQAEAEAAAFQAAAKgIAFQgIAFgNAAQgNAAgIgFgAgMAOQAAAIAMAAQAMAAAAgIQAAgJgMAAQgMAAAAAJgAgKgOQAAAIAKAAQALAAAAgIQAAgHgLAAQgKAAAAAHg");
	this.shape_1289.setTransform(177.6,26.9);

	this.shape_1290 = new cjs.Shape();
	this.shape_1290.graphics.f("#000000").s().p("AgQAAQAAgdAagRIAHAJQgRAPAAAWQAAAYARAOIgHAJQgagQAAgfg");
	this.shape_1290.setTransform(172.65,27.275);

	this.shape_1291 = new cjs.Shape();
	this.shape_1291.graphics.f("#000000").s().p("AgZAhIAAhBIAZAAQAaAAAAAXQAAAKgGAGQgHAGgLAAIgMAAIAAAUgAgKAAIAKAAQALAAAAgKQAAgJgLAAIgKAAg");
	this.shape_1291.setTransform(164.725,26.9);

	this.shape_1292 = new cjs.Shape();
	this.shape_1292.graphics.f("#000000").s().p("AANAhIAAgbIgZAAIAAAbIgPAAIAAhBIAPAAIAAAZIAZAAIAAgZIAPAAIAABBg");
	this.shape_1292.setTransform(157.825,26.9);

	this.shape_1293 = new cjs.Shape();
	this.shape_1293.graphics.f("#000000").s().p("AgUAaQgIgJAAgRQAAgPAIgJQAHgJANAAQAOAAAHAJQAIAJAAAPQAAAQgIAJQgHAJgOAAQgNAAgHgIgAgMAAQAAAVAMAAQANAAAAgVQAAgTgNAAQgMAAAAATg");
	this.shape_1293.setTransform(148.375,26.875);

	this.shape_1294 = new cjs.Shape();
	this.shape_1294.graphics.f("#000000").s().p("AACAhIAAgwIgSADIAAgPIAhgFIAABBg");
	this.shape_1294.setTransform(142.65,26.9);

	this.shape_1295 = new cjs.Shape();
	this.shape_1295.graphics.f("#000000").s().p("AABAhIAAgwIgRADIAAgPIAhgFIAABBg");
	this.shape_1295.setTransform(138.2,26.9);

	this.shape_1296 = new cjs.Shape();
	this.shape_1296.graphics.f("#000000").s().p("AgYAdIAAgPQAJAHAOAAQAMAAAAgHQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgGAAIgIgCQgSgDAAgPQAAgKAHgFQAHgGAMAAQAOAAAJAFIgBAOQgMgFgKAAQgLAAAAAGQAAABAAABQABAAAAABQAAAAABABQAAAAABAAQABACAFAAIAIACQAKABAFAEQAEAFAAAIQAAAKgHAGQgHAFgNAAQgNAAgKgFg");
	this.shape_1296.setTransform(130.525,26.875);

	this.shape_1297 = new cjs.Shape();
	this.shape_1297.graphics.f("#000000").s().p("AgRApIAWhRIANAAIgWBRg");
	this.shape_1297.setTransform(125.725,27.025);

	this.shape_1298 = new cjs.Shape();
	this.shape_1298.graphics.f("#000000").s().p("AgYAdIAAgPQAJAHAOAAQAMAAAAgHQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgGAAIgIgCQgSgDAAgPQAAgKAHgFQAHgGAMAAQAOAAAJAFIgBAOQgMgFgKAAQgLAAAAAGQAAABAAABQABAAAAABQAAAAABABQAAAAABAAQABACAFAAIAIACQAKABAFAEQAEAFAAAIQAAAKgHAGQgHAFgNAAQgNAAgKgFg");
	this.shape_1298.setTransform(120.975,26.875);

	this.shape_1299 = new cjs.Shape();
	this.shape_1299.graphics.f("#000000").s().p("AgTAbQgIgHAAgSQAAgQAIgJQAHgKAQAAQAMAAAHADIAAAOQgHgEgKAAQgRAAAAAUQACgEAEgDQAFgCAFAAQAKAAAHAFQAGAFAAAKQAAAKgHAHQgHAGgMAAQgNAAgIgHgAgIAEQgCADAAAEQAAAFACADQADADAFAAQANAAAAgLQAAgKgNAAQgFAAgDADg");
	this.shape_1299.setTransform(112.2,26.875);

	this.shape_1300 = new cjs.Shape();
	this.shape_1300.graphics.f("#000000").s().p("AgHAhIAAgzIgVAAIAAgOIA5AAIAAAOIgVAAIAAAzg");
	this.shape_1300.setTransform(105.725,26.9);

	this.shape_1301 = new cjs.Shape();
	this.shape_1301.graphics.f("#000000").s().p("AAXAhIAAgtIgTAtIgIAAIgTgtIAAAtIgOAAIAAhBIAVAAIAQApIARgpIAVAAIAABBg");
	this.shape_1301.setTransform(97.975,26.9);

	this.shape_1302 = new cjs.Shape();
	this.shape_1302.graphics.f("#000000").s().p("AgVAhIAAhBIAQAAIAAAzIAbAAIAAAOg");
	this.shape_1302.setTransform(88.275,26.9);

	this.shape_1303 = new cjs.Shape();
	this.shape_1303.graphics.f("#000000").s().p("AANAhIAAgbIgZAAIAAAbIgPAAIAAhBIAPAAIAAAZIAZAAIAAgZIAPAAIAABBg");
	this.shape_1303.setTransform(81.825,26.9);

	this.shape_1304 = new cjs.Shape();
	this.shape_1304.graphics.f("#000000").s().p("AAPAhIgPgYIgPAYIgSAAIAZgiIgXgfIATAAIAMAUIANgUIASAAIgWAfIAZAig");
	this.shape_1304.setTransform(74.775,26.9);

	this.shape_1305 = new cjs.Shape();
	this.shape_1305.graphics.f("#000000").s().p("AgHAhIAAgzIgVAAIAAgOIA5AAIAAAOIgVAAIAAAzg");
	this.shape_1305.setTransform(65.425,26.9);

	this.shape_1306 = new cjs.Shape();
	this.shape_1306.graphics.f("#000000").s().p("AgXAiIAAgMIATgSIAIgIQADgEAAgDQAAgIgJAAQgLAAgKAHIAAgPQAKgGANAAQALAAAGAGQAGAFAAAIQAAAIgFAGQgEAFgIAIIgIAHIAaAAIAAAOg");
	this.shape_1306.setTransform(59.375,26.825);

	this.shape_1307 = new cjs.Shape();
	this.shape_1307.graphics.f("#000000").s().p("AgGAGQgDgCAAgEQAAgDADgDQACgCAEAAQAFAAADACQACADAAADQAAAEgCACQgDAEgFAAQgEAAgCgEg");
	this.shape_1307.setTransform(54.975,29.35);

	this.shape_1308 = new cjs.Shape();
	this.shape_1308.graphics.f("#000000").s().p("AABAhIAAgwIgRADIAAgPIAhgFIAABBg");
	this.shape_1308.setTransform(51.1,26.9);

	this.shape_1309 = new cjs.Shape();
	this.shape_1309.graphics.f("#000000").s().p("AAJAbIAAgdQAAgLgIAAQgJAAAAAOIAAAaIgQAAIAAgzIAPAAIAAALQAEgMAMAAQAIgBAFAFQAFAFAAAKIAAAhg");
	this.shape_1309.setTransform(43.475,27.55);

	this.shape_1310 = new cjs.Shape();
	this.shape_1310.graphics.f("#000000").s().p("AgTAUQgIgGAAgOQAAgMAIgHQAHgHAMAAQANAAAHAHQAIAHgBAMQABAOgIAGQgHAHgNAAQgMAAgHgHgAgLAAQAAAOALAAQANAAAAgOQAAgNgNAAQgLAAAAANg");
	this.shape_1310.setTransform(37.25,27.6);

	this.shape_1311 = new cjs.Shape();
	this.shape_1311.graphics.f("#000000").s().p("AgHAmIAAgzIAPAAIAAAzgAgIgcQAAgJAIAAQAKAAAAAJQAAAJgKAAQgIAAAAgJg");
	this.shape_1311.setTransform(32.7,26.425);

	this.shape_1312 = new cjs.Shape();
	this.shape_1312.graphics.f("#000000").s().p("AgMAMIAAgTIgJAAIAAgLIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgMIAOAAIAAAPIAUAAIAAALIgUAAIAAARQAAAKAJAAQAGAAAFgBIAAAMQgHADgHAAQgUgBAAgVg");
	this.shape_1312.setTransform(28.65,26.95);

	this.shape_1313 = new cjs.Shape();
	this.shape_1313.graphics.f("#000000").s().p("AgHAmIAAgzIAOAAIAAAzgAgJgcQAAgJAJAAQAKAAAAAJQAAAJgKAAQgJAAAAgJg");
	this.shape_1313.setTransform(24.75,26.425);

	this.shape_1314 = new cjs.Shape();
	this.shape_1314.graphics.f("#000000").s().p("AgUAfQgGgIAAgMQAAgNAGgIQAGgGAKAAQALAAAFAKIAAgdIAPAAIAABHIgPAAIAAgNQgDAOgNAAQgKgBgGgFgAgLAKQAAAOALAAQAMAAAAgNIAAgBQAAgNgMgBQgLAAAAAOg");
	this.shape_1314.setTransform(19.925,26.65);

	this.shape_1315 = new cjs.Shape();
	this.shape_1315.graphics.f("#000000").s().p("AgWAhIAAhBIAtAAIAAANIgdAAIAAANIAZAAIAAAMIgZAAIAAAOIAdAAIAAANg");
	this.shape_1315.setTransform(14.025,26.9);

	this.shape_1316 = new cjs.Shape();
	this.shape_1316.graphics.f("#000000").s().p("AAJAkIAAgeQAAgJgIAAQgJAAAAAOIAAAZIgQAAIAAhHIAQAAIAAAeQAEgLALAAQAIAAAFAEQAFAGAAAIIAAAig");
	this.shape_1316.setTransform(266.475,13.7);

	this.shape_1317 = new cjs.Shape();
	this.shape_1317.graphics.f("#000000").s().p("AgNAUQgIgGABgOQgBgMAIgHQAGgHAMAAQAJAAAHADIAAAOQgGgEgIAAQgNAAAAANQAAAOANAAQAHAAAIgEIAAANQgHAEgKAAQgMAAgGgHg");
	this.shape_1317.setTransform(260.8,14.7);

	this.shape_1318 = new cjs.Shape();
	this.shape_1318.graphics.f("#000000").s().p("AgRAUQgHgGAAgOQAAgMAIgHQAHgHALAAQALAAAGAHQAGAFAAAMIAAAGIgiAAQABAHADACQAEADAGAAQALgBAIgEIAAALQgIAFgNAAQgMAAgIgHgAALgFQAAgKgKAAQgIAAgCAKIAUAAIAAAAg");
	this.shape_1318.setTransform(255.475,14.7);

	this.shape_1319 = new cjs.Shape();
	this.shape_1319.graphics.f("#000000").s().p("AgHAhIAAgzIgVAAIAAgOIA5AAIAAAOIgVAAIAAAzg");
	this.shape_1319.setTransform(249.375,14);

	this.shape_1320 = new cjs.Shape();
	this.shape_1320.graphics.f("#000000").s().p("AgZAhIAAhBIAZAAQAaAAAAAXQAAAKgGAGQgHAGgLAAIgMAAIAAAUgAgKAAIAKAAQALAAAAgJQAAgKgLAAIgKAAg");
	this.shape_1320.setTransform(240.525,14);

	this.shape_1321 = new cjs.Shape();
	this.shape_1321.graphics.f("#000000").s().p("AgYAeIABgPQALAEAKABQALgBAAgIQAAgKgPABQgJAAgHACIAAgkIAsAAIAAANIgeAAIAAALIAIgBQAZAAAAAUQAAALgHAGQgHAFgMAAQgMAAgLgDg");
	this.shape_1321.setTransform(234.275,14.05);

	this.shape_1322 = new cjs.Shape();
	this.shape_1322.graphics.f("#000000").s().p("AgSAXQgFgEAAgIQABgHAEgEQAFgEAJAAIAJAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAAgBQAAgGgJAAQgKAAgIAFIAAgOQAKgEAKAAQAWAAAAATIAAAhIgOAAIAAgJQgEAKgMAAQgHAAgEgEgAgJALQAAAGAHAAQADAAADgDQAEgDAAgGIAAAAIgJAAQgIAAAAAGg");
	this.shape_1322.setTransform(225.75,14.7);

	this.shape_1323 = new cjs.Shape();
	this.shape_1323.graphics.f("#000000").s().p("AgPAaIAAgyIAOAAIAAAOQAEgPANAAIAAAQQgIAAgEACQgEADAAAHIAAAXg");
	this.shape_1323.setTransform(221.3,14.675);

	this.shape_1324 = new cjs.Shape();
	this.shape_1324.graphics.f("#000000").s().p("AgMAMIAAgSIgJAAIAAgMIAGAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAAgLIAOAAIAAAOIAUAAIAAAMIgUAAIAAAQQAAAKAJAAQAGAAAFgBIAAAMQgHACgHAAQgUAAAAgVg");
	this.shape_1324.setTransform(216.5,14.05);

	this.shape_1325 = new cjs.Shape();
	this.shape_1325.graphics.f("#000000").s().p("AgUAWIAAgLQAIAEALABQAJAAAAgFQAAgEgHAAIgHgCQgPgCAAgMQAAgRAVAAQAMAAAIAEIgBANQgIgFgKAAQgHAAAAAFQAAADAGABIAGAAQAJACAEADQADACAAAHQAAASgWAAQgNAAgHgFg");
	this.shape_1325.setTransform(211.475,14.7);

	this.shape_1326 = new cjs.Shape();
	this.shape_1326.graphics.f("#000000").s().p("AAQAhIgEgOIgYAAIgFAOIgPAAIAWhBIAVAAIAWBBgAAIAGIgIgaIgIAaIAQAAg");
	this.shape_1326.setTransform(205.425,14);

	this.shape_1327 = new cjs.Shape();
	this.shape_1327.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1327.setTransform(196.825,14.75);

	this.shape_1328 = new cjs.Shape();
	this.shape_1328.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1328.setTransform(191.475,14.75);

	this.shape_1329 = new cjs.Shape();
	this.shape_1329.graphics.f("#000000").s().p("AgOAiQgEgDgEgGQgDgFAAgKQAAgIADgFQAEgHAEgCQAGgDAGgBQAGAAAEADQAFADADAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgFAEQgFACgGAAQgGAAgGgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQAEgCABgEQADgEAAgEIAAgDQAAgIgFgDQgEgEgHgBQgGABgEAEg");
	this.shape_1329.setTransform(185.35,13.75);

	this.shape_1330 = new cjs.Shape();
	this.shape_1330.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgCQgDgCgFgBIgJACIgJADIAAgJIAKgDIAJgCQAKAAAGAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgIAAgEgDgAgJAFQgCACAAAEQAAAEACACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1330.setTransform(179.6,14.75);

	this.shape_1331 = new cjs.Shape();
	this.shape_1331.graphics.f("#000000").s().p("AgOAiQgEgDgDgGQgEgFAAgKQAAgIAEgFQADgHAEgCQAGgDAGgBQAGAAAEADQAFADADAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgFAEQgFACgGAAQgGAAgGgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAEAAAEgCQADgCADgEQACgEAAgEIAAgDQAAgIgFgDQgEgEgHgBQgGABgEAEg");
	this.shape_1331.setTransform(173.75,13.75);

	this.shape_1332 = new cjs.Shape();
	this.shape_1332.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1332.setTransform(169.475,13.6);

	this.shape_1333 = new cjs.Shape();
	this.shape_1333.graphics.f("#000000").s().p("AgEAkIAAhHIAJAAIAABHg");
	this.shape_1333.setTransform(166.9,13.7);

	this.shape_1334 = new cjs.Shape();
	this.shape_1334.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAJAAIAMAAIACAAIABgCIAAgDQAAgEgEgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQACACAFAAQADAAAEgCQADgCABgDQADgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_1334.setTransform(162.8,14.75);

	this.shape_1335 = new cjs.Shape();
	this.shape_1335.graphics.f("#000000").s().p("AgOAYQgEgCgCgEQgDgFAAgGIAAggIALAAIAAAdQAAAHADADQADADAGAAQADAAAEgCQADgCABgEQACgEABgFIAAgZIAKAAIAAAyIgKAAIAAgNQgDAIgEADQgGADgFAAQgFAAgFgCg");
	this.shape_1335.setTransform(157.1,14.8);

	this.shape_1336 = new cjs.Shape();
	this.shape_1336.graphics.f("#000000").s().p("AgLAZIgJgDIAAgIIAJADQAFABAGAAQAFAAADgCQADgCAAgDQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBgBQgCgBgEAAIgIgCQgIgBgEgDQgDgDAAgGQAAgHAFgEQAGgEAJgBIALACIAIADIgBAIQgIgFgJAAQgFAAgDADQgDABAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACABAEABIAIABIAJACQADABACADQABADAAAEQAAAIgGAFQgFADgKAAQgGAAgFgBg");
	this.shape_1336.setTransform(151.625,14.75);

	this.shape_1337 = new cjs.Shape();
	this.shape_1337.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgCAEgBAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgEQAGgDAFAAQAFAAAFACQAEACACAFQADAEAAAGIAAAgg");
	this.shape_1337.setTransform(146.2,14.7);

	this.shape_1338 = new cjs.Shape();
	this.shape_1338.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1338.setTransform(140.225,14.75);

	this.shape_1339 = new cjs.Shape();
	this.shape_1339.graphics.f("#000000").s().p("AAcAaIAAgdQAAgHgCgDQgDgDgFAAQgGAAgEAEQgDAFAAAIIAAAZIgJAAIAAgdQAAgNgLAAQgGAAgDAEQgEAFAAAIIAAAZIgKAAIAAgyIAKAAIAAALQACgGAFgDQAEgDAGAAQAHAAAEADQADADABAHQACgHAFgDQAFgDAGAAQAIAAAEAEQAFAGAAAJIAAAgg");
	this.shape_1339.setTransform(132.925,14.7);

	this.shape_1340 = new cjs.Shape();
	this.shape_1340.graphics.f("#000000").s().p("AgSAbQgEgEgCgGQgCgGAAgJQAAgQAIgKQAHgJAPAAIAKABIAIADIAAAJIgIgDIgJgBQgJAAgGAHQgFAGAAAMQACgEAFgDQAGgDAFAAQAHAAAGADQAFACADAEQADAFAAAHQAAAGgDAFQgDAFgGADQgGADgIAAQgMAAgHgHgAgHAAQgDABgCADQgCADAAAEQAAAEACAEQACADADACQAEABADAAQAIAAAEgDQAEgEAAgGQAAgHgEgDQgEgDgIAAQgDAAgEABg");
	this.shape_1340.setTransform(122.575,13.975);

	this.shape_1341 = new cjs.Shape();
	this.shape_1341.graphics.f("#000000").s().p("AgMAhQgHgBgEgDIAAgKIALAEIALACQADAAAEgCQADgBACgCQACgDAAgDQAAgEgEgDQgDgDgHAAIgKAAIAAgIIAKAAQAFAAAEgCQADgDAAgFQAAgEgDgDQgFgDgGAAQgFAAgFACQgFABgFACIAAgKQAJgEAMAAQAHAAAFACQAHACACAEQADAEABAGQAAAFgEAEQgEAEgGACQAHABAEAEQAEAEAAAGQAAAGgDAEQgDAEgGADQgGACgHAAQgGAAgFgBg");
	this.shape_1341.setTransform(116.6,13.975);

	this.shape_1342 = new cjs.Shape();
	this.shape_1342.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1342.setTransform(108.275,14.75);

	this.shape_1343 = new cjs.Shape();
	this.shape_1343.graphics.f("#000000").s().p("AgNAiQgFgDgDgGQgDgFAAgKQAAgIADgFQADgHAFgCQAEgDAHgBQAGAAAEADQAFADACAGIAAggIAKAAIAABHIgKAAIAAgLQgCAGgEAEQgFACgGAAQgHAAgEgCgAgKgCQgEADAAAJQAAAKAEAEQAEAEAGAAQAFAAADgCQADgCACgEQACgEAAgEIAAgDQAAgIgDgDQgFgEgHgBQgGABgEAEg");
	this.shape_1343.setTransform(102.15,13.75);

	this.shape_1344 = new cjs.Shape();
	this.shape_1344.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQgBgEgDgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDABgEIAAgCIgNAAQgFAAgDACg");
	this.shape_1344.setTransform(93.85,14.75);

	this.shape_1345 = new cjs.Shape();
	this.shape_1345.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1345.setTransform(89.625,14.7);

	this.shape_1346 = new cjs.Shape();
	this.shape_1346.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1346.setTransform(84.575,14.75);

	this.shape_1347 = new cjs.Shape();
	this.shape_1347.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1347.setTransform(80.425,13.6);

	this.shape_1348 = new cjs.Shape();
	this.shape_1348.graphics.f("#000000").s().p("AgNAUQgHgHAAgNQAAgMAHgHQAGgHAMAAIAIACQAEAAAEACIAAAJIgHgDIgIgBQgHAAgFAFQgEADAAAJQAAAJAEAFQAFADAHAAIAIgBIAHgCIAAAJIgHACIgJABQgMABgGgHg");
	this.shape_1348.setTransform(76.525,14.75);

	this.shape_1349 = new cjs.Shape();
	this.shape_1349.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgDACQgEACgCAEQgBAEAAAFIAAAZIgKAAIAAgyIAJAAIAAAMQADgGAFgEQAEgDAGAAQAGAAADACQAFACACAFQADAEgBAGIAAAgg");
	this.shape_1349.setTransform(71.1,14.7);

	this.shape_1350 = new cjs.Shape();
	this.shape_1350.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIABgCIAAgDQAAgEgEgCQgCgCgGgBIgKACIgIADIAAgJIAJgDIAKgCQALAAAEAFQAGAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgHAAgFgDgAgJAFQgCACAAAEQAAAEACACQACACAFAAQADAAAEgCQADgCABgDQADgDAAgEIAAgCIgNAAQgFAAgDACg");
	this.shape_1350.setTransform(65.15,14.75);

	this.shape_1351 = new cjs.Shape();
	this.shape_1351.graphics.f("#000000").s().p("AANAaIAAgdQAAgNgMAAQgDAAgEACQgDACgBAEQgDAEAAAFIAAAZIgKAAIAAgyIAKAAIAAAMQADgGAEgEQAFgDAGAAQAFAAAEACQAFACACAFQACAEAAAGIAAAgg");
	this.shape_1351.setTransform(59.7,14.7);

	this.shape_1352 = new cjs.Shape();
	this.shape_1352.graphics.f("#000000").s().p("AgEAlIAAgyIAJAAIAAAygAgEgYQgCgDAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCADQgCABgDAAQgCAAgCgBg");
	this.shape_1352.setTransform(55.225,13.6);

	this.shape_1353 = new cjs.Shape();
	this.shape_1353.graphics.f("#000000").s().p("AgLAlIAAgqIgIAAIAAgIIAGAAIACAAIAAgCIAAgCQAAgGACgEQADgEAEgCQAEgDAGAAQAHAAAFADIAAAIIgFgBIgGgBQgFAAgDADQgCADAAAFIAAADIATAAIAAAIIgTAAIAAAqg");
	this.shape_1353.setTransform(51.9,13.6);

	this.shape_1354 = new cjs.Shape();
	this.shape_1354.graphics.f("#000000").s().p("AgRAXQgEgEAAgIQAAgHAFgEQAEgDAKAAIALAAIACAAIAAgCIAAgDQAAgEgDgCQgCgCgGgBIgJACIgJADIAAgJIAJgDIAKgCQALAAAFAFQAFAFAAAIIAAAhIgKAAIAAgKQgCAFgEAEQgFACgGAAQgIAAgEgDgAgJAFQgDACABAEQgBAEADACQADACAEAAQADAAAEgCQADgCABgDQACgDAAgEIAAgCIgMAAQgFAAgDACg");
	this.shape_1354.setTransform(44.25,14.75);

	this.shape_1355 = new cjs.Shape();
	this.shape_1355.graphics.f("#000000").s().p("AgFAcQgGgFAAgLIAAgWIgJAAIAAgHIAHAAIACgBIAAgCIAAgMIALAAIAAAPIAVAAIAAAHIgVAAIAAAVQAAAHACADQACADAGAAQAGAAAFgCIAAAJIgGABIgHABQgIABgFgGg");
	this.shape_1355.setTransform(39.175,14.05);

	this.shape_1356 = new cjs.Shape();
	this.shape_1356.graphics.f("#000000").s().p("AgNAaIAAgyIAJAAIAAAPQACgIAEgEQAFgEAHAAIAAALQgIAAgFAFQgEADAAAIIAAAYg");
	this.shape_1356.setTransform(35.125,14.7);

	this.shape_1357 = new cjs.Shape();
	this.shape_1357.graphics.f("#000000").s().p("AgQAUQgHgGAAgOQAAgIADgGQAEgFAFgDQAGgDAGgBQALABAGAFQAGAGAAAMIAAAEIglAAQAAAGACAEQACAEAEABQAEABAFAAQAKABAJgFIAAAIIgJADIgMABQgLABgHgHgAAPgEQAAgOgOAAQgFAAgEAEQgEADgBAHIAcAAIAAAAg");
	this.shape_1357.setTransform(30.075,14.75);

	this.shape_1358 = new cjs.Shape();
	this.shape_1358.graphics.f("#000000").s().p("AgLAlIAAgqIgIAAIAAgIIAFAAIADAAIAAgCIAAgCQAAgGACgEQADgEAEgCQAEgDAGAAQAIAAAEADIAAAIIgFgBIgGgBQgFAAgDADQgCADAAAFIAAADIATAAIAAAIIgTAAIAAAqg");
	this.shape_1358.setTransform(25.25,13.6);

	this.shape_1359 = new cjs.Shape();
	this.shape_1359.graphics.f("#000000").s().p("AgXAaQgIgJAAgRQAAgQAIgIQAJgJAOAAQAQAAAIAJQAIAIAAAQQAAARgIAJQgIAIgQAAQgOAAgJgIgAgPgSQgFAHAAALQAAANAFAGQAGAGAJAAQALAAAFgGQAFgGAAgNQAAgMgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_1359.setTransform(19.3,13.975);

	this.shape_1360 = new cjs.Shape();
	this.shape_1360.graphics.f("#000000").s().p("AAAAFIgHAOIgHgFIALgMIgQgCIADgJIAOAHIgCgQIAIAAIgCAQIAPgHIADAJIgQACIALAMIgHAFg");
	this.shape_1360.setTransform(13.325,12.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1360},{t:this.shape_1359},{t:this.shape_1358},{t:this.shape_1357},{t:this.shape_1356},{t:this.shape_1355},{t:this.shape_1354},{t:this.shape_1353},{t:this.shape_1352},{t:this.shape_1351},{t:this.shape_1350},{t:this.shape_1349},{t:this.shape_1348},{t:this.shape_1347},{t:this.shape_1346},{t:this.shape_1345},{t:this.shape_1344},{t:this.shape_1343},{t:this.shape_1342},{t:this.shape_1341},{t:this.shape_1340},{t:this.shape_1339},{t:this.shape_1338},{t:this.shape_1337},{t:this.shape_1336},{t:this.shape_1335},{t:this.shape_1334},{t:this.shape_1333},{t:this.shape_1332},{t:this.shape_1331},{t:this.shape_1330},{t:this.shape_1329},{t:this.shape_1328},{t:this.shape_1327},{t:this.shape_1326},{t:this.shape_1325},{t:this.shape_1324},{t:this.shape_1323},{t:this.shape_1322},{t:this.shape_1321},{t:this.shape_1320},{t:this.shape_1319},{t:this.shape_1318},{t:this.shape_1317},{t:this.shape_1316},{t:this.shape_1315},{t:this.shape_1314},{t:this.shape_1313},{t:this.shape_1312},{t:this.shape_1311},{t:this.shape_1310},{t:this.shape_1309},{t:this.shape_1308},{t:this.shape_1307},{t:this.shape_1306},{t:this.shape_1305},{t:this.shape_1304},{t:this.shape_1303},{t:this.shape_1302},{t:this.shape_1301},{t:this.shape_1300},{t:this.shape_1299},{t:this.shape_1298},{t:this.shape_1297},{t:this.shape_1296},{t:this.shape_1295},{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1292},{t:this.shape_1291},{t:this.shape_1290},{t:this.shape_1289},{t:this.shape_1288},{t:this.shape_1287},{t:this.shape_1286},{t:this.shape_1285},{t:this.shape_1284},{t:this.shape_1283},{t:this.shape_1282},{t:this.shape_1281},{t:this.shape_1280},{t:this.shape_1279},{t:this.shape_1278},{t:this.shape_1277},{t:this.shape_1276},{t:this.shape_1275},{t:this.shape_1274},{t:this.shape_1273},{t:this.shape_1272},{t:this.shape_1271},{t:this.shape_1270},{t:this.shape_1269},{t:this.shape_1268},{t:this.shape_1267},{t:this.shape_1266},{t:this.shape_1265},{t:this.shape_1264},{t:this.shape_1263},{t:this.shape_1262},{t:this.shape_1261},{t:this.shape_1260},{t:this.shape_1259},{t:this.shape_1258},{t:this.shape_1257},{t:this.shape_1256},{t:this.shape_1255},{t:this.shape_1254},{t:this.shape_1253},{t:this.shape_1252},{t:this.shape_1251},{t:this.shape_1250},{t:this.shape_1249},{t:this.shape_1248},{t:this.shape_1247},{t:this.shape_1246},{t:this.shape_1245},{t:this.shape_1244},{t:this.shape_1243},{t:this.shape_1242},{t:this.shape_1241},{t:this.shape_1240},{t:this.shape_1239},{t:this.shape_1238},{t:this.shape_1237},{t:this.shape_1236},{t:this.shape_1235},{t:this.shape_1234},{t:this.shape_1233},{t:this.shape_1232},{t:this.shape_1231},{t:this.shape_1230},{t:this.shape_1229},{t:this.shape_1228},{t:this.shape_1227},{t:this.shape_1226},{t:this.shape_1225},{t:this.shape_1224},{t:this.shape_1223},{t:this.shape_1222},{t:this.shape_1221},{t:this.shape_1220},{t:this.shape_1219},{t:this.shape_1218},{t:this.shape_1217},{t:this.shape_1216},{t:this.shape_1215},{t:this.shape_1214},{t:this.shape_1213},{t:this.shape_1212},{t:this.shape_1211},{t:this.shape_1210},{t:this.shape_1209},{t:this.shape_1208},{t:this.shape_1207},{t:this.shape_1206},{t:this.shape_1205},{t:this.shape_1204},{t:this.shape_1203},{t:this.shape_1202},{t:this.shape_1201},{t:this.shape_1200},{t:this.shape_1199},{t:this.shape_1198},{t:this.shape_1197},{t:this.shape_1196},{t:this.shape_1195},{t:this.shape_1194},{t:this.shape_1193},{t:this.shape_1192},{t:this.shape_1191},{t:this.shape_1190},{t:this.shape_1189},{t:this.shape_1188},{t:this.shape_1187},{t:this.shape_1186},{t:this.shape_1185},{t:this.shape_1184},{t:this.shape_1183},{t:this.shape_1182},{t:this.shape_1181},{t:this.shape_1180},{t:this.shape_1179},{t:this.shape_1178},{t:this.shape_1177},{t:this.shape_1176},{t:this.shape_1175},{t:this.shape_1174},{t:this.shape_1173},{t:this.shape_1172},{t:this.shape_1171},{t:this.shape_1170},{t:this.shape_1169},{t:this.shape_1168},{t:this.shape_1167},{t:this.shape_1166},{t:this.shape_1165},{t:this.shape_1164},{t:this.shape_1163},{t:this.shape_1162},{t:this.shape_1161},{t:this.shape_1160},{t:this.shape_1159},{t:this.shape_1158},{t:this.shape_1157},{t:this.shape_1156},{t:this.shape_1155},{t:this.shape_1154},{t:this.shape_1153},{t:this.shape_1152},{t:this.shape_1151},{t:this.shape_1150},{t:this.shape_1149},{t:this.shape_1148},{t:this.shape_1147},{t:this.shape_1146},{t:this.shape_1145},{t:this.shape_1144},{t:this.shape_1143},{t:this.shape_1142},{t:this.shape_1141},{t:this.shape_1140},{t:this.shape_1139},{t:this.shape_1138},{t:this.shape_1137},{t:this.shape_1136},{t:this.shape_1135},{t:this.shape_1134},{t:this.shape_1133},{t:this.shape_1132},{t:this.shape_1131},{t:this.shape_1130},{t:this.shape_1129},{t:this.shape_1128},{t:this.shape_1127},{t:this.shape_1126},{t:this.shape_1125},{t:this.shape_1124},{t:this.shape_1123},{t:this.shape_1122},{t:this.shape_1121},{t:this.shape_1120},{t:this.shape_1119},{t:this.shape_1118},{t:this.shape_1117},{t:this.shape_1116},{t:this.shape_1115},{t:this.shape_1114},{t:this.shape_1113},{t:this.shape_1112},{t:this.shape_1111},{t:this.shape_1110},{t:this.shape_1109},{t:this.shape_1108},{t:this.shape_1107},{t:this.shape_1106},{t:this.shape_1105},{t:this.shape_1104},{t:this.shape_1103},{t:this.shape_1102},{t:this.shape_1101},{t:this.shape_1100},{t:this.shape_1099},{t:this.shape_1098},{t:this.shape_1097},{t:this.shape_1096},{t:this.shape_1095},{t:this.shape_1094},{t:this.shape_1093},{t:this.shape_1092},{t:this.shape_1091},{t:this.shape_1090},{t:this.shape_1089},{t:this.shape_1088},{t:this.shape_1087},{t:this.shape_1086},{t:this.shape_1085},{t:this.shape_1084},{t:this.shape_1083},{t:this.shape_1082},{t:this.shape_1081},{t:this.shape_1080},{t:this.shape_1079},{t:this.shape_1078},{t:this.shape_1077},{t:this.shape_1076},{t:this.shape_1075},{t:this.shape_1074},{t:this.shape_1073},{t:this.shape_1072},{t:this.shape_1071},{t:this.shape_1070},{t:this.shape_1069},{t:this.shape_1068},{t:this.shape_1067},{t:this.shape_1066},{t:this.shape_1065},{t:this.shape_1064},{t:this.shape_1063},{t:this.shape_1062},{t:this.shape_1061},{t:this.shape_1060},{t:this.shape_1059},{t:this.shape_1058},{t:this.shape_1057},{t:this.shape_1056},{t:this.shape_1055},{t:this.shape_1054},{t:this.shape_1053},{t:this.shape_1052},{t:this.shape_1051},{t:this.shape_1050},{t:this.shape_1049},{t:this.shape_1048},{t:this.shape_1047},{t:this.shape_1046},{t:this.shape_1045},{t:this.shape_1044},{t:this.shape_1043},{t:this.shape_1042},{t:this.shape_1041},{t:this.shape_1040},{t:this.shape_1039},{t:this.shape_1038},{t:this.shape_1037},{t:this.shape_1036},{t:this.shape_1035},{t:this.shape_1034},{t:this.shape_1033},{t:this.shape_1032},{t:this.shape_1031},{t:this.shape_1030},{t:this.shape_1029},{t:this.shape_1028},{t:this.shape_1027},{t:this.shape_1026},{t:this.shape_1025},{t:this.shape_1024},{t:this.shape_1023},{t:this.shape_1022},{t:this.shape_1021},{t:this.shape_1020},{t:this.shape_1019},{t:this.shape_1018},{t:this.shape_1017},{t:this.shape_1016},{t:this.shape_1015},{t:this.shape_1014},{t:this.shape_1013},{t:this.shape_1012},{t:this.shape_1011},{t:this.shape_1010},{t:this.shape_1009},{t:this.shape_1008},{t:this.shape_1007},{t:this.shape_1006},{t:this.shape_1005},{t:this.shape_1004},{t:this.shape_1003},{t:this.shape_1002},{t:this.shape_1001},{t:this.shape_1000},{t:this.shape_999},{t:this.shape_998},{t:this.shape_997},{t:this.shape_996},{t:this.shape_995},{t:this.shape_994},{t:this.shape_993},{t:this.shape_992},{t:this.shape_991},{t:this.shape_990},{t:this.shape_989},{t:this.shape_988},{t:this.shape_987},{t:this.shape_986},{t:this.shape_985},{t:this.shape_984},{t:this.shape_983},{t:this.shape_982},{t:this.shape_981},{t:this.shape_980},{t:this.shape_979},{t:this.shape_978},{t:this.shape_977},{t:this.shape_976},{t:this.shape_975},{t:this.shape_974},{t:this.shape_973},{t:this.shape_972},{t:this.shape_971},{t:this.shape_970},{t:this.shape_969},{t:this.shape_968},{t:this.shape_967},{t:this.shape_966},{t:this.shape_965},{t:this.shape_964},{t:this.shape_963},{t:this.shape_962},{t:this.shape_961},{t:this.shape_960},{t:this.shape_959},{t:this.shape_958},{t:this.shape_957},{t:this.shape_956},{t:this.shape_955},{t:this.shape_954},{t:this.shape_953},{t:this.shape_952},{t:this.shape_951},{t:this.shape_950},{t:this.shape_949},{t:this.shape_948},{t:this.shape_947},{t:this.shape_946},{t:this.shape_945},{t:this.shape_944},{t:this.shape_943},{t:this.shape_942},{t:this.shape_941},{t:this.shape_940},{t:this.shape_939},{t:this.shape_938},{t:this.shape_937},{t:this.shape_936},{t:this.shape_935},{t:this.shape_934},{t:this.shape_933},{t:this.shape_932},{t:this.shape_931},{t:this.shape_930},{t:this.shape_929},{t:this.shape_928},{t:this.shape_927},{t:this.shape_926},{t:this.shape_925},{t:this.shape_924},{t:this.shape_923},{t:this.shape_922},{t:this.shape_921},{t:this.shape_920},{t:this.shape_919},{t:this.shape_918},{t:this.shape_917},{t:this.shape_916},{t:this.shape_915},{t:this.shape_914},{t:this.shape_913},{t:this.shape_912},{t:this.shape_911},{t:this.shape_910},{t:this.shape_909},{t:this.shape_908},{t:this.shape_907},{t:this.shape_906},{t:this.shape_905},{t:this.shape_904},{t:this.shape_903},{t:this.shape_902},{t:this.shape_901},{t:this.shape_900},{t:this.shape_899},{t:this.shape_898},{t:this.shape_897},{t:this.shape_896},{t:this.shape_895},{t:this.shape_894},{t:this.shape_893},{t:this.shape_892},{t:this.shape_891},{t:this.shape_890},{t:this.shape_889},{t:this.shape_888},{t:this.shape_887},{t:this.shape_886},{t:this.shape_885},{t:this.shape_884},{t:this.shape_883},{t:this.shape_882},{t:this.shape_881},{t:this.shape_880},{t:this.shape_879},{t:this.shape_878},{t:this.shape_877},{t:this.shape_876},{t:this.shape_875},{t:this.shape_874},{t:this.shape_873},{t:this.shape_872},{t:this.shape_871},{t:this.shape_870},{t:this.shape_869},{t:this.shape_868},{t:this.shape_867},{t:this.shape_866},{t:this.shape_865},{t:this.shape_864},{t:this.shape_863},{t:this.shape_862},{t:this.shape_861},{t:this.shape_860},{t:this.shape_859},{t:this.shape_858},{t:this.shape_857},{t:this.shape_856},{t:this.shape_855},{t:this.shape_854},{t:this.shape_853},{t:this.shape_852},{t:this.shape_851},{t:this.shape_850},{t:this.shape_849},{t:this.shape_848},{t:this.shape_847},{t:this.shape_846},{t:this.shape_845},{t:this.shape_844},{t:this.shape_843},{t:this.shape_842},{t:this.shape_841},{t:this.shape_840},{t:this.shape_839},{t:this.shape_838},{t:this.shape_837},{t:this.shape_836},{t:this.shape_835},{t:this.shape_834},{t:this.shape_833},{t:this.shape_832},{t:this.shape_831},{t:this.shape_830},{t:this.shape_829},{t:this.shape_828},{t:this.shape_827},{t:this.shape_826},{t:this.shape_825},{t:this.shape_824},{t:this.shape_823},{t:this.shape_822},{t:this.shape_821},{t:this.shape_820},{t:this.shape_819},{t:this.shape_818},{t:this.shape_817},{t:this.shape_816},{t:this.shape_815},{t:this.shape_814},{t:this.shape_813},{t:this.shape_812},{t:this.shape_811},{t:this.shape_810},{t:this.shape_809},{t:this.shape_808},{t:this.shape_807},{t:this.shape_806},{t:this.shape_805},{t:this.shape_804},{t:this.shape_803},{t:this.shape_802},{t:this.shape_801},{t:this.shape_800},{t:this.shape_799},{t:this.shape_798},{t:this.shape_797},{t:this.shape_796},{t:this.shape_795},{t:this.shape_794},{t:this.shape_793},{t:this.shape_792},{t:this.shape_791},{t:this.shape_790},{t:this.shape_789},{t:this.shape_788},{t:this.shape_787},{t:this.shape_786},{t:this.shape_785},{t:this.shape_784},{t:this.shape_783},{t:this.shape_782},{t:this.shape_781},{t:this.shape_780},{t:this.shape_779},{t:this.shape_778},{t:this.shape_777},{t:this.shape_776},{t:this.shape_775},{t:this.shape_774},{t:this.shape_773},{t:this.shape_772},{t:this.shape_771},{t:this.shape_770},{t:this.shape_769},{t:this.shape_768},{t:this.shape_767},{t:this.shape_766},{t:this.shape_765},{t:this.shape_764},{t:this.shape_763},{t:this.shape_762},{t:this.shape_761},{t:this.shape_760},{t:this.shape_759},{t:this.shape_758},{t:this.shape_757},{t:this.shape_756},{t:this.shape_755},{t:this.shape_754},{t:this.shape_753},{t:this.shape_752},{t:this.shape_751},{t:this.shape_750},{t:this.shape_749},{t:this.shape_748},{t:this.shape_747},{t:this.shape_746},{t:this.shape_745},{t:this.shape_744},{t:this.shape_743},{t:this.shape_742},{t:this.shape_741},{t:this.shape_740},{t:this.shape_739},{t:this.shape_738},{t:this.shape_737},{t:this.shape_736},{t:this.shape_735},{t:this.shape_734},{t:this.shape_733},{t:this.shape_732},{t:this.shape_731},{t:this.shape_730},{t:this.shape_729},{t:this.shape_728},{t:this.shape_727},{t:this.shape_726},{t:this.shape_725},{t:this.shape_724},{t:this.shape_723},{t:this.shape_722},{t:this.shape_721},{t:this.shape_720},{t:this.shape_719},{t:this.shape_718},{t:this.shape_717},{t:this.shape_716},{t:this.shape_715},{t:this.shape_714},{t:this.shape_713},{t:this.shape_712},{t:this.shape_711},{t:this.shape_710},{t:this.shape_709},{t:this.shape_708},{t:this.shape_707},{t:this.shape_706},{t:this.shape_705},{t:this.shape_704},{t:this.shape_703},{t:this.shape_702},{t:this.shape_701},{t:this.shape_700},{t:this.shape_699},{t:this.shape_698},{t:this.shape_697},{t:this.shape_696},{t:this.shape_695},{t:this.shape_694},{t:this.shape_693},{t:this.shape_692},{t:this.shape_691},{t:this.shape_690},{t:this.shape_689},{t:this.shape_688},{t:this.shape_687},{t:this.shape_686},{t:this.shape_685},{t:this.shape_684},{t:this.shape_683},{t:this.shape_682},{t:this.shape_681},{t:this.shape_680},{t:this.shape_679},{t:this.shape_678},{t:this.shape_677},{t:this.shape_676},{t:this.shape_675},{t:this.shape_674},{t:this.shape_673},{t:this.shape_672},{t:this.shape_671},{t:this.shape_670},{t:this.shape_669},{t:this.shape_668},{t:this.shape_667},{t:this.shape_666},{t:this.shape_665},{t:this.shape_664},{t:this.shape_663},{t:this.shape_662},{t:this.shape_661},{t:this.shape_660},{t:this.shape_659},{t:this.shape_658},{t:this.shape_657},{t:this.shape_656},{t:this.shape_655},{t:this.shape_654},{t:this.shape_653},{t:this.shape_652},{t:this.shape_651},{t:this.shape_650},{t:this.shape_649},{t:this.shape_648},{t:this.shape_647},{t:this.shape_646},{t:this.shape_645},{t:this.shape_644},{t:this.shape_643},{t:this.shape_642},{t:this.shape_641},{t:this.shape_640},{t:this.shape_639},{t:this.shape_638},{t:this.shape_637},{t:this.shape_636},{t:this.shape_635},{t:this.shape_634},{t:this.shape_633},{t:this.shape_632},{t:this.shape_631},{t:this.shape_630},{t:this.shape_629},{t:this.shape_628},{t:this.shape_627},{t:this.shape_626},{t:this.shape_625},{t:this.shape_624},{t:this.shape_623},{t:this.shape_622},{t:this.shape_621},{t:this.shape_620},{t:this.shape_619},{t:this.shape_618},{t:this.shape_617},{t:this.shape_616},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613},{t:this.shape_612},{t:this.shape_611},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605},{t:this.shape_604},{t:this.shape_603},{t:this.shape_602},{t:this.shape_601},{t:this.shape_600},{t:this.shape_599},{t:this.shape_598},{t:this.shape_597},{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// back
	this.shape_1361 = new cjs.Shape();
	this.shape_1361.graphics.f("rgba(255,255,255,0.698)").s().p("EgV3AtXMAAAhatMArvAAAMAAABatg");
	this.shape_1361.setTransform(142,291.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1361).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.legal, new cjs.Rectangle(-7,-2,300,600), null);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Warstwa_1
	this.instance = new lib._img();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1, new cjs.Rectangle(0,0,300,600), null);


(lib.hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A1PRgMAAAgi/MAqfAAAMAAAAi/g");
	this.shape.setTransform(136,112.025);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,272,224.1);


(lib.desde = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgCAEAAQAEAAADACQADADAAADQAAAFgDACQgDACgEAAQgEAAgCgCg");
	this.shape.setTransform(9.325,53.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgNAkQgJgHgDgQIgLAAIACgIIAIAAIAAgFIAAgFIgKAAIACgHIAJAAQADgPAKgIQAKgJAOAAQAHABAGABIALAFIAAAMQgFgDgFgBQgGgCgHgBQgTAAgFAUIAdAAIAAAHIgeAAIAAAFIAAAFIAeAAIAAAIIgdAAQACAKAGAFQAGAFAKAAQAIAAAFgDIALgFIAAAMQgFAEgGACQgGACgIAAQgPAAgKgJg");
	this.shape_1.setTransform(3.375,49.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTApQgIgDgEgFQgEgGAAgIQAAgEACgFQADgEAEgDQAFgDAGAAQgIgDgFgFQgFgFAAgHQAAgHAEgGQAFgEAHgEQAIgCAJAAQAKAAAIACQAIAEAEAEQAEAGAAAHQAAAHgFAFQgEAFgJADQAGAAAFADQAFADACAEQACAFAAAEQAAAIgEAGQgEAFgIADQgJADgLAAQgKAAgJgDgAgPAJQgGADAAAHQAAAGAGAEQAFAFAKAAQALAAAGgFQAFgEAAgGQAAgOgWAAQgKAAgFAEgAgOgdQgEAEAAAGQAAAGAEAEQAFADAJAAQAKAAAFgDQAFgEAAgGQAAgHgFgDQgFgEgKAAQgJAAgFAEg");
	this.shape_2.setTransform(-5.025,49.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRArIAihJIgwAAIAAgMIA/AAIAAAJIgiBMg");
	this.shape_3.setTransform(-12.925,49.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_4.setTransform(-18.325,54.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgRArQgHgCgGgEIABgMQAGAEAHABQAIACAGAAQAFAAAFgCQAEgCADgCQACgDAAgFQAAgGgFgDQgFgEgIAAIgNAAIAAgLIAMAAQAHABAFgEQAFgDAAgGQAAgGgFgEQgGgDgIAAIgNACQgHABgFADIAAgMQALgHAPAAQAKAAAHADQAHADAEAFQAEAGAAAHQAAAHgEAFQgFAFgIADQAKABAFAFQAEAGAAAHQAAAIgEAFQgEAGgHADQgIADgJABQgIAAgIgCg");
	this.shape_5.setTransform(-23.425,49.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAIArIAAgRIguAAIAAgLIAqg5IASAAIAAA4IARAAIAAAMIgRAAIAAARgAgXAOIAfAAIAAgrg");
	this.shape_6.setTransform(-31.675,49.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgQArIgLgDIAAgNQAFADAGABQAEABAHAAQAMAAAHgIQAHgIAAgQQgDAFgHAEQgGAEgIAAQgKAAgGgDQgHgEgEgGQgDgFgBgJQAAgIAEgHQAFgHAHgEQAHgDALAAQAPAAAKAJQAFAFACAHQADAIAAAMQAAAWgKAMQgKAMgTAAIgMgBgAgPgbQgEAFAAAIQAAAIAEAFQAFADAKAAQAFAAAFgCQAFgBADgDQACgEAAgFQAAgGgCgEQgDgEgFgDQgEgCgGAAQgJAAgGAFg");
	this.shape_7.setTransform(-40.2,49.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgGAHQgDgCAAgFQAAgDADgDQACgCAEAAQAEAAADACQADADAAADQAAAFgDACQgDACgEAAQgEAAgCgCg");
	this.shape_8.setTransform(-45.825,53.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgQAqIgOgEIABgNQAGADAHACQAHABAHAAQAIAAAGgDQAFgFAAgIQAAgJgGgDQgGgDgLAAIgLAAIgLACIAAgsIA3AAIAAALIgqAAIAAAVIAPgBQAPAAAIAHQAIAFAAAOQAAAJgEAHQgEAGgHADQgIADgJAAQgIAAgHgBg");
	this.shape_9.setTransform(-51.125,49.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAGArIAAhGIgZAGIAAgNIAngIIAABVg");
	this.shape_10.setTransform(-58.225,49.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgGAgQgDgCAAgFQAAgEADgCQACgDAEAAQAEAAADADQADACAAAEQAAAFgDACQgDACgEAAQgEAAgCgCgAgGgSQgDgCAAgEQAAgFADgCQACgCAEAAQAEAAADACQADACAAAFQAAAEgDACQgDADgEAAQgEAAgCgDg");
	this.shape_11.setTransform(-65.625,50.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgWAdQgGgFABgJQgBgKAHgFQAGgEAMAAIAPAAIACgBIABgCIAAgDQAAgGgDgDQgEgDgIAAQgGAAgHACIgKAEIAAgMIALgEQAGgCAIAAQANAAAGAGQAIAGAAALIAAAsIgOAAIAAgOQgCAIgFAEQgGAEgIAAQgLAAgFgGgAgMAGQgDADAAAFQAAAFADADQADADAGAAQAFAAAEgCQAEgDACgEQADgEAAgGIAAgCIgRAAQgGAAgEACg");
	this.shape_12.setTransform(-70.9,50.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgIAlQgGgHAAgOIAAgcIgMAAIAAgLIAJAAIACAAIABgCIAAgRIAOAAIAAATIAbAAIAAALIgbAAIAAAaQgBAJADAFQADADAIAAQAIAAAGgCIAAALIgIACIgJABQgLAAgHgGg");
	this.shape_13.setTransform(-77.45,49.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAJAAAQQAAARgJAJQgJAJgQAAQgPAAgJgJgAgPgQQgFAGAAAKQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgKgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_14.setTransform(-84.475,50.525);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgSAfQgGgDgCgFQgEgGAAgIIAAgqIAOAAIAAAmQAAAJAEAEQAEAEAHAAQAFAAAFgDQAEgCACgGQADgFAAgGIAAghIAMAAIAABBIgMAAIAAgQQgEAJgFAEQgHAFgIAAQgHAAgFgDg");
	this.shape_15.setTransform(-92.5,50.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgSAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAGAAAFACIAKADIAAAMIgJgEQgFgBgGAAQgKAAgFAFQgGAGAAALQAAAMAGAGQAFAFAKAAQAHAAAEgBIAJgEIAAALIgJAEQgFACgHAAQgPAAgJgJg");
	this.shape_16.setTransform(-99.65,50.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgWAdQgFgFgBgJQABgKAGgFQAGgEAMAAIAPAAIACgBIABgCIAAgDQAAgGgDgDQgFgDgHAAQgHAAgFACIgLAEIAAgMIALgEQAGgCAIAAQANAAAHAGQAGAGABALIAAAsIgOAAIAAgOQgCAIgGAEQgGAEgHAAQgKAAgGgGgAgMAGQgDADAAAFQAAAFADADQADADAGAAQAEAAAFgCQAFgDACgEQACgEAAgGIAAgCIgRAAQgGAAgEACg");
	this.shape_17.setTransform(-109.9,50.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAlAiIAAgmQAAgKgDgDQgDgEgIAAQgHAAgFAFQgFAHAAAKIAAAhIgMAAIAAgmQAAgRgOAAQgIAAgEAFQgEAHAAAKIAAAhIgOAAIAAhBIAOAAIAAAPQADgJAFgDQAGgFAIAAQAIAAAGAFQAEAEACAIQADgJAFgDQAGgFAJAAQAKAAAGAHQAFAFAAANIAAAqg");
	this.shape_18.setTransform(-119.05,50.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgGAwIAAhBIANAAIAABBgAgGggQgCgDAAgEQAAgEACgCQADgCADAAQAEAAADACQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_19.setTransform(-126.775,49.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgHAlQgHgHAAgOIAAgcIgMAAIAAgLIAJAAIACAAIABgCIAAgRIANAAIAAATIAdAAIAAALIgdAAIAAAaQAAAJADAFQAEADAHAAQAIAAAHgCIAAALIgIACIgJABQgMAAgGgGg");
	this.shape_20.setTransform(-131.75,49.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgGAvIAAhdIANAAIAABdg");
	this.shape_21.setTransform(-136.525,49.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgaAwQgJgKAAgUIAAgvIAOAAIAAAtQAAAKACAGQACAGAFADQAEAEAIAAQAIAAAFgDQAFgDACgHQACgFAAgLIAAgtIAOAAIAAAvQAAAUgJAKQgIAKgTAAQgSAAgIgKgAgIgnIALgSIAQAAIgPASg");
	this.shape_22.setTransform(-142.725,48.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgGAGQgDgBAAgFQAAgDADgDQACgCAEAAQAEAAADACQADADAAADQAAAFgDABQgDADgEAAQgEAAgCgDg");
	this.shape_23.setTransform(138.225,36.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgNAlQgJgJgDgPIgLAAIACgIIAIAAIAAgEIAAgGIgKAAIACgIIAJAAQADgOAKgIQAKgJAOABQAHgBAGACIALAFIAAANQgFgEgFgCQgGgCgHAAQgTABgFASIAdAAIAAAIIgeAAIAAAGIAAAEIAeAAIAAAIIgdAAQACAKAGAFQAGAFAKgBQAIAAAFgCIALgFIAAANQgFADgGACQgGACgIAAQgPgBgKgHg");
	this.shape_24.setTransform(132.275,32.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAGArIAAhFIgZAFIAAgNIAngIIAABVg");
	this.shape_25.setTransform(124.975,32.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgYAjQgFgFgCgHQgDgIAAgMQAAgWAKgMQAKgMATAAIANABQAGABAFACIAAANQgGgDgFgBQgFgBgHAAQgMAAgHAIQgHAIAAAQQADgFAHgEQAGgEAIAAQAKAAAHADQAGAEAEAFQAEAGAAAJQAAAIgEAHQgEAHgIAEQgHADgKAAQgQAAgKgJgAgJAAQgFACgCADQgDAEAAAFQAAAGADAEQACAEAFADQAEACAFAAQAKAAAFgFQAGgFAAgIQAAgIgFgFQgFgDgKAAQgFAAgFABg");
	this.shape_26.setTransform(118.425,32.675);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_27.setTransform(112.625,37.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgTApQgIgCgEgHQgEgFAAgHQAAgFACgFQADgEAEgDQAFgDAGAAQgIgCgFgGQgFgFAAgHQAAgHAEgGQAFgFAHgDQAIgCAJAAQAKAAAIACQAIADAEAFQAEAGAAAHQAAAHgFAGQgEAFgJACQAGAAAFADQAFADACAEQACAFAAAFQAAAHgEAFQgEAHgIACQgJADgLAAQgKAAgJgDgAgPAJQgGADAAAHQAAAHAGADQAFAEAKABQALgBAGgEQAFgDAAgHQAAgPgWAAQgKAAgFAFgAgOgdQgEAEAAAGQAAAGAEAEQAFADAJAAQAKAAAFgDQAFgEAAgGQAAgGgFgEQgFgDgKgBQgJABgFADg");
	this.shape_28.setTransform(107.025,32.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAGArIAAhFIgZAFIAAgNIAngIIAABVg");
	this.shape_29.setTransform(99.775,32.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgYAjQgFgFgCgHQgDgIAAgMQAAgWAKgMQAKgMATAAIANABQAGABAFACIAAANQgGgDgFgBQgFgBgHAAQgMAAgHAIQgHAIAAAQQADgFAHgEQAGgEAIAAQAKAAAHADQAGAEAEAFQAEAGAAAJQAAAIgEAHQgEAHgIAEQgHADgKAAQgQAAgKgJgAgJAAQgFACgCADQgDAEAAAFQAAAGADAEQACAEAFADQAEACAFAAQAKAAAFgFQAGgFAAgIQAAgIgFgFQgFgDgKAAQgFAAgFABg");
	this.shape_30.setTransform(93.225,32.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgGAGQgDgBAAgFQAAgDADgDQACgCAEAAQAEAAADACQADADAAADQAAAFgDABQgDADgEAAQgEAAgCgDg");
	this.shape_31.setTransform(87.525,36.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgQAqIgOgEIABgNQAGADAHACQAHACAHAAQAIAAAGgFQAFgEAAgIQAAgJgGgDQgGgDgLAAIgLAAIgLACIAAgsIA3AAIAAAMIgqAAIAAAUIAPgBQAPABAIAGQAIAGAAANQAAAJgEAHQgEAGgHAEQgIACgJAAQgIABgHgCg");
	this.shape_32.setTransform(82.225,32.75);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgGAgQgDgCAAgFQAAgEADgCQACgDAEAAQAEAAADADQADACAAAEQAAAFgDACQgDACgEAAQgEAAgCgCgAgGgSQgDgCAAgEQAAgFADgCQACgCAEAAQAEAAADACQADACAAAFQAAAEgDACQgDADgEAAQgEAAgCgDg");
	this.shape_33.setTransform(73.325,33.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgWAdQgGgFAAgJQAAgKAHgFQAGgEAMAAIAPAAIACgBIABgCIAAgDQAAgGgDgDQgEgDgIAAQgGAAgHACIgKAEIAAgMIALgEQAHgCAHAAQANAAAHAGQAHAGAAALIAAAsIgOAAIAAgOQgCAIgGAEQgGAEgHAAQgLAAgFgGgAgMAGQgEADABAFQgBAFAEADQADADAGAAQAEAAAFgCQAEgDADgEQACgEAAgGIAAgCIgRAAQgGAAgEACg");
	this.shape_34.setTransform(68.05,33.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgSAsQgHgDgDgJQgEgHAAgLQAAgMAEgHQADgIAHgEQAHgEAIAAQAIAAAFAEQAHADADAJIAAgqIANAAIAABdIgNAAIAAgPQgCAIgHAEQgGAEgHABQgKgBgGgDgAgNgDQgGAEAAANQAAALAGAGQAFAFAIAAQAFAAAFgDQAFgCACgFQADgEAAgHIAAgDQAAgLgFgEQgGgGgJAAQgIAAgFAGg");
	this.shape_35.setTransform(60.45,32.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgWAdQgGgFABgJQgBgKAHgFQAGgEAMAAIAPAAIACgBIABgCIAAgDQAAgGgEgDQgDgDgIAAQgGAAgHACIgKAEIAAgMIALgEQAGgCAIAAQANAAAGAGQAIAGAAALIAAAsIgNAAIAAgOQgDAIgFAEQgGAEgIAAQgLAAgFgGgAgMAGQgDADAAAFQAAAFADADQADADAGAAQAFAAAEgCQAEgDACgEQADgEAAgGIAAgCIgQAAQgIAAgDACg");
	this.shape_36.setTransform(52.95,33.675);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgSAiIAAhBIANAAIAAASQADgKAFgFQAHgFAJAAIAAAPQgLAAgHAFQgFAFAAALIAAAfg");
	this.shape_37.setTransform(47.475,33.625);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgIAkQgGgGAAgOIAAgcIgMAAIAAgKIAJAAIACgBIABgDIAAgQIAOAAIAAAUIAcAAIAAAKIgcAAIAAAbQgBAIADAEQADAFAIAAQAIAAAHgDIAAALIgJACIgJABQgLABgHgIg");
	this.shape_38.setTransform(41.35,32.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEADQgFACgCAGQgCAFAAAGIAAAhIgOAAIAAhBIAOAAIAAAQQADgJAGgEQAGgFAIAAQAHAAAGADQAFADADAFQADAGgBAJIAAApg");
	this.shape_39.setTransform(34.4,33.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgcArIAAhVIA5AAIAAAMIgrAAIAAAYIAmAAIAAAKIgmAAIAAAaIArAAIAAANg");
	this.shape_40.setTransform(26.575,32.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgGAGQgDgBAAgFQAAgDADgDQACgCAEAAQAEAAADACQADADAAADQAAAFgDABQgDADgEAAQgEAAgCgDg");
	this.shape_41.setTransform(17.725,36.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgRAzQAMgKAFgMQAFgNAAgQQAAgPgFgNQgFgMgMgKIAGgIQAOALAIAPQAHAPAAARQAAASgHAPQgIAQgOAKg");
	this.shape_42.setTransform(13.275,33.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEADQgEACgCAGQgDAFAAAGIAAAhIgNAAIAAhBIAMAAIAAAQQAEgJAGgEQAGgFAIAAQAHAAAFADQAGADADAFQADAGAAAJIAAApg");
	this.shape_43.setTransform(7.45,33.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgYAnQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAIAAARQAAARgJAJQgJAIgQABQgPAAgJgJgAgPgDQgFAFAAALQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgMgFgEQgFgGgLAAQgKAAgFAGgAgIgeIALgRIAQAAIgPARg");
	this.shape_44.setTransform(-0.525,32.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgGAwIAAhBIANAAIAABBgAgGggQgCgDAAgEQAAgEACgCQADgCADAAQAEAAADACQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_45.setTransform(-6.175,32.175);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgSAaQgIgJgBgRQABgQAIgJQAJgJAPAAQAHAAAEACIAKADIAAAMIgJgEQgFgBgGAAQgJAAgGAFQgGAGAAALQAAAMAGAGQAGAFAJAAQAHAAAEgBIAJgEIAAALIgJAEQgFACgHAAQgPAAgJgJg");
	this.shape_46.setTransform(-11.2,33.675);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgWAdQgGgFABgJQgBgKAHgFQAGgEAMAAIAPAAIACgBIABgCIAAgDQAAgGgEgDQgDgDgIAAQgGAAgHACIgKAEIAAgMIALgEQAGgCAHAAQAOAAAGAGQAIAGgBALIAAAsIgMAAIAAgOQgDAIgFAEQgGAEgIAAQgLAAgFgGgAgMAGQgDADgBAFQABAFADADQADADAGAAQAEAAAFgCQAEgDACgEQADgEAAgGIAAgCIgQAAQgIAAgDACg");
	this.shape_47.setTransform(-18.15,33.675);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgGAwIAAhBIANAAIAABBgAgGggQgCgDAAgEQAAgEACgCQADgCADAAQAEAAADACQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_48.setTransform(-23.125,32.175);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgSAaQgJgJABgRQgBgQAJgJQAJgJAPAAQAGAAAFACIAKADIAAAMIgJgEQgFgBgGAAQgJAAgGAFQgGAGAAALQAAAMAGAGQAGAFAJAAQAHAAAFgBIAJgEIAAALIgKAEQgFACgHAAQgPAAgJgJg");
	this.shape_49.setTransform(-28.15,33.675);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEADQgEACgCAGQgDAFAAAGIAAAhIgNAAIAAhBIAMAAIAAAQQAEgJAGgEQAGgFAIAAQAHAAAFADQAGADADAFQADAGAAAJIAAApg");
	this.shape_50.setTransform(-35.3,33.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgWAdQgGgFABgJQgBgKAHgFQAGgEAMAAIAPAAIACgBIABgCIAAgDQAAgGgEgDQgDgDgIAAQgGAAgHACIgKAEIAAgMIALgEQAGgCAIAAQANAAAGAGQAIAGAAALIAAAsIgOAAIAAgOQgCAIgFAEQgGAEgIAAQgLAAgFgGgAgMAGQgDADAAAFQAAAFADADQADADAGAAQAFAAAEgCQAEgDACgEQADgEAAgGIAAgCIgRAAQgGAAgEACg");
	this.shape_51.setTransform(-43,33.675);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEADQgEACgCAGQgDAFAAAGIAAAhIgNAAIAAhBIAMAAIAAAQQAEgJAGgEQAGgFAIAAQAHAAAFADQAGADADAFQADAGAAAJIAAApg");
	this.shape_52.setTransform(-50.15,33.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgGAwIAAhBIANAAIAABBgAgGggQgCgDAAgEQAAgEACgCQADgCADAAQAEAAADACQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_53.setTransform(-55.875,32.175);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgPAwIAAg3IgKAAIAAgKIAHAAIADgBIAAgCIAAgCQAAgIADgGQADgFAGgDQAFgDAIAAQAKAAAHADIAAALIgHgCIgIgBQgHAAgEAEQgDAEAAAHIAAAEIAZAAIAAAKIgZAAIAAA3g");
	this.shape_54.setTransform(-60.2,32.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgWAdQgFgFAAgJQAAgKAGgFQAGgEAMAAIAPAAIADgBIAAgCIAAgDQAAgGgEgDQgDgDgIAAQgGAAgGACIgLAEIAAgMIAMgEQAGgCAGAAQAOAAAGAGQAIAGgBALIAAAsIgMAAIAAgOQgDAIgFAEQgHAEgIAAQgKAAgFgGgAgMAGQgDADgBAFQABAFADADQADADAGAAQAFAAAEgCQAFgDABgEQADgEAAgGIAAgCIgQAAQgIAAgDACg");
	this.shape_55.setTransform(-70.15,33.675);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgGAvIAAhdIANAAIAABdg");
	this.shape_56.setTransform(-75.125,32.325);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEADQgFACgCAGQgCAFAAAGIAAAhIgOAAIAAhBIAOAAIAAAQQADgJAGgEQAGgFAIAAQAHAAAGADQAFADADAFQADAGgBAJIAAApg");
	this.shape_57.setTransform(-83.95,33.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgVAaQgJgJAAgRQAAgKAEgIQAEgIAIgEQAHgEAJAAQAOAAAIAIQAHAIAAAOIAAAHIgwAAQAAAIADAEQACAFAFACQAFACAHAAQAOAAAKgGIAAALQgEACgHACQgHACgIAAQgPAAgJgJgAATgFQAAgTgSAAQgHAAgFAFQgFAFgBAJIAkAAIAAAAg");
	this.shape_58.setTransform(-91.675,33.675);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAJAAAQQAAARgJAJQgJAJgQAAQgPAAgJgJgAgPgQQgFAGAAAKQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgKgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_59.setTransform(-102.575,33.675);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgSAsQgGgDgEgJQgEgHAAgLQAAgMAEgHQAEgIAGgEQAHgEAIAAQAIAAAFAEQAGADAEAJIAAgqIANAAIAABdIgNAAIAAgPQgCAIgHAEQgGAEgIABQgIgBgHgDgAgOgDQgFAEAAANQAAALAFAGQAGAFAIAAQAFAAAFgDQAFgCADgFQACgEAAgHIAAgDQAAgLgGgEQgEgGgKAAQgIAAgGAGg");
	this.shape_60.setTransform(-110.85,32.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgGAwIAAhBIANAAIAABBgAgGggQgCgDAAgEQAAgEACgCQADgCADAAQAEAAADACQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_61.setTransform(-116.375,32.175);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgTAfQgFgDgDgFQgCgGAAgIIAAgqIANAAIAAAmQAAAJAEAEQAEAEAHAAQAFAAAEgDQAFgCACgGQADgFgBgGIAAghIAOAAIAABBIgOAAIAAgQQgCAJgHAEQgGAFgIAAQgHAAgGgDg");
	this.shape_62.setTransform(-122.15,33.775);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgGAvIAAhdIANAAIAABdg");
	this.shape_63.setTransform(-127.675,32.325);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgSAaQgJgJABgRQgBgQAJgJQAJgJAPAAQAGAAAFACIAKADIAAAMIgJgEQgFgBgGAAQgJAAgGAFQgGAGAAALQAAAMAGAGQAGAFAJAAQAHAAAFgBIAJgEIAAALIgKAEQgFACgHAAQgPAAgJgJg");
	this.shape_64.setTransform(-132.65,33.675);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEADQgFACgBAGQgDAFAAAGIAAAhIgNAAIAAhBIAMAAIAAAQQADgJAHgEQAGgFAIAAQAHAAAFADQAGADADAFQADAGAAAJIAAApg");
	this.shape_65.setTransform(-139.8,33.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgGAwIAAhBIANAAIAABBgAgGggQgCgDAAgEQAAgEACgCQADgCADAAQAEAAADACQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_66.setTransform(-145.525,32.175);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAJAAAQQAAARgJAJQgJAJgQAAQgPAAgJgJgAgPgQQgFAGAAAKQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgKgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_67.setTransform(149.125,16.825);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEACQgEAEgCAEQgDAGAAAHIAAAgIgOAAIAAhBIAOAAIAAAQQADgJAGgFQAHgEAHAAQAHAAAGADQAFADADAFQACAGABAJIAAApg");
	this.shape_68.setTransform(141.3,16.75);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAJAAAQQAAARgJAJQgJAJgQAAQgPAAgJgJgAgPgQQgFAGAAAKQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgKgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_69.setTransform(130.025,16.825);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgHAkQgHgGAAgOIAAgcIgMAAIAAgKIAJAAIACgCIABgCIAAgRIAOAAIAAAVIAcAAIAAAKIgcAAIAAAbQgBAIADAEQADAFAIAAQAIAAAHgEIAAAMIgJADIgJABQgLAAgGgIg");
	this.shape_70.setTransform(122.8,15.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgGAwIAAhBIANAAIAABBgAgGggQgCgDAAgEQAAgEACgCQADgCADAAQAEAAADACQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_71.setTransform(118.025,15.325);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgSAsQgGgEgEgHQgEgIAAgLQAAgMAEgHQAEgIAGgEQAGgEAJAAQAIAAAFAEQAGADAEAJIAAgpIANAAIAABcIgNAAIAAgPQgCAIgHAEQgGAFgHAAQgJAAgHgEgAgOgDQgFAEAAANQAAALAFAGQAGAFAIAAQAFAAAFgDQAFgCADgFQACgFAAgGIAAgDQAAgLgFgEQgFgGgKAAQgIAAgGAGg");
	this.shape_72.setTransform(112,15.55);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgVAnQgJgJAAgRQAAgMAEgGQAEgIAIgEQAHgEAJAAQAOAAAIAIQAHAIAAANIAAAIIgwAAQAAAIADAEQACAEAFADQAFACAHAAQAOAAAKgGIAAALQgEACgHABQgHACgIABQgPAAgJgJgAATAHQAAgSgSAAQgHAAgFAEQgFAFgBAJIAkAAIAAAAgAgGgdIALgRIAQAAIgPARg");
	this.shape_73.setTransform(104.475,15.55);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgSAiIAAhBIANAAIAAASQADgKAFgFQAHgFAJAAIAAAPQgLAAgHAFQgFAFAAALIAAAfg");
	this.shape_74.setTransform(98.625,16.775);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgSAaQgJgJABgRQgBgQAJgJQAJgJAPAAQAGAAAFACIAKADIAAAMIgJgEQgFgBgGAAQgJAAgGAFQgGAGAAALQAAAMAGAGQAGAFAJAAQAHAAAFgBIAJgEIAAALIgKAEQgFACgHAAQgPAAgJgJg");
	this.shape_75.setTransform(92.45,16.825);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgVAaQgJgJAAgRQAAgKAEgIQAEgIAIgEQAHgEAJAAQAOAAAIAIQAHAIAAAOIAAAHIgwAAQAAAIADAEQACAFAFACQAFACAHAAQAOAAAKgGIAAALQgEACgHACQgHACgIAAQgPAAgJgJgAATgFQAAgTgSAAQgHAAgFAFQgFAFgBAJIAkAAIAAAAg");
	this.shape_76.setTransform(82.175,16.825);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgSAsQgGgEgEgHQgEgIAAgLQAAgMAEgHQAEgIAGgEQAGgEAJAAQAIAAAFAEQAGADAEAJIAAgpIANAAIAABcIgNAAIAAgPQgCAIgHAEQgGAFgHAAQgJAAgHgEgAgOgDQgFAEAAANQAAALAFAGQAGAFAIAAQAFAAAFgDQAFgCADgFQACgFAAgGIAAgDQAAgLgFgEQgFgGgKAAQgIAAgGAGg");
	this.shape_77.setTransform(74.2,15.55);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAJAAAQQAAARgJAJQgJAJgQAAQgPAAgJgJgAgPgQQgFAGAAAKQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgKgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_78.setTransform(63.125,16.825);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgSAiIAAhBIANAAIAAASQADgKAFgFQAHgFAJAAIAAAPQgLAAgHAFQgFAFAAALIAAAfg");
	this.shape_79.setTransform(56.975,16.775);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgTAfQgEgDgDgFQgEgGAAgIIAAgqIAOAAIAAAmQAAAJAEAEQAEAEAHAAQAFAAAFgDQAEgCACgGQADgFAAgGIAAghIANAAIAABBIgNAAIAAgQQgEAJgFAEQgHAFgIAAQgHAAgGgDg");
	this.shape_80.setTransform(50.05,16.925);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgPAuQgHgBgEgDIAAgLQALAFANAAQAJAAAGgEQAGgFAAgLIAAgKQgDAHgGAEQgGAEgHAAQgIAAgHgEQgGgDgEgHQgDgHAAgLQAAgMADgIQAEgHAGgEQAHgEAIAAQAHAAAGAEQAHAEACAIIAAgOIANAAIAAA8QAAALgEAHQgFAHgIADQgHADgJAAQgHAAgHgBgAgNgdQgFAGAAAMQAAALAFAEQAFAFAIAAQAFAAAFgCQAEgCADgFQACgDAAgGIAAgDQAAgLgFgGQgFgFgJAAQgIAAgFAFg");
	this.shape_81.setTransform(41.975,18.075);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgVAaQgJgJAAgRQAAgKAEgIQAEgIAIgEQAHgEAJAAQAOAAAIAIQAHAIAAAOIAAAHIgwAAQAAAIADAEQACAFAFACQAFACAHAAQAOAAAKgGIAAALQgEACgHACQgHACgIAAQgPAAgJgJgAATgFQAAgTgSAAQgHAAgFAFQgFAFgBAJIAkAAIAAAAg");
	this.shape_82.setTransform(34.525,16.825);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgPAhQgHgCgEgCIAAgMQAFADAGACQAHACAHAAQAHAAAEgCQAEgDABgEQgBgEgCgCQgCgCgGgBIgMgCQgKgBgEgEQgEgEgBgIQAAgKAIgFQAGgGANAAQAHAAAHACQAGABAFADIgBALQgLgGgNAAQgFAAgEADQgEACAAAFQAAADACACQADACAFABIAKABQAHABAFACQAEACADADQABAEAAAFQAAALgHAFQgIAGgMAAQgJAAgGgCg");
	this.shape_83.setTransform(27.6,16.825);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgGAvIAAhdIANAAIAABdg");
	this.shape_84.setTransform(19.325,15.475);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgVAaQgJgJAAgRQAAgKAEgIQAEgIAIgEQAHgEAJAAQAOAAAIAIQAHAIAAAOIAAAHIgwAAQAAAIADAEQACAFAFACQAFACAHAAQAOAAAKgGIAAALQgEACgHACQgHACgIAAQgPAAgJgJgAATgFQAAgTgSAAQgHAAgFAFQgFAFgBAJIAkAAIAAAAg");
	this.shape_85.setTransform(13.975,16.825);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AARAiIAAgmQAAgRgPAAQgFAAgEACQgEAEgCAEQgDAGAAAHIAAAgIgOAAIAAhBIAOAAIAAAQQADgJAGgFQAHgEAHAAQAHAAAGADQAFADADAFQACAGABAJIAAApg");
	this.shape_86.setTransform(3.15,16.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAJAAAQQAAARgJAJQgJAJgQAAQgPAAgJgJgAgPgQQgFAGAAAKQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgKgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_87.setTransform(-4.825,16.825);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgPAhQgHgCgEgCIAAgMQAFADAHACQAFACAIAAQAHAAAEgCQAFgDgBgEQABgEgDgCQgDgCgFgBIgLgCQgLgBgEgEQgFgEABgIQAAgKAGgFQAIgGAMAAQAIAAAFACQAHABAEADIgBALQgKgGgMAAQgGAAgFADQgEACABAFQAAADACACQACACAGABIAKABQAHABAFACQAFACABADQADAEAAAFQAAALgIAFQgIAGgNAAQgHAAgHgCg");
	this.shape_88.setTransform(-12.05,16.825);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgNAlQgJgJgDgPIgLAAIACgIIAIAAIAAgEIAAgFIgKAAIACgJIAJAAQADgOAKgIQAKgIAOAAQAHAAAGABIALAFIAAANQgFgEgFgCQgGgBgHAAQgTAAgFASIAdAAIAAAJIgeAAIAAAFIAAAEIAeAAIAAAIIgdAAQACAKAGAFQAGAFAKgBQAIAAAFgCIALgFIAAANQgFADgGABQgGACgIABQgPgBgKgHg");
	this.shape_89.setTransform(-22.975,15.85);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgTApQgIgDgEgGQgEgFAAgHQAAgFACgFQADgEAEgDQAFgDAGAAQgIgCgFgGQgFgFAAgHQAAgHAEgFQAFgFAHgEQAIgCAJAAQAKAAAIACQAIAEAEAFQAEAFAAAHQAAAHgFAGQgEAEgJACQAGABAFADQAFADACAEQACAFAAAFQAAAHgEAFQgEAGgIADQgJADgLAAQgKAAgJgDgAgPAJQgGADAAAHQAAAHAGAEQAFADAKAAQALAAAGgDQAFgEAAgHQAAgPgWAAQgKAAgFAFgAgOgdQgEAEAAAGQAAAGAEADQAFAEAJAAQAKAAAFgEQAFgDAAgGQAAgHgFgDQgFgDgKAAQgJAAgFADg");
	this.shape_90.setTransform(-31.375,15.85);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgeAsIAAgLIAbgYIAKgKIAGgIQACgEAAgFQAAgGgEgDQgFgDgHAAQgHAAgIACQgHACgGAFIAAgNQAMgJARAAQAJAAAHADQAGADAEAFQADAGAAAHQAAAGgDAGQgDAGgFAFIgNAMIgQAQIAqAAIAAAMg");
	this.shape_91.setTransform(-39.225,15.775);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgJASIAGgjIANAAIgKAjg");
	this.shape_92.setTransform(-44.675,20.475);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AAIArIAAgSIguAAIAAgKIAqg5IASAAIAAA4IARAAIAAALIgRAAIAAASgAgXAOIAfAAIAAgsg");
	this.shape_93.setTransform(-50.525,15.85);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AAGArIAAhFIgZAFIAAgNIAngIIAABVg");
	this.shape_94.setTransform(-58.025,15.85);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgPAhQgGgCgFgCIAAgMQAFADAGACQAHACAHAAQAHAAAEgCQAFgDAAgEQAAgEgDgCQgCgCgHgBIgLgCQgKgBgEgEQgEgEAAgIQgBgKAIgFQAGgGANAAQAIAAAFACQAHABAFADIgBALQgLgGgNAAQgGAAgDADQgFACAAAFQAAADADACQADACAFABIAKABQAHABAFACQAFACACADQABAEABAFQgBALgHAFQgIAGgMAAQgJAAgGgCg");
	this.shape_95.setTransform(-67.1,16.825);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgVAaQgJgJAAgRQAAgKAEgIQAEgIAIgEQAHgEAJAAQAOAAAIAIQAHAIAAAOIAAAHIgwAAQAAAIADAEQACAFAFACQAFACAHAAQAOAAAKgGIAAALQgEACgHACQgHACgIAAQgPAAgJgJgAATgFQAAgTgSAAQgHAAgFAFQgFAFgBAJIAkAAIAAAAg");
	this.shape_96.setTransform(-74.075,16.825);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgGAvIAAhdIANAAIAABdg");
	this.shape_97.setTransform(-79.425,15.475);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgWAdQgGgFABgJQgBgKAHgFQAGgEAMAAIAPAAIACgBIABgCIAAgDQAAgGgEgDQgDgDgIAAQgGAAgHACIgKAEIAAgMIALgEQAGgCAIAAQANAAAGAGQAIAGgBALIAAAsIgMAAIAAgOQgDAIgFAEQgHAEgIAAQgKAAgFgGgAgMAGQgDADgBAFQABAFADADQADADAGAAQAFAAAEgCQAEgDACgEQADgEAAgGIAAgCIgQAAQgIAAgDACg");
	this.shape_98.setTransform(-84.75,16.825);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgTAfQgEgDgEgFQgCgGAAgIIAAgqIANAAIAAAmQAAAJAEAEQAEAEAHAAQAFAAAEgDQAEgCADgGQADgFgBgGIAAghIAOAAIAABBIgOAAIAAgQQgCAJgHAEQgGAFgIAAQgHAAgGgDg");
	this.shape_99.setTransform(-92.1,16.925);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgSAaQgJgJABgRQgBgQAJgJQAJgJAPAAQAGAAAFACIAKADIAAAMIgJgEQgFgBgGAAQgJAAgGAFQgGAGAAALQAAAMAGAGQAGAFAJAAQAHAAAFgBIAJgEIAAALIgKAEQgFACgHAAQgPAAgJgJg");
	this.shape_100.setTransform(-99.25,16.825);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgPAhQgGgCgFgCIAAgMQAFADAHACQAFACAIAAQAHAAAEgCQAEgDABgEQgBgEgCgCQgDgCgFgBIgMgCQgJgBgFgEQgEgEgBgIQAAgKAHgFQAIgGAMAAQAHAAAHACQAGABAEADIAAALQgLgGgNAAQgGAAgEADQgDACAAAFQAAADACACQADACAFABIAKABQAIABAEACQAEACACADQACAEAAAFQABALgIAFQgIAGgNAAQgHAAgHgCg");
	this.shape_101.setTransform(-109.1,16.825);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgYAaQgJgJAAgRQAAgQAJgJQAJgJAPAAQAQAAAJAJQAJAJAAAQQAAARgJAJQgJAJgQAAQgPAAgJgJgAgPgQQgFAGAAAKQAAAMAFAFQAFAGAKAAQAKAAAGgGQAFgFAAgMQAAgKgFgGQgFgGgLAAQgKAAgFAGg");
	this.shape_102.setTransform(-116.325,16.825);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AgGAvIAAhdIANAAIAABdg");
	this.shape_103.setTransform(-121.975,15.475);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgVAaQgJgJAAgRQAAgKAEgIQAEgIAIgEQAHgEAJAAQAOAAAIAIQAHAIAAAOIAAAHIgwAAQAAAIADAEQACAFAFACQAFACAHAAQAOAAAKgGIAAALQgEACgHACQgHACgIAAQgPAAgJgJgAATgFQAAgTgSAAQgHAAgFAFQgFAFgBAJIAkAAIAAAAg");
	this.shape_104.setTransform(-130.625,16.825);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgSAsQgGgEgFgHQgDgIAAgLQAAgMADgHQAFgIAGgEQAGgEAJAAQAHAAAHAEQAFADAEAJIAAgpIANAAIAABcIgMAAIAAgPQgDAIgGAEQgHAFgIAAQgJAAgGgEgAgNgDQgGAEAAANQAAALAGAGQAFAFAIAAQAGAAAEgDQAFgCACgFQADgFAAgGIAAgDQAAgLgGgEQgEgGgKAAQgIAAgFAGg");
	this.shape_105.setTransform(-138.6,15.55);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgKAiQgHgPAAgTQAAgRAHgQQAIgPAOgKIAGAIQgMAKgFAMQgFANAAAPQAAAQAFAMQAFANAMAKIgGAIQgOgLgIgOg");
	this.shape_106.setTransform(-144.4,16.35);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AAAANIgOAfIgWgRIAYgXIghgEIAJgbIAdARIgHghIAdAAIgHAhIAdgRIAJAbIghAEIAZAXIgXARg");
	this.shape_107.setTransform(173.2,-11.925);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgwAzIAAgcQATALAaAAQAUAAAAgKQAAgIgOgCIgRgCQgjgFAAgdQAAgmAyAAQAbAAAQAJIgCAcQgSgKgWAAQgSAAAAALQAAAHAOACIAPACQAUADAIAHQAJAGAAAPQAAApg0AAQgdAAgRgKg");
	this.shape_108.setTransform(162,-7.325);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgmAtQgRgPAAgeQAAgcARgRQARgPAZAAQAZAAAOAOQANAOAAAaIAAAPIhNAAQACAOAIAGQAHAFAQAAQAYAAARgJIAAAaQgRAKgdAAQgdAAgQgQgAAagMQAAgXgXgBQgUABgEAXIAvAAIAAAAg");
	this.shape_109.setTransform(149.775,-7.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AA4A7IAAhBQAAgXgSAAQgVAAAAAfIAAA5IghAAIAAhBQAAgXgRAAQgWAAAAAfIAAA5IgiAAIAAhzIAhAAIAAAZQAJgbAcgBQAcABAGAbQAKgbAcgBQARAAAKALQAKALAAAVIAABLg");
	this.shape_110.setTransform(133.225,-7.45);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgoBcIA0i3IAdAAIgzC3g");
	this.shape_111.setTransform(118.775,-8.625);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AgsAZIgTAAIAEgSIANAAIgBgHIABgGIgRAAIAEgSIAPAAQAGgZAQgNQASgOAZAAQAXAAATAKIAAAgQgRgNgVAAQgaAAgIAXIAmAAIAAASIgpAAIAAAGIAAAHIApAAIAAASIgmAAQAGAWAcAAQATAAAVgMIAAAeQgSAMgaAAQg3AAgKg0g");
	this.shape_112.setTransform(107.4,-8.925);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgzBFIAAgfQASAJAVAAQAnAAABgtQgEAKgKAFQgLAGgNAAQgYAAgOgMQgOgMAAgXQAAgXAPgOQARgPAbAAQAeAAARAQQATARAAAoQAAAkgRAVQgSAXgkAAQgZAAgSgIgAgagYQAAAWAaAAQAMAAAHgGQAHgFAAgLQAAgLgHgGQgHgHgMAAQgaAAAAAYg");
	this.shape_113.setTransform(92.875,-8.975);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("Ag3BCIADggQAYALAWAAQAagBAAgUQAAgUgjAAQgTAAgRAEIAAhTIBlAAIAAAfIhEAAIAAAYIATgBQA3AAAAAsQAAAZgPAOQgRANgbAAQgcAAgYgJg");
	this.shape_114.setTransform(79.25,-8.8);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AADBKIAAhtIgoAHIAAgiIBLgLIAACTg");
	this.shape_115.setTransform(66.9,-8.925);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AglAmQgOgNAAgZQAAgYAOgNQAOgNAXAAQAYAAAOANQAOANAAAYQAAAZgOANQgOANgYAAQgXAAgOgNgAgWAAQAAAaAWAAQAXAAAAgaQAAgagXAAQgWAAAAAag");
	this.shape_116.setTransform(51.475,-4.425);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgsAZIgTAAIAEgSIANAAIgBgHIABgGIgRAAIAEgSIAPAAQAGgZAQgNQASgOAZAAQAXAAATAKIAAAgQgRgNgVAAQgaAAgIAXIAmAAIAAASIgpAAIAAAGIAAAHIApAAIAAASIgmAAQAGAWAcAAQATAAAVgMIAAAeQgSAMgaAAQg3AAgKg0g");
	this.shape_117.setTransform(33.15,-8.925);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AgvA5QgRgUAAglQAAgkARgUQARgUAeAAQAfAAARAUQARAUAAAkQAAAkgRAVQgRAUgfAAQgeAAgRgUgAgcAAQAAAuAcAAQAdAAAAguQAAgtgdAAQgcAAAAAtg");
	this.shape_118.setTransform(18.475,-8.925);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AgvA5QgRgUAAglQAAgkARgUQARgUAeAAQAfAAARAUQARAUAAAkQAAAkgRAVQgRAUgfAAQgeAAgRgUgAgcAAQAAAuAcAAQAdAAAAguQAAgtgdAAQgcAAAAAtg");
	this.shape_119.setTransform(3.575,-8.925);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AgzBFIAAgfQASAJAVAAQAnAAABgtQgEAKgKAFQgLAGgNAAQgYAAgOgMQgOgMAAgXQAAgXAPgOQARgPAbAAQAeAAARAQQATARAAAoQAAAkgRAVQgSAXgkAAQgZAAgSgIgAgagYQAAAWAaAAQAMAAAHgGQAHgFAAgLQAAgLgHgGQgHgHgMAAQgaAAAAAYg");
	this.shape_120.setTransform(-11.175,-8.975);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AgQAQQgGgGAAgKQAAgIAGgHQAGgFAKAAQALAAAGAFQAGAHAAAIQAAAKgGAGQgGAFgLAAQgKAAgGgFg");
	this.shape_121.setTransform(-21.625,-3.45);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("Ag2BMIAAgbIAsgnQAOgNAFgHQAGgJAAgIQAAgQgWAAQgXAAgXAOIAAggQAXgOAdAAQAZAAAOANQANALAAATQAAARgKAOQgJAMgUASIgRAQIA8AAIAAAfg");
	this.shape_122.setTransform(-31.275,-9.075);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("Ag2BMIAAgbIAsgnQAOgNAFgHQAGgJAAgIQAAgQgWAAQgXAAgXAOIAAggQAXgOAdAAQAZAAAOANQANALAAATQAAARgKAOQgJAMgUASIgRAQIA8AAIAAAfg");
	this.shape_123.setTransform(-44.175,-9.075);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AAjA/Igmg3IghAAIAAA3IgLAAIAAh9IAuAAQAsABAAAiQAAAggjADIAoA3gAgkgBIAlAAQAeAAAAgaQAAgZghAAIgiAAg");
	this.shape_124.setTransform(-60.875,-5.8);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("Ag5AAQAAhAA5AAQA6AAAABAQAABBg6AAQg5AAAAhBgAguAAQAAA3AuAAQAvAAAAg3QAAg1gvAAQguAAAAA1g");
	this.shape_125.setTransform(-74.475,-5.825);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AgrA/IAAh9IAtAAQArABAAAmQgBATgKAKQgLALgVAAIgjAAIAAAugAghAHIAiAAQAhAAAAgeQAAgdghAAIgiAAg");
	this.shape_126.setTransform(-86.9,-5.8);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("Ag5AAQAAhAA5AAQA6AAAABAQAABBg6AAQg5AAAAhBgAguAAQAAA3AuAAQAvAAAAg3QAAg1gvAAQguAAAAA1g");
	this.shape_127.setTransform(-104.825,-5.825);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgmA/IAAh9IALAAIAABzIBCAAIAAAKg");
	this.shape_128.setTransform(-116.575,-5.8);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("Ag5ATQAAhAA5AAQA6AAAABAQAABBg6AAQg5AAAAhBgAguATQAAA3AuAAQAvAAAAg2QAAg2gvAAQguAAAAA1gAgIg6IASgZIANAAIgVAZg");
	this.shape_129.setTransform(-129.225,-7.75);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgsA2IAAgMQATAMAZAAQAjAAAAgZQAAgKgHgFQgFgFgPgDIgWgEQgegEgBgaQAAgQAMgJQAMgKAVAAQAZAAAQAKIAAALQgTgLgWAAQgPAAgJAGQgJAHAAAMQAAAKAGAFQAFAEAMACIAVAEQATADAHAHQAJAIgBANQAAARgMAKQgNAJgUAAQgbAAgRgKg");
	this.shape_130.setTransform(-141.7,-5.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.desde, new cjs.Rectangle(-149.2,-30.4,337.2,100.69999999999999), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgbAhQgGgGAAgLQAAgLAHgFQAHgFANAAIANAAQAFAAAAgEIAAgCQAAgIgOAAQgPAAgLAGIAAgTQAPgGAPAAQAgAAAAAbIAAAwIgVAAIAAgNQgFAPgSAAQgLAAgGgGgAgNAQQAAAIAKAAQAGAAAEgEQAFgEAAgIIAAgBIgOAAQgLAAAAAJg");
	this.shape.setTransform(127.025,-19.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSASIAAgbIgMAAIAAgRIAJAAQADAAAAgEIAAgRIAWAAIAAAVIAcAAIAAARIgcAAIAAAXQgBAQANgBQAIAAAIgCIAAASQgKADgKAAQgeAAAAgeg");
	this.shape_1.setTransform(119.6,-20.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWAmIAAhJIAVAAIAAAUQAEgWAUAAIAAAYQgLAAgGADQgGAEAAAKIAAAig");
	this.shape_2.setTransform(113.45,-19.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgYAdQgLgKAAgTQAAgSALgKQALgKAPAAQARAAAJAJQAIAJAAAQIAAAKIgxAAQABAJAFAEQAFADAKAAQAPAAALgFIAAAQQgLAGgTAAQgSAAgKgKgAARgIQAAgPgPAAQgMAAgDAPIAeAAIAAAAg");
	this.shape_3.setTransform(106.15,-19.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgTA1IAAg4IgLAAIAAgRIAHAAQAEAAAAgEIAAgBQAAgMAIgHQAJgIAOAAQALAAAIACIAAASQgIgDgIAAQgNAAAAANIAAACIAZAAIAAARIgZAAIAAA4g");
	this.shape_4.setTransform(99.025,-21.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgcAdQgLgKABgTQgBgSALgKQAKgKASAAQASAAALAKQALAKAAASQAAATgLAKQgLAKgSAAQgSAAgKgKgAgRAAQAAAUARAAQASAAAAgUQAAgTgSAAQgRAAAAATg");
	this.shape_5.setTransform(91.15,-19.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgbAfQgIgHABgOIAAgvIAVAAIAAApQABAPAMAAQAOAAgBgTIAAglIAXAAIAABJIgWAAIAAgRQgGATgRAAQgMAAgGgHg");
	this.shape_6.setTransform(78.5,-19.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgSASIAAgbIgMAAIAAgRIAJAAQADAAAAgEIAAgRIAWAAIAAAVIAcAAIAAARIgcAAIAAAXQgBAQANgBQAIAAAIgCIAAASQgKADgKAAQgeAAAAgeg");
	this.shape_7.setTransform(70.55,-20.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgbAhQgGgGAAgLQAAgLAHgFQAHgFANAAIANAAQAFAAAAgEIAAgCQAAgIgOAAQgPAAgLAGIAAgTQAPgGAPAAQAgAAAAAbIAAAwIgVAAIAAgNQgFAPgSAAQgLAAgGgGgAgNAQQAAAIAKAAQAGAAAEgEQAFgEAAgIIAAgBIgOAAQgLAAAAAJg");
	this.shape_8.setTransform(59.225,-19.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgSASIAAgbIgMAAIAAgRIAIAAQAEAAAAgEIAAgRIAWAAIAAAVIAcAAIAAARIgcAAIAAAXQgBAQANgBQAIAAAIgCIAAASQgKADgKAAQgdAAgBgeg");
	this.shape_9.setTransform(51.75,-20.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgKA2IAAhJIAVAAIAABJgAgNgpQAAgMANAAQAOAAAAAMQAAANgOAAQgNAAAAgNg");
	this.shape_10.setTransform(46.175,-21.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgUAdQgKgKAAgTQAAgSAKgKQAKgKASAAQALAAALAFIAAATQgIgGgMABQgTAAAAATQAAAUATAAQALAAAKgGIAAATQgKAGgNAAQgSAAgKgKg");
	this.shape_11.setTransform(40.35,-19.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKA2IAAhJIAVAAIAABJgAgNgpQAAgMANAAQAOAAAAAMQAAANgOAAQgNAAAAgNg");
	this.shape_12.setTransform(34.625,-21.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgKA0IAAhnIAVAAIAABng");
	this.shape_13.setTransform(30.5,-21.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgcAdQgLgKABgTQgBgSALgKQAKgKASAAQASAAALAKQALAKAAASQAAATgLAKQgLAKgSAAQgSAAgKgKgAgRAAQAAAUARAAQASAAAAgUQAAgTgSAAQgRAAAAATg");
	this.shape_14.setTransform(24,-19.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgjAqIAAgVQAOAIATABQARAAAAgLQAAgEgCgBQgDgCgIgCIgNgCQgagEAAgXQAAgMAKgJQALgIASAAQAUAAAMAHIgBAUQgRgHgPgBQgPAAAAAKQAAAEADACQADACAGABIAMACQAOACAIAGQAGAGAAAMQAAAPgLAJQgKAHgTAAQgTAAgOgHg");
	this.shape_15.setTransform(15.2,-20.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// border
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,2,0,1).p("AtWiVIatAAIAAErI6tAAg");
	this.shape_16.setTransform(69.15,-17.45,0.8187,1,0,0,0,-2.2,4);

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,-37.4,142,32), null);


(lib.txt21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// letters2
	this.letters1 = new lib.letters1b();
	this.letters1.name = "letters1";
	this.letters1.setTransform(129.8,32.95,1,1,0,0,0,57.1,12.1);

	this.timeline.addTween(cjs.Tween.get(this.letters1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt21, new cjs.Rectangle(-0.7,6.1,579.3000000000001,142), null);


(lib.txt11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// letters2
	this.letters1 = new lib.letters1();
	this.letters1.name = "letters1";
	this.letters1.setTransform(129.8,32.95,1,1,0,0,0,57.1,12.1);

	this.timeline.addTween(cjs.Tween.get(this.letters1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt11, new cjs.Rectangle(-0.7,12.7,579.3000000000001,85), null);


(lib.txt3c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.slash3 = new lib.slash1();
	this.slash3.name = "slash3";
	this.slash3.setTransform(-17.6,26.25,1.0517,1.0572,0,0,0,3.9,6.2);

	this.timeline.addTween(cjs.Tween.get(this.slash3).wait(1));

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag0AAQAAg6A0AAQA1AAAAA6QAAA7g1AAQg0AAAAg7gAgqAAQAAAxAqAAQArAAAAgxQAAgxgrAAQgqAAAAAxg");
	this.shape.setTransform(109.025,43.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAPAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_1.setTransform(96.2,43.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag0AAQAAg6A0AAQA1AAAAA6QAAA7g1AAQg0AAAAg7gAgqAAQAAAxAqAAQArAAAAgxQAAgxgrAAQgqAAAAAxg");
	this.shape_2.setTransform(83.425,43.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_3.setTransform(71.325,43.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_4.setTransform(63.45,43.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgpA5IAAhxIApAAQAmAAAAAcQAAAWgVAGQAZADAAAYQAAAegnAAgAgfAwIAhAAQAeAAAAgWQAAgXgfAAIggAAgAgfgEIAgAAQAbAAAAgXQAAgVgdAAIgeAAg");
	this.shape_5.setTransform(56.225,43.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAFAYIAIgvIALAAIgLAvgAgXAYIAIgvIALAAIgLAvg");
	this.shape_6.setTransform(42.625,40.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgRA5IAvhoIhGAAIAAgJIBRAAIAAAHIgwBqg");
	this.shape_7.setTransform(34.225,43.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AANA5IAAhlIgjAKIAAgKIAtgMIAABxg");
	this.shape_8.setTransform(25.275,43.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_9.setTransform(12.8,43.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgsA5IAAhxIAjAAQA2AAAAA4QAAAcgOAPQgOAOgaAAgAgjAwIAaAAQAsAAAAgwQAAgvgsAAIgaAAg");
	this.shape_10.setTransform(1.875,43.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgJAAIAAhxIAOAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_11.setTransform(179.35,25.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag0ARQAAg5A0AAQA1AAAAA5QAAA8g1AAQg0AAAAg8gAgqARQAAAzAqAAQArgBAAgxQAAgxgrAAQgqAAAAAwgAgHg1IAQgXIAMAAIgTAXg");
	this.shape_12.setTransform(166.575,23.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_13.setTransform(158.05,25.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgbAsQgOgPAAgdQAAgcAOgPQAOgPAVAAQASAAAPAJIAAALQgQgLgPAAQgSAAgLAMQgMANAAAYQAAAZAMANQALAMASAAQAPgBARgKIAAALQgQAJgSAAQgWAAgNgPg");
	this.shape_14.setTransform(150.75,25.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_15.setTransform(139.825,25.425);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_16.setTransform(129.1,25.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_17.setTransform(119.375,25.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_18.setTransform(108.475,25.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_19.setTransform(93.45,25.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgsA5IAAhxIAjAAQA2AAAAA4QAAAcgOAPQgOAOgaAAgAgjAwIAaAAQAsAAAAgwQAAgvgsAAIgaAAg");
	this.shape_20.setTransform(82.525,25.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgpAxIAAgKQATALAVAAQAgAAAAgYQAAgJgFgEQgFgFgNgCIgVgEQgcgEAAgYQAAgOALgJQALgJATAAQAWAAAPAJIAAALQgRgLgUAAQgOAAgJAGQgHAHgBAKQAAAJAGAFQAFAEALACIATAEQARACAHAHQAIAGAAANQAAAPgNAJQgLAJgTAAQgXAAgRgKg");
	this.shape_21.setTransform(67,25.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_22.setTransform(56.225,25.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_23.setTransform(44.775,25.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAOAAIBHBnIAAhnIAKAAIAABxg");
	this.shape_24.setTransform(32.6,25.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_25.setTransform(20.475,25.425);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_26.setTransform(10.425,25.425);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_27.setTransform(0.875,25.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3c, new cjs.Rectangle(-21.7,11.4,214,46.1), null);


(lib.txt3b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.slash3 = new lib.slash1();
	this.slash3.name = "slash3";
	this.slash3.setTransform(-17.6,26.25,1.0517,1.0572,0,0,0,3.9,6.2);

	this.timeline.addTween(cjs.Tween.get(this.slash3).wait(1));

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape.setTransform(224.825,43.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgbAtQgOgQAAgcQAAgcAOgQQAOgPAVAAQARAAARAJIAAAKQgRgKgQAAQgSAAgKANQgMANAAAYQAAAZAMAMQAKALASAAQAQAAARgLIAAALQgQAKgSAAQgWAAgNgOg");
	this.shape_1.setTransform(214,43.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_2.setTransform(206.6,43.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAfA5IgigyIgeAAIAAAyIgKAAIAAhxIAqAAQAoAAAAAgQAAAcggADIAlAygAghAAIAiAAQAcAAAAgYQAAgXgfAAIgfAAg");
	this.shape_3.setTransform(199.45,43.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgpA5IAAhxIApAAQAmAAAAAcQAAAWgVAGQAZADAAAYQAAAegnAAgAgfAwIAhAAQAeAAAAgWQAAgXgfAAIggAAgAgfgEIAgAAQAbAAAAgXQAAgVgdAAIgeAAg");
	this.shape_4.setTransform(188.325,43.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAxA5IAAhlIgvBlIgEAAIgvhlIAABlIgJAAIAAhxIAOAAIAsBiIAthiIAOAAIAABxg");
	this.shape_5.setTransform(174.825,43.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAqBMIgNgiIg6AAIgNAiIgKAAIAuhyIAOAAIAtBygAAZAhIgZhAIgZBAIAyAAgAgGg0IAQgXIAMAAIgTAXg");
	this.shape_6.setTransform(161.525,41.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_7.setTransform(151.475,43.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_8.setTransform(140.575,43.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgJAAIAAhxIANAAIBHBnIAAhnIAJAAIAABxg");
	this.shape_9.setTransform(128.4,43.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_10.setTransform(119.8,43.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_11.setTransform(108.3,43.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgJAAIAAhxIANAAIBHBnIAAhnIAJAAIAABxg");
	this.shape_12.setTransform(96.45,43.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ag0AAQAAg6A0AAQA1AAAAA6QAAA7g1AAQg0AAAAg7gAgqAAQAAAxAqAAQArAAAAgxQAAgxgrAAQgqAAAAAxg");
	this.shape_13.setTransform(83.675,43.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAgA5IAAg1Ig/AAIAAA1IgKAAIAAhxIAKAAIAAA0IA/AAIAAg0IAKAAIAABxg");
	this.shape_14.setTransform(71.45,43.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgoA5IAAhxIAqAAQAmAAAAAkQAAARgKAJQgKAJgSAAIggAAIAAAqgAgeAGIAfAAQAeAAgBgaQABgbgeAAIgfAAg");
	this.shape_15.setTransform(60.6,43.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_16.setTransform(49.125,43.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAfA5IgigyIgeAAIAAAyIgKAAIAAhxIArAAQAnAAAAAgQAAAcggADIAlAygAghAAIAiAAQAcAAAAgYQAAgXgfAAIgfAAg");
	this.shape_17.setTransform(38.45,43.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_18.setTransform(26.675,43.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAxA5IAAhlIgvBlIgEAAIgvhlIAABlIgJAAIAAhxIAOAAIAsBiIAthiIAOAAIAABxg");
	this.shape_19.setTransform(13.375,43.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgpAxIAAgKQATALAVAAQAgAAAAgYQAAgJgFgEQgFgFgNgCIgVgEQgcgEAAgYQAAgOALgJQALgJATAAQAWAAAQAJIgBALQgRgLgUAAQgOAAgJAGQgHAHgBAKQAAAJAGAFQAFAEALACIAUAEQAQACAHAHQAIAGgBANQAAAPgMAJQgLAJgTAAQgYAAgQgKg");
	this.shape_20.setTransform(0.75,43.475);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_21.setTransform(133.175,25.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_22.setTransform(122.95,25.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgsA5IAAhxIAjAAQA2AAAAA4QAAAcgOAPQgOAOgaAAgAgjAwIAaAAQAsAAAAgwQAAgvgsAAIgaAAg");
	this.shape_23.setTransform(112.025,25.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAPAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_24.setTransform(95.05,25.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("Ag0ARQAAg5A0AAQA1AAAAA5QAAA8g1AAQg0AAAAg8gAgqARQAAAzAqAAQArgBAAgxQAAgxgrAAQgqAAAAAwgAgHg1IAQgXIAMAAIgTAXg");
	this.shape_25.setTransform(82.275,23.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_26.setTransform(73.75,25.425);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgbAsQgOgPAAgdQAAgcAOgPQANgPAXAAQAQAAAQAJIAAALQgQgLgPAAQgTAAgKAMQgMANAAAYQAAAZAMANQAKAMATAAQAPgBARgKIAAALQgQAJgRAAQgXAAgNgPg");
	this.shape_27.setTransform(66.45,25.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgbAsQgOgPAAgdQAAgcAOgPQANgPAXAAQAQAAAQAJIAAALQgQgLgPAAQgTAAgKAMQgMANAAAYQAAAZAMANQAKAMATAAQAPgBARgKIAAALQgQAJgRAAQgXAAgNgPg");
	this.shape_28.setTransform(56.1,25.45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_29.setTransform(45.85,25.425);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgFA5IAAgtIgthEIAMAAIAmA7IAng7IAMAAIgvBEIAAAtg");
	this.shape_30.setTransform(35.275,25.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("Ag0AAQAAg6A0AAQA1AAAAA6QAAA7g1AAQg0AAAAg7gAgqAAQAAAyAqAAQArgBAAgxQAAgxgrAAQgqAAAAAxg");
	this.shape_31.setTransform(23.775,25.45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAfA5IgigyIgeAAIAAAyIgKAAIAAhxIArAAQAnAAAAAgQAAAcggADIAlAygAghAAIAiAAQAcAAAAgYQgBgXgdAAIggAAg");
	this.shape_32.setTransform(12.45,25.425);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgnA5IAAhxIApAAQAnAAAAAkQAAARgLAJQgJAJgTAAIgfAAIAAAqgAgdAGIAeAAQAdAAAAgaQAAgbgdAAIgeAAg");
	this.shape_33.setTransform(1.4,25.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3b, new cjs.Rectangle(-21.7,11.4,254.39999999999998,46.1), null);


(lib.txt3a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.slash3 = new lib.slash1();
	this.slash3.name = "slash3";
	this.slash3.setTransform(-17.6,26.25,1.0518,1.0572,0,0,0,3.9,6.2);

	this.timeline.addTween(cjs.Tween.get(this.slash3).wait(1));

	// Warstwa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoAxIAAgKQASALAVAAQAgAAAAgYQAAgJgFgEQgGgFgMgCIgUgEQgcgEAAgYQgBgOALgJQALgJATAAQAWAAAPAJIAAALQgRgLgUAAQgOAAgIAGQgIAHAAAKQgBAJAGAFQAFAEALACIATAEQARACAHAHQAIAGAAANQgBAPgMAJQgLAJgTAAQgXAAgQgKg");
	this.shape.setTransform(116.7,61.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_1.setTransform(106.6,61.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgiA5IAAhxIAKAAIAABoIA7AAIAAAJg");
	this.shape_2.setTransform(96.875,61.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_3.setTransform(85.975,61.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAgA5IgigyIgfAAIAAAyIgKAAIAAhxIArAAQAnAAAAAgQAAAcggADIAlAygAghAAIAhAAQAcAAAAgYQAAgXgdAAIggAAg");
	this.shape_4.setTransform(75.3,61.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_5.setTransform(63.475,61.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape_6.setTransform(52.75,61.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAxA5IAAhlIgvBlIgEAAIgvhlIAABlIgJAAIAAhxIAOAAIAsBiIAthiIAOAAIAABxg");
	this.shape_7.setTransform(39.775,61.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_8.setTransform(30,61.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAgA5IgjgyIgeAAIAAAyIgKAAIAAhxIAqAAQAoAAAAAgQAAAcggADIAlAygAghAAIAhAAQAdAAAAgYQgBgXgeAAIgfAAg");
	this.shape_9.setTransform(22.85,61.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_10.setTransform(11.75,61.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgnA5IAAhxIApAAQAnAAAAAkQAAARgLAJQgJAJgTAAIgfAAIAAAqgAgdAGIAeAAQAdAAAAgaQAAgbgdAAIgeAAg");
	this.shape_11.setTransform(1.4,61.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgoAxIAAgKQARALAWAAQAgAAAAgYQAAgJgFgEQgGgFgNgCIgTgEQgcgEAAgYQAAgOAKgJQALgJATAAQAWAAAQAJIgBALQgRgLgUAAQgOAAgIAGQgJAHABAKQAAAJAFAFQAFAEAKACIAVAEQAPACAIAHQAHAGAAANQABAPgMAJQgMAJgTAAQgYAAgPgKg");
	this.shape_12.setTransform(199.8,43.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape_13.setTransform(189.7,43.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAgA5IgigyIgfAAIAAAyIgKAAIAAhxIAqAAQAoAAAAAgQAAAcggADIAlAygAghAAIAhAAQAcAAAAgYQAAgXgdAAIggAAg");
	this.shape_14.setTransform(179.35,43.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Ag0AAQAAg6A0AAQA1AAAAA6QAAA7g1AAQg0AAAAg7gAgqAAQAAAxAqAAQArAAAAgxQAAgxgrAAQgqAAAAAxg");
	this.shape_15.setTransform(166.925,43.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgpAxIAAgKQATALAVAAQAgAAAAgYQAAgJgFgEQgFgFgNgCIgVgEQgcgEAAgYQAAgOALgJQALgJATAAQAWAAAQAJIgBALQgRgLgUAAQgOAAgJAGQgHAHgBAKQAAAJAGAFQAFAEALACIAUAEQAQACAHAHQAIAGgBANQAAAPgMAJQgLAJgTAAQgYAAgQgKg");
	this.shape_16.setTransform(155.55,43.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAPAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_17.setTransform(144,43.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape_18.setTransform(132.55,43.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgpAxIAAgKQASALAWAAQAgAAAAgYQAAgJgFgEQgFgFgNgCIgVgEQgcgEAAgYQAAgOALgJQALgJATAAQAWAAAQAJIgBALQgRgLgUAAQgOAAgJAGQgHAHgBAKQABAJAFAFQAFAEALACIAUAEQAPACAIAHQAIAGgBANQAAAPgLAJQgMAJgTAAQgYAAgQgKg");
	this.shape_19.setTransform(122.15,43.475);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAPAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_20.setTransform(106.3,43.475);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("Ag0AAQAAg6A0AAQA1AAAAA6QAAA7g1AAQg0AAAAg7gAgqAAQAAAxAqAAQArAAAAgxQAAgxgrAAQgqAAAAAxg");
	this.shape_21.setTransform(93.525,43.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgbAtQgOgQAAgcQAAgcAOgQQANgPAWAAQASAAAQAJIAAAKQgRgKgQAAQgRAAgLANQgMANAAAYQAAAZAMAMQALALARAAQAQAAARgLIAAALQgQAKgSAAQgWAAgNgOg");
	this.shape_22.setTransform(82.05,43.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_23.setTransform(66.825,43.475);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAgA5IgigyIgfAAIAAAyIgKAAIAAhxIAqAAQAoAAAAAgQAAAcggADIAlAygAghAAIAhAAQAdAAAAgYQgBgXgeAAIgfAAg");
	this.shape_24.setTransform(56.15,43.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA4AAIAAAIIg4AAIAAAuIA/AAIAAAJg");
	this.shape_25.setTransform(45.05,43.475);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgoAxIAAgKQARALAWAAQAgAAAAgYQAAgJgFgEQgGgFgNgCIgUgEQgbgEAAgYQAAgOAKgJQALgJATAAQAWAAAQAJIgBALQgRgLgUAAQgOAAgIAGQgJAHABAKQAAAJAFAFQAFAEAKACIAVAEQAPACAIAHQAHAGAAANQABAPgMAJQgMAJgTAAQgYAAgPgKg");
	this.shape_26.setTransform(34.65,43.475);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_27.setTransform(23.875,43.475);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAgA5IgigyIgfAAIAAAyIgKAAIAAhxIArAAQAnAAAAAgQAAAcggADIAlAygAghAAIAhAAQAcAAAAgYQAAgXgdAAIggAAg");
	this.shape_28.setTransform(13.2,43.475);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgEA5IAAhoIgsAAIAAgJIBhAAIAAAJIgsAAIAABog");
	this.shape_29.setTransform(1.375,43.475);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAiA5IhHhmIAABmIgKAAIAAhxIAPAAIBGBnIAAhnIAKAAIAABxg");
	this.shape_30.setTransform(145.9,25.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("Ag0ARQAAg5A0AAQA1AAAAA5QAAA8g1AAQg0AAAAg8gAgqARQAAAzAqAAQArgBAAgxQAAgxgrAAQgqAAAAAwgAgHg1IAQgXIAMAAIgTAXg");
	this.shape_31.setTransform(133.125,23.65);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_32.setTransform(124.6,25.425);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgpAxIAAgKQATALAVAAQAgAAAAgYQAAgJgFgEQgFgFgNgCIgVgEQgcgEAAgYQAAgOALgJQALgJATAAQAWAAAPAJIAAALQgRgLgUAAQgOAAgJAGQgHAHgBAKQAAAJAGAFQAFAEALACIATAEQARACAHAHQAIAGAAANQAAAPgNAJQgLAJgTAAQgXAAgRgKg");
	this.shape_33.setTransform(117.4,25.425);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgEA5IAAhxIAJAAIAABxg");
	this.shape_34.setTransform(110.15,25.425);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgHA5IgqhxIALAAIAmBqIAnhqIALAAIgsBxg");
	this.shape_35.setTransform(102.625,25.425);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgkA5IAAhxIBJAAIAAAJIg/AAIAAApIA5AAIAAAIIg5AAIAAAuIA/AAIAAAJg");
	this.shape_36.setTransform(87.9,25.425);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgsA5IAAhxIAjAAQA2AAAAA4QAAAcgOAPQgOAOgaAAgAgjAwIAaAAQAsAAAAgwQAAgvgsAAIgaAAg");
	this.shape_37.setTransform(76.975,25.425);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_38.setTransform(60.775,25.425);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AAgA5IgigyIgfAAIAAAyIgKAAIAAhxIArAAQAnAAAAAgQAAAcggADIAlAygAghAAIAhAAQAcAAAAgYQAAgXgdAAIggAAg");
	this.shape_39.setTransform(50.1,25.425);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAqA5IgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAPIgZhAIgZBAIAyAAg");
	this.shape_40.setTransform(38.325,25.425);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAxA5IAAhlIgvBlIgEAAIgvhlIAABlIgJAAIAAhxIAOAAIAsBiIAthiIAOAAIAABxg");
	this.shape_41.setTransform(25.025,25.425);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAqBMIgNghIg6AAIgNAhIgKAAIAuhxIAOAAIAtBxgAAZAiIgZhAIgZBAIAyAAgAgGg0IAQgXIAMAAIgTAXg");
	this.shape_42.setTransform(11.725,23.55);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgbAsQgOgPAAgdQAAgcAOgPQAOgPAVAAQASAAAPAJIAAALQgQgLgPAAQgSAAgLAMQgMANAAAYQAAAZAMANQALAMASAAQAPgBARgKIAAALQgQAJgSAAQgWAAgNgPg");
	this.shape_43.setTransform(0.9,25.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt3a, new cjs.Rectangle(-21.7,11.4,233,64.1), null);


(lib.txt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// slash3
	this.slash3 = new lib.slash1();
	this.slash3.name = "slash3";
	this.slash3.setTransform(3.45,-12.65,1.6684,1.6739,0,0,0,4,6);

	this.timeline.addTween(cjs.Tween.get(this.slash3).wait(1));

	// slash3Guide
	this.slash3Guide = new lib.slash1();
	this.slash3Guide.name = "slash3Guide";
	this.slash3Guide.setTransform(222.4,-12.65,1.6736,1.674,0,0,0,4.2,6);

	this.timeline.addTween(cjs.Tween.get(this.slash3Guide).wait(1));

	// letters2
	this.letters2 = new lib.letters2b();
	this.letters2.name = "letters2";
	this.letters2.setTransform(-1.5,-42);

	this.timeline.addTween(cjs.Tween.get(this.letters2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(-3.2,-33.9,234.7,42), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// slash3
	this.slash3 = new lib.slash1();
	this.slash3.name = "slash3";
	this.slash3.setTransform(3.45,-12.65,1.6684,1.6739,0,0,0,4,6);

	this.timeline.addTween(cjs.Tween.get(this.slash3).wait(1));

	// slash3Guide
	this.slash3Guide = new lib.slash1();
	this.slash3Guide.name = "slash3Guide";
	this.slash3Guide.setTransform(199.4,-12.65,1.6736,1.674,0,0,0,4.2,6);

	this.timeline.addTween(cjs.Tween.get(this.slash3Guide).wait(1));

	// letters2
	this.letters2 = new lib.letters2();
	this.letters2.name = "letters2";
	this.letters2.setTransform(-1.5,-42);

	this.timeline.addTween(cjs.Tween.get(this.letters2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(-3.2,-33.9,211.7,42), null);


// stage content:
(lib._300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var img1 = this.img1;
		var cta = this.cta;
		var logo = this.logo;
		var square_logo = this.square_logo;
		var legal = this.legal;
		
		//var txt1 = this.txt1;
		//var txt11 = this.txt11;
		var txt2 = this.txt2;
		var txt21 = this.txt21;
		var txt3 = this.txt3;
		var txt31 = this.txt31;
		var txt3a = this.txt3a;
		var txt3b = this.txt3b;
		var txt3c = this.txt3c;
		var desde = this.desde;
		
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf, options) {
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf, options);
			}
		}
		
		
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat:-1, repeatDelay:7});
		
		var hit = this.hit;
		hit.addEventListener("mouseover", function() {
			tl.pause();
		});
		
		hit.addEventListener("mouseout", function() {
			tl.play();
		});
		
		tl
			.set([txt2.slash3Guide, txt3.slash3Guide], { visible: false })
		    //.set([slash3], { alpha: 0 })
		
			.add("frame1")
			.from(img1, 1, {alpha: 0, ease: Power2.easeOut}, "frame1")
			.from([txt3, txt31], 1, {alpha:0, y: "-=10", ease: Power2.easeOut}, "frame1+=.5")
		    .to([txt3.slash3], .5, { alpha:1, x:txt3.slash3Guide.x, y:txt3.slash3Guide.y, ease: Power0.easeNone}, "frame1+=1.5")
		    .from(txt3.letters2.children, .5/(txt3.letters2.children.length-1), {stagger:.5/(txt3.letters2.children.length-1), alpha:0, ease: Power0.easeNone}, "frame1+=1.5")
			.from([desde, square_logo], 1, {alpha:0, y: "-=10", ease: Power2.easeOut}, "frame1+=2")
			.from(cta, 1, { alpha: 0, y: "-=10", ease: Power2.easeOut}, "frame1+=2.5")
		
			.add(autoShot)
		    .add('frame2', '+=2.5')
			.to([txt3,txt31,cta, desde, square_logo], .5, {alpha:0, ease: Power2.easeOut}, "frame2")
			.from([txt3a], 1, {alpha:0, y: "-=10", ease: Power2.easeOut}, "frame2+=.5")
			.from([txt3b], 1, {alpha:0, y: "-=10", ease: Power2.easeOut}, "frame2+=1.5")
			.from([txt3c], 1, {alpha:0, y: "-=10", ease: Power2.easeOut}, "frame2+=2.5")
			.to(cta, .5, {alpha: 1, ease: Power2.easeOut}, "frame2+=3.5")
		
			.add(autoShot)
			.add("frame3", "+=2")
			.to([txt3a, txt3b, txt3c], .5, {alpha:0, ease: Power2.easeOut}, "frame3")
			.from([txt2, txt21], 1, {alpha:0, y: "-=10", ease: Power2.easeOut}, "frame3+=.5")
		    .to([txt2.slash3], .5, { alpha:1, x:txt2.slash3Guide.x, y:txt2.slash3Guide.y, ease: Power0.easeNone}, "frame3+=1.5")
		    .from(txt2.letters2.children, .5/(txt2.letters2.children.length-1), {stagger:.5/(txt2.letters2.children.length-1), alpha:0, ease: Power0.easeNone}, "frame3+=1.5")
		
		.add(autoShot, "+=.2")
			.add("legal", "+=2")
			.to([txt2,txt21,cta], .5, {alpha:0, ease: Power2.easeOut}, "legal")
			.from([legal], .5, {alpha:0, ease: Power2.easeOut}, "legal+=.5")
			.from(hit, .1, { y:"+="+h }, "legal+=1")
		
			.call(autoShot, [true],"+=1")
			;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logo = new lib.opel_new();
	this.logo.name = "logo";
	this.logo.setTransform(147,543.85,0.8396,0.8398,0,0,0,29.4,26);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// hit
	this.hit = new lib.hit();
	this.hit.name = "hit";
	this.hit.setTransform(148.25,293.1,1,2.5441,0,0,0,136,111.5);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// legal
	this.legal = new lib.legal();
	this.legal.name = "legal";
	this.legal.setTransform(358,127.35,1,1,0,0,0,350,118);

	this.timeline.addTween(cjs.Tween.get(this.legal).wait(1));

	// square_logo
	this.square_logo = new lib.square_logo();
	this.square_logo.name = "square_logo";
	this.square_logo.setTransform(82.15,219.2,0.75,0.75,0,0,0,67.2,23.4);

	this.timeline.addTween(cjs.Tween.get(this.square_logo).wait(1));

	// txt31
	this.txt31 = new lib.txt11();
	this.txt31.name = "txt31";
	this.txt31.setTransform(33.35,20.85,0.48,0.4796,0,0,0,75.7,14.3);

	this.timeline.addTween(cjs.Tween.get(this.txt31).wait(1));

	// txt3
	this.txt3 = new lib.txt1();
	this.txt3.name = "txt3";
	this.txt3.setTransform(29.6,107.55,1,1,0,0,0,0.2,27.2);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// desde
	this.desde = new lib.desde();
	this.desde.name = "desde";
	this.desde.setTransform(37.15,99.85,0.75,0.7499,0,0,0,-143.8,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.desde).wait(1));

	// txt21
	this.txt21 = new lib.txt21();
	this.txt21.name = "txt21";
	this.txt21.setTransform(36.35,32.85,0.48,0.4796,0,0,0,75.7,14.3);

	this.timeline.addTween(cjs.Tween.get(this.txt21).wait(1));

	// txt2
	this.txt2 = new lib.txt2();
	this.txt2.name = "txt2";
	this.txt2.setTransform(34.6,145.55,1,1,0,0,0,0.2,27.2);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// txt3c
	this.txt3c = new lib.txt3c();
	this.txt3c.name = "txt3c";
	this.txt3c.setTransform(252,160.55,1,1,0,0,0,197.5,24.7);

	this.timeline.addTween(cjs.Tween.get(this.txt3c).wait(1));

	// txt3b
	this.txt3b = new lib.txt3b();
	this.txt3b.name = "txt3b";
	this.txt3b.setTransform(252,113.55,1,1,0,0,0,197.5,24.7);

	this.timeline.addTween(cjs.Tween.get(this.txt3b).wait(1));

	// txt3a
	this.txt3a = new lib.txt3a();
	this.txt3a.name = "txt3a";
	this.txt3a.setTransform(252,48.5,1,1,0,0,0,197.5,24.7);

	this.timeline.addTween(cjs.Tween.get(this.txt3a).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(116.9,499.05,1,1.0001,0,0,0,37.9,8.8);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// img1
	this.img1 = new lib.img1();
	this.img1.name = "img1";
	this.img1.setTransform(154,333,1,1,0,0,0,154,333);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(150,300,150,300.1);
// library properties:
lib.properties = {
	id: 'C24CD912A357430CB2AAC859A7EB09C3',
	width: 300,
	height: 600,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"index_atlas_P_1.png", id:"index_atlas_P_1"},
		{src:"index_atlas_NP_1.jpg", id:"index_atlas_NP_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C24CD912A357430CB2AAC859A7EB09C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;