(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bd = function() {
	this.initialize(img.bd);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,236,255);


(lib.kvfond = function() {
	this.initialize(img.kvfond);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteBox = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A8eIoIAAxPMA49AAAIAARPg");
	this.shape.setTransform(182.325,55.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteBox, new cjs.Rectangle(0,0,364.7,110.5), null);


(lib.txt2a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bold
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BD2F27").s().p("AgbAjIAAgLIAmguIglAAIAAgMIA1AAIAAAKIgmAvIAnAAIAAAMg");
	this.shape.setTransform(86.975,24.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BD2F27").s().p("AgPAfQgIgEgFgJQgFgIABgKQgBgJAFgJQAFgIAHgEQAIgFAJAAQAPAAAJAIQAIAJAAARIAAAEIg1AAIADAJQAEAGAEADQAGADAGAAQAIAAAFgDIAIgIIAJAHQgFAHgHAFQgIAEgLAAQgJAAgIgFgAAUgHQgBgHgDgEQgFgGgKABQgFgBgFAEQgFADgDAFIgCAFIAnAAIAAAAg");
	this.shape_1.setTransform(79.9,24.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BD2F27").s().p("AgFAjIgchFIAPAAIATA0IATg0IAOAAIgbBFg");
	this.shape_2.setTransform(72.475,24.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BD2F27").s().p("AgWAfQgFgFAAgJQAAgGACgDQABgEAGgCQAFgDAIgBIAVgEIAAgFQAAgHgEgDQgDgCgIAAQgHAAgDABQgDACgCAEIgMgEQADgIAHgDQAHgEAKAAQAJAAAGADQAGACAEAFQACAFAAAIIAAAuIgKAAIgCgGQgFAEgHACQgEACgGAAQgJAAgHgFgAgCAHQgIABgCADQgCACgBAEQAAAEAEACQACACAFAAQAFAAAFgCQAFgCAFgEIAAgOg");
	this.shape_3.setTransform(61.6,24.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BD2F27").s().p("AARAjIAAgpQAAgJgDgEQgDgEgKAAQgFAAgEADQgEACgEAFIAAAwIgOAAIAAhEIALAAIACAHIAKgGQAFgCAGAAQAIAAAGACQAGACADAGQAEAGgBALIAAAqg");
	this.shape_4.setTransform(54.3,24.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BD2F27").s().p("AgQAhQgHgDgCgFQgEgHAAgKIAAgrIANAAIAAAqQABAJADAEQAEAEAIAAQAEAAAFgDQAEgCAEgEIAAgyIANAAIAABFIgLAAIgBgGQgFADgFACQgFACgGABQgIgBgFgCg");
	this.shape_5.setTransform(46.2,24.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BD2F27").s().p("AARAjIAAgpQAAgJgDgEQgEgEgJAAQgFAAgEADQgFACgDAFIAAAwIgNAAIAAhEIAKAAIACAHIAJgGQAGgCAHAAQAHAAAGACQAGACADAGQAEAGAAALIAAAqg");
	this.shape_6.setTransform(34.8,24.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BD2F27").s().p("AgVAfQgHgFAAgJQAAgGACgDQADgEAEgCQAGgDAJgBIATgEIAAgFQAAgHgDgDQgDgCgJAAQgGAAgEABQgDACgBAEIgMgEQACgIAIgDQAIgEAJAAQAJAAAGADQAGACADAFQADAFABAIIAAAuIgLAAIgCgGQgGAEgFACQgFACgGAAQgKAAgFgFgAgCAHQgHABgDADQgCACAAAEQAAAEADACQACACAFAAQAFAAAFgCQAFgCAEgEIAAgOg");
	this.shape_7.setTransform(26.9,24.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BD2F27").s().p("AgOAhQgHgCgFgEIAGgKQAEAEAGACQAGABAFAAQAHAAADgBQADgDAAgEQAAgDgCgCQgCgDgGgCIgJgDQgIgCgFgEQgFgFAAgIQAAgGADgEQADgEAFgDQAGgCAHAAQAHAAAGACQAGACAFADIgIAKQgDgDgFgBIgJgBQgFAAgDACQgCACAAADQAAADACACIAIAFIAJADQAJACAEAFQAFAFAAAHQAAAJgHAGQgGAFgNAAQgIAAgHgDg");
	this.shape_8.setTransform(20.425,24.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BD2F27").s().p("AgVAfQgHgFABgJQAAgGABgDQADgEAFgCQAFgDAIgBIAVgEIAAgFQgBgHgDgDQgDgCgJAAQgGAAgDABQgDACgCAEIgMgEQACgIAIgDQAHgEAKAAQAJAAAGADQAGACAEAFQACAFAAAIIAAAuIgKAAIgCgGQgFAEgGACQgFACgGAAQgKAAgFgFgAgCAHQgIABgCADQgDACAAAEQAAAEAEACQACACAFAAQAFAAAFgCQAFgCAFgEIAAgOg");
	this.shape_9.setTransform(13.55,24.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BD2F27").s().p("AggAzIAAhkIAKAAIACAHQAEgDAFgDQAGgCAFAAQAKAAAHAFQAHAEAFAJQAEAIAAAKQAAALgEAHQgFAIgIAEQgIAFgIAAQgGAAgGgCIgHgEIAAAkgAgLgkQgEACgEAEIAAAfQADAEAFACQAEACAGAAQAGAAAEgDQAFgDADgEQADgGAAgHQAAgHgDgFQgDgGgEgDQgFgDgGAAQgFAAgFACg");
	this.shape_10.setTransform(6.375,26.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BD2F27").s().p("AgRAfQgIgEgFgJQgEgIgBgKQABgJAEgJQAFgHAIgFQAIgFAJAAQAKAAAIAFQAIAEAFAIQAEAJAAAJQAAAKgEAIQgFAJgIAEQgIAFgKAAQgJAAgIgFgAgKgUQgGADgCAGQgDAFAAAGQAAAHADAFQACAFAGAEQAEADAGAAQAGAAAFgDQAGgDACgFQADgGABgHQgBgGgDgFQgCgGgGgDQgFgEgGAAQgGAAgEAEg");
	this.shape_11.setTransform(174.65,11.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BD2F27").s().p("AgGAxIAAhhIANAAIAABhg");
	this.shape_12.setTransform(168.875,10.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BD2F27").s().p("AgRAfQgIgEgFgJQgEgIgBgKQABgJAEgJQAFgHAIgFQAIgFAJAAQAKAAAIAFQAIAEAFAIQAEAJAAAJQAAAKgEAIQgFAJgIAEQgIAFgKAAQgJAAgIgFgAgKgUQgFADgDAGQgDAFAAAGQAAAHADAFQADAFAFAEQAEADAGAAQAGAAAFgDQAGgDACgFQAEgGAAgHQAAgGgEgFQgCgGgGgDQgFgEgGAAQgGAAgEAEg");
	this.shape_13.setTransform(163.05,11.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BD2F27").s().p("AgOAiQgHgDgFgEIAGgKQAEAEAGACQAGACAFAAQAHAAADgCQADgDAAgEQAAgDgCgDQgCgCgGgCIgJgDQgIgCgFgEQgFgFAAgIQAAgGADgEQADgFAFgCQAGgCAHAAQAHAAAGACQAGACAFAEIgIAJQgDgDgFgBIgJgCQgFABgDACQgCACAAADQAAADACADIAIADIAJAEQAJACAEAFQAFAEAAAJQAAAJgHAFQgGAFgNAAQgIAAgHgCg");
	this.shape_14.setTransform(155.825,11.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BD2F27").s().p("AgPAfQgIgEgFgJQgFgIABgKQgBgJAFgJQAEgIAJgEQAHgFAJAAQAPAAAJAIQAIAKAAAQIAAAEIg1AAIAEAJQADAFAEAEQAGADAGAAQAHAAAFgDIAIgIIAKAHQgFAHgHAFQgIAEgLAAQgJAAgIgFgAAUgHQgBgHgEgEQgFgGgIAAQgGAAgFAEQgFADgCAGIgDAEIAnAAIAAAAg");
	this.shape_15.setTransform(145.35,11.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BD2F27").s().p("AgQAhQgHgCgCgHQgEgFAAgLIAAgqIAOAAIAAApQAAAJADAEQADAEAJgBQAFAAAEgCQAEgCAEgFIAAgwIANAAIAABEIgLAAIgBgGQgFADgFACQgFADgGAAQgIAAgFgDg");
	this.shape_16.setTransform(137.45,11.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BD2F27").s().p("AAUAzIAAgkQgEADgFACQgFABgGAAQgIAAgIgFQgIgEgEgIQgEgHAAgLQAAgKAEgIQAFgJAIgEQAIgFAJAAQAGAAAFACQAFACADADIABgGIALAAIAABkgAgIgjQgFADgDAGQgDAFAAAHQAAAHADAFQACAFAFADQAFADAFAAQAGAAAFgBQAEgCAEgDIAAgiQgDgEgEgBQgFgCgFAAQgGAAgFADg");
	this.shape_17.setTransform(129.225,13.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BD2F27").s().p("AgOAiQgHgDgFgEIAGgKQAEAEAGACQAGACAFAAQAHAAADgCQADgDAAgEQAAgDgCgDQgCgCgGgCIgJgDQgIgCgFgEQgFgFAAgIQAAgGADgEQADgFAFgCQAGgCAHAAQAHAAAGACQAGACAFAEIgIAJQgDgDgFgBIgJgCQgFABgDACQgCACAAADQAAADACADIAIADIAJAEQAJACAEAFQAFAEAAAJQAAAJgHAFQgGAFgNAAQgIAAgHgCg");
	this.shape_18.setTransform(118.675,11.85);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BD2F27").s().p("AgPAfQgIgEgFgJQgFgIAAgKQAAgJAFgJQAFgIAHgEQAJgFAIAAQAPAAAJAIQAJAKAAAQIAAAEIg1AAIACAJQADAFAFAEQAGADAFAAQAJAAAFgDIAIgIIAJAHQgEAHgJAFQgHAEgLAAQgJAAgIgFgAAUgHQgBgHgDgEQgFgGgKAAQgFAAgFAEQgFADgDAGIgBAEIAmAAIAAAAg");
	this.shape_19.setTransform(111.75,11.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BD2F27").s().p("AgQAtQgIgFgEgIQgEgIAAgKQAAgLAEgHQAFgIAIgFQAIgEAJAAIALABIAHADIAAggIANAAIAABhIgLAAIgBgGIgJAFQgGADgGAAQgJAAgHgFgAgIgGQgFADgDAEQgDAGAAAHQAAAGADAGQACAFAFAEQAFADAFAAQAGAAAFgCQAEgCAEgEIAAghQgDgDgEgCQgFgCgFAAQgGAAgFAEg");
	this.shape_20.setTransform(103.525,10.475);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BD2F27").s().p("AgWAfQgFgFgBgJQAAgGADgDQACgEAEgDQAGgCAJgBIATgFIAAgEQABgHgEgDQgEgDgHAAQgHAAgEACQgDACgBAEIgMgDQADgJAHgDQAIgEAJAAQAJAAAGACQAGADADAFQAEAFAAAIIAAAvIgLAAIgCgHQgGAEgFACQgFACgGAAQgJAAgHgFgAgDAHQgGACgDABQgDADABAEQAAAEACACQADACAFAAQAFAAAFgCQAFgCAEgEIAAgPg");
	this.shape_21.setTransform(95.85,11.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BD2F27").s().p("AgQAtQgIgFgEgIQgEgIAAgKQAAgLAEgHQAFgIAIgFQAIgEAJAAIALABIAHADIAAggIANAAIAABhIgLAAIgBgGIgJAFQgGADgGAAQgJAAgHgFgAgIgGQgFADgDAEQgDAGAAAHQAAAGADAGQACAFAFAEQAFADAFAAQAGAAAFgCQAEgCAEgEIAAghQgDgDgEgCQgFgCgFAAQgGAAgFAEg");
	this.shape_22.setTransform(88.175,10.475);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BD2F27").s().p("AgGAyIAAhFIANAAIAABFgAgFghQgDgDAAgDQAAgEADgDQACgCADAAQAEAAACACQADADAAAEQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_23.setTransform(82.625,10.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BD2F27").s().p("AARAjIAAgpQAAgJgDgEQgEgEgJAAQgFAAgEADQgEACgEAFIAAAwIgOAAIAAhEIALAAIACAHIAKgGQAFgCAHAAQAHAAAGACQAGACADAGQADAGABALIAAAqg");
	this.shape_24.setTransform(76.95,11.775);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BD2F27").s().p("AgQAhQgHgCgCgHQgEgFAAgLIAAgqIAOAAIAAApQgBAJAEAEQADAEAJgBQAEAAAEgCQAFgCADgFIAAgwIAOAAIAABEIgLAAIgCgGQgEADgFACQgFADgGAAQgIAAgFgDg");
	this.shape_25.setTransform(68.85,11.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BD2F27").s().p("AgGAoQgGgGAAgKIAAglIgNAAIAAgLIANAAIAAgUIANAAIAAAUIAWAAIAAALIgWAAIAAAfQAAAJACADQABAEAGAAIAFgBIAHgCIAEALIgJADIgJAAQgKAAgEgFg");
	this.shape_26.setTransform(62.1,10.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BD2F27").s().p("AgRAjIAAhEIAKAAIACAHIAGgFQADgCAFAAIAJgBIgBANIgJABQgEAAgDACIgFAFIAAAwg");
	this.shape_27.setTransform(57.425,11.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#BD2F27").s().p("AgRAfQgIgEgFgJQgEgIgBgKQABgJAEgJQAFgHAIgFQAIgFAJAAQAKAAAIAFQAIAEAFAIQAEAJAAAJQAAAKgEAIQgFAJgIAEQgIAFgKAAQgJAAgIgFgAgKgUQgGADgCAGQgDAFAAAGQAAAHADAFQACAFAGAEQAEADAGAAQAGAAAFgDQAGgDACgFQADgGABgHQgBgGgDgFQgCgGgGgDQgFgEgGAAQgGAAgEAEg");
	this.shape_28.setTransform(50.45,11.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#BD2F27").s().p("AggAzIAAhkIAKAAIACAHQAEgDAFgDQAGgCAFAAQAKAAAHAFQAHAEAFAJQAEAIAAAKQAAALgEAHQgFAIgIAEQgIAFgIAAQgGAAgGgCIgHgEIAAAkgAgLgkQgEACgEAEIAAAfQADAEAFACQAEACAGAAQAGAAAEgDQAFgDADgEQADgGAAgHQAAgHgDgFQgDgGgEgDQgFgDgGAAQgFAAgFACg");
	this.shape_29.setTransform(42.525,13.325);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#BD2F27").s().p("AgRAfQgIgEgFgJQgEgIAAgKQAAgJAEgJQAFgHAIgFQAIgFAJAAQAKAAAIAFQAIAEAFAIQAEAJABAJQgBAKgEAIQgFAJgIAEQgIAFgKAAQgJAAgIgFgAgKgUQgGADgCAGQgEAFAAAGQAAAHAEAFQACAFAGAEQAFADAFAAQAHAAAEgDQAFgDAEgFQACgGAAgHQAAgGgCgFQgEgGgFgDQgEgEgHAAQgFAAgFAEg");
	this.shape_30.setTransform(34.05,11.85);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#BD2F27").s().p("AgRAyIALgfIgbhEIAPAAIATA0IATg0IAOAAIgnBjg");
	this.shape_31.setTransform(22.9,13.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#BD2F27").s().p("AgVAfQgHgFAAgJQAAgGACgDQACgEAFgDQAFgCAKgBIAUgFIAAgEQgBgHgDgDQgDgDgJAAQgGAAgEACQgDACgBAEIgMgDQACgJAIgDQAHgEAKAAQAJAAAGACQAGADADAFQADAFAAAIIAAAvIgKAAIgCgHQgGAEgFACQgFACgGAAQgKAAgFgFgAgCAHQgHACgDABQgCADAAAEQAAAEADACQACACAFAAQAFAAAFgCQAFgCAFgEIAAgPg");
	this.shape_32.setTransform(15.55,11.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#BD2F27").s().p("AAYAvIAAgpIgvAAIAAApIgOAAIAAhdIAOAAIAAApIAvAAIAAgpIAOAAIAABdg");
	this.shape_33.setTransform(7.1,10.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt2a, new cjs.Rectangle(0,0,213.5,33.6), null);


(lib.txt1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BD2F27").s().p("AAhAyIgLgdIgrAAIgLAdIgPAAIAohjIAPAAIAoBjgAARAJIgRgsIgQAsIAhAAg");
	this.shape.setTransform(187.3,39.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BD2F27").s().p("AgGAyIAAhWIghAAIAAgNIBPAAIAAANIghAAIAABWg");
	this.shape_1.setTransform(177.825,39.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BD2F27").s().p("AAhAyIgLgdIgrAAIgLAdIgPAAIAohjIAPAAIAoBjgAARAJIgRgsIgQAsIAhAAg");
	this.shape_2.setTransform(168.4,39.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BD2F27").s().p("AgGAyIAAhjIANAAIAABjg");
	this.shape_3.setTransform(161.075,39.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BD2F27").s().p("AgrAyIAAhjIAkAAQAKAAAKAEQAJAEAHAHQAHAHAEAJQAEAJAAAJQAAAKgEAJQgEAKgHAHQgHAGgJAEQgKAEgKAAgAgdAlIAWAAQAIAAAGgDQAHgDAEgFQAGgFACgHQADgGAAgIQAAgGgDgHQgCgHgGgFQgEgFgHgDQgGgDgIAAIgWAAg");
	this.shape_4.setTransform(153.8,39.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BD2F27").s().p("AggAyIAAhjIBBAAIAAANIgzAAIAAAdIAtAAIAAAMIgtAAIAAAgIAzAAIAAANg");
	this.shape_5.setTransform(144.025,39.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BD2F27").s().p("AAkAyIAAg/IgeA/IgKAAIgfg/IAAA/IgOAAIAAhjIALAAIAnBQIAmhQIALAAIAABjg");
	this.shape_6.setTransform(132.75,39.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BD2F27").s().p("AAeAyIg4hJIAABJIgOAAIAAhjIALAAIA4BKIAAhKIAOAAIAABjg");
	this.shape_7.setTransform(120.675,39.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BD2F27").s().p("AgGAyIAAhjIANAAIAABjg");
	this.shape_8.setTransform(112.925,39.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BD2F27").s().p("AAhAyIgLgdIgrAAIgLAdIgPAAIAnhjIAQAAIAoBjgAARAJIgRgsIgRAsIAiAAg");
	this.shape_9.setTransform(101.85,39.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BD2F27").s().p("AgPAwQgKgEgHgHQgHgIgEgJQgEgJAAgLQAAgKAEgJQAEgJAHgIQAHgHAKgEQAKgEAKAAQANAAALAGQALAFAHAKIgMAIQgEgHgIgEQgIgEgKAAQgKAAgJAGQgIAFgFAIQgEAJAAAJQAAAKAEAJQAFAIAIAFQAJAGAKAAQAKAAAIgEQAGgDAFgFIAAgQIgcAAIAAgMIAqAAIAAAhQgHAKgLAFQgMAGgNAAQgKAAgKgEg");
	this.shape_10.setTransform(91.075,39.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BD2F27").s().p("AggAyIAAhjIBBAAIAAANIgzAAIAAAdIAtAAIAAAMIgtAAIAAAgIAzAAIAAANg");
	this.shape_11.setTransform(81.625,39.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BD2F27").s().p("AASAyIgbgnIgLAAIAAAnIgPAAIAAhjIAjAAQAJAAAHAEQAHAEADAHQAFAHAAAIQAAAJgFAHQgDAGgHAEQgEACgFABIAdAogAgUAAIASAAQAIAAAFgFQAEgFAAgJQAAgIgEgFQgFgFgIAAIgSAAg");
	this.shape_12.setTransform(72.8,39.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BD2F27").s().p("AgGAyIAAhWIghAAIAAgNIBPAAIAAANIghAAIAABWg");
	this.shape_13.setTransform(63.425,39.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BD2F27").s().p("AAeAyIg4hJIAABJIgOAAIAAhjIALAAIA4BKIAAhKIAOAAIAABjg");
	this.shape_14.setTransform(53.525,39.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BD2F27").s().p("AggAyIAAhjIBBAAIAAANIgzAAIAAAdIAtAAIAAAMIgtAAIAAAgIAzAAIAAANg");
	this.shape_15.setTransform(44.025,39.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BD2F27").s().p("AAeAyIg4hJIAABJIgOAAIAAhjIALAAIA4BKIAAhKIAOAAIAABjg");
	this.shape_16.setTransform(29.875,39.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BD2F27").s().p("AgUAwQgJgEgHgHQgHgIgEgJQgEgJAAgLQAAgKAEgJQAEgKAHgHQAHgHAJgEQAKgEAKAAQALAAAKAEQAJAEAHAHQAHAIAEAJQAEAJAAAKQAAALgEAJQgEAKgHAHQgHAHgJAEQgKAEgLAAQgKAAgKgEgAgSgfQgIAFgFAIQgEAJAAAJQAAAKAEAIQAFAJAIAFQAIAGAKAAQALAAAIgGQAIgFAFgIQAEgJAAgKQAAgJgEgIQgFgJgIgFQgIgGgLAAQgKAAgIAGg");
	this.shape_17.setTransform(18.375,39.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BD2F27").s().p("AgPAwQgJgEgHgHQgHgIgEgJQgEgJAAgLQAAgKAEgJQAEgJAHgIQAHgHAJgEQAKgEAKAAQANAAALAGQALAFAHAKIgMAIQgFgHgHgEQgIgEgKAAQgKAAgIAGQgIAFgFAIQgEAJAAAJQAAAKAEAJQAFAIAIAFQAIAGAKAAQAKAAAIgEQAHgEAFgHIAMAJQgHAJgLAFQgLAGgNAAQgKAAgKgEg");
	this.shape_18.setTransform(7.425,39.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BD2F27").s().p("AAAAIIgJAWIgQgMIARgQIgXgCIAGgSIAVAMIgFgXIATAAIgFAXIAUgMIAHASIgYADIARAPIgQAMg");
	this.shape_19.setTransform(115.45,9.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BD2F27").s().p("AgMAwQgKgEgHgHQgHgHgEgKIAAgBIgKAAIAAgOIAGAAIAAgFIAAgDIgGAAIAAgOIAKAAIAAgCQAEgKAHgHQAHgHAKgEQAJgEAKAAQAOAAAMAGQALAGAHAKIgUAOQgEgGgFgDQgHgDgHAAQgIAAgFAEQgFACgCAEIAaAAIgCAOIgeAAIgBADIABAFIAdAAIgDAOIgTAAIAGAFQAFAEAIAAQAHAAAHgDQAFgDAEgGIAUAOQgHAKgLAGQgMAGgOAAQgKAAgJgEg");
	this.shape_20.setTransform(106.55,11.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BD2F27").s().p("AgUAuQgJgGgGgMQgFgMAAgQQAAgPAFgMQAGgMAJgGQAJgGALAAQANAAAJAGQAJAHAFALQAFAMAAAPQAAAQgFAMQgFAMgJAGQgJAGgNAAQgLAAgJgGgAgKgUQgEAHAAANQAAAOAEAHQAEAHAGAAQAHAAAFgHQADgHABgOQgBgNgDgHQgFgHgHAAQgGAAgEAHg");
	this.shape_21.setTransform(96.1,11.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BD2F27").s().p("AgVAuQgIgGgFgMQgGgMAAgQQAAgPAGgMQAFgMAIgGQAJgGAMAAQANAAAJAGQAJAHAFALQAFAMAAAPQAAAQgFAMQgFAMgJAGQgJAGgNAAQgMAAgJgGgAgKgUQgEAHAAANQAAAOAEAHQAEAHAGAAQAHAAAFgHQADgHAAgOQAAgNgDgHQgFgHgHAAQgGAAgEAHg");
	this.shape_22.setTransform(86.6,11.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BD2F27").s().p("AgjAzIAAgTIAkghIAGgGIADgFIABgFQAAgEgDgDQgCgDgGAAQgGAAgCAEQgDADgBAGIgYgEQABgKAFgHQAEgHAIgEQAHgEALAAQAMAAAIAEQAIADAEAHQAEAHAAAJQAAAFgCAFQgBAGgEAEIgLAMIgSASIAlAAIAAAVg");
	this.shape_23.setTransform(77.425,11.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BD2F27").s().p("AgJAJQgEgDAAgGQAAgFAEgEQAEgDAFAAQAGAAAEADQAEAEAAAFQAAAGgEADQgEAFgGAAQgFAAgEgFg");
	this.shape_24.setTransform(71.225,15.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BD2F27").s().p("AgTAwQgHgDgFgGQgFgFgCgHIAYgJQABAFADACQAEADAGAAQAGAAAEgDQAEgDAAgFQAAgGgEgDQgEgDgGAAIgLAAIAAgOIAOgTIgjAAIAAgWIBBAAIAAATIgQAVQAGABAFAEQAFAEADAFQADAGAAAIQAAAJgFAIQgEAIgJAEQgJAEgMAAQgLAAgIgDg");
	this.shape_25.setTransform(64.825,11.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BD2F27").s().p("AgCAyIAAhJIgTAJIAAgZIAVgKIAWAAIAABjg");
	this.shape_26.setTransform(57.225,11.225);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BD2F27").s().p("AgjAyIAAhjIBGAAIAAAXIgtAAIAAAQIAoAAIAAAUIgoAAIAAARIAuAAIAAAXg");
	this.shape_27.setTransform(47.15,11.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#BD2F27").s().p("AguAyIAAhjIApAAQALAAAKAEQAJAEAHAGQAHAHAEAJQAEAJAAAKQAAAKgEAJQgEAJgHAHQgHAHgJAEQgKAEgKAAgAgVAbIAQAAQAGAAAEgCQAFgCAEgEQADgEACgFQACgEAAgGQAAgEgCgFQgCgFgDgEQgEgEgFgCQgEgCgGAAIgQAAg");
	this.shape_28.setTransform(37.125,11.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#BD2F27").s().p("AgVAyQgJgDgKgGIALgUQAGAEAHADQAHACAJAAQAHAAADgBQAEgCAAgEQAAgDgCgCQgDgCgGgCIgOgGQgJgDgFgDQgGgDgDgGQgDgGAAgIQAAgKAFgGQAFgHAJgEQAIgDAKAAIAPABQAGABAFACQAGACAGAEIgLAUIgMgGQgHgCgIAAQgEAAgDABQgDACAAAEQAAADACACQACACAEABIAOAFQAJADAGAEQAHADADAGQAEAFAAAJQAAAQgLAHQgLAIgTAAQgMAAgJgCg");
	this.shape_29.setTransform(26.675,11.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#BD2F27").s().p("AgjAyIAAhjIBGAAIAAAXIgtAAIAAAQIAoAAIAAAUIgoAAIAAARIAuAAIAAAXg");
	this.shape_30.setTransform(17.9,11.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#BD2F27").s().p("AguAyIAAhjIApAAQALAAAKAEQAJAEAHAGQAHAHAEAJQAEAJAAAKQAAAKgEAJQgEAJgHAHQgHAHgJAEQgKAEgKAAgAgVAbIAQAAQAGAAAEgCQAFgCAEgEQADgEACgFQACgEAAgGQAAgEgCgFQgCgFgDgEQgEgEgFgCQgEgCgGAAIgQAAg");
	this.shape_31.setTransform(7.875,11.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1a, new cjs.Rectangle(0,0,198,50), null);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F4248").s().p("AAaAyIgxhBIAABBIgTAAIAAhjIARAAIAwBCIAAhCIAUAAIAABjg");
	this.shape.setTransform(209.35,11.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3F4248").s().p("AgJAyIAAhjIATAAIAABjg");
	this.shape_1.setTransform(201.45,11.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F4248").s().p("AgPAwQgKgEgHgHQgHgHgEgKQgFgJAAgLQAAgKAFgJQAEgKAHgHQAHgHAKgEQAJgEALAAQAOAAALAFQALAGAHAJIgQALQgEgFgHgEQgHgDgJAAQgJAAgHAFQgIAEgDAIQgFAHAAAIQAAAJAFAHQADAIAIAEQAHAFAJAAQAJAAAIgDIAIgFIAAgPIgZAAIAAgOIAsAAIAAAlQgIAJgKAFQgMAFgOAAQgLAAgJgEg");
	this.shape_2.setTransform(193.5,11.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F4248").s().p("AgJAyIAAhjIATAAIAABjg");
	this.shape_3.setTransform(185.7,11.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3F4248").s().p("AAQAyIgZglIgJAAIAAAlIgUAAIAAhjIAmAAQAKAAAIAEQAHAEAEAHQAEAHAAAJQAAAKgEAHQgEAGgIAEIgGACIAcAngAgSgCIAQAAQAGAAAFgEQAEgEAAgHQAAgIgEgEQgFgEgGAAIgQAAg");
	this.shape_4.setTransform(179.05,11.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3F4248").s().p("AgTAwQgKgEgHgHQgHgHgEgKQgFgJAAgLQAAgKAFgJQAEgKAHgHQAHgHAKgEQAJgEAKAAQALAAAKAEQAKAEAGAHQAIAHADAKQAFAJAAAKQAAALgFAJQgDAKgIAHQgGAHgKAEQgKAEgLAAQgKAAgJgEgAgQgbQgHAEgEAIQgEAHAAAIQAAAIAEAIQAEAIAHAEQAIAFAIAAQAJAAAIgFQAHgEAEgIQAEgHAAgJQAAgHgEgIQgEgIgHgEQgIgFgJAAQgIAAgIAFg");
	this.shape_5.setTransform(167.9,11.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3F4248").s().p("AgSAwQgHgDgFgGQgEgGgCgHIASgFQABAGAFADQAEADAIAAQAIAAAFgEQAEgEAAgHQAAgHgEgEQgFgEgIAAIgLAAIAAgLIATgZIgmAAIAAgRIA9AAIAAAOIgUAZQAJACAGAEQAFAFADAFQADAHAAAGQgBAKgEAHQgEAIgJAEQgIAEgLAAQgLAAgHgDg");
	this.shape_6.setTransform(154.175,11.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3F4248").s().p("AgPAwQgJgEgHgHQgIgHgEgKQgEgJAAgLQAAgKAEgJQAEgKAIgHQAHgHAJgEQAKgEAKAAQANAAAMAGQALAFAHAKIgQALQgEgGgHgDQgHgEgJAAQgJAAgHAFQgHAEgEAIQgEAHAAAIQAAAJAEAHQAEAIAHAEQAHAFAJAAQAJAAAHgEQAHgDAEgGIAPALQgGAKgMAFQgLAGgNAAQgKAAgKgEg");
	this.shape_7.setTransform(144.975,11.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3F4248").s().p("AAaAyIgxhBIAABBIgTAAIAAhjIARAAIAxBCIAAhCIATAAIAABjg");
	this.shape_8.setTransform(130.45,11.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3F4248").s().p("AgiBCIAAhjIBEAAIAAASIgvAAIAAAWIApAAIAAAQIgpAAIAAAZIAwAAIAAASgAAHgvQgDgDAAgEQAAgFADgDQADgDAFAAQAEAAADADQADADAAAFQAAAEgDADQgDAEgEAAQgFAAgDgEgAgWgvQgDgDgBgEQABgFADgDQADgDAEAAQAFAAADADQADADAAAFQAAAEgDADQgDAEgFAAQgEAAgDgEg");
	this.shape_9.setTransform(120.75,9.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F4248").s().p("AgTAwQgKgEgHgHQgHgHgFgKQgDgJAAgLQAAgKADgJQAFgKAHgHQAHgHAKgEQAJgEAKAAQALAAAKAEQAJAEAIAHQAHAHADAKQAFAJAAAKQAAALgFAJQgDAKgHAHQgIAHgJAEQgKAEgLAAQgKAAgJgEgAgPgbQgIAEgEAIQgEAHAAAIQAAAIAEAIQAEAIAIAEQAHAFAIAAQAKAAAHgFQAHgEAEgIQAEgHAAgJQAAgHgEgIQgEgIgHgEQgHgFgKAAQgIAAgHAFg");
	this.shape_10.setTransform(110.1,11.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F4248").s().p("AAQAyIgZglIgJAAIAAAlIgUAAIAAhjIAmAAQAKAAAIAEQAHAEAEAHQAEAHAAAJQAAAKgEAHQgEAGgIAEIgGACIAcAngAgSgCIAQAAQAGAAAFgEQAEgEAAgHQAAgIgEgEQgFgEgGAAIgQAAg");
	this.shape_11.setTransform(99.85,11.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3F4248").s().p("AgJAyIAAhRIggAAIAAgSIBTAAIAAASIggAAIAABRg");
	this.shape_12.setTransform(90.125,11.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3F4248").s().p("AgJAyIAAhjIATAAIAABjg");
	this.shape_13.setTransform(83.3,11.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3F4248").s().p("AgPAwQgJgEgHgHQgIgHgEgKQgEgJAAgLQAAgKAEgJQAEgKAIgHQAHgHAJgEQAKgEAKAAQANAAAMAGQALAFAHAKIgQALQgEgGgHgDQgHgEgJAAQgJAAgHAFQgHAEgEAIQgEAHAAAIQAAAJAEAHQAEAIAHAEQAHAFAJAAQAJAAAHgEQAHgDAEgGIAPALQgGAKgMAFQgLAGgNAAQgKAAgKgEg");
	this.shape_14.setTransform(75.925,11.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3F4248").s().p("AgWAuQgKgFgEgJQgFgKAAgOIAAg6IATAAIAAA6QAAAJADAFQACAFAFACQAGADAGAAQAIAAAFgDQAFgCACgFQADgFAAgJIAAg6IATAAIAAA6QAAAOgFAKQgEAJgJAFQgKAFgOAAQgNAAgJgFg");
	this.shape_15.setTransform(61.675,11.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F4248").s().p("AgJAyIAAhRIggAAIAAgSIBTAAIAAASIggAAIAABRg");
	this.shape_16.setTransform(51.875,11.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3F4248").s().p("AgiAyIAAhjIBEAAIAAASIgvAAIAAAXIApAAIAAAPIgpAAIAAAZIAwAAIAAASg");
	this.shape_17.setTransform(39.75,11.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3F4248").s().p("AgPAwQgKgEgHgHQgHgHgEgKQgFgJAAgLQAAgKAFgJQAEgKAHgHQAHgHAKgEQAKgEAKAAQAOAAALAFQALAGAHAJIgQALQgEgFgHgEQgHgDgJAAQgJAAgHAFQgIAEgEAIQgEAHAAAIQAAAJAEAHQAEAIAIAEQAHAFAJAAQAJAAAHgDIAJgFIAAgPIgZAAIAAgOIAsAAIAAAlQgIAJgKAFQgMAFgOAAQgKAAgKgEg");
	this.shape_18.setTransform(29.35,11.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3F4248").s().p("AgJAyIAAhjIATAAIAABjg");
	this.shape_19.setTransform(21.55,11.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3F4248").s().p("AghAyIAAhjIAUAAIAABRIAvAAIAAASg");
	this.shape_20.setTransform(15.525,11.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3F4248").s().p("AghAyIAAhjIBDAAIAAASIgvAAIAAAXIAqAAIAAAPIgqAAIAAAZIAvAAIAAASg");
	this.shape_21.setTransform(6.75,11.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(0,0,246.5,22), null);


(lib.txt_legal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F4248").s().p("AgDAJIgEgBIACgDIADABIACABIADgBIABgCIgBgBIgCgBIgCgBIgDgBQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBIABgDIACgCIADAAIAEAAIADACIgCADIgCgCIgDAAIgBAAIgBACIAAACIACABIADABQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAABQgCABgEAAIgDgBg");
	this.shape.setTransform(49.925,4.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3F4248").s().p("AgDAJIgEgEQgBgCgBgDQABgCABgCQABgDADgBIADgBQAFAAACACQACADAAAEIAAABIgNAAIAAACIADADIACABIAEgBIACgCIACACIgDADQgCABgEAAIgDgBgAAGgBIgBgEQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgBABIgDACIAAACIAKAAIAAAAg");
	this.shape_1.setTransform(47.95,4.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F4248").s().p("AgBACIAAgCIAAgBIABgBIABABIABABIgBACIgBAAIgBAAg");
	this.shape_2.setTransform(46.4,5.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F4248").s().p("AAFAKIAAgLIgBgEIgEgBIgCABIgCACIAAANIgEAAIAAgTIADAAIABACIADgBIACgBIAEABIADACIABAFIAAALg");
	this.shape_3.setTransform(44.775,4.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3F4248").s().p("AgEAJIgDgEQgBgCAAgDQAAgCABgCQABgDACgBIAFgBQAEAAACACQACADABAEIAAABIgPAAIABACIACADIADABIADgBIADgCIADACIgEADQgCABgDAAIgFgBgAAGgBIgCgEQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAIgDABIgCACIgBACIALAAIAAAAg");
	this.shape_4.setTransform(42.5,4.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3F4248").s().p("AgEAJIgEgEQgBgCAAgDQAAgCABgCQABgDADgBIAEgBIAFABIAEAEQABACAAACQAAADgBACIgEAEQgCABgDAAIgEgBgAgCgFIgDACIAAADIAAADIADADIACABIADgBIADgDIAAgDIAAgDIgDgCIgDgBIgCABg");
	this.shape_5.setTransform(40.275,4.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3F4248").s().p("AgEAKIAAgTIADAAIAAACIABgBIACgBIADAAIAAADIgDABIgCAAIAAACIAAANg");
	this.shape_6.setTransform(38.575,4.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3F4248").s().p("AgBALQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAgBAAAAIAAgKIgDAAIAAgEIADAAIAAgFIADAAIAAAFIAHAAIAAAEIgHAAIAAAIIABAEIACAAIACAAIABAAIABACIgCABIgDABQAAAAgBAAQgBAAAAAAQAAgBAAAAQgBAAAAgBg");
	this.shape_7.setTransform(36.925,4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3F4248").s().p("AgBAOIAAgTIADAAIAAATgAgBgJIAAgCIAAgBIABgBIABABIABABIgBACIgBABIgBgBg");
	this.shape_8.setTransform(35.7,4.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3F4248").s().p("AgDANIgFgDIgCgFIgBgFIABgEIACgFIAFgDIAEgBQAEAAADACQACABADACIgEADIgDgDIgFgBQgCAAgCABIgDAEIgCAEIACAFQAAAAABABQAAAAAAABQABAAAAABQAAAAABAAQACACACAAIAFgBIADgDIAEACIgFAEQgDACgEAAIgEgBg");
	this.shape_9.setTransform(33.9,4.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F4248").s().p("AAFAKIAAgLIgBgEIgEgBIgCABIgCACIAAANIgEAAIAAgTIADAAIABACIADgBIACgBIAEABIADACIABAFIAAALg");
	this.shape_10.setTransform(30.325,4.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F4248").s().p("AgDAJIgEgEQgBgCgBgDQABgCABgCQABgDADgBIADgBQAFAAACACQADADgBAEIAAABIgNAAIAAACIADADIACABIAEgBIACgCIACACIgDADQgCABgEAAIgDgBgAAGgBIgBgEQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgBABIgDACIAAACIAKAAIAAAAg");
	this.shape_11.setTransform(28.05,4.825);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3F4248").s().p("AgDAJIgEgBIACgDIADABIACABIADgBIABgCIgBgBIgCgBIgCgBIgDgBQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBIABgDIACgCIADAAIAEAAIADACIgCADIgCgCIgDAAIgBAAIgBACIAAACIACABIADABQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAABQgCABgEAAIgDgBg");
	this.shape_12.setTransform(25.075,4.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3F4248").s().p("AgDAJIgEgEQgBgCgBgDQABgCABgCQABgDADgBIADgBQAFAAACACQADADgBAEIAAABIgNAAIAAACIADADIACABIAEgBIACgCIACACIgDADQgCABgEAAIgDgBgAAGgBIgBgEQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgBABIgDACIAAACIAKAAIAAAAg");
	this.shape_13.setTransform(23.1,4.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3F4248").s().p("AAFAKIAAgLIgBgEIgEgBIgCABIgCACIAAANIgEAAIAAgTIADAAIABACIADgBIACgBIAEABIADACIABAFIAAALg");
	this.shape_14.setTransform(20.875,4.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3F4248").s().p("AgEAJIgEgEQgBgCAAgDQAAgCABgCQABgDADgBIAEgBIAFABIAEAEQABACAAACQAAADgBACIgEAEQgCABgDAAIgEgBgAgCgFIgDACIAAADIAAADIADADIACABIADgBIADgDIAAgDIAAgDIgDgCIgDgBIgCABg");
	this.shape_15.setTransform(18.575,4.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F4248").s().p("AgBAOIAAgTIADAAIAAATgAgBgJIAAgCIAAgBIABgBIACABIAAABIAAACIgCABIgBgBg");
	this.shape_16.setTransform(16.95,4.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3F4248").s().p("AgDAJIgEgEQgBgCAAgDQAAgCABgCQABgDADgBIAEgBQADAAACABQABABAAAAQABAAAAABQAAAAABABQAAAAAAABIgDACIgCgDIgDgBIgDABIgCACIAAADIAAADIADADIACABIADgBIADgCIACACQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAABQgCABgDAAQgCAAgCgBg");
	this.shape_17.setTransform(15.425,4.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3F4248").s().p("AgBAOIAAgTIADAAIAAATgAgBgJIAAgCIAAgBIABgBIABABIABABIgBACIgBABIgBgBg");
	this.shape_18.setTransform(13.9,4.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3F4248").s().p("AgEANIgDgEQgCgCAAgDQAAgDACgBQABgDACgBIAFgBIADAAIABABIAAgJIAFAAIAAAbIgEAAIAAgCIgCABIgEABIgEgBgAgCgBIgCABIAAAEIAAADIACADIADABIADgBIABgBIAAgJIgBgCIgDAAIgDABg");
	this.shape_19.setTransform(12.15,4.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3F4248").s().p("AAFAKIAAgLIgBgEIgEgBIgCABIgCACIAAANIgEAAIAAgTIADAAIABACIADgBIACgBIAEABIADACIABAFIAAALg");
	this.shape_20.setTransform(9.925,4.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3F4248").s().p("AgEAJIgEgEQgBgCAAgDQAAgCABgCQABgDADgBIAEgBIAFABIAEAEQABACAAACQAAADgBACIgEAEQgCABgDAAIgEgBgAgCgFIgDACIAAADIAAADIADADIACABIADgBIADgDIAAgDIAAgDIgDgCIgDgBIgCABg");
	this.shape_21.setTransform(7.625,4.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3F4248").s().p("AgDANIgEgDIgEgFIgBgFIABgEIAEgFIAEgDIAFgBQADAAADACQADABABACIgCADIgEgDIgEgBQgCAAgDABIgDAEIgBAEIABAFQAAAAABABQAAAAAAABQABAAAAABQABAAAAAAQADACACAAIAEgBIAEgDIACACIgEAEQgDACgDAAIgFgBg");
	this.shape_22.setTransform(5.15,4.475);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3F4248").s().p("AAAACIgCAFIgDgBIAFgFIgHgBIABgDIAGADIgBgGIADAAIgBAGIAGgCIABACIgHABIAFAFIgDABg");
	this.shape_23.setTransform(2.875,3.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt_legal, new cjs.Rectangle(0,0,53,8.8), null);


(lib.logo_Citroen_horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// white_left
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhSD2QgngUgeglQgeglgQgwQgRgyAAg2QAAg1ARgyQAQgwAeglQAeglAngUQAogVAqAAQAsAAAnAVQAnAUAeAlQAeAlAQAwQARAyAAA1QAAA2gRAyQgQAwgeAlQgeAlgnAUQgnAVgsAAQgqAAgogVgAiaCLIAAABQAbAwApAbQApAbAtAAQAvAAAogbQApgbAbgwIAAgBIibhzgACvBcIAAAAQAFgOADgPIACgNIAAAAIi5iIIi4CIIAAAAIAAAAIACANQADAPAEAOIAAAAICviBgAC+gIIAAgBQgCgugPgrQgPgqgaghQgbghgigRQgigSglAAQgkAAgiASQgiARgbAhQgbAhgOAqQgPArgBAuIAAABIC8iNg");
	this.shape.setTransform(218.65,4.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah/HaQjngFiOiDQiOiCAAjPIAAgBQAAhgAkhVQAjhVBDhBQBGhBBgglQBggkBygDIADAAIDFgDQDigCCWAAQCEABA/ABIAAC0IowgCQhDAAhCACIg1ACIgEABIgEAAQiMAFhUBQQhUBQAACAQAACBBVBOQBVBPCOAEQBMAEBrAAQHegBBZgBIAAC3Qg7ABj/AAQlkAAhkgDg");
	this.shape_1.setTransform(5.1176,6.9306,0.1898,0.19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibBFQgcAAgVgUQgUgUAAgcQAAgcAUgUQAUgVAdAAIE4AAQAcAAAVAVQATAUABAcQgBAcgTAUQgVAUgcAAg");
	this.shape_2.setTransform(130.3663,-5.6971,0.1898,0.19);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ApGHfIAAu9ISNAAIAAC1Iu3AAIAADPINCAAIAACtItCAAIAADXIO3AAIAAC1g");
	this.shape_3.setTransform(135.5777,6.9686,0.1898,0.19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjAHzQjsgFiRiKQiRiJAAjaIAAgBQAAhmAlhZQAkhbBFhCQBHhGBigmQBhgmB1gEIADAAIAzgCQBBgCBGAAQBdAABoAEQDsAKCRCJQCRCKAADVIAAABQAABmglBaQgkBZhFBDQhHBGhiAmQhhAnh1ADIgDAAQhKAEhwAAQhuAAhXgEgAmWjhQhUBUAACLQAACMBVBUQBVBUCSAEIADAAQBdAEBcAAQBtAAAugEIAIAAQCRgGBUhUQBUhUABiKIAAgBQAAiMhVhTQhVhTiVgHIgJAAQhUgEg5AAQhEAAhEACIg2ACIgEAAIgFAAQiRAHhUBUg");
	this.shape_4.setTransform(105.5862,6.9686,0.1898,0.19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AqpHfIAAu9IPCAAQCmAABdBOQBdBNAACJQAACYhWA/QhYBCjbAFIhqAAIIkF3Ik3AAIqRnbIAAg3IIbAAQBdADAmgoQAcgeAAg8QAAg5ghgcQghgdhAgBIrtAAIAAMIg");
	this.shape_5.setTransform(74.9539,6.9686,0.1898,0.19);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AibBFQgcAAgVgUQgUgUgBgcQABgcAUgUQAUgVAdAAIE5AAQAcAAATAVQAUAUAAAcQAAAbgUAVQgTAUgcAAg");
	this.shape_6.setTransform(140.7321,-5.6971,0.1898,0.19);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AGnHfIAAncQAAihhYhJQhQhCigAAIoFAAIAAMIIjVAAIAAu9IMNAAQD1ABCBCDQB0B3AADMIAAH2g");
	this.shape_7.setTransform(164.3969,6.9686,0.1898,0.19);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhqHfIAAu9IDVAAIAAO9g");
	this.shape_8.setTransform(26.0059,6.8973,0.1898,0.19);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhqHfIAAsIIofAAIAAi1IUTAAIAAC1IofAAIAAMIg");
	this.shape_9.setTransform(45.0193,6.8973,0.1898,0.19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_Citroen_horizontal, new cjs.Rectangle(-7.1,-21.9,249.5,60.3), null);


(lib._img = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.kvfond();
	this.instance.setTransform(-6,115);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._img, new cjs.Rectangle(-6,115,970,250), null);


(lib.ctaTxt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgRAqQgJgEgGgGQgGgHgEgHQgDgJAAgJQAAgIADgJQAEgIAGgGQAGgHAJgDQAIgDAJAAQAKAAAIADQAJADAGAHQAGAGAEAIQADAJAAAIQAAAJgDAJQgEAIgGAGQgGAGgJAEQgIADgKABQgJAAgIgEgAgLgTQgFADgDAFQgDAGAAAFQAAAGADAFQADAGAFADQAFAEAGAAQAHAAAFgEQAGgDACgFQAEgGAAgGQAAgFgEgFQgCgGgGgDQgFgEgHAAQgGAAgFAEg");
	this.shape.setTransform(122.45,11.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdAsIAAhXIAVAAIAABDIAnAAIAAAUg");
	this.shape_1.setTransform(114,11.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeAsIAAhXIA9AAIAAAVIgnAAIAAAOIAiAAIAAARIgiAAIAAAOIAnAAIAAAVg");
	this.shape_2.setTransform(106.275,11.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTAoQgJgFgEgIQgFgIAAgNIAAgxIAXAAIAAAxQAAAGABAEQACAEAEABQADACAEAAQAGAAADgCQAEgBABgEQACgEAAgGIAAgxIAWAAIAAAxQAAANgEAIQgFAIgIAFQgIAEgNAAQgLAAgIgEg");
	this.shape_3.setTransform(97.575,11.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAqQgIgEgHgGQgGgHgDgHQgEgJAAgJQAAgIAEgJQADgIAHgGQAGgHAIgDQAJgDAJAAQANAAAJAEQAKAFAGAIIgRAMQgDgEgGgCQgFgCgHAAQgGAAgFAEQgGADgDAFQgDAGAAAFQAAAGADAGQADAGAGADQAGADAGAAQAHAAAFgCIAEgCIAAgKIgSAAIAAgQIAoAAIAAAjQgHAIgKAEQgJAEgNABQgJAAgJgEg");
	this.shape_4.setTransform(88.125,11.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTA6IAAhWIAVAAIAABWgAgSgiIAQgXIAWAAIgTAXg");
	this.shape_5.setTransform(82.175,9.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgSArQgIgDgIgEIAJgRIAMAFQAGACAHABQAGgBADgBQADgCAAgDQAAgDgCgBQgCgCgGgCIgMgEIgMgHQgFgCgCgFQgDgFAAgHQAAgIAEgHQAFgFAHgEQAIgCAIAAIANABIAKACIAJAGIgJARIgKgGQgGgCgHABQgEAAgCABQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQAAABABAAQACACAEABIALAFQAIACAGAEQAFACADAFQADAEAAAJQAAANgJAGQgJAIgRAAQgKgBgIgCg");
	this.shape_6.setTransform(75.175,11.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AATAsIgjgyIAAAyIgWAAIAAhXIAUAAIAjAyIAAgyIAWAAIAABXg");
	this.shape_7.setTransform(66.425,11.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgRAqQgIgEgHgGQgGgHgDgHQgEgJAAgJQAAgIAEgJQADgIAGgGQAHgHAIgDQAIgDAJAAQAKAAAJADQAIADAGAHQAGAGAEAIQADAJAAAIQAAAJgDAJQgEAIgGAGQgGAGgIAEQgJADgKABQgJAAgIgEgAgLgTQgGADgCAFQgDAGAAAFQAAAGADAFQACAGAGADQAFAEAGAAQAHAAAFgEQAFgDADgFQADgGAAgGQAAgFgDgFQgDgGgFgDQgFgEgHAAQgGAAgFAEg");
	this.shape_8.setTransform(56.45,11.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOAqQgIgEgGgGQgGgGgEgIQgDgJAAgJQAAgIADgJQAEgIAGgGQAGgHAIgDQAJgDAJAAQAMAAAKAEQAKAGAGAJIgSAMQgDgFgFgCQgFgDgHAAQgGAAgFAEQgFADgDAFQgDAGAAAFQAAAGADAGQACAFAGADQAFAEAGAAQAHAAAFgDQAFgDAEgFIARANQgGAJgKAFQgKAFgMABQgJgBgJgDg");
	this.shape_9.setTransform(46.875,11.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaTxt, new cjs.Rectangle(40.1,1.2,89.6,19.6), null);


(lib.ctaBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8098AA").s().p("ApoDPQhTAAg7g7Qg6g6AAhTIAAgNQAAhTA6g7QA7g6BTAAITfAAIAAABQBKAEA2A1QA6A7AABTIAAANQAABTg6A6Qg2A2hKAEIAAABg");
	this.shape.setTransform(81.7,20.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaBg, new cjs.Rectangle(0,0,163.4,41.4), null);


(lib.big_days = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bd();
	this.instance.setTransform(0,0,0.2321,0.2321);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.big_days, new cjs.Rectangle(0,0,54.8,59.2), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ctaTxt
	this.ctaTxt = new lib.ctaTxt();
	this.ctaTxt.name = "ctaTxt";
	this.ctaTxt.setTransform(84.8,20.7,1,1,0,0,0,84.9,11);

	this.timeline.addTween(cjs.Tween.get(this.ctaTxt).wait(1));

	// ctaBg
	this.ctaBg = new lib.ctaBg();
	this.ctaBg.name = "ctaBg";
	this.ctaBg.setTransform(86.05,19.05,0.8701,0.8816,0,0,0,83,19);

	this.timeline.addTween(cjs.Tween.get(this.ctaBg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(13.9,2.3,142.1,36.5), null);


(lib.aniBox = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1
	this.img1 = new lib._img();
	this.img1.name = "img1";
	this.img1.setTransform(496,125,1,1,0,0,0,484,240);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	// img1Guide
	this.img1Guide = new lib._img();
	this.img1Guide.name = "img1Guide";
	this.img1Guide.setTransform(232,125,1,1,0,0,0,484,240);

	this.timeline.addTween(cjs.Tween.get(this.img1Guide).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aniBox, new cjs.Rectangle(-258,0,1234,250), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var aniBox = this.aniBox;
		var whiteBox = this.whiteBox;
		
		var img1 = this.aniBox.img1;
		var img1Guide = this.aniBox.img1Guide;
		
		var big_days = this.big_days;
		var logo = this.logo;
		
		var txt1 = this.txt1;
		var txt1a = this.txt1a;
		var txt2 = this.txt2;
		var txt2a = this.txt2a;
		var txt2b = this.txt2b;
		
		var txt_legal = this.txt_legal;
		
		var cta = this.cta;
		var ctaTxt = cta.ctaTxt;
		var ctaBg = cta.ctaBg;
		
		var h = lib.properties.height;
		var w = lib.properties.width;
		
		
		function getTime(){
			console.log(tl.duration());
		}
		
		function autoShot(tf, options) {
			if (window.takeAutoShot != undefined) {
				window.takeAutoShot(tf, options);
			}
		}
		
		this.tl = tl = gsap.timeline({onStart:getTime, repeat:1, repeatDelay:3, ease:Power2.easeOut});
		
			
		tl
		
			.add("frame1")
			.set(img1Guide, {visible:false})
			.to(big_days, {duration:1, alpha: 0}, "frame1+=1")
		
			.add("frame2", "frame1+=2")
			.from([whiteBox, txt1, txt1a], {duration: .7, x: "+="+w}, "frame2")
			.to(img1, {duration: .5, x: img1Guide.x, y: img1Guide.y, scaleX: img1Guide.scaleX, scaleY: img1Guide.scaleY}, "frame2+=.2")
			.add(autoShot)
			
			.add("frame3","frame2+=3")
			.to(txt1a, {duration: .2, alpha:0}, "frame3")
			.from(txt2a, .5, {x: "+=25" , alpha: 0}, "frame3+=.5")
			.add(autoShot)
		
			.add("frame4","frame3+=3")
			.to(txt2a, {duration: .2, alpha:0}, "frame4")
			.to(txt1, {duration: .5, y: "-=10", alpha:1}, "frame4+=.5")
			.from(cta, .5, {x: "-=22" , alpha: 0}, "frame4+=.5")
			.from(txt_legal, {duration:.5, alpha: 0}, "frame4+=.5")
			.call(autoShot, [true],"+=1")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// logo
	this.logo = new lib.logo_Citroen_horizontal();
	this.logo.name = "logo";
	this.logo.setTransform(109.35,39.85,0.7,0.6994,0,0,0,116.7,5);
	this.logo.shadow = new cjs.Shadow("rgba(153,153,153,1)",0,0,18);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.setTransform(649.3,125.3,2,2,0,0,0,85,20.7);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt_legal
	this.txt_legal = new lib.txt_legal();
	this.txt_legal.name = "txt_legal";
	this.txt_legal.setTransform(573.25,228.7,2.5,2.5,0,0,0,26.5,4.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_legal).wait(1));

	// txt2a
	this.txt2a = new lib.txt2a();
	this.txt2a.name = "txt2a";
	this.txt2a.setTransform(499.7,112.7,2,2,0,0,0,-0.5,-0.4);

	this.timeline.addTween(cjs.Tween.get(this.txt2a).wait(1));

	// txt1a
	this.txt1a = new lib.txt1a();
	this.txt1a.name = "txt1a";
	this.txt1a.setTransform(499.6,135.4,1.95,1.95,0,0,0,0,25);

	this.timeline.addTween(cjs.Tween.get(this.txt1a).wait(1));

	// txt1
	this.txt1 = new lib.txt1();
	this.txt1.name = "txt1";
	this.txt1.setTransform(680.4,74.4,2,2,0,0,0,90.7,12.2);

	this.timeline.addTween(cjs.Tween.get(this.txt1).wait(1));

	// big_days
	this.big_days = new lib.big_days();
	this.big_days.name = "big_days";
	this.big_days.setTransform(269.05,125.05,2,2,0,0,0,27.4,29.6);

	this.timeline.addTween(cjs.Tween.get(this.big_days).wait(1));

	// whiteBox
	this.whiteBox = new lib.whiteBox();
	this.whiteBox.name = "whiteBox";
	this.whiteBox.setTransform(734.95,124.95,1.3438,2.2635,0,0,0,182.3,55.2);

	this.timeline.addTween(cjs.Tween.get(this.whiteBox).wait(1));

	// msk (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKNAR+MAAAgj7MCUbAAAMAAAAj7g");
	mask.setTransform(485,125);

	// aniBox
	this.aniBox = new lib.aniBox();
	this.aniBox.name = "aniBox";
	this.aniBox.setTransform(364,45,1,1,0,0,0,364,45);

	var maskedShapeInstanceList = [this.aniBox];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.aniBox).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(488.7,125,503.3,125);
// library properties:
lib.properties = {
	id: '1C1E05274011C24EBDE45892271DAE73',
	width: 970,
	height: 250,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"bd.png", id:"bd"},
		{src:"kvfond.png", id:"kvfond"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1C1E05274011C24EBDE45892271DAE73'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;