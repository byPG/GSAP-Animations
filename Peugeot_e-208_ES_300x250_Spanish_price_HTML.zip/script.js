window.onload = function() {

    TweenMax.set('.centerX', {position:'absolute', xPercent:-50, left:'50%'});
    TweenMax.set('.centerY', {position:'absolute', yPercent:-50, top:'50%'});
    TweenMax.set('.centerXY', {position:'absolute', xPercent:-50, yPercent:-50, left:'50%', top:'50%'});

    var tl = new TimelineMax({repeat:1, repeatDelay: 3})
    
    .set('#ad', {visibility : 'visible'})

    .addLabel('start', '+=.2')
    .from('#title div', .5, {xPercent : -100, ease: Power2.easeOut}, 'start')
    .staggerFrom(['#text1', '#text1 i'], .5, {x : 30, opacity:0, ease: Power2.easeOut}, .1)
    .from('#ml1', .5, {opacity:0, ease: Power2.easeOut})

    .addLabel('s2', '+=2.5')
    .from('#visual2', .01, {opacity : 0, ease: Power2.easeOut}, 's2')
    .staggerFrom(['#text2', '#text2 i'], .5, {x : 30, opacity:0, ease: Power2.easeOut}, .1)

    .addLabel('s3', '+=2.5')
    .from('#visual3', .01, {opacity : 0, ease: Power2.easeOut}, 's3')
    .staggerFrom(['#text3', '#text3 i'], .5, {x : 30, opacity:0, ease: Power2.easeOut}, .1)

    .addLabel('s4', '+=2.5')
    .from('#text5', .01, {opacity : 0, ease: Power2.easeOut}, 's4')
    .to(['#title'], .01, {opacity: 0, ease: Power2.easeOut}, 's4')
    .from('#visual4', .01, {opacity : 0, ease: Power2.easeOut}, 's4')
    .from('#text4', .5, {x : 30, opacity:0, ease: Power2.easeOut})

    .addLabel('legal', '+=2.5')
    .to(['#logo', "#text5"], .01, {opacity: 0, ease: Power2.easeOut}, 'legal')
    .from('#legal', .01, {opacity : 0, ease: Power2.easeOut}, 'legal')

    .addLabel('backup', '+=2.5')
    .to(['#logo', '#title'], .01, {opacity : 1, ease: Power2.easeOut}, 'backup')
    .from(['#visual5'], .01, {opacity : 0, ease: Power2.easeOut}, 'backup')
    .from('#text-packshot', .5, {x : 30, opacity:0, ease: Power2.easeOut})
    .from('#cta', .5, {width : 0, ease: Power2.easeOut})
    

}